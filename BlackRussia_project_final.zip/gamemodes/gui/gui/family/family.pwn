// file: family.pwn
enum s_family_player
{
    ID_FAMILY,
    ID_SQL_FAMILY,
    STREAMER_TAG_3D_TEXT_LABEL:TEXT_FAMILY,
    RANG_FAMILY,

    MUTE_FAMILY,
    //WARN_FAMILY,

    ACCESS_GIVE,
    ACCESS_MONEY,
    ACCESS_ARMOUR,
    ACCESS_MATERIAL,
    ACCESS_HEATH_KIT,
    ACCESS_PATRON,
    ACCESS_MASK,
};

//family log
#define type_log_money  3
#define type_log_material 4
#define type_log_armour  8
#define type_log_heath_kit 6
#define type_log_patron  7
#define type_log_mask  5

#define type_log_kick 2
#define type_log_invite 1

#define type_log_car 9
#define type_log_dostup 11
#define type_log_rang 10

new player_family[MAX_PLAYERS][s_family_player];

// Family invite accept/decline prompt: [0] label, [1] Yes button, [2] No
// button. Mirrors the org /invite textdraw in laird.pwn, but kept separate
// (own array + own show/hide) since /faminvite runs through the native
// Accept/Decline dialog (id 2243) rather than the generic offer system -
// the click handlers below just call the same accept/decline logic that
// dialog uses. Created once per player in OnPlayerConnect below.
new PlayerText:faminvite_offer_PTD[MAX_PLAYERS][3];

#define GetPlayerFamily(%0,%1)  player_family[%0][%1]
#define SetPlayerFamily(%0,%1,%2)  player_family[%0][%1]=%2
#define AddPlayerFamily(%0,%1,%2,%3)  player_family[%0][%1]%2=%3
#define GetPlayerRangFamily(%0)  player_family[%0][RANG_FAMILY]
#define GetPlayerIdFamily(%0)  player_family[%0][ID_FAMILY]

new price_up_sklad[7] = {0, 100000, 200000, 500000, 800000, 1000000, 2000000};
new price_up_weapon[7] = {0, 700000, 1000000, 1200000, 1350000, 1500000, 2000000};
new price_up_compound[7] = {0, 700000, 1000000, 1500000, 2000000, 2500000, 3000000};

new count_money_level[7] = {200000, 500000, 2000000, 4000000, 8000000, 15000000, 30000000};
new count_material_level[7] = {250, 500, 1500, 3000, 6000, 12000, 15000};
new count_heath_kit_level[7] = {100, 250, 400, 500, 600, 700, 1000};
new count_mask_level[7] = {25, 50, 150, 300, 600, 1200, 1500};
new count_armour_level[7] = {100, 100, 100, 100, 100, 100, 100};

new count_weapon_level[7] = {24, 30, 29, 25, 33, 34, 31};
new count_patron_level[7] = {100000, 200000, 300000, 500000, 600000, 800000, 10000000};

new count_compound_level[7] = {100, 200, 350, 400, 500, 700, 1000};

new name_weapon_family[7][24] =
{
    {"Desert Eagle"},
    {"AK-47"},
    {"MP5"},
    {"Shotgun"},
    {"Country Rifle"},
    {"Sniper Rifle"},
    {"M4"}
};

#define FSendClientMessage(%0,%1,%2,%3,%4)	format(%0, sizeof(%0),%3,%4) && SendClientMessage(%1, %2, %0)
#define BackSendClientMessage(%0,%1,%2)	SendClientMessage(%0, %1, %2) && callcmd::family(%0)

enum s_family
{
    family_database,
    family_color,
    family_reputation,
    family_name[32],
    family_owner,
    family_slot_veh,
    family_count_veh,
    family_count_people,
    family_status_storage,
    family_money,
    family_armour,
    family_material,
    family_heath_kit,
    family_patron,
    family_mask,
    family_lvl_storage,
    family_lvl_weapon,
    family_lvl_compound,
    family_house
};

new family_type_color[18][12] =
{
    {"{af9a5b}"},   // ����������
    {"{b1b7f1}"},   // ����������
    {"{5ba8a4}"},   // ���������
    {"{b9378f}"},   // �������
    {"{1028f4}"},   // �����
    {"{5054ec}"},   // ����������
    {"{01ff23}"},   // �������
    {"{f29527}"},   // ���������
    {"{6c4559}"},   // ��������
    {"{f2dafe}"},   // ������-�������
    {"{7eadff}"},   // �������
    {"{c95eec}"},   // ���������
    {"{852048}"},   // ��������
    {"{76b3f2}"},   // ��������
    {"{dcb72b}"},   // ������
    {"{31d166}"},   // ����������
    {"{3969cd}"},   // �����������
    {"{c9e8f2}"}    // ������-�������
};

#define MAX_FAM  5000
new family[MAX_FAM][s_family];
new family_rang_name[MAX_FAM][5][24];
new family_rang_dostup[MAX_FAM][5][6];

#define GetFamily(%0,%1)  family[%0][%1]
#define SetFamily(%0,%1,%2)  family[%0][%1]=%2
#define AddFamily(%0,%1,%2,%3)  family[%0][%1]%2=%3

#define c_f "{D9FF00}[Family]{FFFFFF} "
#define c_f_g "{1EFF00}[Family]{FFFFFF} "
#define c_f_r "{FF0000}[Family]{FFFFFF} "

#define STATUS_UNLOADED 0
#define STATUS_LOADED 1

enum s_family_vehicle
{
    OW_F_database,
    OW_F_server,
    CAR_F_database,
    V_F_NUMBER[32],
    V_F_REGION[8],
    V_F_NUMBER_TYPE,
    V_F_MODEL,
    V_F_COLOR_1,
    V_F_COLOR_2,
    V_F_RANG,
    Float:V_F_SPAWN_X,
    Float:V_F_SPAWN_Y,
    Float:V_F_SPAWN_Z,
    Float:V_F_SPAWN_A,
    Float:V_F_SPAWN_LAST_X,
    Float:V_F_SPAWN_LAST_Y,
    Float:V_F_SPAWN_LAST_Z,
    Float:V_F_SPAWN_LAST_A,
    V_F_WORLD,
    V_F_INT,

    //addition (������� ���������� � ������� � ������� ����)
    V_F_COUNT_BOX,
    STREAMER_TAG_3D_TEXT_LABEL:V_F_TEXT_CONT,
    V_F_AREA_CONT,
    bool:V_F_STATUS_CONT
};

new vehicle_family[MAX_OWNABLE_CARS][s_family_vehicle];

#define GetCarFamily(%0,%1)  vehicle_family[%0][%1]
#define SetCarFamily(%0,%1,%2)  vehicle_family[%0][%1]=%2
#define AddCarFamily(%0,%1,%2,%3)  vehicle_family[%0][%1]%2=%3



new f_string144[144];
new f_string64[64];
new f_string184[184];
new f_string32[32];

public OnGameModeInit()
{
    for(new i;i < MAX_PLAYERS;i++) SetPlayerFamily(i, ID_FAMILY, -1);
    for(new i;i < MAX_FAM;i++) SetFamily(i, family_database, -1);
    for(new i;i < MAX_OWNABLE_CARS;i++) SetCarFamily(i, CAR_F_database, -1);

    SetTimer("CREATE_ACCOUNTS_TABLE", 4000, false);
    SetTimer("welsi_LoadFamily", 1400, false);
    SetTimer("CheckMutePlayer", 1000, true);
    #if defined fam_OnGameModeInit
        return fam_OnGameModeInit();
    #else
        return 1;
    #endif
}
   #if defined _ALS_OnGameModeInit
    #undef OnGameModeInit
#else
    #define _ALS_OnGameModeInit
#endif
#define OnGameModeInit fam_OnGameModeInit
#if defined fam_OnGameModeInit
    forward fam_OnGameModeInit();
#endif

public OnPlayerConnect(playerid)
{
    SetTimerEx("LoadPlayerFamily", 3000, false, "i", playerid);
    CreateFamInviteOfferPTD(playerid);
    #if defined fam_OnPlayerConnect
        return fam_OnPlayerConnect(playerid);
    #else
        return 1;
    #endif
}
#if defined _ALS_OnPlayerConnect
    #undef OnPlayerConnect
#else
    #define _ALS_OnPlayerConnect
#endif
#define OnPlayerConnect fam_OnPlayerConnect
#if defined fam_OnPlayerConnect
    forward fam_OnPlayerConnect(playerid);
#endif

public OnPlayerDisconnect(playerid, reason)
{
    SetTimerEx("UnLoadPlayerFamily", 1000, false, "i", playerid);
    #if defined fam_OnPlayerDisconnect
        return fam_OnPlayerDisconnect(playerid, reason);
    #else
        return 1;
    #endif
}
#if defined _ALS_OnPlayerDisconnect
    #undef OnPlayerDisconnect
#else
    #define _ALS_OnPlayerDisconnect
#endif
#define OnPlayerDisconnect fam_OnPlayerDisconnect
#if defined fam_OnPlayerDisconnect
    forward fam_OnPlayerDisconnect(playerid, reason);
#endif

public: welsi_LoadFamily()
{
    new Cache:cache=mysql_query(mysql, "SELECT * FROM family");

    if(mysql_errno())
        return printf("[FAMILY SQL #1] LoadFamily %d", mysql_errno());

    if(!cache_num_rows())
        return print("None Cache | Query load Family");

    new rows = cache_num_rows();

    if(rows > 300)
    {
        rows = 300;
        printf("count family (%d) > 300", rows);
    } 

    for(new i; i < rows; i ++)
    {
        SetFamily(i, family_database, cache_get_field_content_int(i, "id"));
        SetFamily(i, family_owner, cache_get_field_content_int(i, "owner"));
        SetFamily(i, family_color, cache_get_field_content_int(i, "color"));
        SetFamily(i, family_count_veh, cache_get_field_content_int(i, "slot_veh"));
        SetFamily(i, family_reputation, cache_get_field_content_int(i, "reputation"));
        SetFamily(i, family_slot_veh, cache_get_field_content_int(i, "slot_veh"));
        cache_get_field_content(i, "name", GetFamily(i, family_name), mysql, 32);

        SetFamily(i, family_patron, cache_get_field_content_int(i, "patron"));
        SetFamily(i, family_patron, cache_get_field_content_int(i, "material"));
        SetFamily(i, family_heath_kit, cache_get_field_content_int(i, "heath_kit"));
        SetFamily(i, family_armour, cache_get_field_content_int(i, "armour"));
        SetFamily(i, family_money, cache_get_field_content_int(i, "money"));

        SetFamily(i, family_lvl_storage, cache_get_field_content_int(i, "level_storage"));
        SetFamily(i, family_lvl_weapon, cache_get_field_content_int(i, "level_weapon"));
        SetFamily(i, family_lvl_compound, cache_get_field_content_int(i, "level_compound"));
        SetFamily(i, family_house, cache_get_field_content_int(i, "house"));

        new rang[5][24], name[12], setting_1,
        setting_2, setting_3, setting_4, setting_5, setting_6;

        cache_get_field_content(i, "rang_1", rang[0], mysql, 24);
        cache_get_field_content(i, "rang_2", rang[1], mysql, 24);
        cache_get_field_content(i, "rang_3", rang[2], mysql, 24);
        cache_get_field_content(i, "rang_4", rang[3], mysql, 24);
        cache_get_field_content(i, "rang_5", rang[4], mysql, 24);

        for(new l;l < 5;l++)
        {
            sscanf(rang[l], "P<,>s[12]ddddd", name, setting_1, setting_2, setting_3, setting_4, setting_5);
            format(family_rang_name[i][l], 24, name);
            family_rang_dostup[i][l][0] = setting_1;
            family_rang_dostup[i][l][1] = setting_2;
            family_rang_dostup[i][l][2] = setting_3;
            family_rang_dostup[i][l][3] = setting_4;
            family_rang_dostup[i][l][4] = setting_5;
            family_rang_dostup[i][l][5] = setting_6;
        }
    }

    for(new i; i < MAX_FAM;i++)
    {
        if(GetFamily(i, family_database) == -1) continue;

        mysql_format(mysql, f_string184, sizeof f_string184, "SELECT"\
        "(SELECT COUNT(*) FROM accounts WHERE family_id = %d) AS accounts_count,"\
        "(SELECT COUNT(*) FROM family_cars WHERE family_owner = %d) AS cars_count", GetFamily(i, family_database), GetFamily(i, family_database)); //������� Grok
        new Cache:ccache = mysql_query(mysql, f_string184);

        if(cache_num_rows())
        {
            new count_auto = cache_get_row_int(0,0),
            count_people = cache_get_row_int(0, 1);

            SetFamily(i, family_count_veh, count_auto);
            SetFamily(i, family_count_people, count_people);
            //printf("%d | people = %d car = %d", mysql_errno(), count_people, count_auto);
        }

        cache_delete(ccache);
    }

    cache_delete(cache);
    return 1;
}

public: UnLoadPlayerFamily(playerid)
{
    if(GetPlayerFamily(playerid, ID_FAMILY) == -1) return 1;

    UpdatePlayerDatabaseInt(playerid, "family_id", GetPlayerFamily(playerid, ID_SQL_FAMILY));
    UpdatePlayerDatabaseInt(playerid, "family_rang", GetPlayerFamily(playerid, RANG_FAMILY));
    UpdatePlayerDatabaseInt(playerid, "family_mute", GetPlayerFamily(playerid, MUTE_FAMILY));
    UpdateAccessPlayerFamily(playerid);

    SetPlayerFamily(playerid, ID_FAMILY, -1);
    SetPlayerFamily(playerid, ID_SQL_FAMILY, -1);
    
    DestroyDynamic3DTextLabel(GetPlayerFamily(playerid, TEXT_FAMILY));
    SetPlayerFamily(playerid, TEXT_FAMILY, STREAMER_TAG_3D_TEXT_LABEL:-1);

    SetPlayerFamily(playerid, RANG_FAMILY, 0);
    SetPlayerFamily(playerid, MUTE_FAMILY, 0);
    //SetPlayerFamily(playerid, WARN_FAMILY, 0);

    SetPlayerFamily(playerid, ACCESS_GIVE, 0);
    SetPlayerFamily(playerid, ACCESS_MONEY, 0);
    SetPlayerFamily(playerid, ACCESS_ARMOUR, 0);
    SetPlayerFamily(playerid, ACCESS_MATERIAL, 0);
    SetPlayerFamily(playerid, ACCESS_HEATH_KIT, 0);
    SetPlayerFamily(playerid, ACCESS_PATRON, 0);
    SetPlayerFamily(playerid, ACCESS_MASK, 0);

    return 1;
}

/*
ALTER TABLE `accounts` ADD `family_id` INT NOT NULL DEFAULT '-1' AFTER `admin`, ADD `family_rang` INT NOT NULL DEFAULT '1' AFTER `family_id`, ADD `family_mute` INT NOT NULL AFTER `family_rang`, ADD `family_access` VARCHAR(24) NOT NULL DEFAULT '0,0,0,0,0,0,0' AFTER `family_mute`;
*/

public:LoadPlayerFamily(playerid)
{
    mysql_format(mysql, f_string64, sizeof(f_string64), "SELECT * FROM accounts WHERE id=%d LIMIT 1", GetPlayerAccountID(playerid));
    new Cache:cache=mysql_query(mysql, f_string64);

    if(mysql_errno())
        return print("[FAMILY SQL #2] LoadPlayerFamily");

    if(!cache_num_rows()) return printf("%d - none accounts", cache_num_rows());

    new access_c[7], access[24];

    new id = cache_get_field_content_int(0, "family_id");
    if(id == -1) return 1;

    for(new i; i <MAX_FAM;i++)
    {
        if(GetFamily(i, family_database) != id) continue;

        SetPlayerFamily(playerid, ID_FAMILY, i);
        break;
    }

    if(GetPlayerFamily(playerid, ID_FAMILY) == -1) return printf("None fAmily - %d", id);

    SetPlayerFamily(playerid, ID_SQL_FAMILY, id);

    SetPlayerFamily(playerid, RANG_FAMILY, cache_get_field_content_int(0, "family_rang"));
    SetPlayerFamily(playerid, MUTE_FAMILY, cache_get_field_content_int(0, "family_mute"));

    //SetPlayerFamily(playerid, WARN_FAMILY, cache_get_field_content_int(0, "family_warn"));

    cache_get_field_content(0, "family_access", access, mysql, 24);
    sscanf(access, "P<,>ddddddd", access_c[0], access_c[1], access_c[2], access_c[3], access_c[4], 
    access_c[5], access_c[6]);

    SetPlayerFamily(playerid, ACCESS_GIVE,      access_c[0]);
    SetPlayerFamily(playerid, ACCESS_MONEY,     access_c[1]);
    SetPlayerFamily(playerid, ACCESS_ARMOUR,    access_c[2]);
    SetPlayerFamily(playerid, ACCESS_MATERIAL,  access_c[3]);
    SetPlayerFamily(playerid, ACCESS_HEATH_KIT, access_c[4]);
    SetPlayerFamily(playerid, ACCESS_PATRON,    access_c[5]);
    SetPlayerFamily(playerid, ACCESS_MASK,      access_c[6]);

	new familyName[64];
	format(familyName, sizeof familyName, "%s", GetFamily(GetPlayerIdFamily(playerid), family_name));
	utf8_to_cp1251(familyName); // ����������� � cp1251

    format(f_string144, sizeof f_string144, "%sFamily: %s", family_type_color[GetFamily(GetPlayerIdFamily(playerid), family_color)], GetFamily(GetPlayerIdFamily(playerid), family_name));
    printf("%s    color %s  name %s ", f_string144, family_type_color[GetFamily(GetPlayerIdFamily(playerid), family_color)], GetFamily(GetPlayerIdFamily(playerid), family_name));
    
    if(IsValidDynamic3DTextLabel(GetPlayerFamily(playerid, TEXT_FAMILY))) DestroyDynamic3DTextLabel(GetPlayerFamily(playerid, TEXT_FAMILY));
    SetPlayerFamily(playerid, TEXT_FAMILY, CreateDynamic3DTextLabel(f_string144, -1, 0.0, 0.0, 0.8, 7.8, playerid));

    cache_delete(cache);
    return 1;   
}

public:CheckMutePlayer()
{
    foreach(new i : Player)
    {
        if(GetPlayerIdFamily(i) == -1) continue;
        else if(!GetPlayerFamily(i, MUTE_FAMILY)) continue;

        player_family[i][MUTE_FAMILY]--;

        if(!player_family[i][MUTE_FAMILY]) SendClientMessage(i, -1, ""c_f_r" Your family chat mute has expired. Do not break the rules again!");
    }    

    return 1;
}

public OnDialogResponse(playerid, dialogid, response, listitem, inputtext[])
{
    new f = GetPlayerIdFamily(playerid);

    if(dialogid == 2223)
    {
        if(response)
        {
            switch(listitem)
            {
                case 0:
                {
                    if(GetPlayerFamily(playerid, RANG_FAMILY) >= 4)
                    {
                        new status = GetFamily(f, family_status_storage);

                        SetFamily(f, family_status_storage, status^1);

                        format(f_string144, sizeof f_string144, "%s %s the storage.", GetPlayerNameEx(playerid), status ? "closed" : "opened");
                        SendFamilyMessage(f, f_string144);
                        callcmd::famsklad(playerid);
                    }
                    else SendClientMessage(playerid,-1,""c_f_r"Closing/opening the storage is only available to the deputy or leader of the family");
                }
                case 1:
                {
                    if(!GetFamily(f, family_status_storage) && GetPlayerFamily(playerid, RANG_FAMILY) < 5)
                        return SendClientMessage(playerid, -1,""c_f_r"The storage is closed.");

                    ShowDialogFamilySklad(playerid, 1, false);
                }
                case 2:ShowDialogFamilySklad(playerid, 1, true);
                case 3:
                {
                    DeletePVar(playerid, "select_get_dostup");

                    if(GetPlayerFamily(playerid, ACCESS_GIVE) || GetPlayerRangFamily(playerid) == 5)
                    {
                        ShowPlayerDialog
                        (
                            playerid, 2230, DIALOG_STYLE_LIST,
                            "{FF000}Access",
                            "1. Give access\n"\
                            "2. Revoke access\n"\
                            "3. View access",
                            "Next", "Back"
                        );
                    }
                }
            }
        }
    }
    if(dialogid == 2225)
    {
        if(response)
        {
            if(GetPVarInt(playerid, "type_sklad"))
            {
                new type_take_or_put;

                switch(GetPVarInt(playerid, "type_sklad"))
                {
                    case 1:type_take_or_put = false;
                    case 2:type_take_or_put = true;
                }

                SetPVarInt(playerid, "type_action_sklad", type_take_or_put+1);
                ShowDialogFamilySklad(playerid, listitem+2, type_take_or_put);
            }
        }
    }
    if(dialogid == 2226)
{
    if(response)
    {
        new take_or_put = GetPVarInt(playerid, "type_action_sklad")-1, type = GetPVarInt(playerid, "select_type_sklad_use");

        switch(type)
        {
            case 2:
            {
                new money = strval(inputtext);

                if(!money)
                    return SendClientMessage(playerid, -1, ""c_f_r"The number must be greater than 0");

                if(!take_or_put)
                {
                    if(money <= GetFamily(f, family_money))
                    {
                        if(!GetPlayerFamily(playerid, ACCESS_MONEY))
                            return SendClientMessage(playerid, -1, "You do not have access.");

                        new money_access = GetPlayerFamily(playerid, ACCESS_MONEY)-money; 

                        if(money_access <= -1 && GetPlayerRangFamily(playerid) != 5)
                            return FSendClientMessage(f_string144, playerid, -1, ""c_f_r"You do not have enough access. Available:%d pcs.", GetPlayerFamily(playerid, ACCESS_MONEY));

                        AddPlayerFamily(playerid, ACCESS_MONEY, -, money);
                        AddFamily(f, family_money, -, money);
                        GivePlayerMoneyEx(playerid, money);

                        SendClientMessage(playerid, -1, ""c_f_g"You took money from the family storage.");
                        format(f_string144, sizeof f_string144, "%s took %d rubles from the storage.", GetPlayerNameEx(playerid), money);
                        SendFamilyMessage(f, f_string144);
                        UpdateColumnFamilyInt(GetFamily(f, family_database), "money", GetFamily(f, family_money));
                        SendFamilyLog(type_log_money, playerid, -1, f_string144);
                    }
                    else SendClientMessage(playerid, -1, ""c_f_r"The family does not have this item.");
                }
                else
                {
                    if(!(GetFamily(f, family_money)+money <= count_money_level[GetFamily(f, family_lvl_storage)-1]))
                        return SendClientMessage(playerid, -1, ""c_f_r"The amount will exceed the maximum available quantity.");

                    if(money <= GetPlayerMoneyEx(playerid))
                    {
                        AddFamily(f, family_money, +, money);
                        GivePlayerMoneyEx(playerid, -money);
                        SendClientMessage(playerid, -1, ""c_f_g"You put money into the family storage.");
                        format(f_string144, sizeof f_string144, "%s put %d rubles into the storage.", GetPlayerNameEx(playerid), money);
                        SendFamilyMessage(f, f_string144);
                        UpdateColumnFamilyInt(GetFamily(f, family_database), "money", GetFamily(f, family_money));
                        SendFamilyLog(type_log_money, playerid, -1, f_string144);
                    }
                    else SendClientMessage(playerid, -1, ""c_f_r"You do not have this item.");
                }
            }
            case 3:
            {
                new material = strval(inputtext);

                if(!material)
                    return SendClientMessage(playerid, -1, ""c_f_r"The number must be greater than 0");

                if(!take_or_put)
                {
                    if(material <= GetFamily(f, family_material))
                    { 
                        if(!GetPlayerFamily(playerid, ACCESS_MATERIAL))
                            return SendClientMessage(playerid, -1, "You do not have access.");

                        new material_access = GetPlayerFamily(playerid, ACCESS_MATERIAL)-material; 

                        if(material_access <= -1 && GetPlayerRangFamily(playerid) != 5)
                            return FSendClientMessage(f_string144, playerid, -1, ""c_f_r"You do not have enough access. Available:%d pcs.", GetPlayerFamily(playerid, ACCESS_MATERIAL));

                        AddPlayerFamily(playerid, ACCESS_MATERIAL, -, 1);

                        AddFamily(f, family_material, -, material);
                        AddPlayerData(playerid, P_METALL, +, material);

                        SendClientMessage(playerid, -1, ""c_f_g"You took materials from the family storage.");
                        format(f_string144, sizeof f_string144, "%s took %d pcs of materials from the storage.", GetPlayerNameEx(playerid), material);
                        SendFamilyMessage(f, f_string144);
                        UpdateColumnFamilyInt(GetFamily(f, family_database), "material", GetFamily(f, family_material));
                        SendFamilyLog(type_log_material, playerid, -1, f_string144);
                    }
                    else SendClientMessage(playerid, -1, ""c_f_r"The family does not have this item.");
                }
                else
                {
                    if(!(GetFamily(f, family_material)+material <= count_material_level[GetFamily(f, family_lvl_storage)-1]))
                        return SendClientMessage(playerid, -1, ""c_f_r"The amount will exceed the maximum available quantity.");
                            
                    if(material <= GetPlayerData(playerid, P_METALL))
                    {
                        AddFamily(f, family_material, +, material);
                        AddPlayerData(playerid, P_METALL, -, material);

                        SendClientMessage(playerid, -1, ""c_f_g"You put materials into the family storage.");
                        format(f_string144, sizeof f_string144, "%s put %d pcs of materials into the storage.", GetPlayerNameEx(playerid), material);
                        SendFamilyMessage(f, f_string144);
                        UpdateColumnFamilyInt(GetFamily(f, family_database), "material", GetFamily(f, family_material));
                        SendFamilyLog(type_log_material, playerid, -1, f_string144);
                    }
                    else SendClientMessage(playerid, -1, ""c_f_r"You do not have this item.");
                }
            }
            case 4:
            {
                if(!take_or_put)
                {
                    if(GetFamily(f, family_material))
                    {
                        if(!GetPlayerFamily(playerid, ACCESS_MASK) && GetPlayerRangFamily(playerid) != 5)
                            return SendClientMessage(playerid, -1, "You do not have access.");
                            
                        AddPlayerFamily(playerid, ACCESS_MASK, -, 1);

                        AddFamily(f, family_material, -, 1);
                        AddPlayerData(playerid, P_MASK, +, 1);

                        SendClientMessage(playerid, -1, ""c_f_g"You took a mask from the family storage.");
                        format(f_string144, sizeof f_string144, "%s took a mask from the storage.", GetPlayerNameEx(playerid));
                        SendFamilyMessage(f, f_string144);
                        UpdateColumnFamilyInt(GetFamily(f, family_database), "mask", GetFamily(f, family_mask));
                        SendFamilyLog(type_log_mask, playerid, -1, f_string144);
                    }
                    else SendClientMessage(playerid, -1, ""c_f_r"The family does not have this item.");
                }
                else
                {
                    if(!(GetFamily(f, family_mask)+1 <= count_material_level[GetFamily(f, family_lvl_storage)-1]))
                        return SendClientMessage(playerid, -1, ""c_f_r"The amount will exceed the maximum available quantity.");

                    if(GetPlayerData(playerid, P_MASK))
                    {
                        AddFamily(f, family_mask, +, 1);
                        AddPlayerData(playerid, P_MASK, -, 1);

                        SendClientMessage(playerid, -1, ""c_f_g"You put a mask into the family storage.");
                        format(f_string144, sizeof f_string144, "%s put a mask into the storage.", GetPlayerNameEx(playerid));
                        SendFamilyMessage(f, f_string144);
                        UpdateColumnFamilyInt(GetFamily(f, family_database), "mask", GetFamily(f, family_mask));
                        SendFamilyLog(type_log_mask, playerid, -1, f_string144);
                    }
                    else SendClientMessage(playerid, -1, ""c_f_r"You do not have this item.");
                }
            }
            case 5:
            {
                if(!take_or_put)
                {
                    switch(listitem)
                    {
                        case 0:
                        {
                            ShowPlayerDialog
                            (
                                playerid, -1, DIALOG_STYLE_MSGBOX, 
                                "{FF0000}Information",
                                "At the first level of weapon upgrade, {FFFF00}Desert Eagle{FFFFFF} is available\n"\
                                "{FFFFFF}At the second level {FFFF00}AK-47\n"\
                                "{FFFFFF}At the third level {FFFF00}MP5\n"\
                                "{FFFFFF}At the fourth level {FFFF00}Shotgun\n"\
                                "{FFFFFF}At the fifth level {FFFF00}Country Rifle\n"\
                                "{FFFFFF}At the sixth level {FFFF00}Sniper Rifle\n"\
                                "{FFFFFF}At the seventh level {FFFF00}M4",
                                "Exit", ""
                            );
                        }
                        case 1:
                        {
                            if(!GetPlayerFamily(playerid, ACCESS_PATRON) && GetPlayerRangFamily(playerid) < 5)
                                return SendClientMessage(playerid, -1, "You do not have access.");

                            new dialog[234], weapon[26];

                            for(new i; i < GetFamily(f, family_lvl_weapon); i++)
                            {
                                format(weapon, sizeof weapon, "%d. %s\n", i+1, name_weapon_family[i]);
                                strcat(dialog, weapon);
                            }

                           ShowPlayerDialog(playerid, 2227, DIALOG_STYLE_LIST, "{FF0000}Select weapon", dialog, "Next", "Exit");

                            if(GetPVarInt(playerid, "select_weapon")) DeletePVar(playerid, "select_weapon");
                            if(GetPVarInt(playerid, "select_weapon_count")) DeletePVar(playerid, "select_weapon_count");
                            SetPVarInt(playerid, "select_weapon", 1);
                        }
                    }
                }
                else
                {
                    switch(listitem)
                    {
                        case 0:
                        {
                            ShowPlayerDialog
                            (
                                playerid, -1, DIALOG_STYLE_MSGBOX, 
                                "{FF0000}Information",
                                "At the first level of weapon upgrade, {FFFF00}Desert Eagle{FFFFFF} is available\n"\
                                "{FFFFFF}At the second level {FFFF00}AK-47\n"\
                                "{FFFFFF}At the third level {FFFF00}MP5\n"\
                                "{FFFFFF}At the fourth level {FFFF00}Shotgun\n"\
                                "{FFFFFF}At the fifth level {FFFF00}Country Rifle\n"\
                                "{FFFFFF}At the sixth level {FFFF00}Sniper Rifle\n"\
                                "{FFFFFF}At the seventh level {FFFF00}M4",
                                "Exit", ""
                            );
                        }
                        case 1:
                        {
                            ShowPlayerDialog
                            (
                                playerid, 2227, DIALOG_STYLE_INPUT, 
                                "{FF0000}Enter quantity",
                                "Enter the number of ammunition you want to put into storage",
                                "Next", "Back"
                            );
                        }
                    }
                }
            }
            case 6:
            {
                if(!take_or_put)
                {
                    if(GetFamily(f, family_armour))
                    {
                        if(!GetPlayerFamily(playerid, ACCESS_ARMOUR) && GetPlayerRangFamily(playerid) != 5)
                            return SendClientMessage(playerid, -1, "You do not have access.");
                            
                        AddPlayerFamily(playerid, ACCESS_ARMOUR, -, 1);

                        AddFamily(f, family_armour, -, 1);
                        SetPlayerArmour(playerid, 100.0);

                        SendClientMessage(playerid, -1, ""c_f_g"You took a bulletproof vest from the family storage.");
                        format(f_string144, sizeof f_string144, "%s took a bulletproof vest from the storage.", GetPlayerNameEx(playerid));
                        SendFamilyMessage(f, f_string144);
                        UpdateColumnFamilyInt(GetFamily(f, family_database), "armour", GetFamily(f, family_armour));
                        SendFamilyLog(type_log_armour, playerid, -1, f_string144);
                    }
                    else SendClientMessage(playerid, -1, ""c_f_r"The family does not have this item.");
                }
                else
                {
                    if(!(GetFamily(f, family_armour)+1 <= count_armour_level[GetFamily(f, family_lvl_storage)-1]))
                        return SendClientMessage(playerid, -1, ""c_f_r"The amount will exceed the maximum available quantity.");

                    AddFamily(f, family_armour, +, 1);
                    SetPlayerArmour(playerid, 0.0);

                    SendClientMessage(playerid, -1, ""c_f_g"You put a bulletproof vest into the family storage.");
                    format(f_string144, sizeof f_string144, "%s put a bulletproof vest into the storage.", GetPlayerNameEx(playerid));
                    SendFamilyMessage(f, f_string144);
                    UpdateColumnFamilyInt(GetFamily(f, family_database), "armour", GetFamily(f, family_armour));
                    SendFamilyLog(type_log_armour, playerid, -1, f_string144);
                }
            }
            case 7:
            {
                if(!take_or_put)
                {
                    if(GetFamily(f, family_heath_kit))
                    {
                        if(!GetPlayerFamily(playerid, ACCESS_HEATH_KIT) && GetPlayerRangFamily(playerid) != 5)
                            return SendClientMessage(playerid, -1, "You do not have access.");
                            
                        new med_slot = -1;
                        new med_count = 0;
                        new total_meds = 0;
                        
                        for(new i = 0; i < MAX_INVENTORY_SLOTS; i++)
                        {
                            if(g_PlayerInventory[playerid][i][inv_itemId] == 22)
                            {
                                total_meds += g_PlayerInventory[playerid][i][inv_itemCount];
                                
                                if(med_slot == -1)
                                {
                                    med_slot = i;
                                    med_count = g_PlayerInventory[playerid][i][inv_itemCount];
                                }
                            }
                        }
                        
                        if(total_meds >= 5)
                            return SendClientMessage(playerid, -1, ""c_f_r"You cannot have more than 5 medkits in your inventory.");
                       
                        if(med_slot != -1)
                        {
                            new new_count = med_count + 1;
                            g_PlayerInventory[playerid][med_slot][inv_itemCount] = new_count;
                            
                            new query[256];
                            mysql_format(mysql, query, sizeof(query),
                                "UPDATE `player_inventory` SET `item_count` = %d WHERE `player_id` = %d AND `slot` = %d AND `is_active` = 0",
                                new_count, GetPlayerAccountID(playerid), med_slot);
                            mysql_tquery(mysql, query);
                        }
                        else
                        {
                            new freeSlot = Inventory_GetFreeSlot(playerid);
                            if(freeSlot == -1)
                                return SendClientMessage(playerid, -1, ""c_f_r"You have no free inventory slots.");
                            
                            Inventory_AddItem(playerid, 22, freeSlot, 1, "");
                        }
                        
                        AddPlayerFamily(playerid, ACCESS_HEATH_KIT, -, 1);
                        AddFamily(f, family_heath_kit, -, 1);
                        
                        SendClientMessage(playerid, -1, ""c_f_g"You took a medkit from the family storage.");
                        format(f_string144, sizeof f_string144, "%s took a medkit from the storage.", GetPlayerNameEx(playerid));
                        SendFamilyMessage(f, f_string144);
                        UpdateColumnFamilyInt(GetFamily(f, family_database), "heath_kit", GetFamily(f, family_heath_kit));
                        SendFamilyLog(type_log_heath_kit, playerid, -1, f_string144);
                    }
                    else SendClientMessage(playerid, -1, ""c_f_r"The family does not have this item.");
                }
                else
                {
                    new med_slot = -1;
                    new med_count = 0;
                    
                    for(new i = 0; i < MAX_INVENTORY_SLOTS; i++)
                    {
                        if(g_PlayerInventory[playerid][i][inv_itemId] == 22)
                        {
                            med_slot = i;
                            med_count = g_PlayerInventory[playerid][i][inv_itemCount];
                            break;
                        }
                    }
                    
                    if(med_slot == -1 || med_count <= 0)
                        return SendClientMessage(playerid, -1, ""c_f_r"You do not have a medkit.");
                    
                    if(!(GetFamily(f, family_heath_kit) + 1 <= count_heath_kit_level[GetFamily(f, family_lvl_storage)-1]))
                        return SendClientMessage(playerid, -1, ""c_f_r"The amount will exceed the maximum available quantity.");
                  
                    if(med_count > 1)
                    {
                        g_PlayerInventory[playerid][med_slot][inv_itemCount] = med_count - 1;
                        
                        new query[256];
                        mysql_format(mysql, query, sizeof(query),
                            "UPDATE `player_inventory` SET `item_count` = %d WHERE `player_id` = %d AND `slot` = %d AND `is_active` = 0",
                            med_count - 1, GetPlayerAccountID(playerid), med_slot);
                        mysql_tquery(mysql, query);
                    }
                    else
                    {
                        g_PlayerInventory[playerid][med_slot][inv_itemId] = 0;
                        g_PlayerInventory[playerid][med_slot][inv_itemCount] = 0;
                        g_PlayerInventory[playerid][med_slot][inv_itemSlot] = med_slot;
                        g_PlayerInventory[playerid][med_slot][inv_itemPlate][0] = 0;
                        g_PlayerInventory[playerid][med_slot][inv_itemType] = 0;
                        g_PlayerInventory[playerid][med_slot][inv_itemWeight] = 0;
                        g_PlayerInventory[playerid][med_slot][inv_itemName][0] = 0;
                        g_PlayerInventory[playerid][med_slot][inv_itemActive] = false;
                        
                        new query[256];
                        mysql_format(mysql, query, sizeof(query),
                            "DELETE FROM `player_inventory` WHERE `player_id` = %d AND `slot` = %d AND `is_active` = 0",
                            GetPlayerAccountID(playerid), med_slot);
                        mysql_tquery(mysql, query);
                    }
                    
                    AddFamily(f, family_heath_kit, +, 1);
                    
                    SendClientMessage(playerid, -1, ""c_f_g"You put a medkit into the family storage.");
                    format(f_string144, sizeof f_string144, "%s put a medkit into the storage.", GetPlayerNameEx(playerid));
                    SendFamilyMessage(f, f_string144);
                    UpdateColumnFamilyInt(GetFamily(f, family_database), "heath_kit", GetFamily(f, family_heath_kit));
                    SendFamilyLog(type_log_heath_kit, playerid, -1, f_string144);
                }
                SetPVarInt(playerid, "select_type_sklad_use", 7);
            }
        }
    }
}
    if(dialogid == 2227)
    {
        if(response)
        {
            if(GetPVarInt(playerid, "select_weapon"))
            {
                if(!GetPVarInt(playerid, "select_weapon_count"))
                {
                    SetPVarInt(playerid, "weapon_select_id", listitem);

                    format(f_string144, sizeof f_string144, "Enter the required number of ammunition, available %d", GetFamily(f, family_patron));

                    ShowPlayerDialog
                    (
                        playerid, 2227, DIALOG_STYLE_INPUT, 
                        "{FF0000}Enter quantity",
                        f_string144,
                        "Next", "Back"
                    );
                    SetPVarInt(playerid, "select_weapon_count", 1);
                    return 1;
                }

                new id = GetPVarInt(playerid, "weapon_select_id");

                new patron = strval(inputtext);

                if(!patron)
                    return SendClientMessage(playerid, -1, ""c_f_r"The number must be greater than 0");

                if(patron > 1000)
                    return SendClientMessage(playerid, -1, ""c_f_r"The number must be less than 1000");

                if(GetFamily(f, family_patron) >= patron)
                {
                    new patron_access = GetPlayerFamily(playerid, ACCESS_PATRON) - patron;

                    if(patron_access <= -1 && GetPlayerRangFamily(playerid) != 5) return FSendClientMessage(f_string144, playerid, -1, ""c_f_r"You do not have enough access. Available:%d pcs.", GetPlayerFamily(playerid, ACCESS_PATRON));
                    
                    AddPlayerFamily(playerid, ACCESS_PATRON, -, patron);

                    AddFamily(f, family_patron, -, patron);
                    //SetPlayerAmmo(playerid, count_weapon_level[listitem], patron);
                    GivePlayerWeapon(playerid, count_weapon_level[id], patron);

                    SendClientMessage(playerid, -1, ""c_f_g"You took weapons and ammunition from the family storage.");
                    format(f_string144, sizeof f_string144, "%s took %s and %d ammunition from the storage.", GetPlayerNameEx(playerid), name_weapon_family[id], patron);
                    SendFamilyMessage(f, f_string144);
                    SendFamilyLog(type_log_patron, playerid, -1, f_string144);
                    UpdateColumnFamilyInt(GetFamily(f, family_database), "patron", GetFamily(f, family_patron));
                }

                return 1;
            }

            new patron = strval(inputtext);

            if(!patron)
                return SendClientMessage(playerid, -1, ""c_f_r"The number must be greater than 0");

            new weapon = GetPlayerWeapon(playerid);
            
            switch(weapon)
            {
                case 0:return SendClientMessage(playerid, -1, ""c_f_r"Take a weapon in your hands.");
                case 24, 30, 29, 25, 33, 34, 31:
                {
                    if(!(GetFamily(f, family_patron)+patron <= count_patron_level[GetFamily(f, family_lvl_weapon)-1]))
                        return SendClientMessage(playerid, -1, ""c_f_r"The amount will exceed the maximum available quantity.");

                    new weapon_id = -1, ammo;

                    for(new i; i < 12;i++)
                    {
                        GetPlayerWeaponData(playerid, i, weapon_id, ammo);

                        if(weapon_id == weapon) break;
                    }    

                    if(weapon_id == -1) return 1;

                    if(ammo >= patron)
                    {
                        new ammo_new = ammo - patron;

                        AddFamily(f, family_patron, +, patron);
                        //SetPlayerAmmo(playerid, weapon_id, ammo_new);
                        ResetPlayerWeapons(playerid);

                        SendClientMessage(playerid, -1, ""c_f_g"You put ammunition into the family storage.");
                        format(f_string144, sizeof f_string144, "%s put %d ammunition into the storage.", GetPlayerNameEx(playerid), patron);
                        SendFamilyMessage(f, f_string144);
                        UpdateColumnFamilyInt(GetFamily(f, family_database), "patron", GetFamily(f, family_patron));
                    }
                    else SendClientMessage(playerid, -1, ""c_f_g"You do not have that many ammunition.");
                }
                default:return SendClientMessage(playerid, -1, ""c_f_r"Your weapon is not suitable for putting ammunition into storage");
            }
        }
    }
    if(dialogid == 2230)
    {
        if(GetPVarInt(playerid, "select_get_dostup"))
        {
            new Name[24], e, to_player = -1, string[234];

            if(sscanf(inputtext, "s[24]", Name))e++ ;
            else if(sscanf(inputtext, "d", to_player))e++;

            if(e == 2) return SendClientMessage(playerid, -1, ""c_f_r" You entered incorrect data.");

            if(to_player == -1)
            {
                if(!strcmp(Name, GetPlayerNameEx(playerid), true))
                    return 1;

                foreach(new i : Player)
                {
                    if(!strcmp(Name, GetPlayerNameEx(i), true))
                    {
                        if(GetFamily(GetPlayerIdFamily(playerid), family_owner) == GetPlayerAccountID(i)) continue;
                        to_player = i;
                        break;
                    }
                }
            }

            if(!IsPlayerConnected(to_player))
                return SendClientMessage(playerid, -1, ""c_f_r"This player is offline.");

            format(string, sizeof string,
            "Nickname:%s\n"\
            "Access to modify permissions: %s\n"\
            "Access to money: %d\n"\
            "Access to materials: %d\n"\
            "Access to masks: %d\n"\
            "Access to medkits: %d\n"\
            "Access to weapons: %d\n"\
            "Access to bulletproof vests: %d",
            GetPlayerNameEx(to_player), GetPlayerFamily(to_player, ACCESS_GIVE) ? "Yes" : "No",
            GetPlayerFamily(to_player, ACCESS_MONEY),
            GetPlayerFamily(to_player, ACCESS_MATERIAL),
            GetPlayerFamily(to_player, ACCESS_MASK),
            GetPlayerFamily(to_player, ACCESS_HEATH_KIT),
            GetPlayerFamily(to_player, ACCESS_PATRON),
            GetPlayerFamily(to_player, ACCESS_ARMOUR));

           ShowPlayerDialog(playerid, -1, DIALOG_STYLE_LIST, "{FF0000}Access information", string, "Exit","");
            return 1;
        }

        DeletePVar(playerid, "status_dialog_access");
        DeletePVar(playerid, "type_dialog_access");
        if(response)
        {
            switch(listitem)
            {
                case 0:ShowDialogAccess(playerid, 1, true);
                case 1:ShowDialogAccess(playerid, 1, false);
                case 2:
                {
                    ShowPlayerDialog
                    (
                        playerid, 2230, DIALOG_STYLE_INPUT,
                        "View access",
                        "Enter the name or ID of the player to view their access",
                        "Next",
                        "Back"
                    );
                    
                    SetPVarInt(playerid, "select_get_dostup", 1);
                }
            }
        }
    }
    if(dialogid == 2231)
    {
        if(response)
        {
            if(GetPVarInt(playerid, "status_dialog_access"))
            {
                new give = GetPVarInt(playerid, "status_dialog_access")-1;

                if(GetPVarInt(playerid, "type_dialog_access"))
                {
                    new Name[24], e, to_player = -1, count, give_text[10];

                    if(give) 
                    {
                        format(give_text, sizeof give_text, "gave");
                        if(sscanf(inputtext, "P<,>s[24]d", Name, count)) e++;
                        else if(sscanf(inputtext, "P<,>dd", to_player, count))e++;
                    } 
                    else {
                        format(give_text, sizeof give_text, "revoked");
                        if(sscanf(inputtext, "s[24]", Name))e++ ;
                        else if(sscanf(inputtext, "d", to_player))e++;
                    } 

                    if(e == 2) return SendClientMessage(playerid, -1, ""c_f_r" You entered incorrect data.");

                    if(count > 200_000_000) return SendClientMessage(playerid, -1, ""c_f_r"The number must be greater than 200,000,000");

                    if(to_player == -1)
                    {
                        if(!strcmp(Name, GetPlayerNameEx(playerid), true)) return 1;

                        foreach(new i : Player)
                        {
                            if(!strcmp(Name, GetPlayerNameEx(i), true))
                            {
                                if(GetFamily(GetPlayerIdFamily(playerid), family_owner) == GetPlayerAccountID(i)) continue;

                                to_player = i;
                                break;
                            }
                        }
                    }

                    if(!IsPlayerConnected(to_player))
                        return SendClientMessage(playerid, -1, ""c_f_r"This player is offline.");

                    new type = GetPVarInt(playerid, "type_dialog_access")-2;

                    switch(type)
                    {
                        case 0:
                        {
                            SetPlayerFamily(to_player, ACCESS_ARMOUR, count);
                            SetPlayerFamily(to_player, ACCESS_MONEY, count);
                            SetPlayerFamily(to_player, ACCESS_HEATH_KIT, count);
                            SetPlayerFamily(to_player, ACCESS_PATRON, count);
                            SetPlayerFamily(to_player, ACCESS_MASK, count);
                            SetPlayerFamily(to_player, ACCESS_MATERIAL, count);
                            SetPlayerFamily(to_player, ACCESS_GIVE, give);
                            format(f_string144, sizeof f_string144, "%s %s %s all access", GetPlayerNameEx(playerid), give_text,GetPlayerNameEx(to_player));
                        }
                        case 1:
                        {
                            SetPlayerFamily(to_player, ACCESS_GIVE, give);
                            format(f_string144, sizeof f_string144, "%s %s %s access to give access", GetPlayerNameEx(playerid), give_text, GetPlayerNameEx(to_player));
                        }
                        case 2:SetPlayerFamily(to_player, ACCESS_MONEY, count);
                        case 3:SetPlayerFamily(to_player, ACCESS_MATERIAL, count);
                        case 4:SetPlayerFamily(to_player, ACCESS_MASK, count);
                        case 5:SetPlayerFamily(to_player, ACCESS_HEATH_KIT, count);
                        case 6:SetPlayerFamily(to_player, ACCESS_PATRON, count);
                        case 7:SetPlayerFamily(to_player, ACCESS_ARMOUR, count);
                    }

                    new dostup[8][24] = {"", "", "money", "materials", "masks", "medkits", "weapons", "bulletproof vests"};

                    if(2 <= type <= 7) format(f_string144, sizeof f_string144, "%s %s %s access to %s in quantity %d", GetPlayerNameEx(playerid), give_text, GetPlayerNameEx(to_player), dostup[type], count);
                    SendFamilyLog(type_log_dostup, playerid, to_player, f_string144);

                    format(f_string144, sizeof f_string144, "%s[%d] changed access settings for %s[%d]", GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player);
                    SendFamilyMessage(f, f_string144);

                    UpdateAccessPlayerFamily(to_player);
                }   
                else ShowDialogAccess(playerid, listitem+2, give);
            }
        }
    }
    
    if(dialogid == 2236)
    {
        if(response)
        {
            if(GetPVarInt(playerid, "select_type_2236"))
            {
                new id_p, count, prichina[16];
                switch(GetPVarInt(playerid, "select_type_2236"))
                {
                    case 1:callcmd::faminvite(playerid, inputtext);
                    case 2:
                    {
                        if(0 <= listitem <= 1 && GetPVarInt(playerid, "prichina") == 0) return ShowMembersFamily(playerid, listitem);

                        new id = GetPlayerListitemValue(playerid, listitem), name[24];

                        format(f_string32, sizeof f_string32, "p_familyrang%d", listitem);
                    
                        if(GetPVarInt(playerid, f_string32) >= GetPlayerRangFamily(playerid))
                            return SendClientMessage(playerid, -1, ""c_f_r"This player has a higher or equal rank than you.");

                        //printf("rang = %d || rang = %d || id = %d ", GetPVarInt(playerid, f_string32), GetPlayerRangFamily(playerid))

                        format(f_string32, sizeof f_string32, "p_familyname%d", listitem);
                        GetPVarString(playerid, f_string32, name, 24);

                        if(!GetPVarInt(playerid, "prichina")) 
                        { 
                           ShowPlayerDialog(
                                playerid, 2236, DIALOG_STYLE_INPUT,
                                "{FF0000}Kick player",
                                "Write the reason for kicking the player",
                                "Next","Back"
                            );
                            SetPVarInt(playerid, "family_player_id", id);
                            SetPVarString(playerid, "family_playername", name);
                            SetPVarInt(playerid, "prichina", 1);
                            SetPVarInt(playerid, "select_type_2326", 2);  
                            return 1; 

                        }
                        else
                        {
                            if(sscanf(inputtext, "s[16]", prichina) || strlen(inputtext) < 5)
                            {
                                SendClientMessage(playerid, -1, ""c_f_r"The reason must be between 5 and 16 characters");
                                return ShowMembersFamily(playerid, 1);
                            } 
                        }

                        new param[24];

                        id = GetPVarInt(playerid, "family_player_id");
                        GetPVarString(playerid, "family_playername", name, sizeof name);

                        foreach(new i : Player)
                        {
                            if(GetPlayerAccountID(i) != id) continue;
                            format(param, sizeof param, "%d %s", i, prichina);
                            callcmd::unfaminvite(playerid, param);
                            return 1;
                        }

                        mysql_format(mysql, f_string144, sizeof f_string144, "UPDATE accounts SET family_id=-1 WHERE id = %d", id);
                        mysql_query(mysql, f_string144, false);

                        if(!mysql_errno())
                        {
                            format(f_string144, sizeof f_string144, "%s kicked player %s. Reason: %s (offline)", GetPlayerNameEx(playerid), name, prichina);
                            SendFamilyMessage(f, f_string144);
                            SendFamilyLog(type_log_kick, playerid, id, f_string144);
                        }
                    }
                    case 3:
                    {
                        if(sscanf(inputtext, "P<,>dds[12]", id_p, count, prichina))
                         return SendClientMessage(playerid, -1, ""c_f_g"You entered parameters incorrectly.");

                        format(inputtext, 18, "%d %d %s", id_p, count, prichina);
                        callcmd::fammute(playerid, inputtext);
                    }
                    case 4:
                    {
                        if(sscanf(inputtext, "P<,>ds[12]", id_p, prichina))
                         return SendClientMessage(playerid, -1, ""c_f_g"You entered parameters incorrectly.");

                        format(inputtext, 16, "%d %s", id_p, prichina);
                        callcmd::unfammute(playerid, inputtext);
                    }
                    case 5:
                    {
                        new Name[24], e, to_player = -1, rang;

                        if(sscanf(inputtext, "P<,>s[24]d", Name, rang))e++ ;
                        else if(sscanf(inputtext, "P<,>dd", to_player, rang))e++;

                        if(e == 2) return SendClientMessage(playerid, -1, ""c_f_r" You entered incorrect data.");

                        if(to_player == -1)
                        {
                            if(!strcmp(Name, GetPlayerNameEx(playerid), true, sizeof Name)) return 1;

                            foreach(new i : Player)
                            {
                                if(!strcmp(Name, GetPlayerNameEx(i), true))
                                {
                                    if(GetFamily(GetPlayerIdFamily(playerid), family_owner) == GetPlayerAccountID(i)) continue;
                                    to_player = i;
                                    break;
                                }
                            }
                        }

                        if(!IsPlayerConnected(to_player) || to_player == playerid)
                            return SendClientMessage(playerid, -1, ""c_f_r"This player is offline.");

                        if(!family_rang_dostup[f][GetPlayerRangFamily(playerid)-1][2])
                            return SendClientMessage(playerid, -1, ""c_f_r"Your rank cannot change ranks.");

                        if(rang >= GetPlayerRangFamily(playerid))
                            return SendClientMessage(playerid, -1, ""c_f_r"Cannot give the same rank as yours or higher.");

                        if(GetPlayerIdFamily(to_player) != f)
                            return SendClientMessage(playerid, -1, ""c_f_r"The player is not in your family.");

                        SetPlayerFamily(to_player, RANG_FAMILY, rang);
                        UpdatePlayerDatabaseInt(to_player, "family_rang", rang);
                        
                        format(f_string144, sizeof f_string144, "%s gave player %s - %s (%d rank).", GetPlayerNameEx(playerid), GetPlayerNameEx(to_player),
                        family_rang_name[f][rang-1], rang);
                        SendFamilyMessage(f, f_string144);
                        SendFamilyLog(type_log_rang, playerid, to_player, f_string144);
                        return 1;
                    }
                }
                return 1;
            }

            switch(listitem)
            {
                case 0:
                {
                    if(!family_rang_dostup[f][GetPlayerRangFamily(playerid)-1][1] && GetPlayerRangFamily(playerid) != 5)
                        return SendClientMessage(playerid, -1, ""c_f_r"Your rank does not have permission.");

                    ShowPlayerDialog
                    (
                        playerid, 2236, DIALOG_STYLE_INPUT,
                        "{FF0000}Accept player",
                        "Enter the player ID below to accept the player.",
                        "Next", "Back"
                    );
                    SetPVarInt(playerid, "select_type_2236", 1);
                }
                case 1:
                {
                    DeletePVar(playerid, "count_list");

                    if(!family_rang_dostup[f][GetPlayerRangFamily(playerid)-1][1] && GetPlayerRangFamily(playerid) != 5)
                        return SendClientMessage(playerid, -1, ""c_f_r"Your rank does not have permission.");


                    ShowMembersFamily(playerid, 0);
                }
                case 2:
                {
                    ShowPlayerDialog
                    (
                        playerid, 2236, DIALOG_STYLE_INPUT,
                        "{FF0000}Give mute",
                        "Enter the player ID, number of minutes, and reason (up to 12 chars) below\n"\
                        "to give the player a mute.\n"\
                        "- Example: 0, 25, Off.",
                        "Next", "Back"
                    );
                    SetPVarInt(playerid, "select_type_2236", 3);
                }
                case 3:
                {
                    ShowPlayerDialog
                    (
                        playerid, 2236, DIALOG_STYLE_INPUT,
                        "{FF0000}Remove mute",
                        "Enter the player ID and reason (up to 12 chars) below to remove the mute\n"\
                        "- Example: 0, Paid",
                        "Next", "Back"
                    );
                    SetPVarInt(playerid, "select_type_2236", 4);
                }
                case 4:
                {
                    ShowPlayerDialog
                    (
                        playerid, 2236, DIALOG_STYLE_INPUT,
                        "{FF0000}Change rank",
                        "Enter the player ID or name and rank separated by a comma\n"\
                        "- Rank is the rank to give the player.\n"\
                        "- Example: Nick_Name, 2",
                        "Next", "Back"
                    );
                    SetPVarInt(playerid, "select_type_2236", 5);
                }
            }
        }
    }
    if(dialogid == 2237)
    {
        if(!response) return 1;

        new type = GetPVarInt(playerid, "select_type_log");

        if(!type)
        {
            SetPVarInt(playerid, "select_type_log", listitem+1);

            type = GetPVarInt(playerid, "select_type_log");

            mysql_format(mysql, f_string184, sizeof f_string184, "SELECT * FROM family_log WHERE family ='%d' AND type = %d", GetFamily(GetPlayerIdFamily(playerid), family_database), type);
            new Cache:result = mysql_query(mysql, f_string184, true);

            new c = cache_num_rows();
            
            new r = c;

            if(!c) return SendClientMessage(playerid, -1, ""c_f_r"Logs not found.");

            new dialog[sizeof f_string184 * 10], text[124], time_data[24];

            if(c > 10) c = 10;

            for(new i, time; i < c; i++)
            {
                time = cache_get_field_content_int(i, "time");
                cache_get_field_content(i, "text", text);

                format(time_data, sizeof time_data, "%02d.%02d.%d %02d:%02d:%02d", 
                ConvertUnixTime(time, CONVERT_TIME_TO_DAYS), ConvertUnixTime(time, CONVERT_TIME_TO_MONTHS), ConvertUnixTime(time, CONVERT_TIME_TO_YEARS),
                ConvertUnixTime(time, CONVERT_TIME_TO_HOURS), ConvertUnixTime(time, CONVERT_TIME_TO_MINUTES), ConvertUnixTime(time, CONVERT_TIME_TO_SECONDS));

                format(f_string184, sizeof f_string184, "{FFFFFF}%d. %s %s\n", i + 1, text, time_data);
                strcat(dialog, f_string184);
            }

            if(r >= 11)
            {
                new buttom[21];
                format(buttom, sizeof buttom, "Next page");
                strcat(dialog, buttom);
                SetPVarInt(playerid, "count_list", 1);

                SetPVarInt(playerid, "up_count", 10);
                SetPVarInt(playerid, "down_count", 11);
            } 

            ShowPlayerDialog
            (
                playerid, 2237, DIALOG_STYLE_LIST,
                "{FF0000} Logs",
                dialog,
                "Close", ""
            );

            cache_delete(result);
            return 1;
        }

        new up = GetPVarInt(playerid, "up_count"),
        down = GetPVarInt(playerid, "down_count");

        if(listitem == up || listitem == down)
        {
            new list = GetPVarInt(playerid, "count_list");

            if(listitem == up)  list++;
            else if(listitem == down) list--;
            SetPVarInt(playerid, "count_list", list);

            new 
            Cache: result,
            id;

            mysql_format(mysql, f_string184, sizeof f_string184, "SELECT * FROM family_log WHERE family ='%d' AND type = %d", GetFamily(GetPlayerIdFamily(playerid), family_database), type);
            result = mysql_query(mysql, f_string184, true);

            new rows = cache_num_rows();
            
            if(!rows) return SendClientMessage(playerid, -1, ""c_f_r"Logs not found.");

            new count_rows, count = 10 * GetPVarInt(playerid, "count_list");

            if(rows >= count)
            {
                count_rows = count;
                SetPVarInt(playerid, "up_count", 10);
                SetPVarInt(playerid, "down_count", 11);
            }
            else
            {
                count_rows = rows;
                new p = count_rows - (count - 10);
                SetPVarInt(playerid, "down_count", p);
                SetPVarInt(playerid, "up_count", 10);
            }

            new dialog[sizeof f_string184 * 10], text[124], time_data[24];

            for(new i = count-10, time; i < count_rows; i++)
            {
                time = cache_get_field_content_int(i, "time");
                cache_get_field_content(i, "text", text);

                format(time_data, sizeof time_data, "%02d.%02d.%d %02d:%02d:%02d", 
                ConvertUnixTime(time, CONVERT_TIME_TO_DAYS), ConvertUnixTime(time, CONVERT_TIME_TO_MONTHS), ConvertUnixTime(time, CONVERT_TIME_TO_YEARS),
                ConvertUnixTime(time, CONVERT_TIME_TO_HOURS), ConvertUnixTime(time, CONVERT_TIME_TO_MINUTES), ConvertUnixTime(time, CONVERT_TIME_TO_SECONDS));

                format(f_string184, sizeof f_string184, "{FFFFFF}%d. %s %s\n", i + 1, text, time_data);
                strcat(dialog, f_string184);
            }

            if(rows >= count+1)
            {
                new buttom[21];
                format(buttom, sizeof buttom, "Next page\n");
                strcat(dialog, buttom);

            }

            if(count >= 11)
            {
                new buttom_1[21];
                format(buttom_1, sizeof buttom_1, "Previous page");
                strcat(dialog, buttom_1);
            }

            ShowPlayerDialog
            (
                playerid, 2237, DIALOG_STYLE_LIST,
                "{FF0000} Logs",
                dialog,
                "Close", ""
            );

            cache_delete(result);

            return 1;
        }
    }
    
    if(dialogid == 2238)
    {
        if(response)
        {
            new fam_name[32], free_id = -1;

            for(new i; i < MAX_FAM; i ++ )
            {
                if(GetFamily(i, family_database) != -1) continue;
                free_id = i;
                break;
            }

            if(free_id == -1)
                return SendClientMessage(playerid, -1, ""c_f_r"You cannot create a family at this time.");

            if(sscanf(inputtext, "s[32]", fam_name) || strlen(inputtext) < 6)
                return SendClientMessage(playerid, -1, "The family name must be between 6 and 32 characters");

            for(new i; i < strlen(fam_name); i++) if(fam_name[i] == '-' && fam_name[i+7] == '}') fam_name[i] = '{';


            if(GetPlayerIdFamily(playerid) != -1)
                return SendClientMessage(playerid, -1, ""c_f_r"You are already in a family.");

            if(GetPlayerMoneyEx(playerid) >= 3_000_000)
            {
                utf8_to_cp1251(fam_name); // ����������� ����� �����������
                mysql_format(mysql, f_string144, sizeof f_string144, "INSERT INTO family (owner,name) VALUES ('%d','%s')", GetPlayerAccountID(playerid), fam_name);
                mysql_query(mysql, f_string144, false);

                if(!mysql_errno())
                {
                    mysql_format(mysql, f_string144, sizeof f_string144, "SELECT * FROM family WHERE owner=%d", GetPlayerAccountID(playerid));
                    new Cache:cache = mysql_query(mysql, f_string144);

                    if(mysql_errno())
                        return printf("[FAMILY SQL #1] LoadFamily %d", mysql_errno());

                    if(!cache_num_rows())
                        return print("None Cache | Query load Family");

                    SetFamily(free_id, family_database, cache_get_field_content_int(0, "id"));

                    mysql_format(mysql, f_string184, sizeof f_string184, "UPDATE accounts SET family_access = '1,1,1,1,1,1,1',family_id = %d,family_rang = 5 WHERE id= %d", 
                    GetFamily(free_id, family_database), GetPlayerAccountID(playerid));
                    mysql_query(mysql, f_string184, false);

                    if(mysql_errno())
                        return SendClientMessage(playerid,-1,""c_f_r"Error in SQL query / Code: Update Account Owner Family");

                    SetFamily(free_id, family_owner, cache_get_field_content_int(0, "owner"));
                    SetFamily(free_id, family_color, cache_get_field_content_int(0, "color"));
                    SetFamily(free_id, family_count_veh, cache_get_field_content_int(0, "slot_veh"));
                    SetFamily(free_id, family_reputation, cache_get_field_content_int(0, "reputation"));
                    cache_get_field_content(0, "name", GetFamily(free_id, family_name), mysql, 32);

                    SetFamily(free_id, family_patron, cache_get_field_content_int(0, "patron"));
                    SetFamily(free_id, family_heath_kit, cache_get_field_content_int(0, "heath_kit"));
                    SetFamily(free_id, family_armour, cache_get_field_content_int(0, "arnour_count"));
                    SetFamily(free_id, family_money, cache_get_field_content_int(0, "money"));

                    SetFamily(free_id, family_lvl_storage, cache_get_field_content_int(0, "level_storage"));
                    SetFamily(free_id, family_lvl_weapon, cache_get_field_content_int(0, "level_weapon"));
                    SetFamily(free_id, family_lvl_compound, cache_get_field_content_int(0, "level_compound"));
                    SetFamily(free_id, family_slot_veh, cache_get_field_content_int(0, "slot_veh"));

                    new rang[5][24], name[12], setting_1,
                    setting_2, setting_3, setting_4, setting_5, setting_6;

                    cache_get_field_content(0, "rang_1", rang[0], mysql, 24);
                    cache_get_field_content(0, "rang_2", rang[1], mysql, 24);
                    cache_get_field_content(0, "rang_3", rang[2], mysql, 24);
                    cache_get_field_content(0, "rang_4", rang[3], mysql, 24);
                    cache_get_field_content(0, "rang_5", rang[4], mysql, 24);

                    for(new l;l < 5;l++)
                    {
                        sscanf(rang[l], "P<,>s[12]ddddd", name, setting_1, setting_2, setting_3, setting_4, setting_5);
                        format(family_rang_name[free_id][l], 24, name);
                        family_rang_dostup[free_id][l][0] = setting_1;
                        family_rang_dostup[free_id][l][1] = setting_2;
                        family_rang_dostup[free_id][l][2] = setting_3;
                        family_rang_dostup[free_id][l][3] = setting_4;
                        family_rang_dostup[free_id][l][4] = setting_5;
                        family_rang_dostup[free_id][l][5] = setting_6;
                    }
                    cache_delete(cache);

                    mysql_format(mysql, f_string64, sizeof f_string64, "SELECT * FROM accounts WHERE family_id=%d", GetFamily(free_id, family_database));
                    cache = mysql_query(mysql, f_string64);

                    SetFamily(free_id, family_count_people, cache_num_rows());
                    cache_delete(cache);

                    LoadPlayerFamily(playerid);

                    GivePlayerMoneyEx(playerid, -3_000_000);
                    ShowNotificationSile(playerid, 2, 5, 0, 0, "You spent 3,000,000 rubles", " ");
                    FSendClientMessage(f_string144, playerid, -1, ""c_f_g"You successfully created the family %s", fam_name);
                   
                   if(GetPlayerData(playerid, P_QUEST_EXP_7) == 0)
						{
						    SendClientMessage(playerid, COR_SERVER, "[Quests]: "c_b"You have successfully completed the quest "c_i"'Better together than alone'. "c_b"Reward: "c_m"10000 rub");
						    GivePlayerMoneyEx(playerid, 10000, "Quest completion");

						    SetPlayerData(playerid, P_QUEST_7, 1);
						    UpdatePlayerDatabaseInt(playerid, "quest_7", 1);
						    
						    AddPlayerData(playerid, P_TOP_5, +, 1);
							UpdatePlayerDatabaseInt(playerid, "TOP_Quest", GetPlayerData(playerid, P_TOP_5));
						}
                }
                else SendClientMessage(playerid, -1, ""c_f_r"Error in SQL query / Code: Create Family");
            }
            else SendClientMessage(playerid, -1, "You do not have enough money.");
        }
    }
    if(dialogid == 2239)
    {
        if(response)
        {
            new rang = strval(inputtext);

            if(!(1 <= rang <= 5))
                return BackSendClientMessage(playerid, -1,  "Rank must be between 1 and 5");

            new id = GetPVarInt(playerid, "select_fam_car");

            mysql_format(mysql, f_string144, sizeof f_string144, "UPDATE family_cars SET rang=%d WHERE id=%d LIMIT 1", rang, id);
            mysql_query(mysql, f_string144, false);

            mysql_format(mysql, f_string64, sizeof f_string64, "SELECT * FROM family_cars WHERE id=%d", id);
            new Cache:cache = mysql_query(mysql, f_string64);

            new model = cache_get_field_content_int(0, "model_id")-400, sql = cache_get_field_content_int(0, "id");

            cache_delete(cache);

            format(f_string144, sizeof f_string144, "%s[%d] changed access to %s (%d) to rank %d.", GetPlayerNameEx(playerid), playerid, GetVehicleInfo(model, VI_NAME), sql, rang);
            SendFamilyMessage(f,  f_string144);
        }
    }
    if(dialogid == 2240)
    {
        if(response)
        {
            if(GetPlayerDonateRub(playerid) >= 300)
            {
                GivePlayerDonateRub(playerid, -300);
                AddFamily(f, family_slot_veh, +, 1);
                UpdateColumnFamilyInt(GetFamily(f, family_database), "slot_veh", GetFamily(f, family_slot_veh));

                format(f_string144, sizeof f_string144, "%s[%d] bought a vehicle slot for the family. Total: %d", 
                GetPlayerNameEx(playerid), playerid, GetFamily(f, family_slot_veh));
                SendFamilyMessage(f, f_string144);

                SendClientMessage(playerid, -1, ""c_f_g"You bought a vehicle slot for the family");
            }
            else FSendClientMessage(f_string144, playerid, -1, ""c_f_r"You do not have enough %d donate rubles", 300-GetPlayerDonateRub(playerid));
        }
    }
    if(dialogid == 2241)
    {
        if(response)
        {
            if(GetPlayerDonateRub(playerid) >= 100)
            {
                new to_player = strval(inputtext);

                if(!IsPlayerConnected(to_player) || to_player == playerid)
                    return SendClientMessage(playerid, -1, ""c_f_r"This player is offline.");

                if(GetPlayerIdFamily(to_player) != -1)
                    return SendClientMessage(playerid, -1, ""c_f_r"The player is already in a family.");

                if(!IsPlayerInRangeOfPlayer(playerid, to_player, 5.0))
                    return SendClientMessage(playerid, 0xCECECEFF, "The player is too far away");

                format(f_string144, sizeof f_string144, "{FFFF00}%s{FFFFFF} wants to transfer the family %s to you.",
                GetPlayerNameEx(playerid), GetFamily(f, family_name));

                DeletePVar(to_player, "player_offer");
                ShowPlayerDialog
                (
                    to_player, 2242, DIALOG_STYLE_MSGBOX,
                    "{FF0000}Family transfer",
                    f_string144,
                    "Accept", "Decline"
                );

                SetPVarInt(to_player, "player_offer", playerid);
            }
            else FSendClientMessage(f_string144, playerid, -1, ""c_f_r"You do not have enough %d donate rubles", 100-GetPlayerDonateRub(playerid));
        }
    }
    if(dialogid == 2242)
    {
        new player_offer = GetPVarInt(playerid, "player_offer"), ff = GetPlayerIdFamily(player_offer);

        if(!response)
        {
            SendClientMessage(player_offer, -1, ""c_f"The player declined your offer.");
            SendClientMessage(playerid, -1, ""c_f"You declined the offer.");
            return 1;
        }

        if(!IsPlayerConnected(player_offer)) return SendClientMessage(playerid, -1, ""c_f_r"The player left the game.");

        GivePlayerDonateRub(player_offer, -100);
        
        SetPlayerFamily(playerid, RANG_FAMILY, 5);
        SetPlayerFamily(playerid, ID_SQL_FAMILY, GetFamily(ff, family_database));
        SetPlayerFamily(playerid, ID_FAMILY, ff);
        UpdatePlayerDatabaseInt(playerid, "family_rang", GetPlayerFamily(playerid, RANG_FAMILY));
        UpdatePlayerDatabaseInt(playerid, "family_id", GetPlayerFamily(playerid, ID_SQL_FAMILY));

        SetPlayerFamily(player_offer, RANG_FAMILY, 1);
        UpdatePlayerDatabaseInt(player_offer, "family_rang", GetPlayerFamily(player_offer, RANG_FAMILY));

        SetFamily(ff, family_owner, GetPlayerAccountID(playerid));
        UpdateColumnFamilyInt(GetFamily(ff, family_database), "owner", GetFamily(ff, family_owner));

        format(f_string144, sizeof f_string144, "%s[%d] transferred the family to %s[%d]", 
        GetPlayerNameEx(player_offer), player_offer, GetPlayerNameEx(playerid), playerid);
        SendFamilyMessage(ff, f_string144);

        LoadPlayerFamily(playerid);
        LoadPlayerFamily(player_offer);

        FSendClientMessage(f_string144, player_offer, -1, ""c_f_g"You transferred the family leadership to {FFFF00}%s", GetPlayerNameEx(playerid));
        FSendClientMessage(f_string144, playerid, -1, ""c_f_g"You received the family leadership from {FFFF00}%s", GetPlayerNameEx(player_offer));
    }
    if(dialogid == 2243)
    {
        HideFamInviteOfferPTD(playerid);

        if(response)
        {
            AcceptFamilyInvite(playerid);
        }
        else
        {
            DeclineFamilyInvite(playerid);
            return 1;
        }
    }
    if(dialogid == 2244)
    {
        if(response)
        {
            new fam_name[32];

            if(sscanf(inputtext, "s[32]", fam_name) || strlen(inputtext) < 6)
                return SendClientMessage(playerid, -1, "The family name must be between 6 and 32 characters");

            for(new i; i < strlen(fam_name); i++) if(fam_name[i] == '-' && fam_name[i+7] == '}') fam_name[i] = '{';

            format(family[f][family_name], 32, fam_name);
            mysql_format(mysql, f_string144, sizeof f_string144, "UPDATE family SET name='%s' WHERE id = %d", GetFamily(f, family_name), GetFamily(f, family_database));
            mysql_query(mysql, f_string144, false);

            GivePlayerDonateRub(playerid, -100);

            FSendClientMessage(f_string144, playerid, -1, ""c_f_g"You changed the name of your family to %s.", GetFamily(f, family_name));
            
            foreach(new i : Player)
            {
                if(GetPlayerIdFamily(i) != f) continue;
        
                UpdateDynamic3DTextLabelText(GetPlayerFamily(f, TEXT_FAMILY), -1, fam_name);
            }

            format(f_string144, sizeof f_string144, "The leader of the family %s[%d] changed the family name to %s.", GetPlayerNameEx(playerid), playerid, fam_name);
            SendFamilyMessage(f, f_string144);
        }
    }
    if(dialogid == 2245)
    {
        if(response)
        {
            switch(listitem)
            {
                case 0:
                {
                    ShowPlayerDialog
                    (
                        playerid, -1, DIALOG_STYLE_MSGBOX,
                        "{FF0000}Family seasons",
                        "In family seasons, the main thing is reputation.\n"\
                        "You can earn reputation in battles for {FFFF00}various enterprises{FFFFFF} and\n"\
                        "{FFFF00}family containers.\n"\
                        "{FFFFFF}The family season ends on {FFFF00}Thursday at 00:00.\n\n"\
                        "{FFFFFF}Reward for {FFFF00}first place{FFFFFF} in the family top:\n"\
                        "90,000 rubles and 40 donate rubles to each family member\n"\
                        "Two vehicle slots for the family\n\n"\
                        "{FFFFFF}Reward for {FFFF00}second place{FFFFFF} in the family top:\n"\
                        "60,000 rubles and 30 donate rubles to each family member\n"\
                        "One vehicle slot for the family\n\n"\
                        "{FFFFFF}Reward for {FFFF00}third place{FFFFFF} in the family top:\n"\
                        "30,000 rubles and 20 donate rubles to each family member",
                        "Exit", ""
                    );
                }
                case 1:
                {

                    mysql_format(mysql, f_string144, sizeof f_string144, "SELECT * FROM family WHERE reputation >= '0' ORDER BY reputation DESC");
                    new Cache:result = mysql_query(mysql, f_string144);

                    if(mysql_errno()) return print("[COLLECTOR_SYSTEM] Error Sql Query: �1");

                    new rows = cache_num_rows();

                    new list[68], dialog[584];

                    new name[32], name_pl[32], rep_pl, reputation, mesto, id, select_family = true, database_family = GetFamily(GetPlayerIdFamily(playerid), family_database);

                    for(new i, count;i < rows;i++)
                    {
                        id = cache_get_field_content_int(i, "id");
                        cache_get_field_content(i, "name", name, mysql, 32);
                        reputation = cache_get_field_content_int(i, "reputation");

                        if(database_family == id)
                        {
                            format(name_pl, sizeof name_pl, name);
                            rep_pl = reputation;
                            mesto = i+1;
                        } 

                        if(count != 10)
                        {
                            format(list, sizeof list, "{FFFFFF} �%d %s %d\n", i+1, name, reputation);
                            strcat(dialog, list);
                            count++;
                        }
                    }

                    format(list, sizeof list, "{FFFF00}- {FFFFFF}�%d %s %d", mesto, name_pl, rep_pl);
                    strcat(dialog, list);
                    
                   ShowPlayerDialog(playerid, -1, DIALOG_STYLE_LIST, "{FF0000}Top families ranking", dialog, "Close", "");
                }
            }
        }
    }
    #if defined fam_OnDialogResponse
    return fam_OnDialogResponse(playerid, dialogid, response, listitem, inputtext);
   #else
        return 1;
    #endif
}
#if defined _ALS_OnDialogResponse
#undef OnDialogResponse
#else
#define _ALS_OnDialogResponse
#endif
#define OnDialogResponse fam_OnDialogResponse
#if defined fam_OnDialogResponse
forward fam_OnDialogResponse(playerid, dialogid, response, listitem, inputtext[]);
#endif





stock ShowDialogFamilyCar(playerid, id)
{
    SetPVarInt(playerid, "select_fam_car", id);

    new status = GetStatusFamilyCar(id);

    if(!status)
    {
        if(GetPlayerRangFamily(playerid) != 5)
        {
            ShowPlayerDialog
            (
                playerid, 2224, DIALOG_STYLE_LIST, 
                "{FF0000}Family vehicle",
                "1. Mark vehicle on GPS\n"\
                "2. Load vehicle\n"\
                "3. Remove vehicle",
                "Next", "Exit"
            );
        }
        else
        {
            ShowPlayerDialog
            (
                playerid, 2224, DIALOG_STYLE_LIST, 
                "{FF0000}Family vehicle",
                "1. Mark vehicle on GPS\n"\
                "2. Load vehicle\n"\
                "3. Remove vehicle\n"\
                "4. Change vehicle access",
                "Next", "Exit"
            );  
        }
    }
    else
    {
        ShowPlayerDialog
        (
            playerid, 2224, DIALOG_STYLE_LIST, 
            "{FF0000}Family vehicle",
            "1. Mark vehicle on GPS\n"\
            "2. Unload vehicle",
            "Next", "Exit"
        );     
    }
}

stock MoveOwnableCar(playerid, database_car, fam)
{
    new fam_id = GetPlayerIdFamily(playerid);

    mysql_format(mysql, f_string64, sizeof f_string64, "SELECT * FROM ownable_cars WHERE id=%d", database_car);
    new Cache:cache_sql = mysql_query(mysql, f_string64);

    if(mysql_errno())
        return SendClientMessage(playerid,-1,""c_f_r"Error in SQL query / Code: MoveOwnableCar");

    if(!cache_num_rows())
        return SendClientMessage(playerid,-1,""c_f_r"Vehicle not found.");

    new model_id, color_1, color_2, number[32], region[8], number_type, 
    Float:pos_x, Float:pos_y, Float:pos_z, Float:angle;

    model_id = cache_get_field_content_int(0, "model_id");
    color_1 = cache_get_field_content_int(0, "color_1");
    color_2 = cache_get_field_content_int(0, "color_2");
    pos_x = cache_get_field_content_float(0, "pos_x");
    pos_y = cache_get_field_content_float(0, "pos_y");
    pos_z = cache_get_field_content_float(0, "pos_z");
    angle = cache_get_field_content_float(0, "angle");
    cache_get_field_content(0, "number", number, mysql, 32);
    cache_get_field_content(0, "region", region, mysql, 8);
    number_type = cache_get_field_content_int(0, "number_type");

    
    new query[2048];
mysql_format
(
    mysql, query, sizeof query,
    "INSERT INTO family_cars \
    (family_owner, model_id, color_1, color_2, pos_x, pos_y, pos_z, angle, create_time, number, region, number_type) \
    VALUES \
    (%d, %d, %d, %d, %f, %f, %f, %f, %d, '%s', '%s', %d)",
    fam, model_id, color_1, color_2, pos_x, pos_y, pos_z, angle, gettime(), number, region, number_type
);
    mysql_query(mysql, query, false);    

    mysql_format(mysql, f_string64, sizeof f_string64, "DELETE FROM ownable_cars WHERE id=%d", database_car);
    if(!mysql_errno()) mysql_query(mysql, f_string64, false);
    
    if(!mysql_errno())
    {
        UnloadPlayerOwnableCar(playerid);
        SendClientMessage(playerid, -1, ""c_f_g" You have successfully added the vehicle to the family.");
        format(f_string144, sizeof f_string144, "Owner %s added the vehicle %s to the family", GetPlayerNameEx(playerid), GetVehicleInfo(model_id-400, VI_NAME));
        SendFamilyMessage(GetPlayerIdFamily(playerid), f_string144);
        AddFamily(fam_id, family_count_veh, +, 1);
    }
    cache_delete(cache_sql);
    return 1;
}

stock MoveFamilyCar(database_car, playerid)
{
    new fam = GetPlayerIdFamily(playerid);

    mysql_format(mysql, f_string64, sizeof f_string64, "SELECT * FROM family_cars WHERE id=%d", database_car);
    new Cache:cache_sql = mysql_query(mysql, f_string64);

    if(mysql_errno())
        return SendClientMessage(playerid,-1,""c_f_r" Error in SQL query / Code: MoveFamilyCar");

    if(!cache_num_rows())
        return SendClientMessage(playerid,-1,""c_f_r" Vehicle not found.");

    new model_id, color_1, color_2, number[32], region[8], number_type, 
    Float:pos_x, Float:pos_y, Float:pos_z, Float:angle;

    model_id = cache_get_field_content_int(0, "model_id");
    color_1 = cache_get_field_content_int(0, "color_1");
    color_2 = cache_get_field_content_int(0, "color_2");
    pos_x = cache_get_field_content_float(0, "pos_x");
    pos_y = cache_get_field_content_float(0, "pos_y");
    pos_z = cache_get_field_content_float(0, "pos_z");
    angle = cache_get_field_content_float(0, "angle");
    cache_get_field_content(0, "number", number, mysql, 32);
    cache_get_field_content(0, "region", region, mysql, 8);
    number_type = cache_get_field_content_int(0, "number_type"); // ����������: ���� cache_get_field_content_float

    new query[2048];
    mysql_format
    (
        mysql, query, sizeof query,
        "INSERT INTO ownable_cars \
        (owner_id, model_id, color_1, color_2, pos_x, pos_y, pos_z, angle, create_time, number, region, number_type) \
        VALUES \
        (%d, %d, %d, %d, %f, %f, %f, %f, %d, '%s', '%s', %d)",
        GetPlayerAccountID(playerid), model_id, color_1, color_2, pos_x, pos_y, pos_z, angle, gettime(), number, region, number_type
    );
    mysql_query(mysql, query, false);

    mysql_format(mysql, f_string64, sizeof f_string64, "DELETE FROM family_cars WHERE id=%d", database_car);
    mysql_query(mysql, f_string64, false);

    if(!mysql_errno())
    {
        SendClientMessage(playerid, -1, ""c_f_g" You have successfully removed the vehicle from the family.");
        format(f_string144, sizeof f_string144, "Owner %s removed the vehicle %s from the family", GetPlayerNameEx(playerid), GetVehicleInfo(model_id-400, VI_NAME));
        SendFamilyMessage(fam, f_string144);
        AddFamily(fam, family_count_veh, -, 1);
    }
    cache_delete(cache_sql);
    return 1;
}

stock LoadFamilyCar(database)
{
    new rows, vehicleid;
    new Cache: result;

    mysql_format(mysql, f_string64, sizeof f_string64, "SELECT * FROM family_cars WHERE id=%d", database);
    result = mysql_query(mysql, f_string64, true);
    rows = cache_num_rows();

    if(!rows) return 1;

    new free_id = GetFreeIDFamilyCar();
    SetCarFamily(free_id, CAR_F_database,       cache_get_field_content_int(0, "id"));

    SetCarFamily(free_id, OW_F_database,     cache_get_field_content_int(0, "family_owner"));
    SetCarFamily(free_id, OW_F_server,     GetFamilyIDSQL(GetCarFamily(free_id, OW_F_database)));

    SetCarFamily(free_id, V_F_MODEL,     cache_get_field_content_int(0, "model_id"));
    SetCarFamily(free_id, V_F_COLOR_1,      cache_get_field_content_int(0, "color_1"));
    SetCarFamily(free_id, V_F_COLOR_2,      cache_get_field_content_int(0, "color_2"));
    SetCarFamily(free_id, V_F_RANG,         cache_get_field_content_int(0, "rang"));

    SetCarFamily(free_id, V_F_SPAWN_X,        cache_get_field_content_float(0, "pos_x"));
    SetCarFamily(free_id, V_F_SPAWN_Y,        cache_get_field_content_float(0, "pos_y"));
    SetCarFamily(free_id, V_F_SPAWN_Z,        cache_get_field_content_float(0, "pos_z"));
    SetCarFamily(free_id, V_F_SPAWN_A,        cache_get_field_content_float(0, "angle"));
   
    SetCarFamily(free_id, V_F_SPAWN_LAST_X,        cache_get_field_content_float(0, "pos_last_x"));
    SetCarFamily(free_id, V_F_SPAWN_LAST_Y,        cache_get_field_content_float(0, "pos_last_y"));
    SetCarFamily(free_id, V_F_SPAWN_LAST_Z,        cache_get_field_content_float(0, "pos_last_z"));
    SetCarFamily(free_id, V_F_SPAWN_LAST_A,        cache_get_field_content_float(0, "angle_last"));

    SetCarFamily(free_id, V_F_COUNT_BOX,        0);
    SetCarFamily(free_id, V_F_TEXT_CONT,        STREAMER_TAG_3D_TEXT_LABEL:-1);
    SetCarFamily(free_id, V_F_AREA_CONT,        -1);
    SetCarFamily(free_id, V_F_STATUS_CONT,      false);

    cache_get_field_content(0, "number", vehicle_family[free_id][V_F_NUMBER], mysql, 32);
    cache_get_field_content(0, "region", vehicle_family[free_id][V_F_REGION], mysql, 8);
    SetCarFamily(free_id, V_F_NUMBER_TYPE,      cache_get_field_content_int(0, "number_type"));

    vehicleid = CreateVehicle
    (
        GetCarFamily(free_id, V_F_MODEL),
        GetCarFamily(free_id, V_F_SPAWN_X),
        GetCarFamily(free_id, V_F_SPAWN_Y),
        GetCarFamily(free_id, V_F_SPAWN_Z),
        GetCarFamily(free_id, V_F_SPAWN_A),
        GetCarFamily(free_id, V_F_COLOR_1),
        GetCarFamily(free_id, V_F_COLOR_2),
        -1,
        0,
        VEHICLE_ACTION_TYPE_FAMILY_CAR,
        free_id
    );

    printf("%d, %f %f %f %f %d %d", GetCarFamily(free_id, V_F_MODEL), GetCarFamily(free_id, V_F_SPAWN_X), GetCarFamily(free_id, V_F_SPAWN_Y), GetCarFamily(free_id, V_F_SPAWN_Z), GetCarFamily(free_id, V_F_SPAWN_A), GetCarFamily(free_id, V_F_COLOR_1), GetCarFamily(free_id, V_F_COLOR_2));
    
    new f_server = GetFamilyIDSQL(GetCarFamily(free_id, OW_F_database));

    if(vehicleid != INVALID_VEHICLE_ID)
    {
        new familyName[64];
        format(familyName, sizeof familyName, "%s", GetFamily(f_server, family_name));
        utf8_to_cp1251(familyName);

        format(vehicle_family[free_id][V_F_NUMBER], 12, vehicle_family[free_id][V_F_NUMBER]);
        SetVehicleNumberPlateEx(vehicleid, vehicle_family[free_id][V_F_NUMBER_TYPE], vehicle_family[free_id][V_F_NUMBER], vehicle_family[free_id][V_F_REGION]);
        SetVehicleParam(vehicleid, V_LOCK, false);
        SetVehicleData(vehicleid, V_MILEAGE, 0.0);
    
        LoadVehicleTuningFromCache(vehicleid, 0, result);

        foreach(new playerid: Player)
        {
            if(IsVehicleStreamedIn(vehicleid, playerid))
            {
                SyncVehicleTuningForPlayer(playerid, vehicleid);
            }
        }
    }

    cache_delete(result);
    return vehicleid != INVALID_VEHICLE_ID ? 1 : 0;
}

stock LoadFamilyCarLastPos(database)
{
    new rows, vehicleid;
    new Cache: result;

    mysql_format(mysql, f_string64, sizeof f_string64, "SELECT * FROM family_cars WHERE id=%d", database);
    result = mysql_query(mysql, f_string64, true);
    rows = cache_num_rows();

    if(!rows) return 1;

    new free_id = GetFreeIDFamilyCar();
    SetCarFamily(free_id, CAR_F_database,       cache_get_field_content_int(0, "id"));

    SetCarFamily(free_id, OW_F_database,     cache_get_field_content_int(0, "family_owner"));
    SetCarFamily(free_id, OW_F_server,     GetFamilyIDSQL(GetCarFamily(free_id, OW_F_database)));

    SetCarFamily(free_id, V_F_MODEL,     cache_get_field_content_int(0, "model_id"));
    SetCarFamily(free_id, V_F_COLOR_1,      cache_get_field_content_int(0, "color_1"));
    SetCarFamily(free_id, V_F_COLOR_2,      cache_get_field_content_int(0, "color_2"));
    SetCarFamily(free_id, V_F_RANG,         cache_get_field_content_int(0, "rang"));

    SetCarFamily(free_id, V_F_SPAWN_X,        cache_get_field_content_float(0, "pos_x"));
    SetCarFamily(free_id, V_F_SPAWN_Y,        cache_get_field_content_float(0, "pos_y"));
    SetCarFamily(free_id, V_F_SPAWN_Z,        cache_get_field_content_float(0, "pos_z"));
    SetCarFamily(free_id, V_F_SPAWN_A,        cache_get_field_content_float(0, "angle"));
   
    SetCarFamily(free_id, V_F_SPAWN_LAST_X,        cache_get_field_content_float(0, "pos_last_x"));
    SetCarFamily(free_id, V_F_SPAWN_LAST_Y,        cache_get_field_content_float(0, "pos_last_y"));
    SetCarFamily(free_id, V_F_SPAWN_LAST_Z,        cache_get_field_content_float(0, "pos_last_z"));
    SetCarFamily(free_id, V_F_SPAWN_LAST_A,        cache_get_field_content_float(0, "angle_last"));

    SetCarFamily(free_id, V_F_COUNT_BOX,        0);
    SetCarFamily(free_id, V_F_TEXT_CONT,        STREAMER_TAG_3D_TEXT_LABEL:-1);
    SetCarFamily(free_id, V_F_AREA_CONT,        -1);
    SetCarFamily(free_id, V_F_STATUS_CONT,      false);

    cache_get_field_content(0, "number", vehicle_family[free_id][V_F_NUMBER], mysql, 32);
    cache_get_field_content(0, "region", vehicle_family[free_id][V_F_REGION], mysql, 8);
    SetCarFamily(free_id, V_F_NUMBER_TYPE,      cache_get_field_content_int(0, "number_type"));

    vehicleid = CreateVehicle
    (
        GetCarFamily(free_id, V_F_MODEL),
        GetCarFamily(free_id, V_F_SPAWN_LAST_X),
        GetCarFamily(free_id, V_F_SPAWN_LAST_Y),
        GetCarFamily(free_id, V_F_SPAWN_LAST_Z),
        GetCarFamily(free_id, V_F_SPAWN_LAST_A),
        GetCarFamily(free_id, V_F_COLOR_1),
        GetCarFamily(free_id, V_F_COLOR_2),
        -1,
        0,
        VEHICLE_ACTION_TYPE_FAMILY_CAR,
        free_id
    );

    printf("%d, %f %f %f %f %d %d", GetCarFamily(free_id, V_F_MODEL), GetCarFamily(free_id, V_F_SPAWN_X), GetCarFamily(free_id, V_F_SPAWN_Y), GetCarFamily(free_id, V_F_SPAWN_Z), GetCarFamily(free_id, V_F_SPAWN_A), GetCarFamily(free_id, V_F_COLOR_1), GetCarFamily(free_id, V_F_COLOR_2));
    
    new f_server = GetFamilyIDSQL(GetCarFamily(free_id, OW_F_database));

    if(vehicleid != INVALID_VEHICLE_ID)
    {
        new familyName[64];
        format(familyName, sizeof familyName, "%s", GetFamily(f_server, family_name));
        utf8_to_cp1251(familyName);

        format(vehicle_family[free_id][V_F_NUMBER], 12, vehicle_family[free_id][V_F_NUMBER]);
        SetVehicleNumberPlateEx(vehicleid, vehicle_family[free_id][V_F_NUMBER_TYPE], vehicle_family[free_id][V_F_NUMBER], vehicle_family[free_id][V_F_REGION]);
        SetVehicleParam(vehicleid, V_LOCK, false);
        SetVehicleData(vehicleid, V_MILEAGE, 0.0);
    
        LoadVehicleTuningFromCache(vehicleid, 0, result);

        foreach(new playerid: Player)
        {
            if(IsVehicleStreamedIn(vehicleid, playerid))
            {
                SyncVehicleTuningForPlayer(playerid, vehicleid);
            }
        }
    }

    cache_delete(result);
    return vehicleid != INVALID_VEHICLE_ID ? 1 : 0;
}

stock UnLoadFamilyCar(database)
{
	new vehicleid = GetVehicleFamilyCar(database);

	if(vehicleid == INVALID_VEHICLE_ID)
	{
		return -1;
	}

	new id = GetVehicleData(vehicleid, V_ACTION_ID);

	DestroyVehicleLabel(vehicleid);
	
	new Float:lastposx, Float:lastposy, Float:lastposz, Float:lastposa;
	GetVehiclePos(vehicleid, lastposx, lastposy, lastposz);
	GetVehicleZAngle(vehicleid, lastposa);

    SetCarFamily(id, CAR_F_database,       -1);

    SetCarFamily(id, OW_F_database,     -1);

    SetCarFamily(id, V_F_MODEL,     0);
    SetCarFamily(id, V_F_COLOR_1,   0);
    SetCarFamily(id, V_F_COLOR_2,   0);
    SetCarFamily(id, V_F_RANG,      0);

    SetCarFamily(id, V_F_SPAWN_X,        0.0);
    SetCarFamily(id, V_F_SPAWN_Y,        0.0);
    SetCarFamily(id, V_F_SPAWN_Z,        0.0);
    SetCarFamily(id, V_F_SPAWN_A,        0.0);
   
    SetCarFamily(id, V_F_SPAWN_LAST_X,        lastposx);
    SetCarFamily(id, V_F_SPAWN_LAST_Y,        lastposy);
    SetCarFamily(id, V_F_SPAWN_LAST_Z,        lastposz);
    SetCarFamily(id, V_F_SPAWN_LAST_A,        lastposa);

    if(IsValidDynamicArea(GetCarFamily(id, V_F_AREA_CONT))) DestroyDynamicArea(GetCarFamily(id, V_F_AREA_CONT));
    if(GetCarFamily(id, V_F_TEXT_CONT) != STREAMER_TAG_3D_TEXT_LABEL:-1)  Delete3DTextLabel(GetCarFamily(id, V_F_TEXT_CONT));

    SetCarFamily(id, V_F_TEXT_CONT,        STREAMER_TAG_3D_TEXT_LABEL:-1);
    SetCarFamily(id, V_F_AREA_CONT,        -1);
    SetCarFamily(id, V_F_STATUS_CONT,      false);
    SetCarFamily(id, V_F_COUNT_BOX,        0);
  
    new dbsend[512];
	mysql_format(mysql, dbsend, sizeof(dbsend),
    "UPDATE family_cars SET pos_last_x = %f, pos_last_y = %f, pos_last_z = %f, angle_last = %f WHERE id = %d",
    lastposx, lastposy, lastposz, lastposa, database);
	mysql_query(mysql, dbsend, false);

	
	DestroyVehicle(vehicleid);

	return 1;
}


stock SendFamilyMessage(fam, text[])
{
    new color[9], name[32];

    format(name, sizeof name, family[fam][family_name]);

    for(new i; i < strlen(name);i++)
    {
        if(name[i] == '{' && name[i+7] == '}') 
        {
            for(new d = 0;d < 8;d++) color[d] = name[i+d];
            break;
        }
    }

    if(!strlen(color)) format(color, sizeof color, family_type_color[GetFamily(fam, family_color)]);
    
    new string[384];
    format(string, sizeof string, "{FFFFFF}%s[%s] %s", color, GetFamily(fam, family_name), text);

    foreach(new i : Player)
    {
        if(!IsPlayerConnected(i)) continue;
        else if(GetPlayerFamily(i, ID_FAMILY) != fam) continue;

        SendClientMessage(i, -1, string);
    }

    return 1;

}

stock GetStatusFamilyCar(database_car)
{
    foreach(new i : Vehicle)
    {
        if(GetVehicleData(i, V_ACTION_TYPE) != VEHICLE_ACTION_TYPE_FAMILY_CAR) continue;
        else if(GetCarFamily(GetVehicleData(i, V_ACTION_ID), CAR_F_database) != database_car) continue;
        return 1;
    }
    return 0;
} 

stock GetVehicleFamilyCar(database_car)
{
    new id = -1;
    foreach(new i : Vehicle)
    {
        if(GetVehicleData(i, V_ACTION_TYPE) != VEHICLE_ACTION_TYPE_FAMILY_CAR) continue;

        id = GetVehicleData(i, V_ACTION_ID);
        if(GetCarFamily(id, CAR_F_database) != database_car) continue;
        return i;
    }
    return INVALID_VEHICLE_ID;
}

stock GetFreeIDFamilyCar()
{
    for(new i; i < MAX_OWNABLE_CARS;i++)
    {
        if(GetCarFamily(i, CAR_F_database) != -1) continue;
        return i;
    }
    return -1;
}

stock GetFamilyIDSQL(database)
{
    for(new i; i <MAX_FAM;i++) if(GetFamily(i, family_database) == database) return i;
    return -1;
}

stock ShowDialogFamilySklad(playerid, type, take_or_put = false)
{
    switch(type)
    {
        case 1:
        {
            if(!take_or_put)
            {
                ShowPlayerDialog
                (
                    playerid, 2225, DIALOG_STYLE_LIST,
                    "{FF0000}Take item from storage",
                    "{FFFF00}|{FFFFFF} Money\n"\
                    "{FFFF00}|{FFFFFF} Materials\n"\
                    "{FFFF00}|{FFFFFF} Masks\n"\
                    "{FFFF00}|{FFFFFF} Weapons\n"\
                    "{FFFF00}|{FFFFFF} Bulletproof vest\n"\
                    "{FFFF00}|{FFFFFF} Medkit",
                    "Next", "Back"
                );
                SetPVarInt(playerid, "type_sklad", 1);
            }else{
                ShowPlayerDialog
                (
                    playerid, 2225, DIALOG_STYLE_LIST,
                    "{FF0000}Put item into storage",
                    "{FFFF00}|{FFFFFF} Money\n"\
                    "{FFFF00}|{FFFFFF} Materials\n"\
                    "{FFFF00}|{FFFFFF} Masks\n"\
                    "{FFFF00}|{FFFFFF} Weapons\n"\
                    "{FFFF00}|{FFFFFF} Bulletproof vest\n"\
                    "{FFFF00}|{FFFFFF} Medkit",
                    "Next", "Back"
                );
                SetPVarInt(playerid, "type_sklad", 2);
            }
        }
        case 2:
        {
            if(!take_or_put)
            {
                format(f_string144, sizeof f_string144, "Enter the amount you want to take (Available:%d)", GetFamily(GetPlayerIdFamily(playerid), family_money));
                ShowPlayerDialog
                (
                    playerid, 2226, DIALOG_STYLE_INPUT,
                    "{FF0000}Take money from storage",
                    f_string144,
                    "Take", "Back"
                );
            }
            else
            {
                if(!GetPlayerMoneyEx(playerid))
                    return SendClientMessage(playerid, -1, ""c_f_r"You have no money.");

                format(f_string144, sizeof f_string144, "Enter the amount you want to put (Available:%d)", GetPlayerMoneyEx(playerid));
                ShowPlayerDialog
                (
                    playerid, 2226, DIALOG_STYLE_INPUT,
                    "{FF0000}Put money into storage",
                    f_string144,
                    "Put", "Back"
                );
            }
            SetPVarInt(playerid, "select_type_sklad_use", 2);
        }
        case 3:
        {
            if(!take_or_put)
            {
                format(f_string144, sizeof f_string144, "Enter the amount you want to take (Available:%d)", GetFamily(GetPlayerIdFamily(playerid), family_material));
                ShowPlayerDialog
                (
                    playerid, 2226, DIALOG_STYLE_INPUT,
                    "{FF0000}Take materials from storage",
                    f_string144,
                    "Take", "Back"
                );
            }
            else
            {
                if(!GetPlayerData(playerid, P_METALL))
                    return SendClientMessage(playerid, -1, ""c_f_r"You have no materials.");

                format(f_string144, sizeof f_string144, "Enter the amount you want to put (Available:%d)", GetPlayerData(playerid, P_METALL));
                ShowPlayerDialog
                (
                    playerid, 2226, DIALOG_STYLE_INPUT,
                    "{FF0000}Put materials into storage",
                    f_string144,
                    "Put", "Back"
                );
            }
            SetPVarInt(playerid, "select_type_sklad_use", 3);
        }
        case 4:
        {
            if(!take_or_put)
            {
                ShowPlayerDialog
                (
                    playerid, 2226, DIALOG_STYLE_MSGBOX,
                    "{FF0000}Take mask",
                    "Do you want to take a mask from the storage?",
                    "Take", "Back"
                );
            }
            else
            {
                if(!GetPlayerData(playerid, P_MASK))
                    return SendClientMessage(playerid, -1, ""c_f_r"You have no mask.");

                ShowPlayerDialog
                (
                    playerid, 2226, DIALOG_STYLE_MSGBOX,
                    "{FF0000}Put mask",
                    "Do you want to put a mask into the storage?",
                    "Put", "Back"
                );
            }
            SetPVarInt(playerid, "select_type_sklad_use", 4);
        }
        case 5:
        {
            if(!take_or_put)
            {
                ShowPlayerDialog
                (
                    playerid, 2226, DIALOG_STYLE_LIST,
                    "{FF0000}Take weapon",
                    "Information\n"\
                    "Take",
                    "Next", "Back"
                );
            }
            else
            {
                ShowPlayerDialog
                (
                    playerid, 2226, DIALOG_STYLE_LIST,
                    "{FF0000}Put weapon",
                    "Information\n"\
                    "Put",
                    "Next", "Back"
                );
            }
            SetPVarInt(playerid, "select_type_sklad_use", 5);
        }
        case 6:
        {
            if(!take_or_put)
            {
                ShowPlayerDialog
                (
                    playerid, 2226, DIALOG_STYLE_MSGBOX,
                    "{FF0000}Take bulletproof vest",
                    "Do you want to take a bulletproof vest from the storage?",
                    "Take", "Back"
                );
            }
            else
            {
                new Float:armour;
                
                GetPlayerArmour(playerid, armour);

                if(armour <= 19.9)
                    return SendClientMessage(playerid, -1, ""c_f_r"You have no bulletproof vest or its durability is below 20 percent.");

                ShowPlayerDialog
                (
                    playerid, 2226, DIALOG_STYLE_MSGBOX,
                    "{FF0000}Put bulletproof vest",
                    "Do you want to put a bulletproof vest into the storage?",
                    "Put", "Back"
                );
            }
            SetPVarInt(playerid, "select_type_sklad_use", 6);
        }
        case 7:
        {
            if(!take_or_put)
            {
                ShowPlayerDialog
                (
                    playerid, 2226, DIALOG_STYLE_MSGBOX,
                    "{FF0000}Take medkit",
                    "Do you want to take a medkit from the storage?",
                    "Take", "Back"
                );
            }
            else
            {
                ShowPlayerDialog
                (
                    playerid, 2226, DIALOG_STYLE_MSGBOX,
                    "{FF0000}Put medkit",
                    "Do you want to put a medkit into the storage?",
                    "Put", "Back"
                );
            }
            SetPVarInt(playerid, "select_type_sklad_use", 7);
        }
    }
    return 1;
}

stock UpdateColumnFamilyInt(f, column[], number)
{
	new query[256];

	mysql_format(mysql, query, sizeof query, "UPDATE family SET `%s`=%d WHERE `id`=%d LIMIT 1", column, number, f);
	mysql_query(mysql, query, false);
	return 1;
}

stock DialogFamily(playerid, dialogid, style, title[], text[], button[], button2[])
{
  if(style == 5)
  {
     ShowPlayerDialog(playerid, 0, DIALOG_STYLE_LIST, "...", "...", "...", ""); 
  }
  ShowPlayerDialog(playerid, dialogid, style, title, text, button, button2);
  return 1;
}

stock ShowDialogAccess(playerid, type, give)
{
    switch(type)
    {
        case 1:
        {
            if(give)
            {
                ShowPlayerDialog
                (
                    playerid, 2231, DIALOG_STYLE_LIST,
                    "{FF0000}Give access",
                    "1. Give access to everything\n"\
                    "2. Access to modify permissions\n"\
                    "3. Access to money\n"\
                    "4. Access to materials\n"\
                    "5. Access to masks\n"\
                    "6. Access to medkits\n"\
                    "7. Access to weapons\n"\
                    "8. Access to bulletproof vests",
                    "Next", "Back"
                );
                SetPVarInt(playerid, "status_dialog_access", 2);
            }
            else
            {
                ShowPlayerDialog
                (
                    playerid, 2231, DIALOG_STYLE_LIST,
                    "{FF0000}Revoke access",
                    "1. Revoke access to everything\n"\
                    "2. Access to modify permissions\n"\
                    "3. Access to money\n"\
                    "4. Access to materials\n"\
                    "5. Access to masks\n"\
                    "6. Access to medkits\n"\
                    "7. Access to weapons\n"\
                    "8. Access to bulletproof vests",
                    "Next", "Back"
                );
                SetPVarInt(playerid, "status_dialog_access", 1);
            }
        }
        case 3:
        {
            ShowPlayerDialog
            (
                playerid, 2231, DIALOG_STYLE_INPUT,
                "Configure access",
                "Enter the name or ID of the player to edit their access",
                "Next",
                "Back"
            );

            SetPVarInt(playerid, "type_dialog_access", type);
        }
        case 2,4..10:
        {
            if(give)
            {
                ShowPlayerDialog
                (
                    playerid, 2231, DIALOG_STYLE_INPUT,
                    "Configure access",
                    "Enter the name or ID of the player and the quantity separated by a comma\n"\
                    "- Quantity is how many items the player can take.\n"\
                    "- Example: Nick_Name, 1000",
                    "Next",
                    "Back"
                );
            }else{
                ShowPlayerDialog
                (
                    playerid, 2231, DIALOG_STYLE_INPUT,
                    "Configure access",
                    "Enter the name or ID of the player to edit their access",
                    "Next",
                    "Back"
                );
            }

            SetPVarInt(playerid, "type_dialog_access", type);
        }
    }
}



stock UpdateDostupFamily(fam, rang)
{
    new setting[38];
    format(setting, sizeof setting, "%s,%d,%d,%d,%d,%d,%d", family_rang_name[fam][rang], family_rang_dostup[fam][rang][0], 
    family_rang_dostup[fam][rang][1], family_rang_dostup[fam][rang][2], family_rang_dostup[fam][rang][3], 
    family_rang_dostup[fam][rang][4], family_rang_dostup[fam][rang][5]);

    new rang_sql_name[5][7] = {"rang_1","rang_2", "rang_3", "rang_4", "rang_5"};

    mysql_format(mysql, f_string184, sizeof f_string184, "UPDATE family SET %s = '%s' WHERE id=%d", rang_sql_name[rang], setting, GetFamily(fam, family_database));
    mysql_query(mysql, f_string184, false);

    return 1;
}
CMD:infdos(playerid, params[])
{
    new f = GetPlayerIdFamily(playerid);
    if(f == -1)
    {
        SendClientMessage(playerid, -1, ""c_f_r"You don't have a family.");
        return 1;
    }
    
    new rank;
    if(sscanf(params, "d", rank))
    {
        SendClientMessage(playerid, -1, ""c_f_r"Usage: /infdos [rank] (1-5)");
        return 1;
    }
    
    if(rank < 1 || rank > 5)
    {
        SendClientMessage(playerid, -1, ""c_f_r"Rank must be between 1 and 5.");
        return 1;
    }
    
    new rank_name[32];
    format(rank_name, sizeof(rank_name), "%s", family_rang_name[f][rank - 1]);
    
    new info[512];
    format(info, sizeof(info),
        "{FF0000}Access for rank %d (%s):\n\n"\
        "{FFFFFF}Accept players: {FFB700}%s\n"\
        "{FFFFFF}Kick players: {FFB700}%s\n"\
        "{FFFFFF}Change ranks: {FFB700}%s\n"\
        "{FFFFFF}Give mute: {FFB700}%s\n"\
        "{FFFFFF}Participate in war: {FFB700}%s\n"\
        "{FFFFFF}Access to storage: {FFB700}%s",
        rank, rank_name,
        (family_rang_dostup[f][rank-1][0] == 0) ? "{00FF00}Yes" : "{FF0000}No",
        (family_rang_dostup[f][rank-1][1] == 0) ? "{00FF00}Yes" : "{FF0000}No",
        (family_rang_dostup[f][rank-1][2] == 0) ? "{00FF00}Yes" : "{FF0000}No",
        (family_rang_dostup[f][rank-1][3] == 0) ? "{00FF00}Yes" : "{FF0000}No",
        (family_rang_dostup[f][rank-1][4] == 0) ? "{00FF00}Yes" : "{FF0000}No",
        (family_rang_dostup[f][rank-1][5] == 0) ? "{00FF00}Yes" : "{FF0000}No"
    );
    
   ShowPlayerDialog(playerid, -1, DIALOG_STYLE_MSGBOX, "{FF0000}Access information", info, "Close", "");
    
    return 1;
}

stock UpdateAccessPlayerFamily(playerid)
{
    new setting[30];
    format(setting, sizeof setting, "%d,%d,%d,%d,%d,%d,%d", GetPlayerFamily(playerid, ACCESS_GIVE),  GetPlayerFamily(playerid, ACCESS_MONEY), 
    GetPlayerFamily(playerid, ACCESS_ARMOUR),  GetPlayerFamily(playerid, ACCESS_MATERIAL),  GetPlayerFamily(playerid, ACCESS_HEATH_KIT), 
    GetPlayerFamily(playerid, ACCESS_PATRON),  GetPlayerFamily(playerid, ACCESS_MASK));

    mysql_format(mysql, f_string184, sizeof f_string184, "UPDATE accounts SET family_access = '%s' WHERE id=%d", setting, GetPlayerAccountID(playerid));
    mysql_query(mysql, f_string184, false);

    return 1;   
}

stock PacketIncomingFamily(playerid, Node:JSONObject)
{
    new type;
    JSON_GetInt(JSONObject, "t", type);

    printf("[IPacket:252] Player %d, GUIID 45, Type: %d", playerid, type);
    new f = GetPlayerIdFamily(playerid);

    switch(type)
    {
        case 1: // �����
        {
            new quest_id;
            JSON_GetInt(JSONObject, "id", quest_id);
            
            new Node:response = JSON_Object();
            JSON_SetInt(response, "t", 1);
            JSON_SetInt(response, "s", 1);
            JSON_SetInt(response, "id", quest_id);
            
            SendPacketToClient(playerid, 45, response);
            JSON_Cleanup(response);
        }
       case 2: // ��������
{
    new s_value;
    JSON_GetInt(JSONObject, "s", s_value);
    
    printf("[FAMILY] ��������: s_value = %d", s_value);
    
    if(s_value == 1) // ������ ���������� � ������
    {
        printf("[FAMILY] ������ ���������� � ������");
        
        new full_json[512];
        JSON_Stringify(JSONObject, full_json, sizeof(full_json));
        printf("[FAMILY] ������ JSON �� �������: %s", full_json);
        
        new car_id = 0;
        
        if(JSON_GetInt(JSONObject, "id", car_id))
        {
            printf("[FAMILY] ����� JSON_GetInt �������� ID: %d", car_id);
        }
        
        if(car_id == 0)
        {
            new Node:idNode;
            if(JSON_GetObject(JSONObject, "id", idNode))
            {
                JSON_GetNodeInt(idNode, car_id);
                printf("[FAMILY] ����� JSON_GetNodeInt �������� ID: %d", car_id);
                JSON_Cleanup(idNode);
            }
        }
        
        if(car_id == 0)
        {
            new id_str[16];
            if(JSON_GetString(JSONObject, "id", id_str, sizeof(id_str)))
            {
                car_id = strval(id_str);
                printf("[FAMILY] ����� JSON_GetString �������� ID: %d", car_id);
            }
        }
        
        if(car_id == 0)
        {
            printf("[FAMILY] �� ������� �������� ID ������");
            ShowNotificationSile(playerid, 2, 5, -1, -1, "Error, failed to load vehicle!", "");
            return 1;
        }
        
        new f = GetPlayerIdFamily(playerid);
        printf("[FAMILY] f = %d", f);
        
        if(f == -1)
        {
            printf("[FAMILY] � ������ ��� �����!");
            ShowNotificationSile(playerid, 2, 5, -1, -1, "You are not in a family.", "");
            return 1;
        }
        
        new family_db = GetFamily(f, family_database);
        printf("[FAMILY] family_db = %d", family_db);
        
        mysql_format(mysql, f_string64, sizeof f_string64, 
            "SELECT * FROM family_cars WHERE id = %d AND family_owner = %d", 
            car_id, family_db);
        
        printf("[FAMILY] SQL: %s", f_string64);
        
        new Cache:cache = mysql_query(mysql, f_string64);
        
        if(mysql_errno())
        {
            printf("[FAMILY] SQL ERROR: %d", mysql_errno());
            ShowNotificationSile(playerid, 2, 5, -1, -1, "Error in SQL query", "");
            cache_delete(cache);
            return 1;
        }
        
        new rows = cache_num_rows();
        printf("[FAMILY] rows = %d", rows);
        
        if(!rows)
        {
            ShowNotificationSile(playerid, 2, 5, -1, -1, "Vehicle not found.", "");
            cache_delete(cache);
            return 1;
        }
        
        new rang = cache_get_field_content_int(0, "rang");
        new status = GetStatusFamilyCar(car_id);
        new model_id = cache_get_field_content_int(0, "model_id");
        new model_name[64];
        GetVehicleModelName(model_id, model_name, sizeof(model_name));
        
        printf("[FAMILY] ���������� � ������: id=%d, name=%s, rang=%d, status=%d", 
            car_id, model_name, rang, status);
        
        new Node:response = JSON_Object();
        JSON_SetInt(response, "t", 2);
        JSON_SetInt(response, "s", 1);
        JSON_SetInt(response, "r", rang);
        JSON_SetInt(response, "d", status);
        JSON_SetInt(response, "m", model_id);
        JSON_SetString(response, "n", model_name);
        JSON_SetInt(response, "g", 0);
        
        new debug_str[2048];
        JSON_Stringify(response, debug_str, sizeof debug_str);
        printf("[FAMILY] �����: %s", debug_str);
        
        SendPacketToClient(playerid, 45, response);
        
        JSON_Cleanup(response);
        cache_delete(cache);
        printf("[FAMILY] ����� ���������");
        return 1;
    }
    else if(s_value == 2) // �������� � �������
    {
        printf("[FAMILY] �������� � �������");
        new car_id, action_id, access, Node:response = JSON_Object();
        JSON_GetInt(JSONObject, "m", car_id);
        JSON_GetInt(JSONObject, "id", action_id);
        JSON_GetInt(JSONObject, "r", access);
        
        if(car_id <= 0)
        {
            printf("[FAMILY] ������: �������� ID ������");
            ShowNotificationSile(playerid, 2, 5, -1, -1, "Error, please try again later.", "");
            JSON_Cleanup(response);
            return 1;
        }
        
        printf("[FAMILY] car_id=%d, action_id=%d, access=%d", car_id, action_id, access);
        
        new model_id = 0;
        new model_name[64] = "Unknown";
        
        mysql_format(mysql, f_string64, sizeof f_string64, 
            "SELECT model_id FROM family_cars WHERE id = %d", car_id);
        new Cache:info_cache = mysql_query(mysql, f_string64);
        if(cache_num_rows())
        {
            model_id = cache_get_field_content_int(0, "model_id");
            GetVehicleModelName(model_id, model_name, sizeof(model_name));
        }
        cache_delete(info_cache);
        
        if(action_id == 1) // ��������� �� ��������
        {
            if(LoadFamilyCar(car_id))
            {
                JSON_SetInt(response, "t", 2); 
                JSON_SetInt(response, "s", 2);
                JSON_SetInt(response, "d", 1);
                
                format(f_string144, sizeof f_string144, "%s %s[%d] loaded the vehicle %s.",
                    family_rang_name[GetPlayerIdFamily(playerid)][GetPlayerFamily(playerid, RANG_FAMILY)-1], GetPlayerNameEx(playerid), playerid, model_name);
                SendFamilyMessage(GetPlayerIdFamily(playerid), f_string144);
                SendFamilyLog(type_log_car, playerid, -1, f_string144);
                ShowNotificationSile(playerid, 3, 5, -1, -1, "Vehicle successfully loaded.", "");
            }
            else
            {
                JSON_SetInt(response, "t", 2);
                JSON_SetInt(response, "s", 2);
                JSON_SetInt(response, "d", 0);
                ShowNotificationSile(playerid, 2, 5, -1, -1, "Error loading vehicle", "");
            } 
        }
        else if(action_id == 4) // ���������
        {
            new vehicleid = GetVehicleFamilyCar(car_id);
            
            if(vehicleid != INVALID_VEHICLE_ID && GetVehicleDriver(vehicleid) == INVALID_PLAYER_ID && GetPlayerRangFamily(playerid) != 5)
            {
                ShowNotificationSile(playerid, 2, 5, -1, -1, "Vehicle is occupied", "");
                JSON_SetInt(response, "t", 2);
                JSON_SetInt(response, "s", 2);
                JSON_SetInt(response, "d", 0);
            }
            else if(UnLoadFamilyCar(car_id))
            {
                JSON_SetInt(response, "t", 2); 
                JSON_SetInt(response, "s", 2);
                JSON_SetInt(response, "d", 1);
                
                format(f_string144, sizeof f_string144, "%s %s[%d] unloaded the vehicle %s",
                    family_rang_name[GetPlayerIdFamily(playerid)][GetPlayerFamily(playerid, RANG_FAMILY)-1], GetPlayerNameEx(playerid), playerid, model_name);
                SendFamilyMessage(GetPlayerIdFamily(playerid), f_string144);
                SendFamilyLog(type_log_car, playerid, -1, f_string144);
                ShowNotificationSile(playerid, 3, 5, -1, -1, "Vehicle successfully unloaded.", "");
            }
            else
            {
                JSON_SetInt(response, "t", 2);
                JSON_SetInt(response, "s", 2);
                JSON_SetInt(response, "d", 0);
                ShowNotificationSile(playerid, 2, 5, -1, -1, "Error unloading vehicle", "");
            }
        }
        else if(action_id == 0) // �������� �� GPS
        {
            new Float:pos_x, Float:pos_y, Float:pos_z;
            new status = GetStatusFamilyCar(car_id);
            new vehicleid = GetVehicleFamilyCar(car_id);
            
            if(status == 1 && vehicleid != INVALID_VEHICLE_ID)
            {
                GetVehiclePos(vehicleid, pos_x, pos_y, pos_z);
                printf("[FAMILY] ������ ���������, ����������: %f, %f, %f", pos_x, pos_y, pos_z);
            }
            else
            {
                mysql_format(mysql, f_string64, sizeof f_string64, 
                    "SELECT pos_x, pos_y, pos_z FROM family_cars WHERE id = %d", car_id);
                new Cache:cache = mysql_query(mysql, f_string64);
                if(cache_num_rows())
                {
                    pos_x = cache_get_field_content_float(0, "pos_x");
                    pos_y = cache_get_field_content_float(0, "pos_y");
                    pos_z = cache_get_field_content_float(0, "pos_z");
                    printf("[FAMILY] ������ ���������, ���������� �� ��: %f, %f, %f", pos_x, pos_y, pos_z);
                }
                cache_delete(cache);
            }
            EnablePlayerGPS(playerid, 55, pos_x, pos_y, pos_z, "The location of the family vehicle parking is marked on GPS");
            JSON_SetInt(response, "t", 2);
            JSON_SetInt(response, "s", 2);
            JSON_SetInt(response, "d", 1);
        }
        else if(action_id == 7) // �������� ��������
        {
            printf("[FAMILY] ����� �������� ��� ������ ID: %d", car_id);
            
            new f = GetPlayerIdFamily(playerid);
            if(f == -1)
            {
                ShowNotificationSile(playerid, 2, 5, -1, -1, "You are not in a family.", "");
                JSON_SetInt(response, "t", 2);
                JSON_SetInt(response, "s", 2);
                JSON_SetInt(response, "d", 0);
                SendPacketToClient(playerid, 45, response);
                JSON_Cleanup(response);
                return 1;
            }
            
            if(GetPlayerRangFamily(playerid) != 5)
            {
                ShowNotificationSile(playerid, 2, 5, -1, -1, "Resetting parking is only available to the family leader.", "");
                JSON_SetInt(response, "t", 2);
                JSON_SetInt(response, "s", 2);
                JSON_SetInt(response, "d", 0);
                SendPacketToClient(playerid, 45, response);
                JSON_Cleanup(response);
                return 1;
            }
            
            new vehicleid = GetVehicleFamilyCar(car_id);
            
            if(vehicleid != INVALID_VEHICLE_ID)
            {
                ShowNotificationSile(playerid, 2, 5, -1, -1, "Cannot reset parking. Unload the vehicle first.", "");
                JSON_SetInt(response, "t", 2);
                JSON_SetInt(response, "s", 2);
                JSON_SetInt(response, "d", 0);
                SendPacketToClient(playerid, 45, response);
                JSON_Cleanup(response);
                return 1;
            }
            
            new Float:new_pos_x = 2501.752;
            new Float:new_pos_y = -760.497;
            new Float:new_pos_z = 11.358;
            new Float:new_angle = 0.0;
            
            new query[256];
            format(query, sizeof(query), 
                "UPDATE family_cars SET pos_x = %f, pos_y = %f, pos_z = %f, angle = %f WHERE id = %d",
                new_pos_x, new_pos_y, new_pos_z, new_angle, car_id);
            
            printf("[FAMILY] SQL: %s", query);
            
            mysql_query(mysql, query, false);
            
            if(!mysql_errno())
            {
                JSON_SetInt(response, "t", 2);
                JSON_SetInt(response, "s", 2);
                JSON_SetInt(response, "d", 1);
                
                format(f_string144, sizeof f_string144, "%s reset the parking of %s to default.",
                    GetPlayerNameEx(playerid), model_name);
                SendFamilyLog(type_log_car, playerid, -1, f_string144);
                
                ShowNotificationSile(playerid, 3, 5, -1, -1, "Parking was successfully reset.", "");
                
                printf("[FAMILY] �������� ������ %d �������� �� ����������: %f, %f, %f", 
                    car_id, new_pos_x, new_pos_y, new_pos_z);
            }
            else
            {
                JSON_SetInt(response, "t", 2);
                JSON_SetInt(response, "s", 2);
                JSON_SetInt(response, "d", 0);
                ShowNotificationSile(playerid, 2, 5, -1, -1, "Error resetting parking", "");
                printf("[FAMILY] SQL ERROR ��� ������ ��������: %d", mysql_errno());
            }
        }
        else if(action_id == 3) // �������� ����
        {
            printf("[FAMILY] ��������� ����� ��� ������ ID: %d", car_id);
            
            new f = GetPlayerIdFamily(playerid);
            if(f == -1)
            {
                ShowNotificationSile(playerid, 2, 5, -1, -1, "You are not in a family.", "");
                JSON_SetInt(response, "t", 2);
                JSON_SetInt(response, "s", 2);
                JSON_SetInt(response, "d", 0);
                SendPacketToClient(playerid, 45, response);
                JSON_Cleanup(response);
                return 1;
            }
            
            if(GetPlayerRangFamily(playerid) != 5)
            {
                ShowNotificationSile(playerid, 2, 5, -1, -1, "Changing vehicle rank is only available to the family leader.", "");
                JSON_SetInt(response, "t", 2);
                JSON_SetInt(response, "s", 2);
                JSON_SetInt(response, "d", 0);
                SendPacketToClient(playerid, 45, response);
                JSON_Cleanup(response);
                return 1;
            }
            
            new vehicleid = GetVehicleFamilyCar(car_id);
            
            if(vehicleid != INVALID_VEHICLE_ID)
            {
                ShowNotificationSile(playerid, 2, 5, -1, -1, "Unload the vehicle first.", "");
                JSON_SetInt(response, "t", 2);
                JSON_SetInt(response, "s", 2);
                JSON_SetInt(response, "d", 0);
                SendPacketToClient(playerid, 45, response);
                JSON_Cleanup(response);
                return 1;
            }
            
            new current_rang = 0;
            mysql_format(mysql, f_string64, sizeof f_string64, 
                "SELECT rang FROM family_cars WHERE id = %d", car_id);
            new Cache:rang_cache = mysql_query(mysql, f_string64);
            if(cache_num_rows())
            {
                current_rang = cache_get_field_content_int(0, "rang");
            }
            cache_delete(rang_cache);
            
            printf("[FAMILY] ������� ���� ������ %d: %d", car_id, current_rang);
            printf("[FAMILY] access = %d (0 - ���������, 1 - ���������)", access);
            
            new new_rang = current_rang;
            
            if(access == 0)
            {
                if(current_rang > 1)
                {
                    new_rang = current_rang - 1;
                    printf("[FAMILY] ��������� ���� � %d �� %d", current_rang, new_rang);
                    ShowNotificationSile(playerid, 3, 5, -1, -1, "Vehicle usage rank was successfully changed.", "");
                }
                else
                {
                    ShowNotificationSile(playerid, 2, 5, -1, -1, "This vehicle already has the minimum rank.", "");
                    JSON_SetInt(response, "t", 2);
                    JSON_SetInt(response, "s", 2);
                    JSON_SetInt(response, "d", 0);
                    SendPacketToClient(playerid, 45, response);
                    JSON_Cleanup(response);
                    return 1;
                }
            }
            else if(access == 1)
            {
                if(current_rang < 5)
                {
                    new_rang = current_rang + 1;
                    printf("[FAMILY] ����������� ���� � %d �� %d", current_rang, new_rang);
                    ShowNotificationSile(playerid, 3, 5, -1, -1, "Vehicle usage rank was successfully changed.", "");
                }
                else
                {
                    ShowNotificationSile(playerid, 2, 5, -1, -1, "This vehicle already has the maximum rank.", "");
                    JSON_SetInt(response, "t", 2);
                    JSON_SetInt(response, "s", 2);
                    JSON_SetInt(response, "d", 0);
                    SendPacketToClient(playerid, 45, response);
                    JSON_Cleanup(response);
                    return 1;
                }
            }
            
            mysql_format(mysql, f_string64, sizeof f_string64, 
                "UPDATE family_cars SET rang = %d WHERE id = %d", new_rang, car_id);
            mysql_query(mysql, f_string64, false);
            
            if(!mysql_errno())
            {
                JSON_SetInt(response, "t", 2);
                JSON_SetInt(response, "s", 2);
                JSON_SetInt(response, "d", 1);
                JSON_SetInt(response, "new_rang", new_rang);
                
                format(f_string144, sizeof f_string144, "%s changed access to %s from rank %d to %d.",
                    GetPlayerNameEx(playerid), model_name, current_rang, new_rang);
                SendFamilyLog(type_log_dostup, playerid, -1, f_string144);
            }
            else
            {
                JSON_SetInt(response, "t", 2);
                JSON_SetInt(response, "s", 2);
                JSON_SetInt(response, "d", 0);
                ShowNotificationSile(playerid, 2, 5, -1, -1, "Error changing rank", "");
            }
        }
        else if(action_id == 2) // ������� �� ����� (������� ������)
        {
            printf("[FAMILY] ������� ���������� �� �����, ������ ID: %d", car_id);
            
            if(GetPlayerRangFamily(playerid) != 5)
            {
                ShowNotificationSile(playerid, 2, 5, -1, -1, "Only the leader can take a vehicle from the family.", "");
                JSON_SetInt(response, "t", 2);
                JSON_SetInt(response, "s", 2);
                JSON_SetInt(response, "d", 0);
                SendPacketToClient(playerid, 45, response);
                JSON_Cleanup(response);
                return 1;
            }
            
            if(GetStatusFamilyCar(car_id))
            {
                ShowNotificationSile(playerid, 2, 5, -1, -1, "Cannot take the vehicle, unload it first.", "");
                JSON_SetInt(response, "t", 2);
                JSON_SetInt(response, "s", 2);
                JSON_SetInt(response, "d", 0);
                SendPacketToClient(playerid, 45, response);
                JSON_Cleanup(response);
                return 1;
            }
            
            if((GetPlayerOwnableCars(playerid) + 1) > GetPlayerCarSlots(playerid))
            {
                ShowNotificationSile(playerid, 2, 5, -1, -1, "You have no free vehicle slots.", "");
                JSON_SetInt(response, "t", 2);
                JSON_SetInt(response, "s", 2);
                JSON_SetInt(response, "d", 0);
                SendPacketToClient(playerid, 45, response);
                JSON_Cleanup(response);
                return 1;
            }
            
            if(MoveFamilyCar(car_id, playerid))
            {
                JSON_SetInt(response, "t", 2);
                JSON_SetInt(response, "s", 2);
                JSON_SetInt(response, "d", 1);
                
                format(f_string144, sizeof f_string144, "%s took the vehicle %s from the family",
                    GetPlayerNameEx(playerid), model_name);
                SendFamilyLog(type_log_car, playerid, -1, f_string144);
                
                ShowNotificationSile(playerid, 3, 5, -1, -1, "You successfully removed the vehicle from the family.", "");
            }
            else
            {
                JSON_SetInt(response, "t", 2);
                JSON_SetInt(response, "s", 2);
                JSON_SetInt(response, "d", 0);
                ShowNotificationSile(playerid, 2, 5, -1, -1, "Error removing vehicle from family.", "");
            }
        }
        else if(action_id == 5) // ��������� � �����
        {
            ShowNotificationSile(playerid, 2, 5, -1, -1, "action id 5");
            JSON_SetInt(response, "t", 2);
            JSON_SetInt(response, "s", 5);
            JSON_SetInt(response, "d", 1);
        }
        else if(action_id == 6) // ��������� �� ����� ��������
{
    printf("[FAMILY] �������� �� ����� �������� ��� ������ ID: %d", car_id);
    
    new f = GetPlayerIdFamily(playerid);
    if(f == -1)
    {
        ShowNotificationSile(playerid, 2, 5, -1, -1, "You are not in a family.", "");
        JSON_SetInt(response, "t", 2);
        JSON_SetInt(response, "s", 2);
        JSON_SetInt(response, "d", 0);
        SendPacketToClient(playerid, 45, response);
        JSON_Cleanup(response);
        return 1;
    }
    
    // ���������, ��������� �� ��� ������
    if(GetStatusFamilyCar(car_id))
    {
        ShowNotificationSile(playerid, 2, 5, -1, -1, "Vehicle is already loaded.", "");
        JSON_SetInt(response, "t", 2);
        JSON_SetInt(response, "s", 2);
        JSON_SetInt(response, "d", 0);
        SendPacketToClient(playerid, 45, response);
        JSON_Cleanup(response);
        return 1;
    }
    
    // �������� ���� ������� � ������
    new rang = 0;
    mysql_format(mysql, f_string64, sizeof f_string64, 
        "SELECT rang FROM family_cars WHERE id = %d", car_id);
    new Cache:rang_cache = mysql_query(mysql, f_string64);
    if(cache_num_rows())
    {
        rang = cache_get_field_content_int(0, "rang");
    }
    cache_delete(rang_cache);
    
    // ��������� ���� ������
    if(GetPlayerRangFamily(playerid) < rang)
    {
        ShowNotificationSile(playerid, 2, 5, -1, -1, "Your rank does not allow you to load this vehicle.", "");
        JSON_SetInt(response, "t", 2);
        JSON_SetInt(response, "s", 2);
        JSON_SetInt(response, "d", 0);
        SendPacketToClient(playerid, 45, response);
        JSON_Cleanup(response);
        return 1;
    }
    
    // ��������� ������
    if(LoadFamilyCarLastPos(car_id))
    {
        JSON_SetInt(response, "t", 2);
        JSON_SetInt(response, "s", 2);
        JSON_SetInt(response, "d", 1);
        
        format(f_string144, sizeof f_string144, "%s %s[%d] loaded the vehicle %s.",
                    family_rang_name[GetPlayerIdFamily(playerid)][GetPlayerFamily(playerid, RANG_FAMILY)-1], GetPlayerNameEx(playerid), playerid, model_name);
                SendFamilyMessage(GetPlayerIdFamily(playerid), f_string144);
                SendFamilyLog(type_log_car, playerid, -1, f_string144);
                ShowNotificationSile(playerid, 3, 5, -1, -1, "Vehicle successfully loaded.", "");
    }
    else
    {
        JSON_SetInt(response, "t", 2);
        JSON_SetInt(response, "s", 2);
        JSON_SetInt(response, "d", 0);
        ShowNotificationSile(playerid, 2, 5, -1, -1, "Error loading vehicle", "");
    }
}
        
        SendPacketToClient(playerid, 45, response);
        JSON_Cleanup(response);
    }
    else // ��������� ������ �����
    {
        printf("[FAMILY] ��������� ������ �����");
        new Node:response = JSON_Object();
        new f = GetPlayerIdFamily(playerid);
        printf("[FAMILY] f = %d", f);
        
        if(f == -1)
        {
            printf("[FAMILY] � ������ ��� �����!");
            ShowNotificationSile(playerid, 2, 5, -1, -1, "You are not in a family.", "");
            return 1;
        }
        
        new family_db = GetFamily(f, family_database);
        printf("[FAMILY] family_db = %d", family_db);
        
        mysql_format(mysql, f_string64, sizeof f_string64, 
            "SELECT * FROM family_cars WHERE family_owner = %d", 
            family_db);
        
        printf("[FAMILY] SQL: %s", f_string64);
        
        new Cache:cache = mysql_query(mysql, f_string64);
        
        if(mysql_errno())
        {
            printf("[FAMILY] SQL ERROR: %d", mysql_errno());
            ShowNotificationSile(playerid, 2, 5, -1, -1, "Error in SQL query", "");
            cache_delete(cache);
            return 1;
        }
        
        new rows = cache_num_rows();
        printf("[FAMILY] rows = %d", rows);
        
        if(rows == 0)
{
    printf("[FAMILY] �������� ���� (0 �����)");
    ShowNotificationSile(playerid, 2, 5, -1, -1, "The vehicle fleet is empty.", "");
    
    // ���������� ������ ������, � �� ���������� �����
    JSON_SetInt(response, "t", 2);
    JSON_SetArray(response, "id", JSON_Array());  // ������ ������
    JSON_SetArray(response, "n", JSON_Array());
    JSON_SetArray(response, "r", JSON_Array());
    JSON_SetArray(response, "st", JSON_Array());
    JSON_SetInt(response, "g", 0);
    
    SendPacketToClient(playerid, 45, response);
    
    cache_delete(cache);
    JSON_Cleanup(response);
    return 1;
}
        
        new Node:carsArray = JSON_Array();
        new Node:carsnameArray = JSON_Array();
        new Node:rangArray = JSON_Array();
        new Node:statusArray = JSON_Array();
        
        for(new i; i < rows; i++)
        {
            new car_id = cache_get_field_content_int(i, "id");
            new model_id = cache_get_field_content_int(i, "model_id");
            new rang = cache_get_field_content_int(i, "rang");
            new status = GetStatusFamilyCar(car_id);
            
            new model_name[64];
            GetVehicleModelName(model_id, model_name, sizeof(model_name));
            
            printf("[FAMILY] ������ %d: id=%d, model=%d, name=%s, rang=%d, status=%d", 
                i, car_id, model_id, model_name, rang, status);
            
            new Node:carNode = JSON_Array(JSON_Int(car_id));
            new Node:carnameNode = JSON_Array(JSON_String(model_name));
            new Node:rangNode = JSON_Array(JSON_Int(rang));
            new Node:statusNode = JSON_Array(JSON_Int(status));
            
            carsArray = JSON_Append(carsArray, carNode);
            carsnameArray = JSON_Append(carsnameArray, carnameNode);
            rangArray = JSON_Append(rangArray, rangNode);
            statusArray = JSON_Append(statusArray, statusNode);
        }
        
        
        JSON_SetInt(response, "t", 2);
        JSON_SetArray(response, "id", carsArray);
        JSON_SetArray(response, "n", carsnameArray);
        JSON_SetArray(response, "r", rangArray);
        JSON_SetArray(response, "st", statusArray);
        JSON_SetInt(response, "g", 0);
        
        new debug_str[2048];
        JSON_Stringify(response, debug_str, sizeof debug_str);
        printf("[FAMILY] �����: %s", debug_str);
        
        SendPacketToClient(playerid, 45, response);
        
        JSON_Cleanup(carsArray);
        JSON_Cleanup(response);
        
        cache_delete(cache);
        printf("[FAMILY] ����� ���������");
    }
}
        case 3: // �������
{
    new item_id;
    JSON_GetInt(JSONObject, "id", item_id);
    printf("[FAMILY] �������: item_id=%d", item_id);
    
    new f = GetPlayerIdFamily(playerid);
    if(f == -1)
    {
        ShowNotificationSile(playerid, 2, 5, -1, -1, "You are not in a family.", "");
        return 1;
    }
    
    
    new item_price = 0;
    new item_object_id = 0;
    new item_server_id = 0;
    new item_title[64];
    new item_type_id = 0;
    
    // ������ �� ������ JSON Shop
    switch(item_id)
    {
        case 0: // ����
        {
            item_price = 80;
            item_object_id = 18526;
            item_server_id = 389;
            format(item_title, sizeof(item_title), "Case");
            item_type_id = 3;
        }
        case 1:
        {
            item_price = 100;
            item_object_id = 7378;
            item_server_id = 442;
            format(item_title, sizeof(item_title), "Katana");
            item_type_id = 0;
        }
        case 2:
        {
            item_price = 60;
            item_object_id = 7344;
            item_server_id = 408;
            format(item_title, sizeof(item_title), "Panama Stone");
            item_type_id = 0;
        }
        case 3:
        {
            item_price = 100;
            item_object_id = 7374;
            item_server_id = 438;
            format(item_title, sizeof(item_title), "Bear");
            item_type_id = 0;
        }
        case 4:
        {
            item_price = 100;
            item_object_id = 7387;
            item_server_id = 451;
            format(item_title, sizeof(item_title), "Shark");
            item_type_id = 0;
        }
        case 5:
        {
            item_price = 100;
            item_object_id = 7385;
            item_server_id = 449;
            format(item_title, sizeof(item_title), "Boat");
            item_type_id = 0;
        }
        case 6:
        {
            item_price = 50;
            item_object_id = 7397;
            item_server_id = 461;
            format(item_title, sizeof(item_title), "Bag");
            item_type_id = 0;
        }
        case 7:
        {
            item_price = 60;
            item_object_id = 7390;
            item_server_id = 454;
            format(item_title, sizeof(item_title), "Guitar");
            item_type_id = 0;
        }
        default:
        {
            ShowNotificationSile(playerid, 2, 5, -1, -1, "Item not found", "");
            return 1;
        }
    }
    
    // �������� �� ������� �������
    new current_tokens = GetPlayerData(playerid, P_FAMILY_TOKEN);
    
    if(current_tokens < item_price)
    {
        ShowNotificationSile(playerid, 2, 5, -1, -1, "Insufficient family tokens!", "");
        
        new Node:response = JSON_Object();
        JSON_SetInt(response, "t", 3);
        JSON_SetInt(response, "s", 0);
        SendPacketToClient(playerid, 45, response);
        JSON_Cleanup(response);
        return 1;
    }
    
    // ������ ��� ����� (type_id == 3)
    if(item_id == 0)
    {
        // ������ ��������� ��������� �� ����� (id ��������� �� ��������)
        new case_items[] = {1, 2, 3, 4, 5, 6, 7}; // ID ��������� ������� ����� �������
        new case_items_count = sizeof(case_items);
        
        // �������� ��������� �������
        new random_index = random(case_items_count);
        new reward_item_id = case_items[random_index];
        
        // �������� ������ ��������� ��������
        new reward_price = 0;
        new reward_server_id = 0;
        new reward_title[64];
        new reward_object_id = 0;
        
        switch(reward_item_id)
        {
            case 1:
            {
                reward_price = 100;
                reward_server_id = 442;
                format(reward_title, sizeof(reward_title), "Katana");
                reward_object_id = 7378;
            }
            case 2:
            {
                reward_price = 60;
                reward_server_id = 408;
                format(reward_title, sizeof(reward_title), "Panama Stone");
                reward_object_id = 7344;
            }
            case 3:
            {
                reward_price = 100;
                reward_server_id = 438;
                format(reward_title, sizeof(reward_title), "Bear");
                reward_object_id = 7374;
            }
            case 4:
            {
                reward_price = 100;
                reward_server_id = 451;
                format(reward_title, sizeof(reward_title), "Shark");
                reward_object_id = 7387;
            }
            case 5:
            {
                reward_price = 100;
                reward_server_id = 449;
                format(reward_title, sizeof(reward_title), "Boat");
                reward_object_id = 7385;
            }
            case 6:
            {
                reward_price = 50;
                reward_server_id = 461;
                format(reward_title, sizeof(reward_title), "Bag");
                reward_object_id = 7397;
            }
            case 7:
            {
                reward_price = 60;
                reward_server_id = 454;
                format(reward_title, sizeof(reward_title), "Guitar");
                reward_object_id = 7390;
            }
        }
        
        // ����� ������� � ���������
        new freeSlot = Inventory_GetFreeSlot(playerid);
        if(freeSlot == -1)
        {
            ShowNotificationSile(playerid, 2, 7, -1, -1, "No free space in inventory!", "");
            return 1;
        }
        
        Inventory_AddItem(playerid, reward_server_id, freeSlot, 1, "");
        SaveInventoryItem(playerid, freeSlot);
        
        // ���������� ������ � �����������
        new dialog_text[512];
        format(dialog_text, sizeof(dialog_text),
            "{FF0000}You opened the case and received:\n\n"\
            "{FFFFFF}Item: {FFB700}%s\n"\
            "{FFFFFF}Value: {FFB700}%d tokens\n\n"\
            "{FFFFFF}Item added to inventory!",
            reward_title, reward_price);
        
        ShowPlayerDialog(playerid, -1, DIALOG_STYLE_MSGBOX, "{FF0000}Case result", dialog_text, "Close", "");
        
        ShowNotificationSile(playerid, 2, 5, -1, -1, "Case opened! Check your inventory.", "");
        
        // ��������� ������ (������ �� ����)
        SetPlayerData(playerid, P_FAMILY_TOKEN, current_tokens - item_price);
        UpdatePlayerDatabaseInt(playerid, "fam_token", GetPlayerData(playerid, P_FAMILY_TOKEN));
        
        // ���������� ����� �� �������� �������
        new Node:response = JSON_Object();
        JSON_SetInt(response, "t", 3);
        JSON_SetInt(response, "s", 1);
        JSON_SetInt(response, "na", GetPlayerData(playerid, P_FAMILY_TOKEN));
        JSON_SetInt(response, "tp", 0);
        
        SendPacketToClient(playerid, 45, response);
        JSON_Cleanup(response);
        
        return 1;
    }
    else // ������� ������� (�� ����)
    {
        // �������� �� ������� ���������� �����
        new freeSlot = Inventory_GetFreeSlot(playerid);
        if(freeSlot == -1)
        {
            ShowNotificationSile(playerid, 2, 7, -1, -1, "No free space in inventory!", "");
            return 1;
        }
        
        // ��������� ������� � ���������
        Inventory_AddItem(playerid, item_server_id, freeSlot, 1, "");
        SaveInventoryItem(playerid, freeSlot);
        
        // ��������� ������
        SetPlayerData(playerid, P_FAMILY_TOKEN, current_tokens - item_price);
        UpdatePlayerDatabaseInt(playerid, "fam_token", GetPlayerData(playerid, P_FAMILY_TOKEN));
        
        // ���������� ����� �� �������� �������
        new Node:response = JSON_Object();
        JSON_SetInt(response, "t", 3);
        JSON_SetInt(response, "s", 1);
        JSON_SetInt(response, "na", GetPlayerData(playerid, P_FAMILY_TOKEN));
        JSON_SetInt(response, "tp", 0);
        
        SendPacketToClient(playerid, 45, response);
        JSON_Cleanup(response);

        ShowNotificationSile(playerid, 2, 5, -1, -1, "Item added to inventory!", "");
        
        return 1;
    }
}
        case 4: // ���������
        {
            new s_value, id_value, f = GetPlayerIdFamily(playerid);
            JSON_GetInt(JSONObject, "s", s_value);
            JSON_GetInt(JSONObject, "id", id_value);
            
            if(f == -1)
            {
           	ShowNotificationSile(playerid, 2, 5, -1, -1, "You are not in a family.", "");
          	 return 1;
            }
            
            new Node:response = JSON_Object();
            JSON_SetInt(response, "t", 4);
            
            if(s_value == 1)
            {
                 switch(id_value) 
                 {
                		case 0:
               		 {
              			if(GetFamily(f, family_money) >= price_up_sklad[GetFamily(f, family_lvl_storage)])
                        {
                            AddFamily(f, family_money, -, price_up_sklad[GetFamily(f, family_lvl_storage)]);
                            SetFamily(f, family_lvl_storage, GetFamily(f, family_lvl_storage)+1);
                            UpdateColumnFamilyInt(GetFamily(f, family_database), "level_storage", GetFamily(f, family_lvl_storage));
                            UpdateColumnFamilyInt(GetFamily(f, family_database), "money", GetFamily(f, family_money));
                            
                            JSON_SetInt(response, "s", 1); 
                            JSON_SetInt(response, "id", 0); 

                            format(f_string144, sizeof f_string144, "%s upgraded the storage to level %d.", GetPlayerNameEx(playerid), GetFamily(f, family_lvl_storage));
                            SendFamilyMessage(f, f_string144);
                        }
                        else 
						{
						 new fmt[512];
						format(fmt, sizeof(fmt), "Not enough money in storage. Need %d more.", price_up_sklad[GetFamily(f, family_lvl_storage)]-GetFamily(f, family_money));
						ShowNotificationSile(playerid, 2, 5, -1, -1, fmt, ""); 
						JSON_SetInt(response, "s", 0);
						} 
              		  } 
             		   case 1:
            			{
           			  if(GetFamily(f, family_money) >= price_up_weapon[GetFamily(f, family_lvl_weapon)])
                        {
                            AddFamily(f, family_money, -, price_up_weapon[GetFamily(f, family_lvl_weapon)]);
                            SetFamily(f, family_lvl_weapon, GetFamily(f, family_lvl_weapon)+1);
                            UpdateColumnFamilyInt(GetFamily(f, family_database), "level_weapon", GetFamily(f, family_lvl_weapon));
                            UpdateColumnFamilyInt(GetFamily(f, family_database), "money", GetFamily(f, family_money));
                            
                            JSON_SetInt(response, "s", 1); 
                            JSON_SetInt(response, "id", 1); 

                            format(f_string144, sizeof f_string144, "%s upgraded weapons to level %d.", GetPlayerNameEx(playerid), GetFamily(f, family_lvl_weapon));
                            SendFamilyMessage(f, f_string144);
                        }
                        else 
						{
						 new fmt[512];
						format(fmt, sizeof(fmt), "Not enough money in storage.");
						ShowNotificationSile(playerid, 2, 5, -1, -1, fmt, ""); 
						JSON_SetInt(response, "s", 0);
						}
           			 } 
          			  case 2:
            			{
           			  if(GetFamily(f, family_money) >= price_up_compound[GetFamily(f, family_lvl_compound)])
                        {
                            AddFamily(f, family_money, -, price_up_compound[GetFamily(f, family_lvl_compound)]);
                            SetFamily(f, family_lvl_compound, GetFamily(f, family_lvl_compound)+1);
                            UpdateColumnFamilyInt(GetFamily(f, family_database), "level_compound", GetFamily(f, family_lvl_compound));
                            UpdateColumnFamilyInt(GetFamily(f, family_database), "money", GetFamily(f, family_money));
                            
                            JSON_SetInt(response, "s", 1); 
                            JSON_SetInt(response, "id", 2); 

                            format(f_string144, sizeof f_string144, "%s upgraded compound to level %d.", GetPlayerNameEx(playerid), GetFamily(f, family_lvl_compound));
                            SendFamilyMessage(f, f_string144);
                        }
                        else 
						{
						 new fmt[512];
						format(fmt, sizeof(fmt), "Insufficient funds in storage.");
						ShowNotificationSile(playerid, 2, 5, -1, -1, fmt, ""); 
						JSON_SetInt(response, "s", 0);
						}
           			 } 
                 }
                 SendPacketToClient(playerid, 45, response);
                 JSON_Cleanup(response);
                 return 1;
            }
            else
            {
           	 JSON_SetInt(response, "s", 3); 
                JSON_SetInt(response, "m", GetFamily(f, family_money));
                
                new Node:upgradesNode = JSON_Array(
                    JSON_Int(GetFamily(f, family_lvl_storage)),
                    JSON_Int(GetFamily(f, family_lvl_weapon)),
                    JSON_Int(GetFamily(f, family_lvl_compound))
                );
                
                JSON_SetArray(response, "y", upgradesNode);
                SendPacketToClient(playerid, 45, response);
                JSON_Cleanup(response);
                JSON_Cleanup(upgradesNode);
                return 1;
            }
        }
        case 5:
{
    new id_value, s_value, r_value, k_value, n_value;
    JSON_GetInt(JSONObject, "id", id_value);
    JSON_GetInt(JSONObject, "s", s_value);
    JSON_GetInt(JSONObject, "r", r_value);
    JSON_GetInt(JSONObject, "k", k_value);
    JSON_GetInt(JSONObject, "n", n_value);
    
    printf("[FAMILY] case 5: id=%d, s=%d, r=%d, k=%d, n=%d", id_value, s_value, r_value, k_value, n_value);
    
    new Node:response = JSON_Object();
    JSON_SetInt(response, "t", 5);
    JSON_SetInt(response, "id", id_value);
    
    if(id_value == 0)
    {
        printf("[FAMILY] �������� �������� ���� (id=0)");
        
        JSON_SetInt(response, "t", 5);
        JSON_SetInt(response, "r", GetFamily(GetPlayerIdFamily(playerid), family_reputation));
        JSON_SetInt(response, "am", GetFamily(GetPlayerIdFamily(playerid), family_count_people));
        JSON_SetInt(response, "s", GetPlayerSkinEx(playerid));
        
        new Node:myNode = JSON_Array(JSON_Int(GetFamily(GetPlayerIdFamily(playerid), family_money)), JSON_Int(count_money_level[GetFamily(GetPlayerIdFamily(playerid), family_lvl_storage)-1]));
        new Node:mkNode = JSON_Array(JSON_Int(GetFamily(GetPlayerIdFamily(playerid), family_material)), JSON_Int(count_material_level[GetFamily(GetPlayerIdFamily(playerid), family_lvl_storage)-1]));
        new Node:msNode = JSON_Array(JSON_Int(GetFamily(GetPlayerIdFamily(playerid), family_mask)), JSON_Int(count_mask_level[GetFamily(GetPlayerIdFamily(playerid), family_lvl_storage)-1]));
        new Node:kbNode = JSON_Array(JSON_Int(0), JSON_Int(0));
        new Node:pnNode = JSON_Array(JSON_Int(GetFamily(GetPlayerIdFamily(playerid), family_patron)), JSON_Int(count_patron_level[GetFamily(GetPlayerIdFamily(playerid), family_lvl_weapon)-1]));
        new Node:btNode = JSON_Array(JSON_Int(GetFamily(GetPlayerIdFamily(playerid), family_armour)), JSON_Int(count_armour_level[GetFamily(GetPlayerIdFamily(playerid), family_lvl_storage)-1]));
        new Node:ugNode = JSON_Array(
            JSON_Int(GetFamily(GetPlayerIdFamily(playerid), family_lvl_storage)), JSON_Int(7),
            JSON_Int(GetFamily(GetPlayerIdFamily(playerid), family_lvl_weapon)), JSON_Int(7),
            JSON_Int(GetFamily(GetPlayerIdFamily(playerid), family_lvl_compound)), JSON_Int(7)
        );
        
        JSON_SetArray(response, "ug", ugNode);
        JSON_SetArray(response, "my", myNode);
        JSON_SetArray(response, "ms", msNode);
        JSON_SetArray(response, "mk", mkNode);
        JSON_SetArray(response, "kb", kbNode);
        JSON_SetArray(response, "bt", btNode);
        JSON_SetArray(response, "pn", pnNode);
        
        SendPacketToClient(playerid, 45, response);
        
        JSON_Cleanup(myNode);
        JSON_Cleanup(mkNode);
        JSON_Cleanup(kbNode);
        JSON_Cleanup(pnNode);
        JSON_Cleanup(ugNode);
        JSON_Cleanup(response);
        return 1;
    }
    else if(id_value == 1)
    {
        printf("[FAMILY] ��������� ������/������ (id=1), s=%d", s_value);
        
        if(s_value == 1) // �������������� �����
{
    new ranksPosition;
    new newRankName[32];
    utf8_to_cp1251(newRankName);
    JSON_GetInt(JSONObject, "r", ranksPosition);
    JSON_GetString(JSONObject, "n", newRankName, sizeof(newRankName));
    
    printf("����: %d, ��������: %s", ranksPosition, newRankName);

    new f = GetPlayerIdFamily(playerid);
    if(f == -1)
    {
        ShowNotificationSile(playerid, 2, 5, -1, -1, "You are not in a family.", "");
        JSON_Cleanup(response);
        return 1;
    }
    
    if(GetPlayerRangFamily(playerid) != 5)
    {
        ShowNotificationSile(playerid, 2, 5, -1, -1, "Only available to the family leader.", "");
        JSON_Cleanup(response);
        return 1;
    }
  
    new len = strlen(newRankName);
    if(len < 3 || len > 24)
    {
        ShowNotificationSile(playerid, 2, 5, -1, -1, "Rank name must be between 3 and 24 characters.", "");
        JSON_Cleanup(response);
        return 1;
    }
    
    if(strfind(newRankName, ",") != -1)
    {
        ShowNotificationSile(playerid, 2, 5, -1, -1, "Rank name cannot contain a comma.", "");
        JSON_Cleanup(response);
        return 1;
    }
  
    format(family_rang_name[f][ranksPosition - 1], 24, newRankName);
   
    UpdateDostupFamily(f, ranksPosition - 1);
   
    JSON_SetInt(response, "t", 5);
    JSON_SetInt(response, "id", 1);
    JSON_SetInt(response, "s", 1);
    JSON_SetInt(response, "n", 1);  
    JSON_SetInt(response, "r", ranksPosition);
    
    SendPacketToClient(playerid, 45, response);
    JSON_Cleanup(response);
    
    
    ShowNotificationSile(playerid, 2, 5, -1, -1, "Rank name changed.", "");
    
    return 1;
}
else if(s_value == 2) // ��������� �������
{
    new access_value;
    JSON_GetInt(JSONObject, "n", access_value);
    printf("[FAMILY] ========== ��������� ������� ==========");
    printf("[FAMILY] ���������: r=%d, k=%d, n=%d", r_value, k_value, access_value);
    
    new f = GetPlayerIdFamily(playerid);
    if(f == -1)
    {
        printf("[FAMILY] ������: ����� �� ������� � �����!");
        ShowNotificationSile(playerid, 2, 5, -1, -1, "You are not in a family.", "");
        JSON_Cleanup(response);
        return 1;
    }
    
    new player_rang = GetPlayerRangFamily(playerid);
    printf("[FAMILY] ���� ������: %d", player_rang);
    
    if(player_rang != 5)
    {
        printf("[FAMILY] ������: ������������ ����!");
        ShowNotificationSile(playerid, 2, 5, -1, -1, "Only the family leader can change permissions.", "");
        JSON_Cleanup(response);
        return 1;
    }
    
    if(r_value >= 1 && r_value <= 5 && k_value >= 0 && k_value <= 5)
    {
        printf("[FAMILY] ������ ���������� ���: ����� %d, ������� %d", r_value, k_value);
        
        // ��������� ���������
        if(access_value == 1) // �������� ������
        {
            // �������� ��� ���������� ����� � ���� ����
            for(new i = r_value - 1; i < 5; i++)
            {
                family_rang_dostup[f][i][k_value] = 0;
                UpdateDostupFamily(f, i);
            }
        }
        else // ��������� ������
        {
            // ��������� ��� ���������� ����� � ���� ����
            for(new i = 0; i <= r_value - 1; i++)
            {
                family_rang_dostup[f][i][k_value] = 1;
                UpdateDostupFamily(f, i);
            }
        }
        
        
        // ����� ��� ������
        JSON_SetInt(response, "t", 5);
        JSON_SetInt(response, "id", 1);
        JSON_SetInt(response, "s", 2);
        JSON_SetInt(response, "n", 1);
        JSON_SetInt(response, "r", r_value);
        JSON_SetInt(response, "k", k_value);
        JSON_SetInt(response, "b", access_value);
    }
    else
    {
        printf("[FAMILY] ������: �������� ���������!");
        ShowNotificationSile(playerid, 2, 5, -1, -1, "Invalid permission parameters", "");
        JSON_Cleanup(response);
        return 1;
    }
    
    SendPacketToClient(playerid, 45, response);
    JSON_Cleanup(response);
    return 1;
}
        else if(s_value == 3) // ��������� �����
{
    printf("[FAMILY] ��������� �����, r=%d", r_value);
    
    new f = GetPlayerIdFamily(playerid);
    if(f == -1)
    {
        ShowNotificationSile(playerid, 2, 5, -1, -1, "You are not in a family.", "");
        JSON_Cleanup(response);
        return 1;
    }
    
    // ��������, ��� ����� ����� ����� �������� ���� (������ �����)
    if(GetPlayerRangFamily(playerid) != 5)
    {
        ShowNotificationSile(playerid, 2, 5, -1, -1, "Only the leader can change the family color.", "");
        JSON_Cleanup(response);
        return 1;
    }
    
    // ��������, ��� ���� ���������� (0-17)
    if(r_value >= 0 && r_value <= 17)
    {
        SetFamily(f, family_color, r_value);
        UpdateColumnFamilyInt(GetFamily(f, family_database), "color", r_value);
        
        JSON_SetInt(response, "t", 5);
        JSON_SetInt(response, "s", 3);
        JSON_SetInt(response, "n", 1);
        JSON_SetInt(response, "r", r_value);
    }
    else
    {
        ShowNotificationSile(playerid, 2, 5, -1, -1, "Invalid color ID!", "");
        JSON_Cleanup(response);
        return 1;
    }
    
    SendPacketToClient(playerid, 45, response);
    JSON_Cleanup(response);
    return 1;
}
else // ��������� ������ ������
{
    printf("[FAMILY] ��������� ������ ������");
    
    new f = GetPlayerIdFamily(playerid);
    if(f == -1)
    {
        ShowNotificationSile(playerid, 2, 5, -1, -1, "You are not in a family.", "");
        JSON_Cleanup(response);
        return 1;
    }
    
    JSON_SetInt(response, "t", 5);
    JSON_SetInt(response, "id", 1);
    JSON_SetInt(response, "st", 1);
    JSON_SetInt(response, "cl", GetFamily(f, family_color));
    
    // �������� ������
    new Node:ranksArray = JSON_Array(
        JSON_String(family_rang_name[f][0]), 
        JSON_String(family_rang_name[f][1]), 
        JSON_String(family_rang_name[f][2]),
        JSON_String(family_rang_name[f][3]),
        JSON_String(family_rang_name[f][4])
    );
    
    // ������ �������� (6 ��������)
    new Node:dostupArray = JSON_Array();
    
    for(new d = 0; d < 6; d++)
    {
        new min_rank = 0;
        // ���� � 1 ����� �����
        for(new i = 0; i < 5; i++)
        {
            if(family_rang_dostup[f][i][d] == 0) // 0 - ���������
            {
                min_rank = i + 1;
                break;
            }
        }
        
        // ���� �� ���� ���� �� ������ (min_rank = 0), ������ 5 (������ �����) ��� 1 (���)
        // ����� ������ �� ����� ���������� ��� ����, ����� 5 - ������ �����
        if(min_rank == 0) min_rank = 5; // ��� 1, � ����������� �� ����, ���� �� ������ ���� ������
        
        printf("[FAMILY] ������ %d: ����������� ���� = %d", d, min_rank);
        
        new Node:dostupNode = JSON_Array(JSON_Int(min_rank));
        dostupArray = JSON_Append(dostupArray, dostupNode);
    }
    
    JSON_SetArray(response, "r", ranksArray);
    JSON_SetArray(response, "rp", dostupArray);
    
    new otvet[2054];
    JSON_Stringify(response, otvet, sizeof(otvet));
    printf("[FAMILY] �����: %s", otvet);
    
    SendPacketToClient(playerid, 45, response);
    
    JSON_Cleanup(ranksArray);
    JSON_Cleanup(dostupArray);
    JSON_Cleanup(response);
    
    return 1;
}
        SendPacketToClient(playerid, 45, response);
        JSON_Cleanup(response);
        return 1;
    }
    else if(id_value == 2)
    {
        printf("[FAMILY] ���������� �������� (id=2), s=%d", s_value);
        
        if(s_value == 1)
        {
            new players_nick[24];
            JSON_GetString(JSONObject, "n", players_nick, sizeof(players_nick));
            printf("[FAMILY] ���������� �� ������: %s", players_nick);
            SetPVarString(playerid, "last_selected_player", players_nick);
            
            new f = GetPlayerIdFamily(playerid);
            if(f == -1)
            {
                ShowNotificationSile(playerid, 2, 5, -1, -1, "You are not in a family.", "");
                JSON_Cleanup(response);
                return 1;
            }
            
            new family_db = GetFamily(f, family_database);
            
            mysql_format(mysql, f_string184, sizeof f_string184,
                "SELECT id, family_rang, family_mute, level, skin, phone FROM accounts WHERE family_id = %d AND name = '%e'",
                family_db, players_nick);
            
            printf("[FAMILY] SQL: %s", f_string184);
            
            new Cache:cache = mysql_query(mysql, f_string184);
            
            if(mysql_errno())
            {
                printf("[FAMILY] SQL ERROR: %d", mysql_errno());
                ShowNotificationSile(playerid, 2, 5, -1, -1, "SQL Error", "");
                cache_delete(cache);
                JSON_Cleanup(response);
                return 1;
            }
            
            new rows = cache_num_rows();
            printf("[FAMILY] ������� �����: %d", rows);
            
            if(rows == 0)
            {
                ShowNotificationSile(playerid, 2, 5, -1, -1, "Player not found in family", "");
                cache_delete(cache);
                JSON_Cleanup(response);
                return 1;
            }
            
            new target_account_id = cache_get_field_content_int(0, "id");
            new family_rang = cache_get_field_content_int(0, "family_rang");
            new family_mute = cache_get_field_content_int(0, "family_mute");
            new level = cache_get_field_content_int(0, "level");
            new skin_id = cache_get_field_content_int(0, "skin");
            new phone = cache_get_field_content_int(0, "phone");
            
            printf("[FAMILY] ������ �� ��: id=%d, rang=%d, mute=%d, level=%d, skin=%d, phone=%d",
                target_account_id, family_rang, family_mute, level, skin_id, phone);
            
            cache_delete(cache);
            
            new rank_name[32];
            if(family_rang >= 1 && family_rang <= 5)
            {
                format(rank_name, sizeof(rank_name), "%s", family_rang_name[f][family_rang - 1]);
            }
            else
            {
                format(rank_name, sizeof(rank_name), "Private");
            }
            
            new status = 0;
            new mute_time = family_mute;
            new bool:is_online = false;
            
            foreach(new p : Player)
            {
                if(IsPlayerConnected(p) && GetPlayerAccountID(p) == target_account_id)
                {
                    is_online = true;
                    status = 1;
                    
                    new player_mute = GetPlayerFamily(p, MUTE_FAMILY);
                    if(player_mute > 0 && player_mute > gettime())
                    {
                        status = 2;
                        mute_time = player_mute - gettime();
                    }
                    break;
                }
            }
            
            if(!is_online && family_mute > 0 && family_mute > gettime())
            {
                status = 2;
                mute_time = family_mute - gettime();
            }
            
            new reprimands = 0;
            if(mute_time > 0)
            {
                new mute_minutes = mute_time / 60;
                if(mute_minutes > 60) reprimands = 3;
                else if(mute_minutes > 30) reprimands = 2;
                else reprimands = 1;
            }
            
            new Node:infoResponse = JSON_Object();
            JSON_SetInt(infoResponse, "t", 5);
            JSON_SetInt(infoResponse, "id", 2);
            JSON_SetInt(infoResponse, "s", 1);
            JSON_SetInt(infoResponse, "sk", skin_id);
            JSON_SetInt(infoResponse, "rk", family_rang);
            JSON_SetInt(infoResponse, "rb", level);
            JSON_SetInt(infoResponse, "rv", reprimands);
            JSON_SetInt(infoResponse, "rp", phone);
            JSON_SetInt(infoResponse, "m", mute_time);
            JSON_SetString(infoResponse, "rn", rank_name);
            
            new debug_str[1024];
            JSON_Stringify(infoResponse, debug_str, sizeof debug_str);
            printf("[FAMILY] ���������� �� ������ %s: %s", players_nick, debug_str);
            
            SendPacketToClient(playerid, 45, infoResponse);
            JSON_Cleanup(infoResponse);
            
            return 1;
        }
        else if(s_value == 2)
{
    new action_type, action_value;
    JSON_GetInt(JSONObject, "r", action_type);
    JSON_GetInt(JSONObject, "k", action_value);
    printf("[FAMILY] �������� � �������: type=%d, value=%d", action_type, action_value);
    
    // �������� �������� ��� �� �������
    new target_nick[128];
    JSON_GetString(JSONObject, "n", target_nick, sizeof(target_nick));
    
    // ���� ��� �� �������, ��Ш� �� �����ͨ�����
    if(strlen(target_nick) == 0)
    {
        GetPVarString(playerid, "last_selected_player", target_nick, sizeof(target_nick));
        printf("[FAMILY] ��� ���� �� ������������: %s", target_nick);
    }
    
    if(strlen(target_nick) == 0)
    {
        ShowNotificationSile(playerid, 2, 5, -1, -1, "No player selected for action", "");
        JSON_Cleanup(response);
        return 1;
    }
    
    printf("[FAMILY] ����: %s", target_nick);
    
    new Node:act_response = JSON_Object();
    JSON_SetInt(act_response, "t", 5);
    JSON_SetInt(act_response, "id", 2);
    JSON_SetInt(act_response, "s", 2);
    
    new f = GetPlayerIdFamily(playerid);
    if(f == -1)
    {
        ShowNotificationSile(playerid, 2, 5, -1, -1, "You are not in a family", "");
        JSON_Cleanup(act_response);
        return 1;
    }
    
    new family_db = GetFamily(f, family_database);
    new player_rang = GetPlayerRangFamily(playerid);
    
    // �������� ������ ���� �� ��
    mysql_format(mysql, f_string184, sizeof f_string184,
        "SELECT id, family_rang, family_mute FROM accounts WHERE family_id = %d AND name = '%e'",
        family_db, target_nick);
    
    new Cache:cache = mysql_query(mysql, f_string184);
    
    if(mysql_errno() || cache_num_rows() == 0)
    {
        printf("[FAMILY] ����� %s �� ������ � �����", target_nick);
        ShowNotificationSile(playerid, 2, 5, -1, -1, "Player not found in family", "");
        cache_delete(cache);
        JSON_Cleanup(act_response);
        return 1;
    }
    
    new target_account_id = cache_get_field_content_int(0, "id");
    new target_rang = cache_get_field_content_int(0, "family_rang");
    new target_mute = cache_get_field_content_int(0, "family_mute");
    
    cache_delete(cache);
    
    // �������� �� ����
    if(target_account_id == GetPlayerAccountID(playerid))
    {
        ShowNotificationSile(playerid, 2, 5, -1, -1, "You cannot interact with yourself.", "");
        JSON_Cleanup(act_response);
        return 1;
    }
    // �������� ���� (������ ������� �����������)
    if(target_rang >= player_rang && player_rang != 5)
    {
        ShowNotificationSile(playerid, 2, 5, -1, -1, "Cannot perform action on a player with equal or higher rank", "");
        JSON_Cleanup(act_response);
        return 1;
    }
    
    // ������� playerid ���� (���� ������)
    new target_playerid = -1;
    foreach(new i : Player)
    {
        if(IsPlayerConnected(i) && GetPlayerAccountID(i) == target_account_id)
        {
            target_playerid = i;
            break;
        }
    }
    
    switch(action_value)
    {
        case 0: // �����
        {
            if(action_type == 0) // �������� ����
            {
           	if(!family_rang_dostup[f][GetPlayerRangFamily(playerid)-1][2])
           {
           ShowNotificationSile(playerid, 2, 5, -1, -1, "You do not have permission to use this function", "");
        JSON_Cleanup(act_response);
        return 1;
       } 
                if(target_rang <= 1)
                {
                    ShowNotificationSile(playerid, 2, 5, -1, -1, "Cannot lower rank below 1", "");
                    JSON_Cleanup(act_response);
                    return 1;
                }
                
                new new_rang = target_rang - 1;
                
                mysql_format(mysql, f_string64, sizeof f_string64,
                    "UPDATE accounts SET family_rang = %d WHERE id = %d", new_rang, target_account_id);
                mysql_query(mysql, f_string64, false);
                
                if(target_playerid != -1)
                {
                    SetPlayerFamily(target_playerid, RANG_FAMILY, new_rang);
                }
                
                format(f_string144, sizeof f_string144, "%s %s[%d] lowered the rank of %s from %d to %d",
                    family_rang_name[f][GetPlayerFamily(playerid, RANG_FAMILY)-1], GetPlayerNameEx(playerid), playerid, target_nick, target_rang, new_rang);
                SendFamilyMessage(f, f_string144);
                SendFamilyLog(type_log_rang, playerid, target_account_id, f_string144);
                
                ShowNotificationSile(playerid, 2, 5, -1, -1, "Rank changed", "");
                JSON_SetInt(act_response, "r", 1);
            }
            else if(action_type == 2) // ��������� ���
            {
           	if(!family_rang_dostup[f][GetPlayerRangFamily(playerid)-1][3])
           {
           ShowNotificationSile(playerid, 2, 5, -1, -1, "You do not have permission to use this function", "");
        JSON_Cleanup(act_response);
        return 1;
       }  
                new current_time = gettime();
                new mute_minutes = 10;
                new new_mute = 0;
                
                if(target_mute > current_time)
                {
                    new_mute = target_mute - (mute_minutes * 60);
                    if(new_mute < current_time) new_mute = 0;
                }
                else
                {
                    ShowNotificationSile(playerid, 2, 5, -1, -1, "Player does not have an active mute", "");
                    JSON_Cleanup(act_response);
                    return 1;
                }
                
                mysql_format(mysql, f_string64, sizeof f_string64,
                    "UPDATE accounts SET family_mute = %d WHERE id = %d", new_mute, target_account_id);
                mysql_query(mysql, f_string64, false);
                
                if(target_playerid != -1)
                {
                    SetPlayerFamily(target_playerid, MUTE_FAMILY, new_mute);
                }
                
                format(f_string144, sizeof f_string144, "%s %s[%d] reduced mute for %s by %d minutes",
                    family_rang_name[f][GetPlayerFamily(playerid, RANG_FAMILY)-1], GetPlayerNameEx(playerid), playerid, target_nick, mute_minutes);
                SendFamilyMessage(f, f_string144);
                SendFamilyLog(type_log_kick, playerid, target_account_id, f_string144);
                
                ShowNotificationSile(playerid, 2, 5, -1, -1, "Mute reduced by 10 minutes", "");
                JSON_SetInt(act_response, "r", 1);
            }
            else if(action_type == 3) // ���
            {
           	if(!family_rang_dostup[f][GetPlayerRangFamily(playerid)-1][1] && GetPlayerRangFamily(playerid) != 5)
          	{
           	 ShowNotificationSile(playerid, 2, 5, -1, -1, "You do not have permission to use this function", "");
       		 JSON_Cleanup(act_response);
        		return 1; 
       		} 
                new kick_reason[64] = "Not specified";
                JSON_GetString(JSONObject, "t", kick_reason, sizeof(kick_reason));
                
                if(target_playerid != -1)
                {
                    SetPlayerFamily(target_playerid, ID_FAMILY, -1);
                    SetPlayerFamily(target_playerid, ID_SQL_FAMILY, -1);
                    SetPlayerFamily(target_playerid, RANG_FAMILY, 0);
                    SetPlayerFamily(target_playerid, MUTE_FAMILY, 0);
                    SetPlayerFamily(target_playerid, ACCESS_GIVE, 0);
                    SetPlayerFamily(target_playerid, ACCESS_MONEY, 0);
                    SetPlayerFamily(target_playerid, ACCESS_ARMOUR, 0);
                    SetPlayerFamily(target_playerid, ACCESS_MATERIAL, 0);
                    SetPlayerFamily(target_playerid, ACCESS_HEATH_KIT, 0);
                    SetPlayerFamily(target_playerid, ACCESS_PATRON, 0);
                    SetPlayerFamily(target_playerid, ACCESS_MASK, 0);
                    
                    UpdatePlayerDatabaseInt(target_playerid, "family_id", -1);
                    UpdatePlayerDatabaseInt(target_playerid, "family_rang", 0);
                    UpdatePlayerDatabaseInt(target_playerid, "family_mute", 0);
                    
                    ShowNotificationSile(target_playerid, 2, 5, -1, -1, "You have been kicked from the family!", "");
                }
                else
                {
                    mysql_format(mysql, f_string184, sizeof f_string184,
                        "UPDATE accounts SET family_id = -1, family_rang = 0, family_mute = 0 WHERE id = %d", target_account_id);
                    mysql_query(mysql, f_string184, false);
                }
                
                AddFamily(f, family_count_people, -, 1);
                
                format(f_string144, sizeof f_string144, "%s %s[%d] kicked %s from the family. Reason: %s",
                    family_rang_name[f][GetPlayerFamily(playerid, RANG_FAMILY)-1], GetPlayerNameEx(playerid), playerid, target_nick, kick_reason);
                SendFamilyMessage(f, f_string144);
                SendFamilyLog(type_log_kick, playerid, target_account_id, f_string144);
                
                ShowNotificationSile(playerid, 2, 5, -1, -1, "Player kicked from the family", "");
                JSON_SetInt(act_response, "r", 1);
            }
        }
        case 1: // ����
        {
            if(action_type == 0) // �������� ����
            {
           	if(!family_rang_dostup[f][GetPlayerRangFamily(playerid)-1][2])
           {
           ShowNotificationSile(playerid, 2, 5, -1, -1, "You do not have permission to use this function", "");
        JSON_Cleanup(act_response);
        return 1;
       }  
                if(target_rang >= 4)
                {
                    ShowNotificationSile(playerid, 2, 5, -1, -1, "Cannot raise rank above 5", "");
                    JSON_Cleanup(act_response);
                    return 1;
                }
                
                new new_rang = target_rang + 1;
                
                mysql_format(mysql, f_string64, sizeof f_string64,
                    "UPDATE accounts SET family_rang = %d WHERE id = %d", new_rang, target_account_id);
                mysql_query(mysql, f_string64, false);
                
                if(target_playerid != -1)
                {
                    SetPlayerFamily(target_playerid, RANG_FAMILY, new_rang);
                }
                
                format(f_string144, sizeof f_string144, "%s %s[%d] raised the rank of %s from %d to %d",
                    family_rang_name[f][GetPlayerFamily(playerid, RANG_FAMILY)-1], GetPlayerNameEx(playerid), playerid, target_nick, target_rang, new_rang);
                SendFamilyMessage(f, f_string144);
                SendFamilyLog(type_log_rang, playerid, target_account_id, f_string144);
                
                ShowNotificationSile(playerid, 2, 5, -1, -1, "Rank raised", "");
                JSON_SetInt(act_response, "r", 1);
            }
            else if(action_type == 2) // ��������� ���
            {
           	if(!family_rang_dostup[f][GetPlayerRangFamily(playerid)-1][3])
           {
           ShowNotificationSile(playerid, 2, 5, -1, -1, "You do not have permission to use this function", "");
        JSON_Cleanup(act_response);
        return 1;
       } 
                new current_time = gettime();
                new mute_minutes = 10;
                new new_mute = 0;
                new max_mute = current_time + (60 * 60);
                
                if(target_mute > current_time)
                {
                    new_mute = target_mute + (mute_minutes * 60);
                }
                else
                {
                    new_mute = current_time + (mute_minutes * 60);
                }
                
                if(new_mute > max_mute)
                {
                    ShowNotificationSile(playerid, 2, 5, -1, -1, "Cannot give a mute longer than 60 minutes!", "");
                    JSON_Cleanup(act_response);
                    return 1;
                }
                
                mysql_format(mysql, f_string64, sizeof f_string64,
                    "UPDATE accounts SET family_mute = %d WHERE id = %d", new_mute, target_account_id);
                mysql_query(mysql, f_string64, false);
                
                if(target_playerid != -1)
                {
                    SetPlayerFamily(target_playerid, MUTE_FAMILY, new_mute);
                }
                
                format(f_string144, sizeof f_string144, "%s %s[%d] increased mute for %s by %d minutes",
                    family_rang_name[f][GetPlayerFamily(playerid, RANG_FAMILY)-1], GetPlayerNameEx(playerid), playerid, target_nick, mute_minutes);
                SendFamilyMessage(f, f_string144);
                
                ShowNotificationSile(playerid, 2, 5, -1, -1, "Mute increased by 10 minutes", "");
                JSON_SetInt(act_response, "r", 1);
            }
        }
    }
    
    SendPacketToClient(playerid, 45, act_response);
    JSON_Cleanup(act_response);
    
    return 1;
}
        else
        {
            printf("[FAMILY] ��������� ������ �������");
            
            new f = GetPlayerIdFamily(playerid);
            if(f == -1)
            {
                ShowNotificationSile(playerid, 2, 5, -1, -1, "You are not in a family.", "");
                JSON_Cleanup(response);
                return 1;
            }
            
            new family_db = GetFamily(f, family_database);
            
            mysql_format(mysql, f_string184, sizeof f_string184,
                "SELECT name, family_rang, family_mute FROM accounts WHERE family_id = %d", family_db);
            new Cache:cache = mysql_query(mysql, f_string184);
            
            if(mysql_errno())
            {
                printf("[FAMILY] SQL ERROR: %d", mysql_errno());
                ShowNotificationSile(playerid, 2, 5, -1, -1, "Error retrieving player list", "");
                cache_delete(cache);
                JSON_Cleanup(response);
                return 1;
            }
            
            new rows = cache_num_rows();
            printf("[FAMILY] ������� �������: %d", rows);
            
            new Node:nicksArray = JSON_Array();
            new Node:infoArray = JSON_Array();
            
            new name_buf[24];
            
            for(new i; i < rows; i++)
            {
                cache_get_field_content(i, "name", name_buf, mysql, 24);
                new family_rang = cache_get_field_content_int(i, "family_rang");
                new family_mute = cache_get_field_content_int(i, "family_mute");
                
                printf("[FAMILY] ����� %d: %s, ����=%d, ���=%d", i + 1, name_buf, family_rang, family_mute);
                
                new status = 0;
                
                foreach(new p : Player)
                {
                    if(IsPlayerConnected(p) && strcmp(GetPlayerNameEx(p), name_buf, true) == 0)
                    {
                        status = 1;
                        if(family_mute > 0) status = 2;
                        break;
                    }
                }
                
                new nicksNode = JSON_Array(JSON_String(name_buf));
                new infoNode = JSON_Array(JSON_Int(family_rang), JSON_Int(status));
                
                nicksArray = JSON_Append(nicksArray, nicksNode);
                infoArray = JSON_Append(infoArray, infoNode);
            }
            
            cache_delete(cache);
            
            JSON_SetInt(response, "t", 5);
            JSON_SetInt(response, "id", 2);
            JSON_SetInt(response, "s", 0);
            JSON_SetArray(response, "np", nicksArray);
            JSON_SetArray(response, "rs", infoArray);
            
            new debug_str[2048];
            JSON_Stringify(response, debug_str, sizeof debug_str);
            printf("[FAMILY] ����� ������ �������: %s", debug_str);
            
            SendPacketToClient(playerid, 45, response);
            
            JSON_Cleanup(nicksArray);
            JSON_Cleanup(infoArray);
            JSON_Cleanup(response);
            
            printf("[FAMILY] ������ ������� ���������");
            return 1;
        }
    }
    else if(id_value == 3) // �����/����
{
    printf("[FAMILY] �����/���� (id=3), r=%d, s=%d", r_value, s_value);
    
    new f = GetPlayerIdFamily(playerid);
    if(f == -1)
    {
        ShowNotificationSile(playerid, 2, 5, -1, -1, "You are not in a family.", "");
        JSON_Cleanup(response);
        return 1;
    }
    JSON_SetInt(response, "t", 5);
    JSON_SetInt(response, "id", 3);
    JSON_SetInt(response, "r", r_value);
    
    if(r_value == 1) // �����
    {
   	JSON_SetInt(response, "s", 1);
        if(s_value == 1) // ������� �����
        {
            ShowNotificationSile(playerid, 2, 5, -1, -1, "Storage is temporarily unavailable.", "");
            JSON_SetInt(response, "s", 1);
        }
    }
    else if(r_value == 0) // ����
    {
   	JSON_SetInt(response, "s", 0);
        if(s_value == 0) // ������� ����
        {
            // ��������� ������� /famsklad
            callcmd::famsklad(playerid);
            JSON_SetInt(response, "s", 0);
            HidePlayerGUI(playerid, 45);
        }
    }
    
    SendPacketToClient(playerid, 45, response);
    JSON_Cleanup(response);
    return 1;
}
    else if(id_value == 4) 
{
    printf("[FAMILY] ���� ����� (id=4)");
    
    new f = GetPlayerIdFamily(playerid);
    if(f == -1)
    {
        ShowNotificationSile(playerid, 2, 5, -1, -1, "You are not in a family.", "");
        JSON_Cleanup(response);
        return 1;
    }
    
    if(GetPlayerRangFamily(playerid) != 5)
    {
        ShowNotificationSile(playerid, 2, 5, -1, -1, "Only available to the leader.", "");
        JSON_Cleanup(response);
        return 1;
    }
    
    DeletePVar(playerid, "select_type_log");
   
    ShowPlayerDialog
    (
        playerid, 2237, DIALOG_STYLE_LIST,
        "{FF0000}Select log", 
        "1. Accepting new family members\n"\
        "2. Firing family members\n"\
        "3. Interaction with storage money\n"\
        "4. Interaction with storage materials\n"\
        "5. Interaction with storage masks\n"\
        "6. Interaction with storage medkits\n"\
        "7. Interaction with storage weapons\n"\
        "8. Interaction with storage bulletproof vests\n"\
        "9. Interaction with family vehicle fleet\n"\
        "10. Rank assignments\n"\
        "11. Access assignments",
        "Next", "Back"
    );
    
    JSON_SetInt(response, "s", 1);
    SendPacketToClient(playerid, 45, response);
    JSON_Cleanup(response);
    
    return 1;
}
    else if(id_value == 5)
    {
        printf("[FAMILY] ������ ������ (id=5)");
        JSON_SetInt(response, "s", 1);
        SendPacketToClient(playerid, 45, response);
        JSON_Cleanup(response);
        ShowNotificationSile(playerid, 2, 5, -1, -1, "Temporarily unavailable.", "");
        return 1;
    }
    
    JSON_Cleanup(response);
    printf("[FAMILY] case 5 ��������, id=%d �� ���������", id_value);
    return 1;
}
        case 6: // �����������
{
    new b;
    JSON_GetInt(JSONObject, "b", b);
    new f = GetPlayerIdFamily(playerid);
    new Node:response = JSON_Object();
    
    
    if(f == -1)
    {
        ShowNotificationSile(playerid, 2, 5, -1, -1, "Error");
        JSON_Cleanup(response);
        return 1;
    }
    
    if(b == 1)
    {
    	new msg[258];
        utf8_to_cp1251(msg);
        JSON_GetString(JSONObject, "m", msg);
        printf("%s ��������� ��� �����", msg);
        
        if(strlen(msg) < 1)
        {
       	 ShowNotificationSile(playerid, 2, 5, -1, -1, "Enter text", "");
        }
        new fm_db = GetFamily(f, family_database);
        
        mysql_format(mysql, f_string184, sizeof f_string184, "INSERT INTO family_ad (family, ad_text, create_id, create_name, time) VALUES ('%d', '%s', '%d', '%s', '%d')", GetPlayerFamily(playerid, ID_SQL_FAMILY),\
                        msg, GetPlayerAccountID(playerid), GetPlayerNameEx(playerid), gettime()+10800);
                        mysql_query(mysql, f_string184, false);
                        
                        /*JSON_SetInt(response, "t", 6);
                        JSON_SetInt(response, "b", 1);
                        JSON_SetString(response, "k", msg);
                        JSON_SetString(response, "n", GetPlayerNameEx(playerid));
                        JSON_SetInt(response, "x", 0);
                        
                        SendPacketToClient(playerid, 45, response);*/
                        new json_str[2054];
                        format(json_str, sizeof(json_str),
        "{\"t\":6,\"b\":1,\"k\":\"%s\",\"n\":\"%s\",\"x\":0}",
        msg, GetPlayerNameEx(playerid));
    printf("����� �����, ��� %s", json_str);
    SendPacketToClientString(playerid, 45, json_str);
                        
        JSON_Cleanup(response);
        return 1;
    }
    else if(b == 2)
    {
   	 new xid;
        JSON_GetInt(JSONObject, "x", xid);
        
        mysql_format(mysql, f_string64, sizeof f_string64, "DELETE FROM family_ad WHERE id = %d", xid);
                    new Cache:cache = mysql_query(mysql, f_string64);
                    
                    JSON_SetInt(response, "t", 6);
                    JSON_SetInt(response, "b", 2);
                    JSON_SetInt(response, "d", xid);
                    JSON_SetInt(response, "x", -1);
                    
                    SendPacketToClient(playerid, 45, response);
        JSON_Cleanup(response);
        return 1;
    }
    else
    {
        mysql_format(mysql, f_string64, sizeof f_string64, 
            "SELECT * FROM family_ad WHERE family = %d", GetPlayerFamily(playerid, ID_SQL_FAMILY));
        new Cache:cache = mysql_query(mysql, f_string64);

        if(mysql_errno())
        {
            printf("[FAMILY] ������ SQL: %d", mysql_errno());
            SendClientMessage(playerid, -1, ""c_f_r" Error in SQL query");
            cache_delete(cache);
            JSON_Cleanup(response);
            return 1;
        }

        new rows = cache_num_rows();
        printf("[FAMILY] ������� �����������: %d", rows);
        
        new Node:mArray = JSON_Array();
        new Node:xArray = JSON_Array();
        
        for(new i; i < rows; i++)
        {
            new ad_text[62];
            new create_name[24];
            new id;
            
            cache_get_field_content(i, "ad_text", ad_text, mysql, 62);
            cache_get_field_content(i, "create_name", create_name, mysql, 24);
            id = cache_get_field_content_int(i, "id");
            
            printf("[FAMILY] %d: �����=%s, �����=%s, id=%d", i, ad_text, create_name, id);
            
            // ���������� ���������: ������ ������� mArray = [�����, �����]
            new Node:mNode = JSON_Array(
                JSON_String(ad_text),
                JSON_String(create_name)
            );
            mArray = JSON_Append(mArray, mNode);
            
            // ���������� ���������: ������ ������� xArray = [id]
            new Node:xNode = JSON_Array(JSON_Int(id));
            xArray = JSON_Append(xArray, xNode);
        }
        
        JSON_SetInt(response, "t", 6);
        JSON_SetArray(response, "m", mArray);
        JSON_SetArray(response, "x", xArray);
        JSON_SetInt(response, "b", 0);
        
        new debug_str[2048];
        JSON_Stringify(response, debug_str, sizeof(debug_str));
        printf("[FAMILY] ����� �����������: %s", debug_str);
        
        SendPacketToClient(playerid, 45, response);
        
        JSON_Cleanup(mArray);
        JSON_Cleanup(xArray);
        JSON_Cleanup(response);
        cache_delete(cache);
    }
    return 1;
}
        case 7: // �������
{
    printf("[FAMILY] ������ �������� �����");
    
    new f = GetPlayerIdFamily(playerid);
    if(f == -1)
    {
        ShowNotificationSile(playerid, 2, 5, -1, -1, "You are not in a family.", "");
        return 1;
    }
    
    new Node:ratingResponse = JSON_Object();
    
    mysql_format(mysql, f_string184, sizeof f_string184, 
        "SELECT id, name, reputation FROM family ORDER BY reputation DESC LIMIT 20");
    new Cache:result = mysql_query(mysql, f_string184);
    
    if(mysql_errno())
    {
        printf("[FAMILY] SQL Error: %d", mysql_errno());
        cache_delete(result);
        return 1;
    }
    
    new rows = cache_num_rows();
    printf("[FAMILY] ������� �����: %d", rows);
    
    new database_family = GetFamily(f, family_database);
    new my_reputation = GetFamily(f, family_reputation);
    new my_position = -1;
    
    JSON_SetInt(ratingResponse, "t", 7);
    JSON_SetInt(ratingResponse, "r", 1500);
    JSON_SetInt(ratingResponse, "tz", 0);
    JSON_SetInt(ratingResponse, "tr", my_reputation);
    
    new Node:pointsArray = JSON_Array();
    new Node:nameArray = JSON_Array();
    
    for(new i; i < rows; i++)
    {
        new id = cache_get_field_content_int(i, "id");
        new reputation = cache_get_field_content_int(i, "reputation");
        new name[32];
        cache_get_field_content(i, "name", name, mysql, 32);
        
        // �����: pointsNode ������ ��������� reputation, 0, 0
        new Node:pointsNode = JSON_Array(
            JSON_Int(reputation), 
            JSON_Int(0), 
            JSON_Int(0)
        );
        pointsArray = JSON_Append(pointsArray, pointsNode);
        
        new Node:nameNode = JSON_Array(JSON_String(name));
        nameArray = JSON_Append(nameArray, nameNode);
        
        if(id == database_family)
        {
            my_position = i + 1;
        }
    }
    
    cache_delete(result);
    
    if(my_position == -1)
    {
        my_position = rows + 1;
    }
    
    JSON_SetInt(ratingResponse, "p", my_position);
    JSON_SetInt(ratingResponse, "tp", 3);
    JSON_SetArray(ratingResponse, "m", pointsArray);
    JSON_SetArray(ratingResponse, "mn", nameArray);
    
    SendPacketToClient(playerid, 45, ratingResponse);
    
    JSON_Cleanup(pointsArray);
    JSON_Cleanup(nameArray);
    JSON_Cleanup(ratingResponse);
    
    return 1;
}
        case 8: // �������� ����������
        {
            new Node:response = JSON_Object();
			DeletePVar(playerid, "last_selected_player");
            JSON_SetInt(response, "t", 8);
            SendPacketToClient(playerid, 45, response);
            JSON_Cleanup(response);
        }
        case 9: // ������ (������� �������)
{
    new s_value, token_value;
    JSON_GetInt(JSONObject, "s", s_value);
    JSON_GetInt(JSONObject, "v", token_value);
    
    new Node:response = JSON_Object();
    JSON_SetInt(response, "t", 9);
    
    if(s_value == 1) // ������ ��������� (�������� �������)
    {
        new price = token_value * 10;
        JSON_SetInt(response, "s", 1);
        JSON_SetInt(response, "m", price); // ���� �� 1 �����
        JSON_SetInt(response, "tp", 0);
        
        SendPacketToClient(playerid, 45, response);
        JSON_Cleanup(response);
        return 1;
    }
    else if(s_value == 2) // ������� �������
    {
        new count = token_value; // ���������� �������
        if(count <= 0)
        {
            ShowNotificationSile(playerid, 2, 5, -1, -1, "Enter a valid number of tokens!", "");
            return 1;
        }
        
        new price = count * 10; // 1 ����� = 10 �����-������
        new current_donate = GetPlayerDonateRub(playerid);
        
        if(current_donate >= price)
        {
            // ��������� �����-�����
            GivePlayerDonateRub(playerid, -price);
            
            // ��������� ������ ������
            new current_tokens = GetPlayerData(playerid, P_FAMILY_TOKEN);
            SetPlayerData(playerid, P_FAMILY_TOKEN, current_tokens + count);
            UpdatePlayerDatabaseInt(playerid, "fam_token", GetPlayerData(playerid, P_FAMILY_TOKEN));
            
            // ���������� ����� �� �������� �������
            JSON_SetInt(response, "s", 2);
            JSON_SetInt(response, "r", 1); // �����
            JSON_SetInt(response, "m", GetPlayerData(playerid, P_FAMILY_TOKEN)); // ������� �����-������
            JSON_SetInt(response, "bc", GetPlayerDonateRub(playerid)); // ������� ������� �����
            
            SendPacketToClient(playerid, 45, response);
            JSON_Cleanup(response);
        }
        else
        {
            // ������������ �������
            JSON_SetInt(response, "s", 2);
            JSON_SetInt(response, "r", 0); // ������
            JSON_SetInt(response, "need", price - current_donate); // ������� �� �������
            
            SendPacketToClient(playerid, 45, response);
            JSON_Cleanup(response);
            
            ShowNotificationSile(playerid, 2, 5, -1, -1, "Insufficient BC!", "");
        }
        
        return 1;
    }
    
    return 1;
}
        case 10: // ������� ������������� (�������� �����)
{
    new s_value;
    JSON_GetInt(JSONObject, "s", s_value);
    
    new Node:response = JSON_Object();
    JSON_SetInt(response, "t", 10);
    
    if(s_value == 0) // ������������� ������ �� �����
    {
        new f = GetPlayerIdFamily(playerid);
        if(f == -1)
        {
            ShowNotificationSile(playerid, 2, 5, -1, -1, "You are not in a family.", "");
            JSON_Cleanup(response);
            return 1;
        }
        
        new player_rang = GetPlayerRangFamily(playerid);
        
        if(player_rang == 5) // ����� ������� ��� �����
        {
            new family_sql = GetFamily(f, family_database);
            new leader_id = GetPlayerAccountID(playerid);
            new leader_name[24];
            GetPlayerName(playerid, leader_name, sizeof(leader_name));
            
            // ���������� ��� ������ ������
            mysql_format(mysql, f_string184, sizeof f_string184, 
                "SELECT id, model_id, color_1, color_2, pos_x, pos_y, pos_z, angle, number, region, number_type FROM family_cars WHERE family_owner = %d", family_sql);
            new Cache:cars_cache = mysql_query(mysql, f_string184);
            
            new rows = cache_num_rows();
            printf("[FAMILY] ���������� %d ����� ������", rows);
            
            new cars_returned = 0;
            
            for(new i; i < rows; i++)
            {
                new model_id = cache_get_field_content_int(i, "model_id");
                new color_1 = cache_get_field_content_int(i, "color_1");
                new color_2 = cache_get_field_content_int(i, "color_2");
                new Float:pos_x = cache_get_field_content_float(i, "pos_x");
                new Float:pos_y = cache_get_field_content_float(i, "pos_y");
                new Float:pos_z = cache_get_field_content_float(i, "pos_z");
                new Float:angle = cache_get_field_content_float(i, "angle");
                new number[32];
                cache_get_field_content(i, "number", number, mysql, 32);
                new region[8];
                cache_get_field_content(i, "region", region, mysql, 8);
                new number_type = cache_get_field_content_int(i, "number_type");
                
                
                    new free_car_id = GetFreeOwnableCarID();
                    if(free_car_id != -1)
                    {
                        SetOwnableCarData(free_car_id, OC_OWNER_ID, leader_id);
                        SetOwnableCarData(free_car_id, OC_MODEL_ID, model_id);
                        SetOwnableCarData(free_car_id, OC_COLOR_1, color_1);
                        SetOwnableCarData(free_car_id, OC_COLOR_2, color_2);
                        SetOwnableCarData(free_car_id, OC_POS_X, pos_x);
                        SetOwnableCarData(free_car_id, OC_POS_Y, pos_y);
                        SetOwnableCarData(free_car_id, OC_POS_Z, pos_z);
                        SetOwnableCarData(free_car_id, OC_ANGLE, angle);
                        strmid(g_ownable_car[free_car_id][OC_NUMBER], number, 0, strlen(number), 32);
                        strmid(g_ownable_car[free_car_id][OC_REGION], region, 0, strlen(region), 8);
                        SetOwnableCarData(free_car_id, OC_NUMBER_TYPE, number_type);
                        SetOwnableCarData(free_car_id, OC_CREATE, gettime());
                        format(g_ownable_car[free_car_id][OC_OWNER_NAME], 24, leader_name);
                        
                        new query[1024];
                        mysql_format(mysql, query, sizeof(query), 
                            "INSERT INTO ownable_cars (owner_id, model_id, color_1, color_2, pos_x, pos_y, pos_z, angle, number, region, number_type, create_time) \
                            VALUES (%d, %d, %d, %d, %f, %f, %f, %f, '%s', '%s', %d, %d)",
                            leader_id, model_id, color_1, color_2, pos_x, pos_y, pos_z, angle, number, region, number_type, gettime());
                        mysql_query(mysql, query, false);
                    }
            }
            
            cache_delete(cars_cache);
            
            // ������� ���� ������� �� �����
            foreach(new i : Player)
            {
                if(GetPlayerFamily(i, ID_SQL_FAMILY) == family_sql)
                {
                    ExitFromFamily(i);
                    SendClientMessage(i, -1, ""c_f_r"The leader disbanded the family. Family removed.");
                }
            }
            
            // ������� ��� ������ �� �������� (��� ��� ����������)
            mysql_format(mysql, f_string144, sizeof f_string144, 
                "DELETE FROM family_cars WHERE family_owner = %d", family_sql);
            mysql_query(mysql, f_string144);
            
            // ������� ���� �����
            mysql_format(mysql, f_string144, sizeof f_string144, 
                "DELETE FROM family_log WHERE family = %d", family_sql);
            mysql_query(mysql, f_string144);
            
            // ������� ���������� �����
            mysql_format(mysql, f_string144, sizeof f_string144, 
                "DELETE FROM family_ad WHERE family = %d", family_sql);
            mysql_query(mysql, f_string144);
            
            // ������� ���� �����
            mysql_format(mysql, f_string64, sizeof f_string64, 
                "DELETE FROM family WHERE id = %d", family_sql);
            mysql_query(mysql, f_string64);
            
            // ��������� ��������
            mysql_format(mysql, f_string144, sizeof f_string144, 
                "UPDATE accounts SET family_id = -1 WHERE family_id = %d", family_sql);
            mysql_query(mysql, f_string144);
            
            // ������� ������ ����� � �������
            SetFamily(f, family_database, -1);
            SetFamily(f, family_color, 0);
            SetFamily(f, family_reputation, 0);
            format(GetFamily(f, family_name), 32, "");
            SetFamily(f, family_owner, 0);
            SetFamily(f, family_slot_veh, 0);
            SetFamily(f, family_count_veh, 0);
            SetFamily(f, family_count_people, 0);
            SetFamily(f, family_status_storage, 0);
            SetFamily(f, family_money, 0);
            SetFamily(f, family_armour, 0);
            SetFamily(f, family_material, 0);
            SetFamily(f, family_heath_kit, 0);
            SetFamily(f, family_patron, 0);
            SetFamily(f, family_mask, 0);
            SetFamily(f, family_lvl_storage, 0);
            SetFamily(f, family_lvl_weapon, 0);
            SetFamily(f, family_lvl_compound, 0);
            
            
            ShowNotificationSile(playerid, 2, 5, -1, -1, "You left the family, and it was disbanded.", "");
        }
        else // ������� ����� �������� �����
        {
            
            format(f_string144, sizeof f_string144, "%s left the family.", GetPlayerNameEx(playerid));
            SendFamilyMessage(f, f_string144);
            SendFamilyLog(type_log_kick, playerid, -1, f_string144);
            
            ExitFromFamily(playerid);
            
            ShowNotificationSile(playerid, 2, 5, -1, -1, "You left the family.", "");
        }
        
        JSON_SetInt(response, "s", 1);
        SendPacketToClient(playerid, 45, response);
        JSON_Cleanup(response);
        
        return 1;
    }
    
    SendPacketToClient(playerid, 45, response);
    JSON_Cleanup(response);
    return 1;
}
    }
    SendPacketToClient(playerid, 45, JSONObject);
}

alias:family("fm", "fmenu", "fammenu ","fam")
CMD:family(playerid, params[])
{
    new f = GetPlayerIdFamily(playerid);
    if(f == -1)
        return ShowNotificationSile(playerid, 2, 6, -1, -1, "You are not in a family.", "");
   
    new ld_flag = (GetPlayerRangFamily(playerid) == 5) ? 1 : 0;
    
    new Node:family_response = JSON_Object(
        "o", JSON_Int(1),
        "t", JSON_Int(0), 
        "n", JSON_String(GetFamily(f, family_name)),
        "k", JSON_Int(ld_flag),  
        "m", JSON_Int(GetPlayerData(playerid, P_FAMILY_TOKEN)),  
        "j", JSON_Int(0),  
        "y", JSON_Int(0), 
        "b", JSON_Int(4),  
        "pn", JSON_String(GetPlayerNameEx(playerid)),  
        "pi", JSON_Int(playerid),  
        "is", JSON_Int(1)  
    );
    
    SendPacketToClient(playerid, 45, family_response);
    JSON_Cleanup(family_response);
    return 1;
}

alias:famsklad("fs", "fsklad")
CMD:famsklad(playerid)
{
    if(GetPlayerIdFamily(playerid) == -1)
        return SendClientMessage(playerid, -1, ""c_f"You don't have a family.");    

    format(f_string144, sizeof f_string144,
    "| Storage: %s\n1. Take from storage\n2. Put into storage\n3. Access", GetFamily(GetPlayerIdFamily(playerid), family_status_storage) ? ("{FF0000}Closed") : ("{00FF00}Open"));

   ShowPlayerDialog(playerid, 2223, DIALOG_STYLE_LIST, "{FF0000}Family storage", f_string144, "Next", "Exit");
    return 1;
}

CMD:fam(playerid, params[])
{
    if(GetPlayerIdFamily(playerid) == -1)
        return SendClientMessage(playerid, -1, ""c_f"You don't have a family."); 

    if(!strlen(params)) return SendClientMessage(playerid, 0xFFFFFFFF, ""c_f_r"Usage: /fam [text]");   

    if(GetPlayerFamily(playerid, MUTE_FAMILY) > 0) 
        return SendClientMessage(playerid, -1, ""c_f_r"You are muted in the family chat.");

    new message[254];

    extract params -> new string:text[125];

    format(message, sizeof message, "%s %s[%d]: %s", family_rang_name[GetPlayerIdFamily(playerid)][GetPlayerFamily(playerid, RANG_FAMILY)-1], GetPlayerNameEx(playerid), playerid, text);
    SendFamilyMessage(GetPlayerIdFamily(playerid), message);
    return 1;
}

CMD:fammute(playerid, params[])
{
    new f = GetPlayerIdFamily(playerid);

    if(f == -1)
        return SendClientMessage(playerid, -1, ""c_f"You don't have a family."); 
    
    new to_player, count, prichina[12];
    if(sscanf(params, "dds[12]", to_player, count, prichina))
        return SendClientMessage(playerid, -1, ""c_f_r"/fammute [Player ID] [Minutes] [Reason (up to 12 chars)]");

    if(GetPlayerIdFamily(to_player) != f)
        return SendClientMessage(playerid, -1, ""c_f_r"The player is not in your family.");

    if(!family_rang_dostup[f][GetPlayerRangFamily(playerid)-1][3])
        return SendClientMessage(playerid, -1, ""c_f_r"Your rank cannot give mutes.");
    
    if(!IsPlayerConnected(to_player) || to_player == playerid)
        return SendClientMessage(playerid, -1, ""c_f_r"The player is offline.");

    if(GetPlayerRangFamily(to_player) >= GetPlayerRangFamily(playerid))
        return SendClientMessage(playerid, -1, ""c_f_r"The player has the same or higher rank.");

    if(GetPlayerFamily(to_player, MUTE_FAMILY) >= 1) return SendClientMessage(playerid, -1, ""c_f_r"The player already has a mute");

    if(count > 180 || !count)
        return SendClientMessage(playerid, -1, ""c_f_r" Mute time must not exceed 180 minutes.");
    
    SetPlayerFamily(to_player, MUTE_FAMILY, 60*count);

    format(f_string144, sizeof f_string144, "%s gave a mute to %s for %d minutes. Reason: %s", GetPlayerNameEx(playerid), GetPlayerNameEx(to_player), count,
    prichina);
    SendFamilyMessage(f, f_string144);

    return 1;
}

CMD:unfammute(playerid, params[])
{
    new f = GetPlayerIdFamily(playerid);

    if(f == -1)
        return SendClientMessage(playerid, -1, ""c_f"You don't have a family."); 
    
    new to_player, prichina[12];
    if(sscanf(params, "ds[12]", to_player, prichina))
        return SendClientMessage(playerid, -1, ""c_f_r"/unfammute [Player ID] [Reason (up to 12 chars)]");

    if(GetPlayerIdFamily(to_player) != f)
        return SendClientMessage(playerid, -1, ""c_f_r"The player is not in your family.");

    if(!family_rang_dostup[f][GetPlayerRangFamily(playerid)-1][3])
        return SendClientMessage(playerid, -1, ""c_f_r"Your rank cannot remove mutes.");
    
    if(!IsPlayerConnected(to_player) || to_player == playerid)
        return SendClientMessage(playerid, -1, ""c_f_r"The player is offline.");

    if(GetPlayerRangFamily(to_player) >= GetPlayerRangFamily(playerid))
        return SendClientMessage(playerid, -1, ""c_f_r"The player has the same or higher rank.");

    if(GetPlayerFamily(to_player, MUTE_FAMILY) == 0) return SendClientMessage(playerid, -1, ""c_f_r"The player does not have a mute");

    SetPlayerFamily(to_player, MUTE_FAMILY, 0);

    format(f_string144, sizeof f_string144, "%s removed the mute from %s. Reason: %s", GetPlayerNameEx(playerid), GetPlayerNameEx(to_player),
    prichina);
    SendFamilyMessage(f, f_string144);

    return 1;
}

stock CreateFamInviteOfferPTD(playerid)
{
	faminvite_offer_PTD[playerid][0] = CreatePlayerTextDraw(playerid, 320.000000, 350.000000, "_");
	PlayerTextDrawLetterSize(playerid, faminvite_offer_PTD[playerid][0], 0.220000, 1.100000);
	PlayerTextDrawAlignment(playerid, faminvite_offer_PTD[playerid][0], 2);
	PlayerTextDrawColor(playerid, faminvite_offer_PTD[playerid][0], -1);
	PlayerTextDrawSetShadow(playerid, faminvite_offer_PTD[playerid][0], 0);
	PlayerTextDrawSetOutline(playerid, faminvite_offer_PTD[playerid][0], 1);
	PlayerTextDrawBackgroundColor(playerid, faminvite_offer_PTD[playerid][0], 0);
	PlayerTextDrawFont(playerid, faminvite_offer_PTD[playerid][0], 1);
	PlayerTextDrawSetProportional(playerid, faminvite_offer_PTD[playerid][0], 1);
	PlayerTextDrawUseBox(playerid, faminvite_offer_PTD[playerid][0], 1);
	PlayerTextDrawBoxColor(playerid, faminvite_offer_PTD[playerid][0], 0x00000099);
	PlayerTextDrawTextSize(playerid, faminvite_offer_PTD[playerid][0], 400.000000, 0.000000);

	faminvite_offer_PTD[playerid][1] = CreatePlayerTextDraw(playerid, 260.000000, 380.000000, "Yes, join now");
	PlayerTextDrawLetterSize(playerid, faminvite_offer_PTD[playerid][1], 0.230000, 1.200000);
	PlayerTextDrawAlignment(playerid, faminvite_offer_PTD[playerid][1], 1);
	PlayerTextDrawColor(playerid, faminvite_offer_PTD[playerid][1], 0x66CC00FF);
	PlayerTextDrawSetShadow(playerid, faminvite_offer_PTD[playerid][1], 0);
	PlayerTextDrawSetOutline(playerid, faminvite_offer_PTD[playerid][1], 1);
	PlayerTextDrawBackgroundColor(playerid, faminvite_offer_PTD[playerid][1], 0);
	PlayerTextDrawFont(playerid, faminvite_offer_PTD[playerid][1], 1);
	PlayerTextDrawSetProportional(playerid, faminvite_offer_PTD[playerid][1], 1);
	PlayerTextDrawSetSelectable(playerid, faminvite_offer_PTD[playerid][1], true);

	faminvite_offer_PTD[playerid][2] = CreatePlayerTextDraw(playerid, 260.000000, 398.000000, "No, I don't want to join");
	PlayerTextDrawLetterSize(playerid, faminvite_offer_PTD[playerid][2], 0.230000, 1.200000);
	PlayerTextDrawAlignment(playerid, faminvite_offer_PTD[playerid][2], 1);
	PlayerTextDrawColor(playerid, faminvite_offer_PTD[playerid][2], 0xFF3333FF);
	PlayerTextDrawSetShadow(playerid, faminvite_offer_PTD[playerid][2], 0);
	PlayerTextDrawSetOutline(playerid, faminvite_offer_PTD[playerid][2], 1);
	PlayerTextDrawBackgroundColor(playerid, faminvite_offer_PTD[playerid][2], 0);
	PlayerTextDrawFont(playerid, faminvite_offer_PTD[playerid][2], 1);
	PlayerTextDrawSetProportional(playerid, faminvite_offer_PTD[playerid][2], 1);
	PlayerTextDrawSetSelectable(playerid, faminvite_offer_PTD[playerid][2], true);

	HideFamInviteOfferPTD(playerid);

	return 1;
}

stock ShowFamInviteOfferPTD(playerid, from_playerid, f)
{
	new label_text[144];

	format(label_text, sizeof label_text, "%s invites you to the family %s", GetPlayerNameEx(from_playerid), GetFamily(f, family_name));

	PlayerTextDrawSetString(playerid, faminvite_offer_PTD[playerid][0], label_text);

	PlayerTextDrawShow(playerid, faminvite_offer_PTD[playerid][0]);
	PlayerTextDrawShow(playerid, faminvite_offer_PTD[playerid][1]);
	PlayerTextDrawShow(playerid, faminvite_offer_PTD[playerid][2]);

	SelectTextDraw(playerid, 0x66CC00FF);

	return 1;
}

stock HideFamInviteOfferPTD(playerid)
{
	PlayerTextDrawHide(playerid, faminvite_offer_PTD[playerid][0]);
	PlayerTextDrawHide(playerid, faminvite_offer_PTD[playerid][1]);
	PlayerTextDrawHide(playerid, faminvite_offer_PTD[playerid][2]);

	CancelSelectTextDraw(playerid);

	return 1;
}

// Shared by the dialog (id 2243) response below and by clicking the "Yes"
// textdraw row - same effect either way. Guarded against being run twice
// (dialog click + textdraw click both firing) since the underlying flow
// had no such guard originally.
stock AcceptFamilyInvite(playerid)
{
    if(GetPlayerIdFamily(playerid) != -1)
        return 0;

    new fff, player = GetPVarInt(playerid, "invite_player");

    fff = GetPlayerIdFamily(player);

    UpdatePlayerDatabaseInt(playerid, "family_id", GetPlayerFamily(player, ID_SQL_FAMILY));
    UpdatePlayerDatabaseInt(playerid, "family_rang", 1);

    LoadPlayerFamily(playerid);
    SendClientMessage(player, -1, ""c_f"You accepted the player into the family.");
    format(f_string144, sizeof f_string144, "%s accepted %s into the family", GetPlayerNameEx(player), GetPlayerNameEx(playerid));
    SendFamilyMessage(fff, f_string144);
    SendFamilyLog(type_log_invite, playerid, player, f_string144);
    if(GetPlayerData(playerid, P_QUEST_7) == 0)
    {
        SendClientMessage(playerid, COR_SERVER, "{ffffff}You have successfully completed the quest {009900}'Join a family'. {ffffff}Your reward: {009900}10000 rub");
        SendClientMessage(playerid, COR_SERVER, "{ffffff}Type {009900}/quest{ffffff} for detailed information about your quests");
        GivePlayerMoneyEx(playerid, 10000, "Quest completion");
        SetPlayerData(player, P_QUEST_7, 1);
        UpdatePlayerDatabaseInt(player, "quest_7", 1);
    }

    return 1;
}

stock DeclineFamilyInvite(playerid)
{
    SendClientMessage(GetPVarInt(playerid, "invite_player"), -1, ""c_f"The player declined your offer.");
    SendClientMessage(playerid, -1, ""c_f"You declined the offer.");

    return 1;
}

CMD:faminvite(playerid, params[])
{
    new f = GetPlayerIdFamily(playerid);

    if(f == -1)
        return SendClientMessage(playerid, -1, ""c_f"You don't have a family."); 
    
    new to_player;
    if(sscanf(params, "d", to_player))
        return SendClientMessage(playerid, -1, ""c_f_r"/faminvite [Player ID]");

    if(family_rang_dostup[f][GetPlayerRangFamily(playerid)-1][0])
        return SendClientMessage(playerid, -1, ""c_f_r"Your rank cannot accept players.");
    
    if(!IsPlayerConnected(to_player) || to_player == playerid)
        return SendClientMessage(playerid, -1, ""c_f_r"The player is offline.");

    if(GetPlayerIdFamily(to_player) != -1)
        return SendClientMessage(playerid, -1, ""c_f_r"The player already has a family.");

    if(GetFamily(f, family_count_people)+1 > count_compound_level[GetFamily(f, family_lvl_compound)-1])
        return SendClientMessage(playerid, -1, ""c_f_r"The family is full.");

	if(!IsPlayerInRangeOfPlayer(playerid, to_player, 5.0))
		return SendClientMessage(playerid, 0xCECECEFF, "The player is too far away");

    format(f_string144, sizeof f_string144, "{FFFF00}%s{FFFFFF} invites you to the family %s",
    GetPlayerNameEx(playerid), GetFamily(f, family_name));

    ShowPlayerDialog
    (
        to_player, 2243, DIALOG_STYLE_MSGBOX,
        "{FF0000}Family invitation",
        f_string144,
        "Accept", "Decline"
    );

    ShowFamInviteOfferPTD(to_player, playerid, f);

    SetPVarInt(to_player, "invite_player", playerid);

    return 1;
}

CMD:unfaminvite(playerid, params[])
{
    new f = GetPlayerIdFamily(playerid);

    if(f == -1)
        return SendClientMessage(playerid, -1, ""c_f"You don't have a family."); 
    
    new to_player,prichinaept[12];
    if(sscanf(params, "ds[12]", to_player, prichinaept))
        return SendClientMessage(playerid, -1, ""c_f_r"/unfaminvite [Player ID] [Reason (up to 12 chars)]");

    if(!family_rang_dostup[f][GetPlayerRangFamily(playerid)-1][1] && GetPlayerRangFamily(playerid) != 5)
        return SendClientMessage(playerid, -1, ""c_f_r"Your rank cannot kick players.");
    
    if(!IsPlayerConnected(to_player) || to_player == playerid)
        return SendClientMessage(playerid, -1, ""c_f_r"The player is offline.");

    if(GetPlayerIdFamily(to_player) != f)
        return SendClientMessage(playerid, -1, ""c_f_r"The player is not in your family.");

    SetPlayerFamily(to_player, ID_FAMILY, -1);
    SetPlayerFamily(to_player, ID_SQL_FAMILY, -1);
    
    DestroyDynamic3DTextLabel(GetPlayerFamily(to_player, TEXT_FAMILY));
    SetPlayerFamily(to_player, TEXT_FAMILY, STREAMER_TAG_3D_TEXT_LABEL:-1);

    SetPlayerFamily(to_player, RANG_FAMILY, 0);
    SetPlayerFamily(to_player, MUTE_FAMILY, 0);
    //SetPlayerFamily(to_player, WARN_FAMILY, 0);

    SetPlayerFamily(to_player, ACCESS_GIVE, 0);
    SetPlayerFamily(to_player, ACCESS_MONEY, 0);
    SetPlayerFamily(to_player, ACCESS_ARMOUR, 0);
    SetPlayerFamily(to_player, ACCESS_MATERIAL, 0);
    SetPlayerFamily(to_player, ACCESS_HEATH_KIT, 0);
    SetPlayerFamily(to_player, ACCESS_PATRON, 0);
    SetPlayerFamily(to_player, ACCESS_MASK, 0);

    UpdatePlayerDatabaseInt(to_player, "family_id", GetPlayerFamily(to_player, ID_FAMILY));
    UpdatePlayerDatabaseInt(to_player, "family_rang", GetPlayerFamily(to_player, RANG_FAMILY));
    UpdatePlayerDatabaseInt(to_player, "family_mute", GetPlayerFamily(to_player, MUTE_FAMILY));
    //UpdatePlayerDatabaseInt(to_player, "family_warn", GetPlayerFamily(to_player, WARN_FAMILY));
    UpdateAccessPlayerFamily(to_player);
    AddFamily(f, family_count_people, -, 1);


    format(f_string144, sizeof f_string144, "%s kicked %s from the family. Reason:%s", GetPlayerNameEx(playerid), GetPlayerNameEx(to_player), prichinaept);
    SendFamilyLog(type_log_kick, playerid, to_player, f_string144);
    SendFamilyMessage(f, f_string144);

    return 1;
}

stock SendFamilyLog(type, playerid, to_player = -1, text[])
{
    new string[324], sql;

    if(to_player != -1) sql = GetPlayerAccountID(to_player);
    else sql = -1;

    mysql_format(mysql, string, sizeof string, "INSERT INTO family_log (family,player,to_player,text,time,type) VALUES (%d,%d,%d,'%s',%d,%d)", GetPlayerFamily(playerid, ID_SQL_FAMILY), GetPlayerAccountID(playerid),
    sql, text, gettime()+10800, type);
    mysql_query(mysql, string, false);

    if(mysql_errno()) return printf("error insert family_log");

    return 1;
}


stock ShowMembersFamily(playerid, listitem)
{
    new list = GetPVarInt(playerid, "count_list");

    if(listitem == 0)  list++;
    else if(listitem == 1 && list != 1) list--;
    SetPVarInt(playerid, "count_list", list);

    new Cache: result;

    mysql_format(mysql, f_string144, sizeof f_string144, "SELECT * FROM accounts WHERE family_id = %d", GetFamily(GetPlayerIdFamily(playerid), family_database));
    result = mysql_query(mysql, f_string144, true);
    if(mysql_errno()) return SendClientMessage(playerid, -1, "error");

    new rows = cache_num_rows();
    
    new count_rows, count = 10 * GetPVarInt(playerid, "count_list");

    if(rows >= count) count_rows = count;
    else count_rows = rows;

    new d_list[86], dialog[sizeof d_list*10+50] = "Next page\nPrevious page\n", family_rang, bool:online, id, name[24], last_login, data[54];
    
    for(new i = count-10, da = 2; i < count_rows;i++, da++)
    {
        online = false;
        id = cache_get_field_content_int(i, "id");
        cache_get_field_content(i, "name", name, mysql, 24);
        last_login = cache_get_field_content_int(i, "last_login");
        family_rang = cache_get_field_content_int(i, "family_rang");

        format(f_string32, sizeof f_string32, "p_familyrang%d", da);
        SetPVarInt(playerid, f_string32, family_rang);
        format(f_string32, sizeof f_string32, "p_familyname%d", da);
        SetPVarString(playerid, f_string32, name);

        foreach(new yo : Player)
        {
            if(GetPlayerAccountID(yo) != id) continue;
            online = true;
            break;
        }

        if(!online)
        {
            format(data, sizeof data, "%02d.%02d.%d %02d:%02d:%02d", ConvertUnixTime(last_login, CONVERT_TIME_TO_DAYS), ConvertUnixTime(last_login, CONVERT_TIME_TO_MONTHS),
            ConvertUnixTime(last_login, CONVERT_TIME_TO_YEARS), ConvertUnixTime(last_login, CONVERT_TIME_TO_HOURS), ConvertUnixTime(last_login, CONVERT_TIME_TO_MINUTES), ConvertUnixTime(last_login, CONVERT_TIME_TO_SECONDS));
        }
        else format(data, sizeof data, "{00FF00}Online{FFFFFF}");

        format(d_list, sizeof d_list, "%s %s\n", name, data);
        strcat(dialog, d_list);
        SetPlayerListitemValue(playerid, da, id);
    }


    ShowPlayerDialog
    (
        playerid, 2236, DIALOG_STYLE_LIST,
        "{FF0000}Select player to kick",
        dialog,
        "Select", "Close"
    );
    SetPVarInt(playerid, "prichina", 0);
    SetPVarInt(playerid, "select_type_2236", 2);
    cache_delete(result);
    return 1;
}

stock GetVehicleDriver(vehicleid)
{
    foreach(new i : Player)
    {
        if(GetPlayerVehicleID(i) == vehicleid) return i;
    }
    return INVALID_PLAYER_ID;
}

public OnPlayerEnterVehicle(playerid, vehicleid, ispassenger)
{
    if(GetVehicleData(vehicleid, V_ACTION_TYPE) == VEHICLE_ACTION_TYPE_FAMILY_CAR){
        new id = GetVehicleData(vehicleid, V_ACTION_ID);
        
		if(GetPlayerRangFamily(playerid) < GetCarFamily(id, V_F_RANG))
        {
            ClearAnimations(playerid);
            return SendClientMessage(playerid, -1, ""c_f_r"You do not have access to this vehicle.");
        }
    }
    #if defined fam_OnPlayerEnterVehicle
        return fam_OnPlayerEnterVehicle(playerid, vehicleid, ispassenger);
    #else
        return 1;
    #endif
}
   #if defined _ALS_OnPlayerEnterVehicle
    #undef OnPlayerEnterVehicle
#else
    #define _ALS_OnPlayerEnterVehicle
#endif
#define OnPlayerEnterVehicle fam_OnPlayerEnterVehicle
#if defined fam_OnPlayerEnterVehicle
    forward fam_OnPlayerEnterVehicle(playerid, vehicleid, ispassenger);
#endif

stock ExitFromFamily(playerid)
{
    new f = GetPlayerIdFamily(playerid);

    AddFamily(f, family_count_people, -, 1);

    SetPlayerFamily(playerid, ID_FAMILY, -1);
    SetPlayerFamily(playerid, ID_SQL_FAMILY, -1);
    
    DestroyDynamic3DTextLabel(GetPlayerFamily(playerid, TEXT_FAMILY));
    SetPlayerFamily(playerid, TEXT_FAMILY, STREAMER_TAG_3D_TEXT_LABEL:-1);

    SetPlayerFamily(playerid, RANG_FAMILY, 0);
    SetPlayerFamily(playerid, MUTE_FAMILY, 0);
    //SetPlayerFamily(playerid, WARN_FAMILY, 0);

    SetPlayerFamily(playerid, ACCESS_GIVE, 0);
    SetPlayerFamily(playerid, ACCESS_MONEY, 0);
    SetPlayerFamily(playerid, ACCESS_ARMOUR, 0);
    SetPlayerFamily(playerid, ACCESS_MATERIAL, 0);
    SetPlayerFamily(playerid, ACCESS_HEATH_KIT, 0);
    SetPlayerFamily(playerid, ACCESS_PATRON, 0);
    SetPlayerFamily(playerid, ACCESS_MASK, 0);

    mysql_format(mysql, f_string144, sizeof f_string144, "UPDATE accounts SET family_id=%d, family_rang=%d, family_mute=%d WHERE id = %d", 
    GetPlayerFamily(playerid, ID_SQL_FAMILY), GetPlayerRangFamily(playerid), GetPlayerFamily(playerid, MUTE_FAMILY), GetPlayerAccountID(playerid));
    mysql_query(mysql, f_string144, false);
    if(mysql_errno()) return printf("ERROR SQL (%s)", f_string144);
    //UpdatePlayerDatabaseInt(playerid, "family_warn", GetPlayerFamily(playerid, WARN_FAMILY));
    UpdateAccessPlayerFamily(playerid);

    return 1;
}