enum E_BAN_SPECTATE_STRUCT
{
    BSP_REASON[128],
    BSP_TIME
}

new const b_ban_spectate[][E_BAN_SPECTATE_STRUCT] =
{
    {"Mass DM", 7},
    {"Insulting family", 14},
    {"Third-party software", 9999},
    {"Bug abuse", 9999},
    {"Buying/Selling Items", 9999},
    {"Advertising", 30},
    {"Damage to economy", 9999},
    {"Incitement of ethnic hatred", 7},
    {"Political/Religious propaganda", 9999},
    {"OOC threats", 7},
    {"Damage to project resources", 9999},
    {"Promo advertising", 14},
    {"Misleading", 15}
};

enum E_MUTE_SPECTATE_STRUCT
{
	MSP_REASON[128],
	MSP_TIME
}

new const b_mute_spectate[][E_MUTE_SPECTATE_STRUCT] =
{
	{"MetaGaming", 30},
	{"Mentioning family", 120},
	{"Disrespect to administration", 120},
	{"CapsLock", 60},
	{"Flood", 30},
	{"Insulting admin", 120},
	{"Translit", 30},
	{"Disrespect to admin", 180},
	{"CapsLock", 60},
	{"Insult", 30},
	{"OOC threats", 120}
};

enum E_JAIL_SPECTATE_STRUCT
{
	JSP_REASON[128],
	JSP_TIME
}

new const b_jail_spectate[][E_JAIL_SPECTATE_STRUCT] =
{
	{"Murder without reason", 60},
	{"Vehicle murder", 60},
	{"Team killing", 60},
	{"nRP behavior", 30},
	{"nRP driving", 30},
	{"Driving off-road", 60},
	{"SpawnKill", 60},
	{"PowerGaming", 30},
	{"RevengKill", 60},
	{"Friendly fire", 60}
};

enum E_WARN_SPECTATE_STRUCT
{
	WSP_REASON[128]
}

new const b_warn_spectate[][E_WARN_SPECTATE_STRUCT] =
{
	{"nRP military unit"},
	{"Immoral actions"},
	{"Avoiding RP"},
	{"Misleading with commands"},
	{"Mass SpawnKill(SK)"},
	{"Mass TeamKill(TK)"},
	{"Mass Death-Match(DM)"},
	{"Transferring IC conflict to OOC"}
};

stock ShowReportsGUI(playerid, name[], text[])
{
    new Node:json = JSON_Object();
    JSON_SetInt(json, "t", 3);
    JSON_SetInt(json, "id", playerid);
    JSON_SetString(json, "pn", name, strlen(name));
    JSON_SetString(json, "tr", text, strlen(text));

    ShowPlayerGUI(playerid, 66, json);
    JSON_Cleanup(json);
    return 1;
}

stock ShowControlPanelGUI(playerid)
{
    new Node:json = JSON_Object();
    JSON_SetInt(json, "t", 6);

    ShowPlayerGUI(playerid, 66, json);
    JSON_Cleanup(json);
    return 1;
}


CMD:showtools(playerid, params[])
{
    new screenType;
    if(sscanf(params, "d", screenType)) return SendClientMessage(playerid, -1, "{FFFF00}| {FFFFFF}Usage: /showtools [screen type]");
    
    switch(screenType)
    {
        case 1: ShowReportsGUI(playerid);
        case 2: ShowControlPanelGUI(playerid);
        default: ShowNotificationSile(playerid, 0, 3, 0, 0, "Invalid input", "");
    }
    
    return 1;
}


stock PacketIncomingAtools(playerid, Node:json)
{
	new buttonId, screenType, closeFlag;
	JSON_GetInt(json, "b", buttonId);
	JSON_GetInt(json, "t", screenType);
	JSON_GetInt(json, "c", closeFlag);
	
    new jsonString[512];
    JSON_Stringify(json, jsonString, sizeof(jsonString));
    printf("[A-DEBUG] AdminTools JSON: %s", jsonString);
	
	if(closeFlag == 1)
	{
		StopSpectate(playerid);
		JSON_Cleanup(json);
		return 1;
	}
	
	new tableButtonId;
	JSON_GetInt(json, "bi", tableButtonId);
	
	switch(screenType)
	{
		case 1:
		{
			new to_player = GetPlayerSpectateData(playerid, S_PLAYER);
			
			if(to_player == -1 || !IsPlayerConnected(to_player))
			{
				SendClientMessage(playerid, 0xFF3333FF, "Player not found!");
				JSON_Cleanup(json);
				return 1;
			}
			
			switch(buttonId)
			{
				case 1:
				{
					if(GetPlayerSpectateData(playerid, S_PLAYER) != -1)
					{
						SetPlayerInterior(playerid, GetPlayerInterior(to_player));
						SetPlayerVirtualWorld(playerid, GetPlayerVirtualWorld(to_player));
						PlayerSpectatePlayer(playerid, to_player);
						ShowSpectateGUI(playerid, to_player);
					}
				}
				case 2:
				{
					new prevPlayer = FindPreviousPlayer(to_player);
					if(prevPlayer != -1)
					{
						StartSpectate(playerid, prevPlayer);
						ShowSpectateGUI(playerid, prevPlayer);
					}
					else ShowNotificationSile(playerid, 0, 3, 0, 0, "Player not found", "");
				}
				case 3:
				{
					new Node:json_response = JSON_Object();
					JSON_SetInt(json_response, "t", 2);
					JSON_SetString(json_response, "bn", "Kick");
					JSON_SetInt(json_response, "tf", 0);
					
					new Node:template1 = JSON_Object("bi", JSON_Int(1), "bn", JSON_String("Reconnect"), "be", JSON_String("Reconnect"));
					new Node:template2 = JSON_Object("bi", JSON_Int(2), "bn", JSON_String("Interference"), "be", JSON_String("Interference"));
					new Node:templates = JSON_Array(template1, template2);
					
					JSON_SetArray(json_response, "bt", templates);
					
					SendPacketToClient(playerid, 66, json_response);
					JSON_Cleanup(json_response);
				}
				case 4:
				{
					new Node:json_response = JSON_Object();
					JSON_SetInt(json_response, "t", 2);
					JSON_SetString(json_response, "bn", "Mute");
					JSON_SetInt(json_response, "tf", 1);
					
					new Node:template50 = JSON_Object("bi", JSON_Int(50), "bn", JSON_String("MG"), "be", JSON_String("MetaGaming"), "br", JSON_Int(30));
					new Node:template51 = JSON_Object("bi", JSON_Int(51), "bn", JSON_String("Mention family"), "be", JSON_String("Mentioning family"), "br", JSON_Int(120));
					new Node:template52 = JSON_Object("bi", JSON_Int(52), "bn", JSON_String("Disrespect to Adm."), "be", JSON_String("Disrespect to administration"), "br", JSON_Int(120));
					new Node:template53 = JSON_Object("bi", JSON_Int(53), "bn", JSON_String("CAPS"), "be", JSON_String("CapsLock"), "br", JSON_Int(60));
					new Node:template54 = JSON_Object("bi", JSON_Int(54), "bn", JSON_String("Flood"), "be", JSON_String("Flood"), "br", JSON_Int(30));
					new Node:template55 = JSON_Object("bi", JSON_Int(55), "bn", JSON_String("Insulting admin"), "be", JSON_String("Insulting admin"), "br", JSON_Int(120));
					new Node:template56 = JSON_Object("bi", JSON_Int(56), "bn", JSON_String("Translit"), "be", JSON_String("Translit"), "br", JSON_Int(30));
					new Node:template57 = JSON_Object("bi", JSON_Int(57), "bn", JSON_String("Disrespectful to admin"), "be", JSON_String("Disrespect to admin"), "br", JSON_Int(180));
					new Node:template58 = JSON_Object("bi", JSON_Int(58), "bn", JSON_String("CAPS"), "be", JSON_String("CapsLock"), "br", JSON_Int(60));
					new Node:template59 = JSON_Object("bi", JSON_Int(59), "bn", JSON_String("Insult"), "be", JSON_String("Insult"), "br", JSON_Int(30));
					new Node:template60 = JSON_Object("bi", JSON_Int(60), "bn", JSON_String("OOC threats"), "be", JSON_String("OOC threats"), "br", JSON_Int(120));
					new Node:templates = JSON_Array(template50, template51, template52, template53, template54, template55, template56, template57, template58, template59, template60);
					
					JSON_SetArray(json_response, "bt", templates);
					
					SendPacketToClient(playerid, 66, json_response);
					JSON_Cleanup(json_response);
				}
				case 5:
				{
					new Node:json_response = JSON_Object();
					JSON_SetInt(json_response, "t", 2);
					JSON_SetString(json_response, "bn", "Jail");
					JSON_SetInt(json_response, "tf", 1);
					
					new Node:template80 = JSON_Object("bi", JSON_Int(80), "bn", JSON_String("DM"), "be", JSON_String("Murder without reason"), "br", JSON_Int(60));
					new Node:template81 = JSON_Object("bi", JSON_Int(81), "bn", JSON_String("DB"), "be", JSON_String("Vehicle murder"), "br", JSON_Int(60));
					new Node:template82 = JSON_Object("bi", JSON_Int(82), "bn", JSON_String("TK"), "be", JSON_String("Team killing"), "br", JSON_Int(60));
					new Node:template83 = JSON_Object("bi", JSON_Int(83), "bn", JSON_String("nRP behavior"), "be", JSON_String("nRP behavior"), "br", JSON_Int(30));
					new Node:template84 = JSON_Object("bi", JSON_Int(84), "bn", JSON_String("nRP drive"), "be", JSON_String("nRP driving"), "br", JSON_Int(30));
					new Node:template85 = JSON_Object("bi", JSON_Int(85), "bn", JSON_String("Driving off-road"), "be", JSON_String("Driving off-road"), "br", JSON_Int(60));
					new Node:template86 = JSON_Object("bi", JSON_Int(86), "bn", JSON_String("SK"), "be", JSON_String("SpawnKill"), "br", JSON_Int(60));
					new Node:template87 = JSON_Object("bi", JSON_Int(87), "bn", JSON_String("PG"), "be", JSON_String("PowerGaming"), "br", JSON_Int(30));
					new Node:template88 = JSON_Object("bi", JSON_Int(88), "bn", JSON_String("RK"), "be", JSON_String("RevengKill"), "br", JSON_Int(60));
					new Node:template89 = JSON_Object("bi", JSON_Int(89), "bn", JSON_String("FF"), "be", JSON_String("Friendly fire"), "br", JSON_Int(60));
					new Node:templates = JSON_Array(template80, template81, template82, template83, template84, template85, template86, template87, template88, template89);
					
					JSON_SetArray(json_response, "bt", templates);
					
					SendPacketToClient(playerid, 66, json_response);
					JSON_Cleanup(json_response);
				}
				case 6:
				{
					new Node:json_response = JSON_Object();
					JSON_SetInt(json_response, "t", 2);
					JSON_SetString(json_response, "bn", "Warning");
					JSON_SetInt(json_response, "tf", 0);
					
					new Node:template100 = JSON_Object("bi", JSON_Int(100), "bn", JSON_String("nRP military unit"), "be", JSON_String("nRP military unit"));
					new Node:template101 = JSON_Object("bi", JSON_Int(101), "bn", JSON_String("Immoral actions"), "be", JSON_String("Immoral actions"));
					new Node:template102 = JSON_Object("bi", JSON_Int(102), "bn", JSON_String("Avoiding RP"), "be", JSON_String("Avoiding RP"));
					new Node:template103 = JSON_Object("bi", JSON_Int(103), "bn", JSON_String("Misleading with commands"), "be", JSON_String("Misleading with commands"));
					new Node:template104 = JSON_Object("bi", JSON_Int(104), "bn", JSON_String("Mass SK"), "be", JSON_String("Mass SpawnKill(SK)"));
					new Node:template105 = JSON_Object("bi", JSON_Int(105), "bn", JSON_String("Mass TK"), "be", JSON_String("Mass TeamKill(TK)"));
					new Node:template106 = JSON_Object("bi", JSON_Int(106), "bn", JSON_String("Mass DM"), "be", JSON_String("Mass Death-Match(DM)"));
					new Node:template107 = JSON_Object("bi", JSON_Int(107), "bn", JSON_String("Transferring IC conflict to OOC"), "be", JSON_String("Transferring IC conflict to OOC"));
					new Node:templates = JSON_Array(template100, template101, template102, template103, template104, template105, template106, template107);
					
					JSON_SetArray(json_response, "bt", templates);
					
					SendPacketToClient(playerid, 66, json_response);
					JSON_Cleanup(json_response);
				}
				case 7:
				{
					new Node:json_response = JSON_Object();
					JSON_SetInt(json_response, "t", 2);
					JSON_SetString(json_response, "bn", "Slap");
					JSON_SetInt(json_response, "tf", 0);
					
					new Node:template16 = JSON_Object("bi", JSON_Int(16), "bn", JSON_String("Slap up"), "be", JSON_String("Throw up"));
					new Node:template17 = JSON_Object("bi", JSON_Int(17), "bn", JSON_String("Slap down"), "be", JSON_String("Throw down"));
					new Node:templates = JSON_Array(template16, template17);
					
					JSON_SetArray(json_response, "bt", templates);
					
					SendPacketToClient(playerid, 66, json_response);
					JSON_Cleanup(json_response);
				}
				case 8:
				{
					new Node:json_response = JSON_Object();
					JSON_SetInt(json_response, "t", 2);
					JSON_SetString(json_response, "bn", "Ban");
					JSON_SetInt(json_response, "tf", 1);
					
					new Node:template18 = JSON_Object("bi", JSON_Int(18), "bn", JSON_String("Mass DM"), "be", JSON_String("Mass DM"), "br", JSON_Int(7));
					new Node:template19 = JSON_Object("bi", JSON_Int(19), "bn", JSON_String("Insulting family"), "be", JSON_String("Insulting family"), "br", JSON_Int(14));
					new Node:template20 = JSON_Object("bi", JSON_Int(20), "bn", JSON_String("Cheats"), "be", JSON_String("Third-party software"), "br", JSON_Int(9999));
					new Node:template21 = JSON_Object("bi", JSON_Int(21), "bn", JSON_String("Bug abuse"), "be", JSON_String("Bug abuse"), "br", JSON_Int(9999));
					new Node:template22 = JSON_Object("bi", JSON_Int(22), "bn", JSON_String("Buying/Selling Items"), "be", JSON_String("Buying/Selling Items"), "br", JSON_Int(9999));
					new Node:template23 = JSON_Object("bi", JSON_Int(23), "bn", JSON_String("Advertising"), "be", JSON_String("Advertising"), "br", JSON_Int(30));
					new Node:template24 = JSON_Object("bi", JSON_Int(24), "bn", JSON_String("Damage to economy"), "be", JSON_String("Damage to economy"), "br", JSON_Int(9999));
					new Node:template25 = JSON_Object("bi", JSON_Int(25), "bn", JSON_String("Incitement of ethnic hatred"), "be", JSON_String("Incitement of ethnic hatred"), "br", JSON_Int(7));
					new Node:template26 = JSON_Object("bi", JSON_Int(26), "bn", JSON_String("Political/Religious propaganda"), "be", JSON_String("Political/Religious propaganda"), "br", JSON_Int(9999));
					new Node:template27 = JSON_Object("bi", JSON_Int(27), "bn", JSON_String("OOC threats"), "be", JSON_String("OOC threats"), "br", JSON_Int(7));
					new Node:template28 = JSON_Object("bi", JSON_Int(28), "bn", JSON_String("Damage to project resources"), "be", JSON_String("Damage to project resources"), "br", JSON_Int(9999));
					new Node:template29 = JSON_Object("bi", JSON_Int(29), "bn", JSON_String("Promo advertising"), "be", JSON_String("Promo advertising"), "br", JSON_Int(14));
					new Node:template30 = JSON_Object("bi", JSON_Int(30), "bn", JSON_String("Misleading"), "be", JSON_String("Misleading"), "br", JSON_Int(15));
					new Node:templates = JSON_Array(template18, template19, template20, template21, template22, template23, template24, template25, template26, template27, template28, template29, template30);
					
					JSON_SetArray(json_response, "bt", templates);
					
					SendPacketToClient(playerid, 66, json_response);
					JSON_Cleanup(json_response);
				}
				case 9:
				{
					new nextPlayer = FindNextPlayer(to_player);
					if(nextPlayer != -1)
					{
						StartSpectate(playerid, nextPlayer);
						ShowSpectateGUI(playerid, nextPlayer);
					}
					else ShowNotificationSile(playerid, 0, 3, 0, 0, "Player not found", "");
				}
				case 10:
				{
					new params[128];
					format(params, sizeof(params), "%d", to_player);
					callcmd::stats(playerid, params);
				}
				case 11: 
				{
					callcmd::af(playerid, "");
				}
			}
		}
		
		case 2:
		{
			new to_player = GetPlayerSpectateData(playerid, S_PLAYER);
			
			if(to_player == -1 || !IsPlayerConnected(to_player))
			{
				SendClientMessage(playerid, 0xFF3333FF, "Player not found!");
				JSON_Cleanup(json);
				return 1;
			}
			
			switch(tableButtonId)
			{
				case 1: 
				{
						if(GetPlayerAdminEx(playerid) < 1) return ShowNotificationSile(playerid, 2, 5, -1, -1, "You do not have access to use this function",  "");
						
						new fmt_msg[128];
						format(fmt_msg, sizeof fmt_msg, "Administrator %s kicked player %s. Reason: Reconnect", GetPlayerNameEx(playerid), GetPlayerNameEx(to_player));

						SendClientMessageToAll(0xFF5533FF, fmt_msg);

						format(fmt_msg, sizeof fmt_msg, "Kicked %s[acc:%d]", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player));
						SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_msg);
						
						new fmt_text[512];
						format(fmt_text, sizeof fmt_text, "[A] Administrator %s[%d] kicked %s[%d]. Reason: Reconnect", GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player);
						SendMessageToAdmins(fmt_text, 0x999999FF); 

						SetTimerEx("KickSpectate", 50, false, "i", to_player);
 
						return 1;
				} 
				case 2:
				{
						if(GetPlayerAdminEx(playerid) < 1) return ShowNotificationSile(playerid, 2, 5, -1, -1, "You do not have access to use this function",  "");
						
						new fmt_msg[128];
						format(fmt_msg, sizeof fmt_msg, "Administrator %s kicked player %s. Reason: Interference", GetPlayerNameEx(playerid), GetPlayerNameEx(to_player));

						SendClientMessageToAll(0xFF5533FF, fmt_msg);

						format(fmt_msg, sizeof fmt_msg, "Kicked %s[acc:%d]", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player));
						SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_msg);
						
						new fmt_text[512];
						format(fmt_text, sizeof fmt_text, "[A] Administrator %s[%d] kicked %s[%d]. Reason: Interference", GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player);
						SendMessageToAdmins(fmt_text, 0x999999FF); 

						SetTimerEx("KickSpectate", 50, false, "i", to_player);
 
						return 1;
				} 
				case 50..60: 
				{
					new index = tableButtonId - 50; 
					
					if(AntiSliv(playerid, "/mute")) return true;

					new fmt_msg[128];
					format(fmt_msg, sizeof fmt_msg, "Administrator %s gave a chat mute to player %s for %d min. Reason: %s", GetPlayerNameEx(playerid), GetPlayerNameEx(to_player), b_mute_spectate[index][MSP_TIME], b_mute_spectate[index][MSP_REASON]);

					 SendClientMessageToAll(0xFF5533FF, fmt_msg);

					SetPlayerData(to_player, P_MUTE, b_mute_spectate[index][MSP_TIME] * 60);
					UpdatePlayerDatabaseInt(to_player, "mute", b_mute_spectate[index][MSP_TIME] * 60);

					SendClientMessage(to_player, 0xCECECEFF, "Time until mute ends: {CCCC00}/time");

					format(fmt_msg, sizeof fmt_msg, "Gave %s[acc:%d] chat mute for %d min. Reason: %s",
					GetPlayerNameEx(to_player), GetPlayerAccountID(to_player), b_mute_spectate[index][MSP_TIME], b_mute_spectate[index][MSP_REASON]);

					 SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_msg);
					return 1; 
				} 
				case 80..89: 
				{
					new index = tableButtonId - 80; 
					if(AntiSliv(playerid, "/jail")) return true;

					new fmt_msg[128];
					format(fmt_msg, sizeof fmt_msg, "Administrator %s jailed player %s for %d min. Reason: %s", GetPlayerNameEx(playerid), GetPlayerNameEx(to_player), b_jail_spectate[index][JSP_TIME], b_jail_spectate[index][JSP_REASON]);

					SendClientMessageToAll(0xFF5533FF, fmt_msg);

					SendClientMessage(to_player, 0xCECECEFF, "Time until release: {CCCC00}/time");

					JailPlayer(to_player, b_jail_spectate[index][JSP_TIME]);

					format(fmt_msg, sizeof fmt_msg, "Jailed %s[acc:%d] for %d min. Reason: %s",
					GetPlayerNameEx(to_player), GetPlayerAccountID(to_player), b_jail_spectate[index][JSP_TIME], b_jail_spectate[index][JSP_REASON]);

					SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_msg);
					return 1;
				} 
				case 100..107: 
				{
					new index = tableButtonId - 100; 
					if(GetPlayerAdminEx(playerid) < 2) return ShowNotificationSile(playerid, 2, 5, -1, -1, "You do not have access to use this function",  "");
					
					if(AntiSliv(playerid, "/warn")) return true;

					AddPlayerData(to_player, P_WARN, +, 1);
					SetPlayerData(to_player, P_WARN_TIME, gettime() + (86400 * 10));

					new fmt_msg[128];
					format(fmt_msg, sizeof fmt_msg, "Administrator %s gave a warning to player %s [%d|3]. Reason: %s", GetPlayerNameEx(playerid), GetPlayerNameEx(to_player), GetPlayerData(to_player, P_WARN), b_warn_spectate[index][BSP_REASON]);

					SendClientMessageToAll(0xFF5533FF, fmt_msg);

					InvitePlayer(to_player, 0, 0, true);

					new uid = GetPlayerAccountID(to_player);
					new warns = GetPlayerData(to_player, P_WARN);
					new warns_time = GetPlayerData(to_player, P_WARN_TIME);

					format(fmt_msg, sizeof fmt_msg, "Gave warn to %s[acc:%d] (%d/3). Reason: %d", GetPlayerNameEx(to_player), uid, warns, b_warn_spectate[index][BSP_REASON]);
					SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_msg);

					if(warns >= 3)
					{
						SendClientMessage(to_player, 0xFF5533FF, "Account banned for 10 days");

						warns =
						warns_time = 0;

						AddBan(uid, gettime(), 10, GetPlayerIpEx(to_player), "received 3 warnings", GetPlayerNameEx(playerid));
						BanEx(to_player, "received 3 warnings");
					}
					else Kick:(to_player);

					format(fmt_msg, sizeof fmt_msg, "UPDATE accounts SET warn=%d,warn_time=%d WHERE id=%d", warns, warns_time, uid);
					mysql_query(mysql, fmt_msg, false);
					
					return 1;
				} 
				case 16:
				{
					if(GetPlayerAdminEx(playerid) < 1) return ShowNotificationSile(playerid, 2, 5, -1, -1, "You do not have access to use this function",  "");
					
					new Float: x, Float: y, Float: z, fmt_text[999], fmt_msg[512];
					GetPlayerPos(to_player, x, y, z);
					
					SetPlayerPos(to_player, x, y, z + 5);
					
					format(fmt_text, sizeof fmt_text, "[A] %s[%d] slapped player %s[%d]", GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player);
					SendMessageToAdmins(fmt_text, 0x999999FF);

					format(fmt_msg, sizeof fmt_msg, "{1E90FF}You slapped player %s[%d]", GetPlayerNameEx(to_player), to_player);
					SendClientMessage(playerid, -1, fmt_msg);

					format(fmt_text, sizeof fmt_text, "{1E90FF}Administrator %s[%d] slapped you.", GetPlayerNameEx(playerid), playerid);
					SendClientMessage(to_player, -1, fmt_text);
					return 1; 
				} 
				case 17:
				{
					if(GetPlayerAdminEx(playerid) < 1) return ShowNotificationSile(playerid, 2, 5, -1, -1, "You do not have access to use this function",  "");
					
					new Float: x, Float: y, Float: z, fmt_text[999], fmt_msg[512];
					GetPlayerPos(to_player, x, y, z);
					
					SetPlayerPos(to_player, x, y, z - 5);
					
					format(fmt_text, sizeof fmt_text, "[A] %s[%d] slapped player %s[%d]", GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player);
					SendMessageToAdmins(fmt_text, 0x999999FF);

					format(fmt_msg, sizeof fmt_msg, "{1E90FF}You slapped player %s[%d]", GetPlayerNameEx(to_player), to_player);
					SendClientMessage(playerid, -1, fmt_msg);

					format(fmt_text, sizeof fmt_text, "{1E90FF}Administrator %s[%d] slapped you.", GetPlayerNameEx(playerid), playerid);
					SendClientMessage(to_player, -1, fmt_text);
					return 1; 
				} 
				case 18..30:
				{
   					new index = tableButtonId - 18;
   					new ban_time = b_ban_spectate[index][BSP_TIME];
   					new reason[64];
   					format(reason, sizeof reason, "%s", b_ban_spectate[index][BSP_REASON]);

   					if(GetPlayerAdminEx(playerid) < 3)
       					return ShowNotificationSile(playerid, 2, 3, 0, 0, "You do not have access to use this function", " ");

   					if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
       					return ShowNotificationSile(playerid, 2, 4, 0, 0, "Player not found", " ");

   					if(GetPlayerAdminEx(to_player) > GetPlayerAdminEx(playerid))
       					return SendClientMessage(playerid, 0xCECECEFF, ""SC"Cannot ban an administrator with higher rank");

   					if(AntiSliv(playerid, "/ban"))
       					return true;
       
					   if(ban_time > 365) 
					   {
							new announce[256];
   					 	format(announce, sizeof announce, "Administrator %s permanently banned player %s. Reason: %s", GetPlayerNameEx(playerid), GetPlayerNameEx(to_player), reason);
   					 	SendClientMessageToAll(0xFF5533FF, announce);
					   } 
					   else 
					   {
   						new announce[256];
   						format(announce, sizeof announce, "Administrator %s banned player %s for %d days. Reason: %s", GetPlayerNameEx(playerid), GetPlayerNameEx(to_player), ban_time, reason);
   						SendClientMessageToAll(0xFF5533FF, announce);
  				 	} 
   
  					new fmt_text[512];
  					format(fmt_text, sizeof fmt_text, "[A] %s[%d] banned player %s[%d]. Reason: %s", GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player, reason);
					  SendMessageToAdmins(fmt_text, 0x999999FF);

   					InfoAstats[1] += 1;

   					new log_msg[256];
   					format(log_msg, sizeof log_msg, "Banned %s[acc:%d] for %d days. Reason: %s", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player), ban_time, reason);
   					SendLog(playerid, LOG_TYPE_SUPERADMIN_ACTION, log_msg);

   					AddBan(GetPlayerAccountID(to_player), gettime(), ban_time, GetPlayerIpEx(to_player), reason, GetPlayerNameEx(playerid));
					   BanEx(to_player, reason);
   					Kick(to_player);

   					return 1;
				}
			}
		}
		
		case 3:
		{
			if(tableButtonId != 0)
			{
			format(f_string144, sizeof f_string144, "tableButtonId %s", tableButtonId);
			ShowNotificationSile(playerid, 2, 5, -1, -1, f_string144, "");
				switch(tableButtonId)
				{
					case 1:
					{
						new xaxaxas[512];
						JSON_GetString(json, "bn", xaxaxas);
						new to_player = GetPlayerSpectateData(playerid, S_PLAYER);
						if(to_player != -1 && IsPlayerConnected(to_player))
						{
							new message[128];
							format(message, sizeof(message), "{FFFF00}|{FFFFFF} You replied: {FFFF00}%s", xaxaxas);
							SendClientMessage(playerid, -1, message);
							
							SendClientMessage(to_player, 0x33CCFFAA, "Hello, I am working on your complaint. // Enjoy the game");
						}
						HidePlayerGUI(playerid);
					}
					case 2:
					{
						new xaxaxas[512];
						JSON_GetString(json, "bn", xaxaxas);
						new to_player = GetPlayerSpectateData(playerid, S_PLAYER);
						if(to_player != -1 && IsPlayerConnected(to_player))
						{
							new message[128];
							format(message, sizeof(message), "{FFFF00}|{FFFFFF} You replied: {FFFF00}%s", xaxaxas);
							SendClientMessage(playerid, -1, message);
							
							SendClientMessage(to_player, 0x33CCFFAA, "Hello, off topic. // Enjoy the game");
						}
						HidePlayerGUI(playerid);
					}
					case 3:
					{
					new xaxaxas[512];
						JSON_GetString(json, "bn", xaxaxas);
						new to_player = GetPlayerSpectateData(playerid, S_PLAYER);
						if(to_player != -1 && IsPlayerConnected(to_player))
						{
							new message[128];
							format(message, sizeof(message), "{FFFF00}|{FFFFFF} You replied: {FFFF00}%s", xaxaxas);
							SendClientMessage(playerid, -1, message);
							
							SendClientMessage(to_player, 0x33CCFFAA, "Hello, through RolePlay. // Enjoy the game");
						}
						HidePlayerGUI(playerid);
					}
				}
			}
			else
			{
			format(f_string144, sizeof f_string144, "buttonId %s", buttonId);
			ShowNotificationSile(playerid, 2, 5, -1, -1, f_string144, "");
				switch(buttonId)
				{
				
					case 1:
					{
						new Node:json_response = JSON_Object();
						JSON_SetInt(json_response, "t", 4);
						
						new Node:template1 = JSON_Object("bi", JSON_Int(1), "bn", JSON_String("hui Zalupa chlen bobr"), "be", JSON_String("hui Zalupa chlen bobr"));
						new Node:template2 = JSON_Object("bi", JSON_Int(2), "bn", JSON_String("Off topic"), "be", JSON_String("Hello, off topic. // Enjoy the game"));
						new Node:template3 = JSON_Object("bi", JSON_Int(3), "bn", JSON_String("Through RP"), "be", JSON_String("Hello, through RolePlay. // Enjoy the game"));
						new Node:templates = JSON_Array(template1, template2, template3);
						
						JSON_SetArray(json_response, "bt", templates);
						
						SendPacketToClient(playerid, 66, json_response);
						JSON_Cleanup(json_response);
					}
					case 2:
					{
						HidePlayerGUI(playerid);
					}
				}
			}
		}
		
		case 4:
		{
			new message[128];
			
			switch(tableButtonId)
			{
				case 1:
				{
				new xaxaxas[512];
					JSON_GetString(json, "be", xaxaxas, sizeof(xaxaxas));
					format(message, sizeof(message), "{FFFF00}|{FFFFFF} You replied: {FFFF00}%s", xaxaxas);
					SendClientMessage(playerid, -1, message);
					HidePlayerGUI(playerid);
				}
				case 2:
				{
					new xaxaxas[512];
					JSON_GetString(json, "be", xaxaxas, sizeof(xaxaxas));
					format(message, sizeof(message), "{FFFF00}|{FFFFFF} You replied: {FFFF00}%s", xaxaxas);
					HidePlayerGUI(playerid);
				}
				case 3:
				{
					new xaxaxas[512];
					JSON_GetString(json, "be", xaxaxas, sizeof(xaxaxas));
					format(message, sizeof(message), "{FFFF00}|{FFFFFF} You replied: {FFFF00}%s", xaxaxas);
					HidePlayerGUI(playerid);
				}
			}
		}
		case 5:
{
    new rep[512];
    new repConverted[512];
    UTF8_tto_CP1251(rep, repConverted, sizeof(repConverted));
    JSON_GetString(json, "rt", repConverted, sizeof(repConverted));

    

    SendClientMessage(playerid, -1, repConverted);

    new Node:response = JSON_Object();
    JSON_SetInt(response, "t", 5);
    JSON_SetString(response, "rt", repConverted);
    
    SendPacketToClient(playerid, 66, response);
}
		case 6:
		{
			if(tableButtonId == 0)
			{
				new Node:json_response = JSON_Object();
				JSON_SetInt(json_response, "t", 8);
				
				new Node:template1 = JSON_Object("bi", JSON_Int(1), "bn", JSON_String("hui Zalupa chlen bobr"), "be", JSON_String("hui Zalupa chlen bobr"));
				new Node:template2 = JSON_Object("bi", JSON_Int(2), "bn", JSON_String("Off topic"), "be", JSON_String("Hello, off topic. // Enjoy the game"));
				new Node:template3 = JSON_Object("bi", JSON_Int(3), "bn", JSON_String("Through RP"), "be", JSON_String("Hello, through RolePlay. // Enjoy the game"));
				new Node:templates = JSON_Array(template1, template2, template3);
				
				JSON_SetArray(json_response, "bt", templates);
				
				SendPacketToClient(playerid, 66, json_response);
				JSON_Cleanup(json_response);
			}
			else if(tableButtonId == 1)
			{
				new Node:json_response = JSON_Object();
				JSON_SetInt(json_response, "t", 9);
				
				SendPacketToClient(playerid, 66, json_response);
				JSON_Cleanup(json_response);
			}
		}
		
		case 7:
		{
			if(tableButtonId != 0)
			{
				new Node:json_response = JSON_Object();
				JSON_SetInt(json_response, "t", 2);
				
				switch(tableButtonId)
				{
					case 3:
					{
						JSON_SetString(json_response, "bn", "Kick");
						JSON_SetInt(json_response, "tf", 0);
						
						new Node:template1 = JSON_Object("bi", JSON_Int(1), "bn", JSON_String("Kick: Afk no esc"), "be", JSON_String("Afk no esc"));
						new Node:template2 = JSON_Object("bi", JSON_Int(2), "bn", JSON_String("Kick: Interference"), "be", JSON_String("Interference"));
						new Node:template3 = JSON_Object("bi", JSON_Int(3), "bn", JSON_String("Kick: Bug"), "be", JSON_String("Bug"));
						new Node:templates = JSON_Array(template1, template2, template3);
						
						JSON_SetArray(json_response, "bt", templates);
					}
					case 4:
					{
						JSON_SetString(json_response, "bn", "Mute");
						JSON_SetInt(json_response, "tf", 1);
						
						new Node:template4 = JSON_Object("bi", JSON_Int(4), "bn", JSON_String("Mute: Insult"), "be", JSON_String("Insulting players"), "br", JSON_Int(15));
						new Node:template5 = JSON_Object("bi", JSON_Int(5), "bn", JSON_String("Mute: Mention family"), "be", JSON_String("Mentioning family"), "br", JSON_Int(30));
						new Node:template6 = JSON_Object("bi", JSON_Int(6), "bn", JSON_String("Mute: Disrespect Adm."), "be", JSON_String("Disrespect to administration"), "br", JSON_Int(60));
						new Node:template7 = JSON_Object("bi", JSON_Int(7), "bn", JSON_String("Mute: CAPS"), "be", JSON_String("Caps in chat"), "br", JSON_Int(10));
						new Node:templates = JSON_Array(template4, template5, template6, template7);
						
						JSON_SetArray(json_response, "bt", templates);
					}
					case 5:
					{
						JSON_SetString(json_response, "bn", "Jail");
						JSON_SetInt(json_response, "tf", 1);
						
						new Node:template8 = JSON_Object("bi", JSON_Int(8), "bn", JSON_String("Jail: DM"), "be", JSON_String("DM without reason"), "br", JSON_Int(10));
						new Node:template9 = JSON_Object("bi", JSON_Int(9), "bn", JSON_String("Jail: DB"), "be", JSON_String("DriveBy"), "br", JSON_Int(15));
						new Node:template10 = JSON_Object("bi", JSON_Int(10), "bn", JSON_String("Jail: TK"), "be", JSON_String("TeamKill"), "br", JSON_Int(20));
						new Node:template11 = JSON_Object("bi", JSON_Int(11), "bn", JSON_String("Jail: Provocation of state orgs"), "be", JSON_String("Provocation of state organizations"), "br", JSON_Int(25));
						new Node:templates = JSON_Array(template8, template9, template10, template11);
						
						JSON_SetArray(json_response, "bt", templates);
					}
					case 6:
					{
						JSON_SetString(json_response, "bn", "Warning");
						JSON_SetInt(json_response, "tf", 0);
						
						new Node:template12 = JSON_Object("bi", JSON_Int(12), "bn", JSON_String("Warning: NonRP COP"), "be", JSON_String("NonRP cop"));
						new Node:template13 = JSON_Object("bi", JSON_Int(13), "bn", JSON_String("Warning: NonRP Military"), "be", JSON_String("NonRP military"));
						new Node:template14 = JSON_Object("bi", JSON_Int(14), "bn", JSON_String("Warning: ORP"), "be", JSON_String("ORP"));
						new Node:template15 = JSON_Object("bi", JSON_Int(15), "bn", JSON_String("Warning: LD removed"), "be", JSON_String("Removing LD"));
						new Node:templates = JSON_Array(template12, template13, template14, template15);
						
						JSON_SetArray(json_response, "bt", templates);
					}
					case 7:
					{
						JSON_SetString(json_response, "bn", "Slap");
						JSON_SetInt(json_response, "tf", 0);
						
						new Node:template16 = JSON_Object("bi", JSON_Int(16), "bn", JSON_String("Slap: Up"), "be", JSON_String("Throw up"));
						new Node:template17 = JSON_Object("bi", JSON_Int(17), "bn", JSON_String("Slap: Down"), "be", JSON_String("Throw down"));
						new Node:templates = JSON_Array(template16, template17);
						
						JSON_SetArray(json_response, "bt", templates);
					}
					case 8:
					{
						JSON_SetString(json_response, "bn", "Ban");
						JSON_SetInt(json_response, "tf", 1);
						
						new Node:template18 = JSON_Object("bi", JSON_Int(18), "bn", JSON_String("Ban: Mass DM"), "be", JSON_String("Mass DM"), "br", JSON_Int(7));
						new Node:template19 = JSON_Object("bi", JSON_Int(19), "bn", JSON_String("Ban: P/P/V"), "be", JSON_String("P/P/V"), "br", JSON_Int(30));
						new Node:template20 = JSON_Object("bi", JSON_Int(20), "bn", JSON_String("Ban: Insult family"), "be", JSON_String("Insulting family"), "br", JSON_Int(14));
						new Node:template21 = JSON_Object("bi", JSON_Int(21), "bn", JSON_String("Ban: Cheats"), "be", JSON_String("Using cheats"), "br", JSON_Int(365));
						new Node:templates = JSON_Array(template18, template19, template20, template21);
						
						JSON_SetArray(json_response, "bt", templates);
					}
				}
				
				SendPacketToClient(playerid, 66, json_response);
				JSON_Cleanup(json_response);
			}
		}
		
		case 9:
		{
			new templateTitle[64], templateDesc[256], templateTime;
			JSON_GetString(json, "bn", templateTitle, sizeof(templateTitle));
			JSON_GetString(json, "be", templateDesc, sizeof(templateDesc));
			JSON_GetInt(json, "br", templateTime);
			
			if(strlen(templateTitle) > 0 && strlen(templateDesc) > 0)
			{
				new msg[128];
				format(msg, sizeof(msg), "{33CCFF}Template created: {FFFFFF}%s - %s", templateTitle, templateDesc);
				SendClientMessage(playerid, -1, msg);
				
				new Node:json_response = JSON_Object();
				JSON_SetInt(json_response, "t", 6);
				
				new Node:btn0 = JSON_Object("bi", JSON_Int(0), "bn", JSON_String("My templates"), "be", JSON_String("View all templates"));
				new Node:btn1 = JSON_Object("bi", JSON_Int(1), "bn", JSON_String("Create template"), "be", JSON_String("Create new template"));
				new Node:buttons = JSON_Array(btn0, btn1);
				
				JSON_SetArray(json_response, "bt", buttons);
				
				SendPacketToClient(playerid, 66, json_response);
				JSON_Cleanup(json_response);
			}
		}

	}
	
	JSON_Cleanup(json);
	return 1;
}

forward KickSpectate(to_player);
public KickSpectate(to_player)
{
	Kick(to_player);
}