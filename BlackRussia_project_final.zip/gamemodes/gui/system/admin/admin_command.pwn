CMD:veh(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 4 && GetPlayerYouTubeEx(playerid) < 1) return ShowNotificationSile(playerid, 2, 3, 0, 0, "You do not have access to use this command", " ");

	extract params -> new model_id, color_1, color_2; else return SendClientMessage(playerid, 0xCECECEFF, "{FF5252}|{ffffff} Usage: /veh [model id] [color 1] [color 2] [player access (optional)]");

	if(!(400 <= model_id <= 30000)) return SendClientMessage(playerid, 0xCECECEFF, "{FF5252}|{ffffff}Use model from 400 to 2591");

	new status;

	sscanf(params, "{d}{d}{d}d", status);

	if(!(0 <= status <= 1))
		return SendClientMessage(playerid, 0x999999FF, "{FF5252}|{ffffff}Player access to vehicle: 0 - No access, 1 - Available to any player");

	new Float: x,
		Float: y,
		Float: z,
		Float: a;

	GetPlayerPos(playerid, x, y, z);
	GetPlayerFacingAngle(playerid, a);

	new vehicleid = CreateVehicle(model_id, x, y, z, a, color_1, color_2, -1, 0, VEHICLE_ACTION_TYPE_ADMIN_CAR, status);

	SetTimerEx("DelayedPutPlayerInVehicle", 150, false, "ii", playerid, vehicleid);
	new plate[32];
	RandomNumberPlate(1, plate, sizeof(plate));
	SetVehicleNumberPlateEx(vehicleid, 1, plate, "52");
	new fmt_text[999];
	ChangeVehicleColor(vehicleid, color_1, color_2);

	format(fmt_text, sizeof fmt_text, "[A] %s[%d] created vehicle (%d, %d, %d)",
	GetPlayerNameEx(playerid), playerid, model_id, color_1, color_2);
    SendMessageToAdmins(fmt_text, 0x999999FF);

	format(fmt_text, sizeof fmt_text, "Created vehicle (%d, %d, %d)", model_id, color_1, color_2);
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_text);

	return 1;
}

CMD:pos(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 13) return 1;

	new Float: x, Float: y, Float: z, interior, virtual_world;

	if(sscanf(params, "P<,>fff", x, y, z))
		return SendClientMessage(playerid, 0xCECECEFF, "Usage: /pos [x y z]");

	sscanf(params, "P<,>{fff}dd", interior, virtual_world);

	return SetPlayerPosEx(playerid, x, y, z, interior, virtual_world);
}

CMD:banip(playerid, params[])
{

	if (GetPlayerAdminEx(playerid) < 13)
		return ShowNotificationSile(playerid, 2, 3, 0, 0, "You do not have access to use this command", " ");

	new to_player, reason[128];
	if (sscanf(params, "us[128]", to_player, reason))
		return SendClientMessage(playerid, -1, ""SC"Usage: /banip [player id] [reason]");

	if (!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
		return ShowNotificationSile(playerid, 2, 4, 0, 0, "Player not found", " ");

	new ip[16];
	GetPlayerIp(to_player, ip, sizeof(ip));

	new cmd[64];
	format(cmd, sizeof(cmd), "banip %s", ip);
	SendRconCommand(cmd);

	new msg[256];
	format(msg, sizeof(msg), "[A] Administrator %s banned IP of player %s (hidden). Reason: %s",
		GetPlayerNameEx(playerid), GetPlayerNameEx(to_player), reason);
	SendClientMessageToAll(0xFF5533FF, msg);

	new log[256];
	format(log, sizeof(log), "Banned IP %s (%s). Reason: %s", ip, GetPlayerNameEx(to_player), reason);
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, log);

	Kick(to_player);

	return 1;
}
CMD:banipoff(playerid, params[])
{

	if (GetPlayerAdminEx(playerid) < 13)
		return ShowNotificationSile(playerid, 2, 3, 0, 0, "You do not have access to use this command", " ");

	new target_name[24], reason[128];
	if (sscanf(params, "s[24]s[128]", target_name, reason))
		return SendClientMessage(playerid, -1, ""SC"Usage: /banipoff [nick] [reason]");

	new query[128];
	mysql_format(mysql, query, sizeof query, "SELECT last_ip FROM accounts WHERE name='%e'", target_name);

	new Cache: result = mysql_query(mysql, query, true);
	if (cache_num_rows() == 0)
	{
		cache_delete(result);
		return SendClientMessage(playerid, 0xFF5533FF, ""SC"Player with that name not found in database.");
	}

	new ip[16];
	cache_get_row(0, 0, ip, sizeof(ip));
	cache_delete(result);

	new cmd[64];
	format(cmd, sizeof(cmd), "banip %s", ip);
	SendRconCommand(cmd);

	new msg[256];
	format(msg, sizeof(msg), "[A] Administrator %s banned IP of offline player %s (hidden). Reason: %s",
		GetPlayerNameEx(playerid), target_name, reason);
	SendClientMessageToAll(0xFF5533FF, msg);

	new log[256];
	format(log, sizeof(log), "Banned IP %s (%s - offline). Reason: %s", ip, target_name, reason);
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, log);

	return 1;
}

CMD:unbanip(playerid, params[])
{

	if (GetPlayerAdminEx(playerid) < 13)
		return ShowNotificationSile(playerid, 2, 3, 0, 0, "You do not have access to use this command", " ");

	new ip[32];
	if (sscanf(params, "s[32]", ip))
		return SendClientMessage(playerid, -1, ""SC"Usage: /unbanip [ip]");

	new string[256], log_msg[256];

	format(string, sizeof(string), "unbanip %s", ip);
	SendRconCommand(string);

	format(string, sizeof(string), "{33FF55}[A] Administrator %s unblocked IP: [hidden]", GetPlayerNameEx(playerid));
	SendClientMessageToAll(-1, string);

	format(log_msg, sizeof(log_msg), "Unblocked IP %s", ip);
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, log_msg);

	return 1;
}

CMD:ban(playerid, params[])
{
	if (GetPlayerAdminEx(playerid) < 3)
		return ShowNotificationSile(playerid, 2, 3, 0, 0, "You do not have access to use this command", " ");

	if (!strlen(params))
		return SendClientMessage(playerid, 0xCECECEFF, ""SC"Usage: /ban [player id] [time] [reason]");

	extract params -> new to_player, ban_time, string:reason[64];

	if (!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
		return ShowNotificationSile(playerid, 2, 4, 0, 0, "Player not found", " ");

	new max_days = GetPlayerAdminEx(playerid) > 4 ? 90 : 30;

	if (!(1 <= ban_time <= max_days))
	{
		new msg[128];
		format(msg, sizeof msg, ""SC"Ban duration can be from 1 to %d days", max_days);
		return SendClientMessage(playerid, 0xCECECEFF, msg);
	}

	if (GetPlayerAdminEx(to_player) > GetPlayerAdminEx(playerid))
		return SendClientMessage(playerid, 0xCECECEFF, ""SC"Cannot ban an administrator with higher rank");

	if (AntiSliv(playerid, "/ban"))
		return true;

	new announce[256];
	format(announce, sizeof announce, "Administrator %s banned player %s for %d days", GetPlayerNameEx(playerid), GetPlayerNameEx(to_player), ban_time);
	if (strlen(reason)) format(announce, sizeof announce, "%s. Reason: %s", announce, reason);
	SendClientMessageToAll(0xFF5533FF, announce);

	InfoAstats[1] += 1;

	if (!strlen(reason)) reason = "No reason";

	new log_msg[256];
	format(log_msg, sizeof log_msg, "Banned %s[acc:%d] for %d days. Reason: %s", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player), ban_time, reason);
	SendLog(playerid, LOG_TYPE_SUPERADMIN_ACTION, log_msg);

	AddBan(GetPlayerAccountID(to_player), gettime(), ban_time, GetPlayerIpEx(to_player), reason, GetPlayerNameEx(playerid));

	Kick(to_player);

	return 1;
}

CMD:unban(playerid, params[])
{

	if(GetPlayerAdminEx(playerid) < 3) return ShowNotificationSile(playerid, 2, 3, 0, 0, "You do not have access to use this command", " ");

	extract params -> new string: player_name[21];

	if(!strlen(player_name)) return SendClientMessage(playerid, 0xCECECEFF, ""SC"Usage: /unban [player nick]");

	new query[80],
		Cache: result,
		rows,
		uid,
		uip[16];

	mysql_format(mysql, query, sizeof query, "SELECT id, last_ip FROM accounts WHERE name='%s'", player_name);
	result = mysql_query(mysql, query, true);

	rows = cache_num_rows();

	if(rows)
	{
		uid = cache_get_row_int(0, 0);
		cache_get_row(0, 1, uip);
	}

	cache_delete(result);

	if(!rows || !uid) return SendClientMessage(playerid, 0x999999FF, ""SC"Player with that name not found");

	mysql_format(mysql, query, sizeof query, "SELECT * FROM ban_list WHERE user_id=%d", uid);
	result = mysql_query(mysql, query, true);

	rows = cache_num_rows();

	cache_delete(result);

	if(!rows) return SendClientMessage(playerid, 0x999999FF, ""SC"Player's account is not banned");

	mysql_format(mysql, query, sizeof query, "DELETE FROM ban_list WHERE user_id=%d", uid);
	mysql_query(mysql, query, false);

	format(query, sizeof query, "unbanip %s", uip);
	SendRconCommand(query);

	SendRconCommand("reloadbans");

	format(query, sizeof query, "Administrator %s unblocked player %s", GetPlayerNameEx(playerid), player_name);

	SendClientMessageToAll(0xFF5533FF, query);

	format(query, sizeof query, "Unbanned %s[acc:%d]", player_name, uid);
	SendLog(playerid, LOG_TYPE_SUPERADMIN_ACTION, query);

	return 1;
}

CMD:setskin(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 12) return ShowNotificationSile(playerid, 2, 3, 0, 0, "You do not have access to use this command", " ");

	extract params -> new to_player, skin_id; else return SendClientMessage(playerid, 0xCECECEFF, ""SC"Usage: /setskin [player id] [skin id]");

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
		return ShowNotificationSile(playerid, 2, 4, 0, 0, "Player not found", " ");
	if(TEST_SERVER == 1)
	{
	    if(playerid != to_player) return SendClientMessage(playerid, -1, "{ff2400}| {ffffff}This command can only be used on yourself on the TEST SERVER!");
	}

	if(GetPlayerTeamEx(to_player)) return SendClientMessage(playerid, 0xCECECEFF, ""SC"Cannot change skin of a player in an organization");

	if(!(1 <= skin_id <= 6500046)) return SendClientMessage(playerid, 0xCECECEFF, ""SC"Skin ID from 1 to 20000");

	SetPlayerData(to_player, P_SKIN, skin_id);
	UpdatePlayerDatabaseInt(to_player, "skin", skin_id);

	SetPlayerSkinInit(to_player);

	new fmt_text[999];

    format(fmt_text, sizeof fmt_text, "{1E90FF}You gave skin #%d to player %s[%d]", skin_id, GetPlayerNameEx(to_player), to_player);
	SendClientMessage(playerid, -1, fmt_text);

	format(fmt_text, sizeof fmt_text, "{1E90FF}You were given skin #%d by administrator %s[%d]", skin_id, GetPlayerNameEx(playerid), playerid);
	SendClientMessage(to_player, -1, fmt_text);

	format(fmt_text, sizeof fmt_text, "{FF5533}[A] %s[%d] gave %s[%d] skin #%d", GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player, skin_id);
	SendMessageToAdmins(fmt_text, 0xCECECEFF);

	format(fmt_text, sizeof fmt_text, "Set %s[acc:%d] skin %d", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player), skin_id);
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_text);

	return 1;
}

CMD:myskin(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 4) return 1;

	ShowPlayerDialog(playerid,DLG_MYSKIN,DIALOG_STYLE_INPUT,"My Skin","Enter skin ID from 1 to 600","Apply","Cancel");

	return 1;
}

CMD:offban(playerid, params[])
{

	if(GetPlayerAdminEx(playerid) < 3) return 1;

	if(!strlen(params)) return SendClientMessage(playerid, 0xCECECEFF, "Usage: /offban [player nick] [days] [reason]");

	extract params -> new string: player_name[21], days, string: reason[30];

	if(!(1 <= days <= 90)) return SendClientMessage(playerid, 0x999999FF, "Days from 1 to 90");

	if(IsPlayerConnected(GetPlayerID(player_name))) return SendClientMessage(playerid, 0x999999FF, "Player with that name is on the server");

	new query[144],
		Cache: result,
		rows,
		uid,
		admin,
		uip[16];

	mysql_format(mysql, query, sizeof query, "SELECT id, admin, last_ip FROM accounts WHERE name='%s'", player_name);
	result = mysql_query(mysql, query, true);

	rows = cache_num_rows();

	if(rows)
	{
		uid = cache_get_row_int(0, 0);
		admin = cache_get_row_int(0, 1);
		cache_get_row(0, 2, uip);
	}

	cache_delete(result);

	if(!rows || !uid) return SendClientMessage(playerid, 0x999999FF, "Player with that name not found");

	if(GetPlayerAdminEx(playerid) < admin) return SendClientMessage(playerid, 0x999999FF, "Cannot ban an administrator with higher rank");

	mysql_format(mysql, query, sizeof query, "SELECT * FROM ban_list WHERE user_id=%d", uid);
	result = mysql_query(mysql, query, true);

	rows = cache_num_rows();

	cache_delete(result);

	if(rows) return SendClientMessage(playerid, 0x999999FF, "Player's account is already banned");

	if(AntiSliv(playerid, "/offban")) return true;

	format(query, sizeof query, "Administrator %s banned player %s for %d days", GetPlayerNameEx(playerid), player_name, days);

	if(strlen(reason) > 0)
		format(query, sizeof query, "%s. Reason: %s", query, reason);

	if(!strlen(reason)) reason = "None";

	SendClientMessageToAll(0xFF5533FF, query);

	format(query, sizeof query, "Offline banned %s[acc:%d] for %d days. Reason: %s", player_name, uid, days, reason);
	SendLog(playerid, LOG_TYPE_SUPERADMIN_ACTION, query);

	format(reason, sizeof reason, "s", reason);

	AddBan(uid, gettime(), days, uip, reason, GetPlayerNameEx(playerid));

	return 1;
}

CMD:house(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 4) return 1;

	extract params -> new house_id; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /house [house number]");

	if(!(0 <= house_id <= g_house_loaded-1)) return SendClientMessage(playerid, 0xCECECEFF, "This house does not exist on the server");

	new Float: x,
		Float: y,
		Float: z,
		Float: angle;

	if(GetHouseData(house_id, H_ENTRACE) != -1)
	{
		EnterPlayerToEntrance(playerid, GetHouseData(house_id, H_ENTRACE));

		x = GetHouseData(house_id, H_POS_X);
		y = GetHouseData(house_id, H_POS_Y);
		z = GetHouseData(house_id, H_POS_Z);
	}
	else
	{
		x = GetHouseData(house_id, H_EXIT_POS_X);
		y = GetHouseData(house_id, H_EXIT_POS_Y);
		z = GetHouseData(house_id, H_EXIT_POS_Z);
		angle = GetHouseData(house_id, H_EXIT_ANGLE);
	}
	SetPlayerPosEx(playerid, x, y, z, angle);

	new fmt_text[35];

	format(fmt_text, sizeof fmt_text, "You teleported to house #%d", house_id);
	SendClientMessage(playerid, -1, fmt_text);

	format(fmt_text, sizeof fmt_text, " to house %d", house_id);
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_text);

	return 1;
}

CMD:biz(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 4) return 1;

	extract params -> new biz_id; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /biz [business number]");

	if(!(0 <= biz_id <= g_business_loaded-1)) return SendClientMessage(playerid, 0xCECECEFF, "This business does not exist on the server");

	SetPlayerPosEx
	(
		playerid,
		GetBusinessData(biz_id, B_POS_X),
		GetBusinessData(biz_id, B_POS_Y),
		GetBusinessData(biz_id, B_POS_Z) + 1.0,
		0.0
	);

	new fmt_text[35];

	format(fmt_text, sizeof fmt_text, "You teleported to business #%d", biz_id);
	SendClientMessage(playerid, -1, fmt_text);

	format(fmt_text, sizeof fmt_text, "Teleported to business %d", biz_id);
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_text);

	return 1;
}

CMD:fuelstation(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 4) return 1;

	extract params -> new fs_id; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /fuelstation [gas station number]");

	if(!(0 <= fs_id <= g_fuel_station_loaded-1)) return SendClientMessage(playerid, 0xCECECEFF, "This gas station does not exist on the server");

	SetPlayerPosEx
	(
		playerid,
		GetFuelStationData(fs_id, FS_POS_X),
		GetFuelStationData(fs_id, FS_POS_Y),
		GetFuelStationData(fs_id, FS_POS_Z),
		0.0
	);

	new fmt_text[35];

	format(fmt_text, sizeof fmt_text, "You teleported to gas station #%d", fs_id);
	SendClientMessage(playerid, -1, fmt_text);

	format(fmt_text, sizeof fmt_text, "Teleported to gas station %d", fs_id);
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_text);

	return 1;
}

CMD:inter(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 1) return ShowNotificationSile(playerid, 2, 3, 0, 0, "You do not have access to use this command", " ");

	extract params -> new to_player, interior; else return SendClientMessage(playerid, 0xCECECEFF, ""SC"Usage: /inter [player id] [interior]");

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
		return ShowNotificationSile(playerid, 2, 4, 0, 0, "Player not found", " ");
	if(TEST_SERVER == 1)
	{
	    if(playerid != to_player) return SendClientMessage(playerid, -1, "{ff2400}| {ffffff}This command can only be used on yourself on the TEST SERVER!");
	}

	SetPlayerInterior(to_player, interior);

	new fmt_msg[999];

	new fmt_text[999];

	format(fmt_msg, sizeof fmt_msg, "[A] %s[%d] set %s[%d] interior %d", GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player, interior);
	SendMessageToAdmins(fmt_msg, 0x999999FF);

    format(fmt_msg, sizeof fmt_msg, "{1E90FF}You set %s[%d] interior %d", GetPlayerNameEx(to_player), to_player, interior);
    SendClientMessage(playerid, 0x66CC00FF, fmt_msg);

	format(fmt_msg, sizeof fmt_msg, "{1E90FF}Administrator %s[%d] set your interior %d", GetPlayerNameEx(playerid), playerid, interior);
	SendClientMessage(to_player, 0x66CC00FF, fmt_msg);

	LinkVehicleToInterior(GetPlayerData(to_player, P_BUY_CAR), interior);

	format(fmt_text, sizeof fmt_text, "Set %s[acc:%d] interior %d", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player), interior);
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_text);

	return 1;
}

CMD:world(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 1) return 1;

	extract params -> new to_player, world; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /world [player id] [virtual world]");

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
		return SendClientMessage(playerid, 0xCECECEFF, "Player not found");
	if(TEST_SERVER == 1)
	{
	    if(playerid != to_player) return SendClientMessage(playerid, -1, "{ff2400}| {ffffff}This command can only be used on yourself on the TEST SERVER!");
	}

	SetPlayerVirtualWorld(to_player, world);

	new fmt_text[110];

	format(fmt_text, sizeof fmt_text, "You set %s[%d] virtual world %d", GetPlayerNameEx(to_player), to_player, world);
	SendClientMessage(playerid, -1, fmt_text);

	format(fmt_text, sizeof fmt_text, "%s[%d] set your virtual world %d", GetPlayerNameEx(playerid), playerid, world);
	SendClientMessage(to_player, -1, fmt_text);

	if(GetPlayerAdminEx(playerid) <= 5)
	{
		format(fmt_text, sizeof fmt_text, "[A] Administrator %s[%d] set %s[%d] virtual world #%d", GetPlayerNameEx(playerid), playerid,
		GetPlayerNameEx(to_player), to_player, world);
		SendMessageToAdmins(fmt_text, 0x999999FF);
	}

	format(fmt_text, sizeof fmt_text, "Set %s[acc:%d] virtual world %d", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player), world);
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_text);

	return 1;
}

CMD:warn(playerid, params[])
{

	if(GetPlayerAdminEx(playerid) < 2) return 1;

	if(!strlen(params)) return SendClientMessage(playerid, 0xCECECEFF, "Usage: /warn [player id] [reason (optional)]");

	extract params -> new to_player, string:reason[66];

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
		return SendClientMessage(playerid, 0xCECECEFF, "Player not found");

	if(GetPlayerAdminEx(to_player) > GetPlayerAdminEx(playerid))
		return SendClientMessage(playerid, 0xCECECEFF, "Cannot give a warning to an admin with higher rank");

	if(AntiSliv(playerid, "/warn")) return true;

	AddPlayerData(to_player, P_WARN, +, 1);
	SetPlayerData(to_player, P_WARN_TIME, gettime() + (86400 * 10));

	new fmt_msg[128];
	format(fmt_msg, sizeof fmt_msg, "Administrator %s gave a warning to player %s [%d|3]", GetPlayerNameEx(playerid), GetPlayerNameEx(to_player), GetPlayerData(to_player, P_WARN));

	if(strlen(reason) > 0)
		format(fmt_msg, sizeof fmt_msg, "%s. Reason: %s", fmt_msg, reason);

	SendClientMessageToAll(0xFF5533FF, fmt_msg);

	InvitePlayer(to_player, 0, 0, true);

	new uid = GetPlayerAccountID(to_player);
	new warns = GetPlayerData(to_player, P_WARN);
	new warns_time = GetPlayerData(to_player, P_WARN_TIME);

	format(fmt_msg, sizeof fmt_msg, "Gave warn to %s[acc:%d] (%d/3). Reason: %d", GetPlayerNameEx(to_player), uid, warns, reason);
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_msg);

	if(warns >= 3)
	{
		SendClientMessage(to_player, 0xFF5533FF, "Account banned for 10 days");

		warns =
		warns_time = 0;

		AddBan(uid, gettime(), 10, GetPlayerIpEx(to_player), "received 3 warnings", GetPlayerNameEx(playerid));
		BanEx(to_player, "received 3 warnings");
	}
	else Kick:(to_player);

	format(fmt_msg, sizeof fmt_msg, "UPDATE accounts SET warn=%d,warn_time=%d WHERE id=%d", warns, warns_time, uid);
	mysql_query(mysql, fmt_msg, false);

	return 1;
}

CMD:unwarn(playerid, params[])
{

	if(GetPlayerAdminEx(playerid) < 2) return 1;
	if(!strlen(params)) return SendClientMessage(playerid, 0xCECECEFF, "Usage: /unwarn [player id] [reason (optional)]");

	extract params -> new to_player, string: reason[66];
	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
		return SendClientMessage(playerid, 0xCECECEFF, "Player not found");

	SetPlayerData(to_player, P_WARN, 		0);
	SetPlayerData(to_player, P_WARN_TIME, 	0);

	UpdatePlayerDatabaseInt(to_player, "warn", 		0);
	UpdatePlayerDatabaseInt(to_player, "warn_time", 	0);

	new fmt_msg[128];
	format(fmt_msg, sizeof fmt_msg, "Administrator %s removed all warnings from player %s", GetPlayerNameEx(playerid), GetPlayerNameEx(to_player));

	if(strlen(reason) > 0)
		format(fmt_msg, sizeof fmt_msg, "%s. Reason: %s", fmt_msg, reason);

	SendClientMessageToAll(0xFF5533FF, fmt_msg);

	format(fmt_msg, sizeof fmt_msg, "Removed all warns from %s[acc:%d]", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player));
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_msg);

	return 1;
}

CMD:spawn(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 2) return ShowNotificationSile(playerid, 2, 3, 0, 0, "You do not have access to use this command", " ");

	extract params -> new to_player, string: reason[30]; else return SendClientMessage(playerid, 0xCECECEFF, ""SC"Usage: /spawn [player id] [Reason]");

	if(TEST_SERVER == 1)
	{
	    if(playerid != to_player) return SendClientMessage(playerid, -1, "{ff2400}| {ffffff}On the TEST SERVER this command can only be used on yourself!");
	}

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player)) return ShowNotificationSile(playerid, 2, 4, 0, 0, "Player not found", " ");

	SetPlayerSpawnInit(to_player);
	SpawnPlayer(to_player);

	new fmt_msg[999];

	if(strlen(reason))
		format(fmt_msg, sizeof fmt_msg, "%s. Reason: %s", fmt_msg, reason);

		format(fmt_msg, sizeof fmt_msg, "[A] %s[%d] respawned %s[%d]. Reason: %s ", GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player, reason);
		SendMessageToAdmins(fmt_msg, 0x999999FF);

    	format(fmt_msg, sizeof fmt_msg, "{1E90FF}You respawned %s[%d]. Reason: %s ", GetPlayerNameEx(to_player), to_player, reason);
    	SendClientMessage(playerid, 0x66CC00FF, fmt_msg);

	format(fmt_msg, sizeof fmt_msg, "{1E90FF}You were respawned by administrator %s[%d]. Reason: %s ", GetPlayerNameEx(playerid), playerid, reason);
	SendClientMessage(to_player, 0x66CC00FF, fmt_msg);

	InfoAstats[3] += 1;

	format(fmt_msg, sizeof fmt_msg, "Respawned %s[acc:%d]. Reason: %s",
	GetPlayerNameEx(to_player), GetPlayerAccountID(to_player), reason);
	return 1;
}

CMD:spcar(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 3) return 1;

	extract params -> new vehicleid; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /spcar [vehicle id]");

	if(IsPlayerInAnyVehicle(playerid) && vehicleid == 0) vehicleid = GetPlayerVehicleID(playerid);

	if(!IsValidVehicle(vehicleid)) return SendClientMessage(playerid, 0xCECECEFF, "This vehicle does not exist on the server");

	SetVehicleToRespawn(vehicleid);

	new fmt_msg[100];

	if(GetPlayerAdminEx(playerid) <= 5)
	{
		format(fmt_msg, sizeof fmt_msg, "[A] Administrator %s[%d] respawned vehicle [#%d]", GetPlayerNameEx(playerid), playerid, vehicleid);
		SendMessageToAdmins(fmt_msg, 0x999999FF);
	}

	format(fmt_msg, sizeof fmt_msg, "Respawned vehicle #%d", vehicleid);
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_msg);

	return 1;
}

CMD:tplist(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 1) return 1;

	ShowTeleportList(playerid);

	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, "Uses teleport menu");

	return 1;
}

CMD:tp(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 1 && GetPlayerYouTubeEx(playerid) < 1)
	return ShowNotificationSile(playerid, 2, 3, 0, 0, "You do not have access to use this command", " ");

	ShowTeleportList(playerid);

	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, "Uses teleport menu");

	return 1;
}

alias:goto("g")

CMD:goto(playerid, params[])
{
    if(GetPlayerAdminEx(playerid) < 1 && GetPlayerYouTubeEx(playerid) < 1)
    return ShowNotificationSile(playerid, 2, 3, 0, 0, "You do not have access to use this command", " ");

	extract params -> new to_player; else return SendClientMessage(playerid, 0xCECECEFF, ""SC"Usage: /goto [player id]");

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
		return ShowNotificationSile(playerid, 2, 4, 0, 0, "Player not found", " ");

    if(GetPlayerSecretEx(to_player) >= 1)
	    return SendClientMessage(playerid, 0xCECECEFF, "Player has stealth privilege");

	new Float: x, Float: y, Float: z, interior, virtual_world;
	GetPlayerPos(to_player, x, y, z);
	interior = GetPlayerInterior(to_player);
	virtual_world = GetPlayerVirtualWorld(to_player);

	SetPlayerPosEx(playerid, x + 1, y + 1, z, 0.0, interior, virtual_world, false);

	SetPlayerInHouse(playerid, GetPlayerInHouse(to_player));
	SetPlayerInBiz(playerid, GetPlayerInBiz(to_player));

	new fmt_msg[999];
    format(fmt_msg, sizeof fmt_msg, "[A] %s[%d] teleported to %s[%d]", GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player);
    SendMessageToAdmins(fmt_msg, 0x999999FF);

	format(fmt_msg, sizeof fmt_msg, "{1E90FF}You successfully teleported to player %s[%d]", GetPlayerNameEx(to_player), to_player);
	SendClientMessage(playerid, 0x66CC00FF, fmt_msg);

	format(fmt_msg, sizeof fmt_msg, "{1E90FF}Administrator %s[%d] successfully teleported to you.", GetPlayerNameEx(playerid), playerid);
	SendClientMessage(to_player, 0x66CC00FF, fmt_msg);

	format(fmt_msg, sizeof fmt_msg, "Teleported to %s[acc:%d]", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player));
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_msg);

	return 1;
}

alias:gethere("gh")

CMD:gethere(playerid, params[])
{
    if(!(GetPlayerAdminEx(playerid) >= 2 || GetPlayerYouTubeEx(playerid) >= 1))
    return ShowNotificationSile(playerid, 2, 3, 0, 0, "You do not have access to use this command", " ");

	extract params -> new to_player; else return SendClientMessage(playerid, 0xCECECEFF, ""SC"Usage: /gethere [player id]");

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
		return ShowNotificationSile(playerid, 2, 4, 0, 0, "Player not found", " ");

	if(GetPlayerSecretEx(to_player) >= 1)
		return SendClientMessage(playerid, 0xCECECEFF, "Player has stealth privilege");

	if(GetPlayerAdminEx(to_player) > GetPlayerAdminEx(playerid))
	{
		SendClientMessage(playerid, 0x66CC33FF, "You are trying to teleport a higher-rank admin to you, they must confirm your action");
		SendPlayerOffer(playerid, to_player, OFFER_TYPE_GETHERE);
	}
	else
	{
		new Float: x, Float: y, Float: z;
		GetPlayerPos(playerid, x, y, z);
		SetPlayerPosEx(to_player, x + 1, y + 1, z, 0.0, GetPlayerInterior(playerid), GetPlayerVirtualWorld(playerid), false);

		SetPlayerInHouse(to_player, GetPlayerInHouse(playerid));
		SetPlayerInBiz(to_player, GetPlayerInBiz(playerid));

		new fmt_msg[999];
		format(fmt_msg, sizeof fmt_msg, "[A] %s[%d] teleported %s[%d] to themselves", GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player);
		SendMessageToAdmins(fmt_msg, 0x999999FF);

		format(fmt_msg, sizeof fmt_msg, "{1E90FF}You successfully teleported %s[%d] to you", GetPlayerNameEx(to_player), to_player);
		SendClientMessage(playerid, -1, fmt_msg);

	    format(fmt_msg, sizeof fmt_msg, "{1E90FF}Administrator %s[%d] successfully teleported you to them.", GetPlayerNameEx(playerid), playerid);
    	SendClientMessage(to_player, 0x66CC00FF, fmt_msg);

		format(fmt_msg, sizeof fmt_msg, "Teleported %s[acc:%d] to themselves", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player));
		SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_msg);
	}

	return 1;
}

CMD:vtp(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 2) return 1;

	extract params -> new to_vehicleid; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /vtp [vehicle id]");
	if(!IsValidVehicle(to_vehicleid)) return SendClientMessage(playerid, 0xCECECEFF, "This vehicle does not exist on the server");

	new Float: x, Float: y, Float: z;
	GetVehiclePos(to_vehicleid, x, y, z);

	SetPlayerPosEx(playerid, x + 1, y + 1, z, 0.0, false);

	SendClientMessage(playerid, -1, "You were teleported");

	new fmt_msg[105];

	format(fmt_msg, sizeof fmt_msg, "Teleported to vehicle #%d", to_vehicleid);
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_msg);

	if(GetPlayerAdminEx(playerid) <= 5)
	{
		format(fmt_msg, sizeof fmt_msg, "[A] %s[%d] teleported to vehicle #%d", GetPlayerNameEx(playerid), playerid, to_vehicleid);
		SendMessageToAdmins(fmt_msg, 0x999999FF);
	}

	return 1;
}

CMD:vget(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 1) return ShowNotificationSile(playerid, 2, 3, 0, 0, "You do not have access to use this command", " ");

	extract params -> new vehicleid; else return SendClientMessage(playerid, 0xCECECEFF, ""SC"Usage: /vget [vehicle id]");
	if(!IsValidVehicle(vehicleid)) return SendClientMessage(playerid, 0xCECECEFF, "This vehicle does not exist on the server");

	new Float: x, Float: y, Float: z;
	GetPlayerPos(playerid, x, y, z);

	SetVehiclePos(vehicleid, x + 2.0, y + 2.0, z);

	new fmt_msg[999];

	format(fmt_msg, sizeof fmt_msg, "Teleported vehicle #%d to yourself", vehicleid);
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_msg);

	format(fmt_msg, sizeof fmt_msg, "[A] %s[%d] teleported vehicle #%d to themselves", GetPlayerNameEx(playerid), playerid, vehicleid);
	SendMessageToAdmins(fmt_msg, 0x999999FF);

	SendClientMessage(playerid, -1, "{1E90FF}You teleported vehicle to you");

	return 1;
}

CMD:getv(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 1) return ShowNotificationSile(playerid, 2, 3, 0, 0, "You do not have access to use this command", " ");

	extract params -> new to_player; else return SendClientMessage(playerid, 0xCECECEFF, ""SC"Usage: /getv [player id]");

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
		return ShowNotificationSile(playerid, 2, 4, 0, 0, "Player not found", " ");

	if(GetPlayerOwnableCar(to_player) == INVALID_VEHICLE_ID)
		return SendClientMessage(playerid, 0x999999FF, ""SC"Player has no personal vehicle");

	new fmt_text[999],
		Float: x,
		Float: y,
		Float: z;

	GetPlayerPos(to_player, x, y, z);

	SetVehiclePos(GetPlayerOwnableCar(to_player), x + 2.0, y + 2.0, z);

	format(fmt_text, sizeof fmt_text, "[A] %s[%d] teleported %s[%d]'s personal vehicle to them", GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player);
	SendMessageToAdmins(fmt_text, 0x999999FF);

	format(fmt_text, sizeof fmt_text, "{1E90FF}You teleported %s[%d]'s personal vehicle to them", GetPlayerNameEx(to_player), to_player);
	SendClientMessage(playerid, -1, fmt_text);

	format(fmt_text, sizeof fmt_text, "{1E90FF}Administrator %s[%d] teleported your personal vehicle to you", GetPlayerNameEx(playerid), playerid);
	SendClientMessage(to_player, -1, fmt_text);

	format(fmt_text, sizeof fmt_text, "Teleported %s[acc:%d]'s vehicle to them", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player));
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_text);

	return 1;
}

CMD:fixcar(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 2) return ShowNotificationSile(playerid, 2, 3, 0, 0, "You do not have access to use this command", " ");

	extract params -> new to_player; else return SendClientMessage(playerid, 0xCECECEFF, ""SC"Usage: /fixcar [player id]");

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
		return ShowNotificationSile(playerid, 2, 4, 0, 0, "Player not found", " ");

	if(!IsPlayerInAnyVehicle(to_player))
		return SendClientMessage(playerid, 0x999999FF, ""SC"Player must be in a vehicle");

	new fmt_text[999],
		vehicleid = GetPlayerVehicleID(to_player);

	RepairVehicle(vehicleid);
	if(IsAOwnableCar(vehicleid)) SetVehicleData(vehicleid, V_HEALTH, 1000.0);

	format(fmt_text, sizeof fmt_text, ""SC"You repaired player %s's vehicle", GetPlayerNameEx(to_player));
	SendClientMessage(playerid, -1, fmt_text);

	format(fmt_text, sizeof fmt_text, "{1E90FF}Administrator %s repaired your vehicle", GetPlayerNameEx(playerid));
	SendClientMessage(to_player, -1, fmt_text);

	format(fmt_text, sizeof fmt_text, "[A] %s[%d] repaired player %s[%d]'s vehicle", GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player);
	SendMessageToAdmins(fmt_text, 0x999999FF);

	format(fmt_text, sizeof fmt_text, "Repaired %s[acc:%d]'s vehicle", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player));
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_text);

	return 1;
}

CMD:setfuel(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 3) return 1;

	extract params -> new vehicleid, fuel; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /setfuel [vehicle id] [fuel amount]");

	if(!IsValidVehicle(vehicleid)) return SendClientMessage(playerid, 0xCECECEFF, "This vehicle does not exist on the server");

	if(!(0 <= fuel <= 150)) return SendClientMessage(playerid, 0x999999FF, "Fuel amount from 0 to 150");

	SetVehicleData(vehicleid, V_FUEL, fuel);

	new fmt_text[80];

	format(fmt_text, sizeof fmt_text, "You set %d fuel in vehicle #%d", fuel, vehicleid);
	SendClientMessage(playerid, -1, fmt_text);

	if(GetPlayerAdminEx(playerid) >= 5)
	{
		format(fmt_text, sizeof fmt_text, "[A] %s[%d] set %d fuel in vehicle #%d", GetPlayerNameEx(playerid), playerid, fuel, vehicleid);
		SendMessageToAdmins(fmt_text, 0x999999FF);
	}

	format(fmt_text, sizeof fmt_text, "Set %d fuel in vehicle #%d", fuel, vehicleid);
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_text);

	return 1;
}

CMD:settime(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 4) return 1;

	extract params -> new time; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /settime [time (0-23)]");

	if(!(0 <= time <= 23)) return SendClientMessage(playerid, 0x999999FF, "Time from 0 to 23 hours");

	SetWorldTime(time);

	new fmt_text[70];

	format(fmt_text, sizeof fmt_text, "You set time %02d:00", time);
	SendClientMessage(playerid, -1, fmt_text);

	if(GetPlayerAdminEx(playerid) <= 5)
	{
		format(fmt_text, sizeof fmt_text, "[A] %s[%d] set server time to %02d:00", GetPlayerNameEx(playerid), playerid, time);
		SendMessageToAdmins(fmt_text, 0x999999FF);
	}

	format(fmt_text, sizeof fmt_text, "Set server time to %02d:00", time);
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_text);

	return 1;
}

CMD:setweather(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 4) return 1;

	extract params -> new weather; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /setweather [weather (0-20)]");

	if(!(-1 <= weather <= 20))
	{
		SendClientMessage(playerid, 0x999999FF, "Weather from 0 to 20 (-1 - random weather change)");
		SendClientMessage(playerid, 0x999999FF, "Recommended: 1, 3, 8, 9, 18");

		return 1;
	}

	if(weather != -1)
		SetWeather(weather);
	else
		SetRandomWeather();

	new fmt_text[70];

	if(weather != -1)
		format(fmt_text, sizeof fmt_text, "You set weather %d", weather);
	else
		format(fmt_text, sizeof fmt_text, "You set random weather");

	SendClientMessage(playerid, -1, fmt_text);

	if(GetPlayerAdminEx(playerid) <= 5)
	{
		if(weather != -1)
			format(fmt_text, sizeof fmt_text, "[A] %s[%d] set server weather to %d", GetPlayerNameEx(playerid), playerid, weather);
		else
			format(fmt_text, sizeof fmt_text, "[A] %s[%d] set random weather on server", GetPlayerNameEx(playerid), playerid);

		SendMessageToAdmins(fmt_text, 0x999999FF);
	}

	format(fmt_text, sizeof fmt_text, "Set weather #%d on server", weather);
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_text);

	return 1;
}

CMD:payday(playerid, params[])
{
	if(strcmp(GetPlayerNameEx(playerid), "Danya_Coder", true) != 0) return ShowNotificationSile(playerid, 2, 6, -1, -1, "The command you entered was not found", "");

	OnPayDay();

	new fmt_text[50];

	SendClientMessage(playerid, -1, "You initiated PayDay");

	format(fmt_text, sizeof fmt_text, "[A] %s[%d] initiated PayDay", GetPlayerNameEx(playerid), playerid);
	SendMessageToAdmins(fmt_text, 0x999999FF);

	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, "Initiated PayDay");

	return 1;
}

CMD:gzcolor(playerid, params[])
{
	if(strcmp(GetPlayerNameEx(playerid), "Danya_Coder", true) != 0) return ShowNotificationSile(playerid, 2, 6, -1, -1, "The command you entered was not found", "");

	extract params -> new gang_id; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /gzcolor [gang id] (0-Free zone, 1-Arzamas gang, 2-Batyrevo gang, 3-Lytkarino gang)");

	if(!(0 <= gang_id <= 3))
		return SendClientMessage(playerid, 0x999999FF, "Gangs: 0-Free zone, 1-Arzamas gang, 2-Batyrevo gang, 3-Lytkarino gang");

	new gang_zone_id = -1;

	for(new idx; idx < g_gang_zones_loaded; idx ++)
	{
		if(!IsPlayerInDynamicArea(playerid, GetGangZoneData(idx, GZ_AREA))) continue;

		gang_zone_id = idx;
		break;
	}

	if(gang_zone_id == -1)
		return SendClientMessage(playerid, 0x999999FF, "You must be on the required territory");

	new fmt_text[75];

	SendClientMessage(playerid, -1, "You changed the gang owning this territory");

	format(fmt_text, sizeof fmt_text, "[A] %s[%d] changed gang for territory #%d to %d", GetPlayerNameEx(playerid), playerid, gang_zone_id, gang_id);
	SendMessageToAdmins(fmt_text, 0x999999FF);

	format(fmt_text, sizeof fmt_text, "Changed gang for territory #%d to %d", gang_zone_id, gang_id);
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_text);

	return 1;
}

CMD:sellproperty(playerid, params[])
{
	if(strcmp(GetPlayerNameEx(playerid), "Danya_Coder", true) != 0) return ShowNotificationSile(playerid, 2, 6, -1, -1, "The command you entered was not found", "");

	SellDebtorsProperty();

	new fmt_text[75];

	SendClientMessage(playerid, -1, "You initiated sale of debtors' property");

	format(fmt_text, sizeof fmt_text, "[A] %s[%d] initiated sale of debtors' property", GetPlayerNameEx(playerid), playerid);
	SendMessageToAdmins(fmt_text, 0x999999FF);

	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, "Initiated sale of debtors' property");

	return 1;
}

CMD:sellhotels(playerid, params[])
{
	if(strcmp(GetPlayerNameEx(playerid), "Danya_Coder", true) != 0) return ShowNotificationSile(playerid, 2, 6, -1, -1, "The command you entered was not found", "");

	SellDebtorsHotels();

	new fmt_text[90];

	SendClientMessage(playerid, -1, "You initiated sale of hotel rooms with debt");

	format(fmt_text, sizeof fmt_text, "[A] %s[%d] initiated sale of hotel rooms with debt", GetPlayerNameEx(playerid), playerid);
	SendMessageToAdmins(fmt_text, 0x999999FF);

	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, "Initiated sale of hotel rooms");

	return 1;
}

CMD:setprods(playerid, params[])
{
	if(strcmp(GetPlayerNameEx(playerid), "Danya_Coder", true) != 0 && strcmp(GetPlayerNameEx(playerid), "Majorka_Gromov", true) != 0) return ShowNotificationSile(playerid, 2, 6, -1, -1, "The command you entered was not found", "");

	extract params -> new biz_id, amount; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /setprods [business id] [amount]");

	if(!(0 <= amount <= 10000))
		return SendClientMessage(playerid, 0x999999FF, "Product amount from 0 to 10000");

	if(!(0 <= biz_id <= g_business_loaded - 1))
		return SendClientMessage(playerid, 0x999999FF, "This business does not exist on the server");

	SetBusinessData(biz_id, B_PRODS, amount);

	new fmt_text[90];

	format(fmt_text, sizeof fmt_text, "UPDATE business SET products=%d WHERE id=%d", GetBusinessData(biz_id, B_PRODS), GetBusinessData(biz_id, B_SQL_ID));
	mysql_query(mysql, fmt_text, false);

	format(fmt_text, sizeof fmt_text, "You set %d products in business #%d", amount, biz_id);
	SendClientMessage(playerid, 0x66CC33FF, fmt_text);

	format(fmt_text, sizeof fmt_text, "[A] %s[%d] set %d products in business #%d", GetPlayerNameEx(playerid), playerid, amount, biz_id);
	SendMessageToAdmins(fmt_text, 0x999999FF);

	return 1;
}

CMD:fullbiz(playerid, params[])
{
	if(strcmp(GetPlayerNameEx(playerid), "Danya_Coder", true) != 0 && strcmp(GetPlayerNameEx(playerid), "Majorka_Gromov", true) != 0) return ShowNotificationSile(playerid, 2, 6, -1, -1, "The command you entered was not found", "");

	extract params -> new amount; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /fullbiz [amount]");

	if(!(0 <= amount <= 10000))
		return SendClientMessage(playerid, 0x999999FF, "Amount from 0 to 10000");

	new value[12];
	valstr(value, amount);
	callcmd::fullprods(playerid, value);
	callcmd::fullfuels(playerid, value);

	return 1;
}

CMD:fullprods(playerid, params[])
{
	if(strcmp(GetPlayerNameEx(playerid), "Danya_Coder", true) != 0 && strcmp(GetPlayerNameEx(playerid), "Majorka_Gromov", true) != 0) return ShowNotificationSile(playerid, 2, 6, -1, -1, "The command you entered was not found", "");

	extract params -> new amount; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /fullprods [amount]");

	if(!(0 <= amount <= 10000))
		return SendClientMessage(playerid, 0x999999FF, "Product amount from 0 to 10000");

	for(new biz_id; biz_id < g_business_loaded - 1; biz_id ++)
		SetBusinessData(biz_id, B_PRODS, amount);

	new fmt_text[90];

	format(fmt_text, sizeof fmt_text, "UPDATE business SET products=%d", amount);
	mysql_query(mysql, fmt_text, false);

	format(fmt_text, sizeof fmt_text, "You set %d products in all businesses", amount);
	SendClientMessage(playerid, 0x66CC33FF, fmt_text);

	format(fmt_text, sizeof fmt_text, "[A] %s[%d] set %d products in all businesses", GetPlayerNameEx(playerid), playerid, amount);
	SendMessageToAdmins(fmt_text, 0x999999FF);

	return 1;
}

CMD:setfuels(playerid, params[])
{
	if(strcmp(GetPlayerNameEx(playerid), "Danya_Coder", true) != 0 && strcmp(GetPlayerNameEx(playerid), "Majorka_Gromov", true) != 0) return ShowNotificationSile(playerid, 2, 6, -1, -1, "The command you entered was not found", "");

	extract params -> new fs_id, amount; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /setfuels [gas station id] [amount]");

	if(!(0 <= amount <= 10000))
		return SendClientMessage(playerid, 0x999999FF, "Fuel amount from 0 to 10000");

	if(!(0 <= fs_id <= g_fuel_station_loaded-1))
		return SendClientMessage(playerid, 0x999999FF, "This gas station does not exist on the server");

	SetFuelStationData(fs_id, FS_FUELS, amount);

	new fmt_text[90];

	format(fmt_text, sizeof fmt_text, "UPDATE fuel_stations SET fuels=%d WHERE id=%d", GetFuelStationData(fs_id, FS_FUELS), GetFuelStationData(fs_id, FS_SQL_ID));
	mysql_query(mysql, fmt_text, false);

	format(fmt_text, sizeof fmt_text, "You set %d fuel in gas station #%d", amount, fs_id);
	SendClientMessage(playerid, 0x66CC33FF, fmt_text);

	format(fmt_text, sizeof fmt_text, "[A] %s[%d] set %d fuel in gas station #%d", GetPlayerNameEx(playerid), playerid, amount, fs_id);
	SendMessageToAdmins(fmt_text, 0x999999FF);

	return 1;
}

CMD:fullfuels(playerid, params[])
{
	if(strcmp(GetPlayerNameEx(playerid), "Danya_Coder", true) != 0 && strcmp(GetPlayerNameEx(playerid), "Majorka_Gromov", true) != 0) return ShowNotificationSile(playerid, 2, 6, -1, -1, "The command you entered was not found", "");

	extract params -> new amount; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /fullfuels [amount]");

	if(!(0 <= amount <= 10000))
		return SendClientMessage(playerid, 0x999999FF, "Fuel amount from 0 to 10000");

	for(new fs_id; fs_id < g_fuel_station_loaded - 1; fs_id ++)
		SetFuelStationData(fs_id, FS_FUELS, amount);

	new fmt_text[90];

	format(fmt_text, sizeof fmt_text, "UPDATE fuel_stations SET fuels=%d", amount);
	mysql_query(mysql, fmt_text, false);

	format(fmt_text, sizeof fmt_text, "You set %d fuel in all gas stations", amount);
	SendClientMessage(playerid, 0x66CC33FF, fmt_text);

	format(fmt_text, sizeof fmt_text, "[A] %s[%d] set %d fuel in all gas stations", GetPlayerNameEx(playerid), playerid, amount);
	SendMessageToAdmins(fmt_text, 0x999999FF);

	return 1;
}

CMD:addbiz(playerid, params[])
{
    if(strcmp(GetPlayerNameEx(playerid), "Danya_Coder", true) != 0)
        return ShowNotificationSile(playerid, 2, 6, -1, -1, "The command you entered was not found", "");

    new type, price, rent_price, name[64];

    if(sscanf(params, "iiis[64]", type, price, rent_price, name))
        return SendClientMessage(playerid, 0xCECECEFF, "Usage: /addbiz [type] [price] [rent price] [name]");

    new fmt_text[512];

    if(!(1 <= type <= 16))
        return SendClientMessage(playerid, 0x999999FF, "Business types: 1-24/7, 2-Club, 3-Stats management, 4-Real estate, 5-Clothing, 6-Hotel, 7-Car dealer, 8-Casino, 9-Cell phone store, 10-Tuning shop, 11-Weapon shop");

    if(price < 1)
        return SendClientMessage(playerid, 0x999999FF, "Business price cannot be less than 1");

    if(rent_price < 1)
        return SendClientMessage(playerid, 0x999999FF, "Rent price cannot be less than 1");

    if(strlen(name) < 3 || strlen(name) > 64)
        return SendClientMessage(playerid, 0x999999FF, "Business name must be between 3 and 64 characters");

    new Cache: result,
        idx = g_business_loaded;

    GetPlayerPos(playerid, g_business[idx][B_POS_X], g_business[idx][B_POS_Y], g_business[idx][B_POS_Z]);

    SetBusinessData(idx, B_PRICE,            price);
    SetBusinessData(idx, B_RENT_PRICE,        rent_price);
    SetBusinessData(idx, B_TYPE,            type);
    SetBusinessData(idx, B_INTERIOR,        type-1);

    format
    (
        fmt_text, sizeof fmt_text,
        "INSERT INTO business \
        (name, type, price, rent_price, x, y, z, interior) \
        VALUES ('%s', '%d', '%d', '%f', '%f', '%f', '%f', '%d')",
        name, type, price, rent_price,
        GetBusinessData(idx, B_POS_X),
        GetBusinessData(idx, B_POS_Y),
        GetBusinessData(idx, B_POS_Z),
        type-1
    );

    result = mysql_query(mysql, fmt_text, true);

    SetBusinessData(idx, B_SQL_ID,         cache_insert_id());

    cache_delete(result);

    g_business_loaded ++;

    CreatePickup(19132, 23, GetBusinessData(idx, B_POS_X), GetBusinessData(idx, B_POS_Y), GetBusinessData(idx, B_POS_Z), 0, PICKUP_ACTION_TYPE_BIZ_ENTER, idx);

    UpdateBusinessLabel(idx);

    new city[MAX_ZONES_NAME + 1], area[MAX_ZONES_NAME + 1];
    GetCityName(GetBusinessData(idx, B_POS_X), GetBusinessData(idx, B_POS_Y), city);
    GetAreaName(GetBusinessData(idx, B_POS_X), GetBusinessData(idx, B_POS_Y), area);
    format(fmt_text, sizeof fmt_text, "[A] %s[%d] created business #%d \"%s\" (%s / %s)",
        GetPlayerNameEx(playerid), playerid, idx, name, city, area);

    SendMessageToAdmins(fmt_text, 0x66CC33FF);

    SendClientMessage(playerid, 0x3399FFFF, "Use {FF5252}/bsetexitpos{3399FF} to finish creating the business");

    return 1;
}

CMD:delbiz(playerid, params[])
{
    if(strcmp(GetPlayerNameEx(playerid), "Danya_Coder", true) != 0) return ShowNotificationSile(playerid, 2, 6, -1, -1, "The command you entered was not found", "");

    new bizid;

    if(sscanf(params, "d", bizid))
        return SendClientMessage(playerid, 0xCECECEFF, "Usage: /delbiz [Business ID]");

    if(bizid < 0 || bizid >= g_business_loaded)
        return SendClientMessage(playerid, 0x999999FF, "Invalid business ID");

    new fmt_text[320];

        DestroyDynamic3DTextLabel(GetBusinessData(bizid, B_LABEL));

    format(fmt_text, sizeof fmt_text, "DELETE FROM business WHERE id = '%d'", GetBusinessData(bizid, B_SQL_ID));
    mysql_query(mysql, fmt_text, false);

    for(new i = 0; i < MAX_BUSINESS; i++)
    {
        SetBusinessData(bizid, i, 0);
    }

    for(new i = bizid + 1; i < g_business_loaded; i++)
    {
        for(new j = 0; j < MAX_BUSINESS; j++)
        {
            SetBusinessData(i - 1, j, GetBusinessData(i, j));
        }
    }

    g_business_loaded--;

    for(new i = 0; i < g_business_loaded; i++)
    {
        UpdateBusinessLabel(i);
    }

    new city[MAX_ZONES_NAME + 1], area[MAX_ZONES_NAME + 1];
    GetCityName(GetBusinessData(bizid, B_POS_X), GetBusinessData(bizid, B_POS_Y), city);
    GetAreaName(GetBusinessData(bizid, B_POS_X), GetBusinessData(bizid, B_POS_Y), area);
    format(fmt_text, sizeof fmt_text, "[A] %s[%d] deleted business #%d (%s / %s)",
        GetPlayerNameEx(playerid), playerid, bizid, city, area);

    SendMessageToAdmins(fmt_text, 0xFF6666FF);

    SendClientMessage(playerid, 0x3399FFFF, "Business successfully deleted!");

    return 1;
}

CMD:bsetexitpos(playerid, params[])
{

	if(strcmp(GetPlayerNameEx(playerid), "Danya_Coder", true) != 0) return ShowNotificationSile(playerid, 2, 6, -1, -1, "The command you entered was not found", "");

	extract params -> new biz_id; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /bsetexitpos [business id]");

	if(!(0 <= biz_id <= g_business_loaded - 1)) return SendClientMessage(playerid, 0x999999FF, "This business does not exist on the server");

	GetPlayerPos(playerid, g_business[biz_id][B_EXIT_POS_X], g_business[biz_id][B_EXIT_POS_Y], g_business[biz_id][B_EXIT_POS_Z]);
	GetPlayerFacingAngle(playerid, g_business[biz_id][B_EXIT_ANGLE]);

	new fmt_text[144];

	format
	(
		fmt_text, sizeof fmt_text,
		"UPDATE business SET exit_x='%f', exit_y='%f', exit_z='%f', exit_angle='%f' WHERE id=%d",
		GetBusinessData(biz_id, B_EXIT_POS_X),
		GetBusinessData(biz_id, B_EXIT_POS_Y),
		GetBusinessData(biz_id, B_EXIT_POS_Z),
		GetBusinessData(biz_id, B_EXIT_ANGLE),
		GetBusinessData(biz_id, B_SQL_ID)
	);

	mysql_query(mysql, fmt_text, false);

	format(fmt_text, sizeof fmt_text, "You successfully changed the exit coordinates of business #%d", biz_id);

	SendClientMessage(playerid, 0x66CC33FF, fmt_text);

	return 1;
}

CMD:bsetpos(playerid, params[])
{

	if(strcmp(GetPlayerNameEx(playerid), "Danya_Coder", true) != 0) return ShowNotificationSile(playerid, 2, 6, -1, -1, "The command you entered was not found", "");

	extract params -> new biz_id; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /bsetpos [business id]");

	if(!(0 <= biz_id <= g_business_loaded - 1)) return SendClientMessage(playerid, 0x999999FF, "This business does not exist on the server");

	GetPlayerPos(playerid, g_business[biz_id][B_POS_X], g_business[biz_id][B_POS_Y], g_business[biz_id][B_POS_Z]);

	new fmt_text[144];

	format
	(
		fmt_text, sizeof fmt_text,
		"UPDATE business SET x='%f', y='%f', z='%f' WHERE id=%d",
		GetBusinessData(biz_id, B_POS_X),
		GetBusinessData(biz_id, B_POS_Y),
		GetBusinessData(biz_id, B_POS_Z),
		GetBusinessData(biz_id, B_SQL_ID)
	);

	mysql_query(mysql, fmt_text, false);

	format(fmt_text, sizeof fmt_text, "You successfully changed the entrance coordinates of business #%d (%s)", biz_id, GetBusinessData(biz_id, B_NAME));
	SendClientMessage(playerid, 0x66CC33FF, fmt_text);

	SendClientMessage(playerid, -1, "Don't forget to use /bsetexitpos id to change exit coordinates");
	UpdateBusinessLabel(biz_id);
	return 1;
}

CMD:addfuelst(playerid, params[])
{
	if(strcmp(GetPlayerNameEx(playerid), "Danya_Coder", true) != 0) return ShowNotificationSile(playerid, 2, 6, -1, -1, "The command you entered was not found", "");

	extract params -> new price, rent_price; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /addfuelst [price] [rent price]");

	if(price < 1) return SendClientMessage(playerid, 0xCECECEFF, "Gas station price cannot be less than 1");

	if(rent_price < 1) return SendClientMessage(playerid, 0xCECECEFF, "Gas station price cannot be less than 1");

	new Cache: result,
		idx = g_fuel_station_loaded;

	GetPlayerPos(playerid, g_fuel_station[idx][FS_POS_X], g_fuel_station[idx][FS_POS_Y], g_fuel_station[idx][FS_POS_Z]);

	new fmt_text[256];

	format
	(

		fmt_text, sizeof fmt_text,
		"INSERT INTO `fuel_stations`\
		(`price`,`rent_price`,`fuels`, `fuel_price`, `buy_fuel_price`, `balance`, `x`, `y`, `z`)\
		VALUES('%d','%d','100','50','50','100000','%f','%f','%f')",
		price, rent_price,
		GetFuelStationData(idx, FS_POS_X),
		GetFuelStationData(idx, FS_POS_Y),
		GetFuelStationData(idx, FS_POS_Z)
	);

	result = mysql_query(mysql, fmt_text, true);

	SetFuelStationData(idx, FS_SQL_ID, 		cache_insert_id());

	cache_delete(result);

	g_fuel_station_loaded ++;

	SetFuelStationData(idx, FS_LABEL, CreateDynamic3DTextLabel("gas station", 0xFF5252FF, GetFuelStationData(idx, FS_POS_X), GetFuelStationData(idx, FS_POS_Y), GetFuelStationData(idx, FS_POS_Z) + 0.3, 6.50));

	UpdateFuelStationLabel(idx);

	format(fmt_text, sizeof fmt_text, "[A] %s[%d] created gas station #%d", GetPlayerNameEx(playerid), playerid, idx);

	SendMessageToAdmins(fmt_text, 0x66CC33FF);
	return 1;
}

CMD:delfuelst(playerid, params[])
{
    if(strcmp(GetPlayerNameEx(playerid), "Danya_Coder", true) != 0) return ShowNotificationSile(playerid, 2, 6, -1, -1, "The command you entered was not found", "");

    new fstid;

    if(sscanf(params, "d", fstid))
        return SendClientMessage(playerid, 0xCECECEFF, "Usage: /delfuelst [Gas station ID]");

    if(fstid < 0 || fstid >= g_fuel_station_loaded)
        return SendClientMessage(playerid, 0x999999FF, "Invalid gas station ID");

    new fmt_text[256];

        DestroyDynamic3DTextLabel(GetFuelStationData(fstid, FS_LABEL));

    format(fmt_text, sizeof fmt_text, "DELETE FROM fuel_stations WHERE id = '%d'", GetFuelStationData(fstid, FS_SQL_ID));
    mysql_query(mysql, fmt_text, false);

    for(new i = 0; i < MAX_FUEL_STATIONS; i++)
    {
        SetFuelStationData(fstid, i, 0);
    }

    for(new i = fstid + 1; i < g_fuel_station_loaded; i++)
    {
        for(new j = 0; j < MAX_FUEL_STATIONS; j++)
        {
            SetFuelStationData(i - 1, j, GetFuelStationData(i, j));
        }
    }

    g_fuel_station_loaded--;

    for(new i = 0; i < g_fuel_station_loaded; i++)
    {
        UpdateFuelStationLabel(i);
    }

    format(fmt_text, sizeof fmt_text, "[A] %s[%d] deleted gas station #%d",
        GetPlayerNameEx(playerid), playerid, fstid);

    SendMessageToAdmins(fmt_text, 0xFF6666FF);

    SendClientMessage(playerid, 0x3399FFFF, "Gas station successfully deleted!");

    return 1;
}

CMD:addhouse(playerid, params[])
{

	if(strcmp(GetPlayerNameEx(playerid), "Danya_Coder", true) != 0) return ShowNotificationSile(playerid, 2, 6, -1, -1, "The command you entered was not found", "");

	extract params -> new type, price, rent_price; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /addhouse [type] [price] [rent price]");

	new fmt_text[300];

	if(!(0 <= type <= sizeof g_house_type - 1))
	{
		SendClientMessage(playerid, 0x999999FF, "House types:");

		for(new i; i < sizeof g_house_type; i ++)
		{
			format(fmt_text, sizeof fmt_text, "%d. %s", i, GetHouseTypeInfo(i, HT_NAME));

			SendClientMessage(playerid, 0xCECECEFF, fmt_text);
		}

		return 1;
	}

	if(price < 1) return SendClientMessage(playerid, 0x999999FF, "House price cannot be less than 1");

	if(rent_price < 1) return SendClientMessage(playerid, 0x999999FF, "Rent price cannot be less than 1");

	new Cache: result,
		idx = g_house_loaded;

	GetPlayerPos(playerid, g_house[idx][H_POS_X], g_house[idx][H_POS_Y], g_house[idx][H_POS_Z]);

	SetHouseData(idx, H_PRICE,			price);
	SetHouseData(idx, H_RENT_PRICE,		rent_price);
	SetHouseData(idx, H_TYPE,			type);

	SetHouseData(idx, H_ENTRACE,		-1);

	format
	(
		fmt_text, sizeof fmt_text,
		"INSERT INTO houses \
		(type, price, rent_price, x, y, z)\
		VALUES ('%d', '%d', '%f', '%f', '%f', '%f')",
		type, price, rent_price,
		GetHouseData(idx, H_POS_X),
		GetHouseData(idx, H_POS_Y),
		GetHouseData(idx, H_POS_Z)
	);

	result = mysql_query(mysql, fmt_text, true);

	SetHouseData(idx, H_SQL_ID, 		cache_insert_id());

	cache_delete(result);

	g_house_loaded ++;

	UpdateHouse(idx);

	new city[MAX_ZONES_NAME + 1], area[MAX_ZONES_NAME + 1];
	GetCityName(GetHouseData(idx, H_POS_X), GetHouseData(idx, H_POS_Y), city);
	GetAreaName(GetHouseData(idx, H_POS_X), GetHouseData(idx, H_POS_Y), area);
	format(fmt_text, sizeof fmt_text, "[A] %s[%d] created house #%d (%s / %s)", GetPlayerNameEx(playerid), playerid, idx, city, area);

	SendMessageToAdmins(fmt_text, 0x66CC33FF);

	SendClientMessage(playerid, 0x3399FFFF, "Use {FF5252}/setexitpos and /setcarpos{3399FF} to finish creating the house");

	return 1;
}

CMD:delhouse(playerid, params[])
{
    if(strcmp(GetPlayerNameEx(playerid), "Danya_Coder", true) != 0) return ShowNotificationSile(playerid, 2, 6, -1, -1, "The command you entered was not found", "");

    new houseid;

    if(sscanf(params, "d", houseid))
        return SendClientMessage(playerid, 0xCECECEFF, "Usage: /delhouse [House ID]");

    if(houseid < 0 || houseid >= g_house_loaded)
        return SendClientMessage(playerid, 0x999999FF, "Invalid house ID");

    new fmt_text[300];

        DestroyPickup(GetHouseData(houseid, H_ENTER_PICKUP));

    format(fmt_text, sizeof fmt_text, "DELETE FROM houses WHERE id = '%d'", GetHouseData(houseid, H_SQL_ID));
    mysql_query(mysql, fmt_text, false);

    format(fmt_text, sizeof fmt_text, "DELETE FROM house_cars WHERE house_id = '%d'", GetHouseData(houseid, H_SQL_ID));
    mysql_query(mysql, fmt_text, false);

    for(new i = 0; i < MAX_HOUSES; i++)
    {
        SetHouseData(houseid, i, 0);
    }

    for(new i = houseid + 1; i < g_house_loaded; i++)
    {
        for(new j = 0; j < MAX_HOUSES; j++)
        {
            SetHouseData(i - 1, j, GetHouseData(i, j));
        }
    }

    g_house_loaded--;

    for(new i = 0; i < g_house_loaded; i++)
    {
        UpdateHouse(i);
    }

    new city[MAX_ZONES_NAME + 1], area[MAX_ZONES_NAME + 1];
    GetCityName(GetHouseData(houseid, H_POS_X), GetHouseData(houseid, H_POS_Y), city);
    GetAreaName(GetHouseData(houseid, H_POS_X), GetHouseData(houseid, H_POS_Y), area);
    format(fmt_text, sizeof fmt_text, "[A] %s[%d] deleted house #%d (%s / %s)",
        GetPlayerNameEx(playerid), playerid, houseid, city, area);

    SendMessageToAdmins(fmt_text, 0xFF6666FF);

    SendClientMessage(playerid, -1, "House successfully deleted!");

    return 1;
}

CMD:setexitpos(playerid, params[])
{
    if(strcmp(GetPlayerNameEx(playerid), "Danya_Coder", true) != 0) return ShowNotificationSile(playerid, 2, 6, -1, -1, "The command you entered was not found", "");

	extract params -> new house_id; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /setexitpos [house id]");

	if(!(0 <= house_id <= g_house_loaded - 1)) return SendClientMessage(playerid, 0x999999FF, "This house does not exist on the server");

	GetPlayerPos(playerid, g_house[house_id][H_EXIT_POS_X], g_house[house_id][H_EXIT_POS_Y], g_house[house_id][H_EXIT_POS_Z]);
	GetPlayerFacingAngle(playerid, g_house[house_id][H_EXIT_ANGLE]);

	new fmt_text[144];

	format
	(
		fmt_text, sizeof fmt_text,
		"UPDATE houses SET exit_x='%f', exit_y='%f', exit_z='%f', exit_angle='%f' WHERE id=%d",
		GetHouseData(house_id, H_EXIT_POS_X),
		GetHouseData(house_id, H_EXIT_POS_Y),
		GetHouseData(house_id, H_EXIT_POS_Z),
		GetHouseData(house_id, H_EXIT_ANGLE),
		GetHouseData(house_id, H_SQL_ID)
	);

	mysql_query(mysql, fmt_text, false);

	format(fmt_text, sizeof fmt_text, "You successfully changed the exit coordinates of house #%d", house_id);

	SendClientMessage(playerid, 0x66CC33FF, fmt_text);

	return 1;
}

CMD:setcarpos(playerid, params[])
{

	if(strcmp(GetPlayerNameEx(playerid), "Danya_Coder", true) != 0) return ShowNotificationSile(playerid, 2, 6, -1, -1, "The command you entered was not found", "");

	extract params -> new house_id; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /setcarpos [house id]");

	if(!(0 <= house_id <= g_house_loaded - 1)) return SendClientMessage(playerid, 0x999999FF, "This house does not exist on the server");

	GetPlayerPos(playerid, g_house[house_id][H_CAR_POS_X], g_house[house_id][H_CAR_POS_Y], g_house[house_id][H_CAR_POS_Z]);
	GetPlayerFacingAngle(playerid, g_house[house_id][H_CAR_ANGLE]);

	new fmt_text[144];

	format
	(
		fmt_text, sizeof fmt_text,
		"UPDATE houses SET car_x='%f', car_y='%f', car_z='%f', car_angle='%f' WHERE id=%d",
		GetHouseData(house_id, H_CAR_POS_X),
		GetHouseData(house_id, H_CAR_POS_Y),
		GetHouseData(house_id, H_CAR_POS_Z),
		GetHouseData(house_id, H_CAR_ANGLE),
		GetHouseData(house_id, H_SQL_ID)
	);

	mysql_query(mysql, fmt_text, false);

	format(fmt_text, sizeof fmt_text, "You successfully changed the vehicle spawn coordinates of house #%d", house_id);

	SendClientMessage(playerid, 0x66CC33FF, fmt_text);

	return 1;
}

CMD:getname(playerid, params[])
{
	if(strcmp(GetPlayerNameEx(playerid), "Danya_Coder", true) != 0) return ShowNotificationSile(playerid, 2, 6, -1, -1, "The command you entered was not found", "");

	extract params -> new user_id; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /getname [account ID]");

	new name[21],
		fmt_text[120];

	format(name, sizeof name, "%s", GetPlayerNameBySqlID(user_id));

	if(strcmp(name, "none", true))
	{
		format(fmt_text, sizeof fmt_text, "Name: %s / Account ID: %d", name, user_id);

		SendClientMessage(playerid, 0x3399FFFF, fmt_text);
	}
	else SendClientMessage(playerid, 0x999999FF, "This account not found in database");

	return 1;
}

CMD:slap(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 2) return 1;

	extract params -> new to_player, set_code, string: reason[30]; else {

		SendClientMessage(playerid, 0xCECECEFF, ""SC"Usage: /slap [player id] [0 - up, 1 - down] [reason]");

		return 1;
	}

	new Float: x, Float: y, Float: z, fmt_text[999];
	GetPlayerPos(to_player, x, y, z);

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
		return ShowNotificationSile(playerid, 2, 4, 0, 0, "Player not found", " ");

	new fmt_msg[999];

	switch(set_code)
	{
		case 0:
		{
			SetPlayerPos(to_player, x, y, z + 5);
			PlayerPlaySound(to_player, 1130, 0.0, 0.0, 0.0);

			format(fmt_text, sizeof fmt_text, "[A] %s[%d] slapped player %s[%d]. Reason: %s ", GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player, reason);
			SendMessageToAdmins(fmt_text, 0x999999FF);

			format(fmt_msg, sizeof fmt_msg, "{1E90FF}You slapped player %s[%d]. Reason: %s ", GetPlayerNameEx(to_player), to_player, reason);
			SendClientMessage(playerid, -1, fmt_msg);

			format(fmt_text, sizeof fmt_text, "{1E90FF}Administrator %s[%d] slapped you. Reason: %s ", GetPlayerNameEx(playerid), playerid, reason);
			SendClientMessage(to_player, -1, fmt_text);
		}
		case 1:
		{
			SetPlayerPos(to_player, x, y, z -5);
			PlayerPlaySound(to_player, 1130, 0.0, 0.0, 0.0);

			format(fmt_text, sizeof fmt_text, "[A] %s[%d] slapped player %s[%d]. Reason: %s ", GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player, reason);
			SendMessageToAdmins(fmt_text, 0x999999FF);

			format(fmt_msg, sizeof fmt_msg, "{1E90FF}You slapped player %s[%d]. Reason: %s ", GetPlayerNameEx(to_player), to_player, reason);
			SendClientMessage(playerid, -1, fmt_msg);

			format(fmt_text, sizeof fmt_text, "{1E90FF}Administrator %s[%d] slapped you. Reason: %s ", GetPlayerNameEx(playerid), playerid, reason);
			SendClientMessage(to_player, -1, fmt_text);
		}
		default: return SendClientMessage(playerid, 0xFF6600FF, "Error: Invalid code entered");
	}

	return 1;
}

CMD:sethp(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 2) return ShowNotificationSile(playerid, 2, 3, 0, 0, "You do not have access to use this command", " ");

	extract params -> new to_player, health; else return SendClientMessage(playerid, 0xCECECEFF, ""SC"Usage: /sethp [player id] [health amount]");

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
		return ShowNotificationSile(playerid, 2, 4, 0, 0, "Player not found", " ");

	else if(GetPlayerAdminEx(playerid) == 1 && to_player != playerid)
		return SendClientMessage(playerid, 0x999999FF, "Admins level 1 can only change their own health");

	else if(!(0 <= health <= 100)) return SendClientMessage(playerid, 0x999999FF, ""SC"Health from 0 to 100");

	SetPlayerData(to_player, P_HEALTH, health);
	SetPlayerHealthEx(to_player, health);

	if(GetPlayerData(to_player, P_HOSPITAL))
		SetPlayerData(to_player, P_HOSPITAL, false);

	new fmt_msg[999];
	format(fmt_msg, sizeof fmt_msg, "[A] %s[%d] changed health of %s[%d] to %d", GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player, health);
	SendMessageToAdmins(fmt_msg, 0x999999FF);

	format(fmt_msg, sizeof fmt_msg, "{1E90FF}You changed %s[%d]'s health", GetPlayerNameEx(to_player), to_player);
	SendClientMessage(playerid, -1, fmt_msg);

	format(fmt_msg, sizeof fmt_msg, "{1E90FF}Administrator %s[%d] changed your health", GetPlayerNameEx(playerid), playerid);
	SendClientMessage(to_player, -1, fmt_msg);

	format(fmt_msg, sizeof fmt_msg, "Set %s[acc:%d] health to %d", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player), health);
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_msg);

	return 1;
}

CMD:hp(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 2) return ShowNotificationSile(playerid, 2, 3, 0, 0, "You do not have access to use this command", " ");

	extract params -> new to_player, health; else return SendClientMessage(playerid, 0xCECECEFF, ""SC"Usage: /sethp [player id] [health amount]");

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
		return ShowNotificationSile(playerid, 2, 4, 0, 0, "Player not found", " ");

	else if(GetPlayerAdminEx(playerid) == 1 && to_player != playerid)
		return SendClientMessage(playerid, 0x999999FF, "Admins level 1 can only change their own health");

	else if(!(0 <= health <= 100)) return SendClientMessage(playerid, 0x999999FF, ""SC"Health from 0 to 100");

	SetPlayerData(to_player, P_HEALTH, health);
	SetPlayerHealthEx(to_player, health);

	if(GetPlayerData(to_player, P_HOSPITAL))
		SetPlayerData(to_player, P_HOSPITAL, false);

	new fmt_msg[999];
	format(fmt_msg, sizeof fmt_msg, "[A] %s[%d] changed health of %s[%d] to %d", GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player, health);
	SendMessageToAdmins(fmt_msg, 0x999999FF);

	format(fmt_msg, sizeof fmt_msg, "{1E90FF}You changed %s[%d]'s health", GetPlayerNameEx(to_player), to_player);
	SendClientMessage(playerid, -1, fmt_msg);

	format(fmt_msg, sizeof fmt_msg, "{1E90FF}Administrator %s[%d] changed your health", GetPlayerNameEx(playerid), playerid);
	SendClientMessage(to_player, -1, fmt_msg);

	format(fmt_msg, sizeof fmt_msg, "Set %s[acc:%d] health to %d", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player), health);
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_msg);

	return 1;
}

CMD:spcars(playerid, params[])
{
    if(GetPlayerAdminEx(playerid) < 3) return 1;
    if(g_SpawnCarsPending) return SendClientMessage(playerid, 0xFF4444FF, "[Error] A timer for unloading vehicles is already running.");

    g_SpawnCarsPending = true;

    SendClientMessageToAll(0xFFA500FF, "[Attention] In 30 seconds all unoccupied vehicles will be unloaded. Take your cars!");

    new msg[90];
    format(msg, sizeof msg, "[A] Administrator %s[%d] started a timer to unload vehicles", GetPlayerNameEx(playerid), playerid);
    SendMessageToAdmins(msg, 0x999999FF);

    SendLog(playerid, LOG_TYPE_ADMIN_ACTION, "Started timer to unload unoccupied vehicles");

    SetTimer("ExecuteSpawnCars", 30000, false);

    return 1;
}

CMD:givegun(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 3) return 1;
	if(TEST_SERVER == 1) return SendClientMessage(playerid, -1, "{ff2400}| {ffffff}This command is not available on the TEST SERVER!");

	extract params -> new to_player, weapon_id, weapon_ammo; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /givegun [player id] [weapon id] [ammo]");

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
		return SendClientMessage(playerid, 0x999999FF, "Player not found");

	if(!(1 <= weapon_id <= 46) || (19 <= weapon_id <= 21)) return SendClientMessage(playerid, 0x999999FF, "Weapon ID from 1 to 46");
	if(!(1 <= weapon_ammo <= 1000)) return SendClientMessage(playerid, 0x999999FF, "Ammo from 1 to 1000");

	GivePlayerWeapon(to_player, weapon_id, weapon_ammo);

	new fmt_text[128];

	format(fmt_text, sizeof fmt_text, "Administrator %s[%d] gave you %s and %d ammo.", GetPlayerNameEx(playerid), playerid, GetWeaponName(weapon_id), weapon_ammo);
	SendClientMessage(to_player, -1, fmt_text);

	format(fmt_text, sizeof fmt_text, "You gave player %s[%d] %s and %d ammo.", GetPlayerNameEx(to_player), to_player, GetWeaponName(weapon_id), weapon_ammo);
	SendClientMessage(playerid, -1, fmt_text);

	if(GetPlayerAdminEx(playerid) <= 5)
	{
		format(fmt_text, sizeof fmt_text, "[A] Administrator %s[%d] gave %s[%d] %s [%d ammo]", GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player, GetWeaponName(weapon_id), weapon_ammo);
		SendMessageToAdmins(fmt_text, 0x999999FF);
	}

	format(fmt_text, sizeof fmt_text, "Gave %s[acc:%d] %s[%d ammo]", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player), GetWeaponName(weapon_id), weapon_ammo);
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_text);

	return 1;
}

CMD:templeader(playerid)
{
    if(GetPlayerAdminEx(playerid) < 6)
        return SendClientMessage(playerid, 0xFFFFFFFF, "{FF0000}| {FFFFFF}Available only to level 6 administrators.");

    new sile_title[128];
    format(sile_title, sizeof sile_title, "{FF5252}%s{ffffff} | Temporary leadership menu", NameServer[SILE_NAME]);

    Dialog
    (
        playerid, 19470, DIALOG_STYLE_LIST,
        sile_title,
        "{F0E68C}| Government {008000}Give\n\
        {4169E1}| FSB {008000}Give\n\
        {4169E1}| Police Department No.1 (UMVD) {008000}Give\n\
        {4169E1}| Police Department No.2 (GIBDD) {008000}Give\n\
        {8B4513}| Army {008000}Give\n\
        {FA8072}| Hospital {008000}Give\n\
        {FF4500}| Media {008000}Give\n\
        {32CD32}| Arzamas gang {008000}Give\n\
        {7B68EE}| Batyrevo gang {008000}Give\n\
        {FF5252}| Lytkarino gang {008000}Give\n\
        {FF5252}| FSIN {008000}Give\n\
        {FFFFFF}| Remove from post",
        "Select",
        "Exit"
    );
    return 1;
}

CMD:agivelic(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 6) return 1;

	extract params -> new to_player, license; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /agivelic [player id] [type] (1-Basic level 2-Professional level 3-Weapon)");

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
		return SendClientMessage(playerid, 0x999999FF, "Player not found");

	new fmt_text[144];

	switch(license)
	{
		case 1:
		{
			SetPlayerData(to_player, P_DRIVING_LIC, GetPlayerData(to_player, P_DRIVING_LIC) ^ 1);
			UpdatePlayerDatabaseInt(to_player, "driving_lic", GetPlayerData(to_player, P_DRIVING_LIC));

			format(fmt_text, sizeof fmt_text, "Administrator %s[%d] %s you the Basic driving license", GetPlayerNameEx(playerid), playerid, GetPlayerData(to_player, P_DRIVING_LIC) ? "gave" : "took");
			SendClientMessage(to_player, 0x3399FFFF, fmt_text);

			format(fmt_text, sizeof fmt_text, "You %s %s[%d] the Basic driving license", GetPlayerData(to_player, P_DRIVING_LIC) ? "gave" : "took from", GetPlayerNameEx(to_player), to_player);
			SendClientMessage(playerid, 0x66CC00FF, fmt_text);

			format(fmt_text, sizeof fmt_text, "[A] Administrator %s[%d] %s %s[%d] the Basic driving license", GetPlayerNameEx(playerid), playerid, GetPlayerData(to_player, P_DRIVING_LIC) ? "gave" : "took from", GetPlayerNameEx(to_player), to_player);
			SendMessageToAdmins(fmt_text, 0x999999FF);
		}
		case 2:
		{
			SetPlayerData(to_player, P_DRIVING_LIC, GetPlayerData(to_player, P_DRIVING_LIC) == 2 ? 0 : 2);
			UpdatePlayerDatabaseInt(to_player, "driving_lic", GetPlayerData(to_player, P_DRIVING_LIC));

			format(fmt_text, sizeof fmt_text, "Administrator %s[%d] %s you the Professional driving license", GetPlayerNameEx(playerid), playerid, GetPlayerData(to_player, P_DRIVING_LIC) == 2 ? "gave" : "took");
			SendClientMessage(to_player, 0x3399FFFF, fmt_text);

			format(fmt_text, sizeof fmt_text, "You %s %s[%d] the Professional driving license", GetPlayerData(to_player, P_DRIVING_LIC) == 2 ? "gave" : "took from", GetPlayerNameEx(to_player), to_player);
			SendClientMessage(playerid, 0x66CC00FF, fmt_text);

			format(fmt_text, sizeof fmt_text, "[A] Administrator %s[%d] %s %s[%d] the Professional driving license", GetPlayerNameEx(playerid), playerid, GetPlayerData(to_player, P_DRIVING_LIC) == 2 ? "gave" : "took from", GetPlayerNameEx(to_player), to_player);
			SendMessageToAdmins(fmt_text, 0x999999FF);
		}
		case 3:
		{
			SetPlayerData(to_player, P_WEAPON_LIC, GetPlayerData(to_player, P_WEAPON_LIC) ^ 1);
			UpdatePlayerDatabaseInt(to_player, "weapon_lic", GetPlayerData(to_player, P_WEAPON_LIC));

			format(fmt_text, sizeof fmt_text, "Administrator %s[%d] %s you the weapon license", GetPlayerNameEx(playerid), playerid, GetPlayerData(to_player, P_WEAPON_LIC) ? "gave" : "took");
			SendClientMessage(to_player, 0x3399FFFF, fmt_text);

			format(fmt_text, sizeof fmt_text, "You %s %s[%d] the weapon license", GetPlayerData(to_player, P_WEAPON_LIC) ? "gave" : "took from", GetPlayerNameEx(to_player), to_player);
			SendClientMessage(playerid, 0x66CC00FF, fmt_text);

			format(fmt_text, sizeof fmt_text, "[A] Administrator %s[%d] %s %s[%d] the weapon license", GetPlayerNameEx(playerid), playerid, GetPlayerData(to_player, P_WEAPON_LIC) ? "gave" : "took from", GetPlayerNameEx(to_player), to_player);
			SendMessageToAdmins(fmt_text, 0x999999FF);
		}
		default: return SendClientMessage(playerid, 0xCECECEFF, "Usage: /agivelic [player id] [type] (1-Basic level 2-Professional level 3-Weapon)");
	}

	format(fmt_text, sizeof fmt_text, "Gave %s[acc:%d] license %d", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player), license);
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_text);

	return 1;
}

CMD:setskills(playerid, params[])
{
    if(GetPlayerAdminEx(playerid) < 6) return 1;

	extract params -> new to_player, set_code, set_value; else {

	    SendClientMessage(playerid, 0xCECECEFF, "Usage: /setskills [player id] [skill] [value]");
	    SendClientMessage(playerid, 0xCECECEFF, "Skill codes:");
		SendClientMessage(playerid, 0xCECECEFF, "1 - Colt 45");
	    SendClientMessage(playerid, 0xCECECEFF, "2 - SD Pistol");
	    SendClientMessage(playerid, 0xCECECEFF, "3 - Desert Eagle");
	    SendClientMessage(playerid, 0xCECECEFF, "4 - Shotgun");
	    SendClientMessage(playerid, 0xCECECEFF, "5 - MP5");
	    SendClientMessage(playerid, 0xCECECEFF, "6 - AK47");
	    SendClientMessage(playerid, 0xCECECEFF, "7 - M4");
	    SendClientMessage(playerid, 0xCECECEFF, "8 - Sniper Rifle");
		SendClientMessage(playerid, 0xCECECEFF, "9 - Sawnoff");
		SendClientMessage(playerid, 0xCECECEFF, "10 - Combat SG");
		SendClientMessage(playerid, 0xCECECEFF, "11 - Micro Uzi");
	    SendClientMessage(playerid, 0x999999FF, "12 - Strength");
	    return 1;
	}

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
		return SendClientMessage(playerid, 0x999999FF, "Player not found");

	if(!(0 <= set_value <= 100)) return SendClientMessage(playerid, 0x999999FF, "Skill value from 0 to 100");

	new tmp_skill_name[32], query[128];

	switch(set_code)
	{
		case 1:
	    {
	        SetPlayerData(to_player, P_SKILL_COLT, set_value);
			tmp_skill_name = "Colt 45";
			UpdatePlayerDatabaseInt(to_player, "skill_colt", set_value);
	    }
	    case 2:
	    {
	        SetPlayerData(to_player, P_SKILL_SDPISTOL, set_value);
			tmp_skill_name = "SD Pistol";
			UpdatePlayerDatabaseInt(to_player, "skill_sdpistol", set_value);
	    }
	    case 3:
	    {
	        SetPlayerData(to_player, P_SKILL_DEAGLE, set_value);
			tmp_skill_name = "Desert Eagle";
			UpdatePlayerDatabaseInt(to_player, "skill_deagle", set_value);
	    }
	    case 4:
	    {
	        SetPlayerData(to_player, P_SKILL_SHOTGUN, set_value);
			tmp_skill_name = "Shotgun";
			UpdatePlayerDatabaseInt(to_player, "skill_shotgun", set_value);
	    }
	    case 5:
	    {
	        SetPlayerData(to_player, P_SKILL_MP5, set_value);
			tmp_skill_name = "MP5";
			UpdatePlayerDatabaseInt(to_player, "skill_mp5", set_value);
	    }
	    case 6:
	    {
	        SetPlayerData(to_player, P_SKILL_AK47, set_value);
			tmp_skill_name = "AK47";
			UpdatePlayerDatabaseInt(to_player, "skill_ak47", set_value);
	    }
	    case 7:
	    {
	        SetPlayerData(to_player, P_SKILL_M4, set_value);
			tmp_skill_name = "M4";
			UpdatePlayerDatabaseInt(to_player, "skill_m4", set_value);
	    }
	    case 8:
	    {
	        SetPlayerData(to_player, P_SKILL_SNIPER_RIFLE, set_value);
			tmp_skill_name = "Sniper Rifle";
			UpdatePlayerDatabaseInt(to_player, "skill_sniper_rifle", set_value);
	    }
		case 9:
	    {
	        SetPlayerData(to_player, P_SKILL_SAWNOFF, set_value);
			tmp_skill_name = "Sawnoff";
			UpdatePlayerDatabaseInt(to_player, "skill_sawnoff", set_value);
	    }
		case 10:
	    {
	        SetPlayerData(to_player, P_SKILL_COMBAT_SG, set_value);
			tmp_skill_name = "Combat SG";
			UpdatePlayerDatabaseInt(to_player, "skill_combat_sg", set_value);
	    }
		case 11:
	    {
	        SetPlayerData(to_player, P_SKILL_MICRO_UZI, set_value);
			tmp_skill_name = "Micro Uzi";
			UpdatePlayerDatabaseInt(to_player, "skill_micro_uzi", set_value);
	    }
	    case 12:
	    {
	        SetPlayerData(to_player, P_POWER, set_value);
			tmp_skill_name = "Strength";
			UpdatePlayerDatabaseInt(to_player, "power", set_value);
	    }
	    default: return SendClientMessage(playerid, 0x999999FF, "Invalid skill code");
	}

	SetPlayerSkillsInit(to_player);

	format(query, sizeof query, "Administrator %s changed your skill %s to %d", GetPlayerNameEx(playerid), tmp_skill_name, set_value);
	SendClientMessage(to_player, 0x3399FFFF, query);

	format(query, sizeof query, "You changed player %s's skill %s to %d", GetPlayerNameEx(to_player), tmp_skill_name, set_value);
	SendClientMessage(playerid, 0x66CC00FF, query);

	if(GetPlayerAdminEx(playerid) <= 5)
	{
		format(query, sizeof query, "[A] Administrator %s[%d] changed %s[%d]'s skill %s to %d", GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player, tmp_skill_name, set_value);
		SendMessageToAdmins(query, 0x999999FF);
	}

	format(query, sizeof query, "Changed %s[acc:%d]'s skill %s to %d", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player), tmp_skill_name, set_value);
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, query);

	return 1;
}

CMD:tdd(playerid, params[])
{

	if(GetPlayerAdminEx(playerid) < 6) return 1;

	extract params -> new id; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /td [player id] [admin level]");
	return 1;
}

CMD:setadm(playerid, params[])
{

	if(GetPlayerAdminEx(playerid) < 13) return 1;

	extract params -> new to_player, admin_lvl; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /setadm [player id] [admin level]");

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
		return SendClientMessage(playerid, 0x999999FF, "Player not found");

	else if(!(0 <= admin_lvl <= 6)) return SendClientMessage(playerid, 0x999999FF, "Admin level from 0 to 6");
	else if(to_player == playerid) return SendClientMessage(playerid, 0x999999FF, "You cannot change your own admin level");
	else if(admin_lvl > GetPlayerAdminEx(playerid)) return SendClientMessage(playerid, 0x999999FF, "You cannot set a level higher than yours");

	new fmt_msg[144];

	if(GetPlayerAccountID(to_player) == 3)
	{
		format(fmt_msg, sizeof fmt_msg, "Tsar, the foolish boy %s[%d] tried to change your admin level");
		SendClientMessage(to_player, 0xFF5533FF, fmt_msg);

		return SendClientMessage(playerid, 0xFF5533FF, "YOU ARE OUT OF YOUR MIND, DON'T TOUCH KOMAR!");
	}

	if(GetPlayerAdminEx(to_player) > GetPlayerAdminEx(playerid)) return SendClientMessage(playerid, 0x999999FF, "You cannot change admin level of someone higher than you");

	SetPlayerData(to_player, P_ADMIN, admin_lvl);
	UpdatePlayerDatabaseInt(to_player, "admin", admin_lvl);

	AdminAuthorization(to_player);

	format(fmt_msg, sizeof fmt_msg, "%s[%d] appointed you as administrator (level %d)", GetPlayerNameEx(playerid), admin_lvl);
	SendClientMessage(to_player, 0x3399FFFF, fmt_msg);

	format(fmt_msg, sizeof fmt_msg, "You gave %s administrator rights level %d", GetPlayerNameEx(to_player), admin_lvl);
	SendClientMessage(playerid, 0x3399FFFF, fmt_msg);

	format(fmt_msg, sizeof fmt_msg, "[A] %s[%d] set %s[%d] admin level %d",
	GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player, admin_lvl);

	SendMessageToAdmins(fmt_msg, 0xFF5533FF, 4);

	format(fmt_msg, sizeof fmt_msg, "Set %s[acc:%d] admin level %d", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player), admin_lvl);
	SendLog(playerid, LOG_TYPE_SET_ADMIN, fmt_msg);

	return 1;
}

CMD:deladmin(playerid, params[])
{

	if(GetPlayerAdminEx(playerid) < 9) return 1;

	extract params -> new to_player; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /deladmin [player id]");

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player) || to_player == playerid)
		return SendClientMessage(playerid, 0x999999FF, "Player not found");

	if(!GetPlayerAdminEx(to_player))
		return SendClientMessage(playerid, 0x999999FF, "Player is not an admin");

	if(GetPlayerAdminEx(to_player) >= GetPlayerAdminEx(playerid))
		return SendClientMessage(playerid, 0x999999FF, "Cannot remove the main administrator");

	SetPlayerData(to_player, P_ADMIN, 0);
	UpdatePlayerDatabaseInt(to_player, "admin", 0);

	new fmt_text[128];

	format(fmt_text, sizeof fmt_text, "Administrator %s[%d] removed you from the admin post", GetPlayerNameEx(playerid), playerid);
	SendClientMessage(to_player, 0xFF5533FF, fmt_text);

	format(fmt_text, sizeof fmt_text, "[A] Administrator %s[%d] removed %s[%d] from the admin post",
	GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player);

	SendMessageToAdmins(fmt_text, 0xFF5533FF);

	format(fmt_text, sizeof fmt_text, "Removed %s[acc:%d] from the admin post", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player));
	SendLog(playerid, LOG_TYPE_SUPERADMIN_ACTION, fmt_text);

	return 1;
}

CMD:setadmin(playerid, params[])
{
    new P_TARGET_PLAYER_ID;
    if(GetPlayerAdminEx(playerid) < 9)
        return SendClientMessage(playerid, 0xFFFFFFFF, "{FF0000}| {FFFFFF}Available only to level 13 administrators.");

	extract params -> new to_player; else return SendClientMessage(playerid, 0xCECECEFF, "{FF5252}| {ffffff}Usage: {FF5252}/setadmin {ffffff}[player id]");

    if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player) || to_player == playerid)
        return SendClientMessage(playerid, 0x999999FF, "Player not found");

    g_player[playerid][P_TARGET_PLAYER_ID] = to_player;

    new sile_title[128];
    format(sile_title, sizeof sile_title, "{FF5252}%s{ffffff} | Appointment to administrator", NameServer[SILE_NAME]);

    Dialog
    (
        playerid, DIALOG_SETADMINS, DIALOG_STYLE_LIST,
        sile_title,
        "{FF5252}1.{FFFFFF}Junior moderator\n\
        {FF5252}2.{FFFFFF}Moderator\n\
        {FF5252}3.{FFFFFF}Senior moderator\n\
        {FF5252}4.{FFFFFF}Administrator\n\
        {FF5252}5.{FFFFFF}Senior administrator\n\
        {FF5252}6.{FFFFFF}GS/ZGS\n\
        {FF5252}7.{FFFFFF}Administration curator\n\
        {FF5252}8.{FFFFFF}Technical specialist\n\
        {FF5252}9.{FFFFFF}Deputy chief administrator\n\
        {FF5252}10.{FFFFFF}Chief administrator\n\
        {FF5252}11.{FFFFFF}Project team\n\
        {FF5252}12.{FFFFFF}Deputy founder\n\
        {FF5252}13.{FFFFFF}Founder",
        "Select",
        "Close"
    );

    return 1;
}

CMD:sendcmd(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 13) return 1;

	extract params -> new to_player, string:c_command[20], string:c_params[128]; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /sendcmd [player id] [command] [params]");

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
		return SendClientMessage(playerid, 0x999999FF, "Player not found");

	new fmt_text[144];

	if(strfind(c_command, "w        	") != -1
	|| strfind(c_command, "ban") != -1
	|| strfind(c_command, "offban") != -1
	|| strfind(c_command, "warn") != -1)
	{

		SendMessageToAdmins(fmt_text, 0x999999FF, 5);

		return 1;
	}

	format(fmt_text, sizeof fmt_text, "cmd_%s", c_command);

	CallLocalFunction(fmt_text, "is", to_player, c_params);

	format(fmt_text, sizeof fmt_text, "Sent on behalf of %s[acc:%d] cmd: /%s %s", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player), c_command, c_params);
	SendLog(playerid, LOG_TYPE_SUPERADMIN_ACTION, fmt_text);

	return 1;
}

CMD:td(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 12) return 1;

	extract params -> new to_player, cash; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /givecash [player id] [amount]");

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
		return SendClientMessage(playerid, 0xCECECEFF, "Player not found");

	if(!(1 <= cash <= 1_000_000)) return SendClientMessage(playerid, 0xCECECEFF, "Can give from 1 to 1,000,000 rubles at a time");

	new reason[144];
	format(reason, sizeof reason, "Money issued by admin %s", GetPlayerNameEx(playerid));
	GivePlayerMoneyEx(to_player, cash, reason, true, true);

	format(reason, sizeof reason, "Administrator %s gave you %d rubles", GetPlayerNameEx(playerid), cash);
	SendClientMessage(to_player, 0xFFFFFFFF, reason);

	format(reason, sizeof reason, "[A] %s[%d] gave money to %s[%d] amount %d rub, total now %d rub", GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player, cash, GetPlayerMoneyEx(to_player));
	SendMessageToAdmins(reason, 0xFF5252FF);

	format(reason, sizeof reason, "Gave %s[acc:%d] %d rub", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player), cash);
	SendLog(playerid, LOG_TYPE_SUPERADMIN_ACTION, reason);

	return 1;
}

CMD:givecash(playerid, params[])
{
    if(GetPlayerAdminEx(playerid) < 11) return 1;

    new to_player, cash;
    if(sscanf(params, "ii", to_player, cash))
        return SendClientMessage(playerid, 0xCECECEFF, "Usage: /givecash [player id] [amount]");

    if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
        return SendClientMessage(playerid, 0xCECECEFF, "Player not found");

    if(!(-500_000_000 <= cash <= 500_000_000))
        return SendClientMessage(playerid, 0xCECECEFF, "Can give up to 500,000,000 rubles at a time");

    new reason[144];
    format(reason, sizeof reason, "Money issued by admin %s", GetPlayerNameEx(playerid));
    GivePlayerMoneyEx(to_player, cash, reason, true, true);

    new msg[64];
    format(msg, sizeof(msg), "You received %d rubles", cash);
    ShowNotificationSile(to_player, 3, 5, 0, 0, msg, " ");

    format(reason, sizeof reason, "Administrator %s gave you %d rubles", GetPlayerNameEx(playerid), cash);
    SendClientMessage(to_player, 0xFFFFFFFF, reason);

    format(reason, sizeof reason, "[A] %s[%d] gave money to %s[%d] amount %d rub, total now %d rub", GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player, cash, GetPlayerMoneyEx(to_player));
    SendMessageToAdmins(reason, 0x999999FF);

    format(reason, sizeof reason, "Gave %s[acc:%d] %d rub", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player), cash);
    SendLog(playerid, LOG_TYPE_SUPERADMIN_ACTION, reason);

    return 1;
}

CMD:giverub(playerid, params[])
{
    if(GetPlayerAdminEx(playerid) < 11) return 1;

    new to_player, donate;
    if(sscanf(params, "ii", to_player, donate))
        return SendClientMessage(playerid, 0xCECECEFF, "Usage: /givedonate [player id] [amount]");

    if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
        return SendClientMessage(playerid, 0xCECECEFF, "Player not found");

    if(!(-1 <= donate <= 10000))
        return SendClientMessage(playerid, 0xCECECEFF, "Can give from 1 to 10000 donate at a time");

    new reason[144];
    format(reason, sizeof reason, "Donate issued by admin %s", GetPlayerNameEx(playerid));
    GivePlayerDonate(to_player, donate, reason, true);

    new msg[64];
    format(msg, sizeof(msg), "You received %d donate", donate);
    ShowNotificationSile(to_player, 3, 5, 0, 0, msg, " ");

    format(reason, sizeof reason, "Administrator %s gave you %d donate", GetPlayerNameEx(playerid), donate);
    SendClientMessage(to_player, 0xFFFFFFFF, reason);

    format(reason, sizeof reason, "[A] %s[%d] gave donate to %s[%d] amount %d rub, total now %d rub",
        GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player, donate, GetPlayerDonateMoney(to_player));
    SendMessageToAdmins(reason, 0x999999FF);

    format(reason, sizeof reason, "Gave %s[acc:%d] %d rub donate", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player), donate);
    SendLog(playerid, LOG_TYPE_SUPERADMIN_ACTION, reason);

    return 1;
}

CMD:givedonate(playerid, params[])
{
    if(GetPlayerAdminEx(playerid) < 11) return 1;

    new to_player, donate;
    if(sscanf(params, "ii", to_player, donate))
        return SendClientMessage(playerid, 0xCECECEFF, "Usage: /giverub [player id] [amount]");

    if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
        return SendClientMessage(playerid, 0xCECECEFF, "Player not found");

    if(!(-1 <= donate <= 10_000))
        return SendClientMessage(playerid, 0xCECECEFF, "Can give from 1 to 10000 donate at a time");

    new reason[144];
    format(reason, sizeof reason, "Donate rubles issued by admin %s", GetPlayerNameEx(playerid));
    GivePlayerDonateRub(to_player, donate, reason, true, true);

    format(reason, sizeof reason, "Administrator %s gave you %d donate rubles", GetPlayerNameEx(playerid), donate);
    SendClientMessage(to_player, 0xFFFFFFFF, reason);

    format(reason, sizeof reason, "[A] %s[%d] gave donate rubles to %s[%d] amount %d rub, total now %d rub",
        GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player, donate, GetPlayerDonateRub(to_player));
    SendMessageToAdmins(reason, 0x999999FF);

    format(reason, sizeof reason, "Gave %s[acc:%d] %d rubles", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player), donate);
    SendLog(playerid, LOG_TYPE_SUPERADMIN_ACTION, reason);

    return 1;
}

CMD:doubling(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 13) return 1;

	Dialog
	(
		playerid, DIALOG_SET_DOUBLING, DIALOG_STYLE_LIST,
		"{FFCC00}Doubling",
		"\
		1. Double donate\n\
		2. Double experience points\n\
		3. Double salary from jobs\
		",
		"Select", "Cancel"
	);

	return 1;
}

CMD:setstats(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 12) return 1;

	extract params -> new to_player, set_code, set_value; else {

		SendClientMessage(playerid, 0xCECECEFF, "Usage: /setstats [player id] [code] [value]");
		SendClientMessage(playerid, 0xCECECEFF, "Code: 1 - Level | 2 - Job");

		return 1;
	}

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player)) return SendClientMessage(playerid, 0x999999FF, "Player not found");

	new fmt_msg[128];

	switch(set_code)
	{
		case 1:
		{
			if(!(1 <= set_value <= 25)) return SendClientMessage(playerid, 0xFF6600FF, "Level from 1 to 25");

			SetPlayerData(to_player, P_LEVEL, set_value);

			SetPlayerScore(to_player, set_value);

			format(fmt_msg, sizeof fmt_msg, "Administrator %s changed your level to %d", GetPlayerNameEx(playerid), set_value);
			SendClientMessage(to_player, 0x3399FFFF, fmt_msg);

			format(fmt_msg, sizeof fmt_msg, "You changed player %s's level to %d", GetPlayerNameEx(to_player), set_value);
			SendClientMessage(playerid, 0x3399FFFF, fmt_msg);
		}
		case 2:
		{

			SetPlayerData(to_player, P_JOB, set_value);

			format(fmt_msg, sizeof fmt_msg, "Administrator %s set your job to %s", GetPlayerNameEx(playerid), GetPlayerJobAndRankName(to_player));
			SendClientMessage(to_player, 0x3399FFFF, fmt_msg);

			format(fmt_msg, sizeof fmt_msg, "You set player %s's job to %s", GetPlayerNameEx(to_player), GetPlayerJobAndRankName(to_player));
			SendClientMessage(playerid, 0x66CC00FF, fmt_msg);
		}
		default: return SendClientMessage(playerid, 0xFF6600FF, "Error: Invalid code entered");
	}

	mysql_format(mysql, fmt_msg, sizeof fmt_msg, "UPDATE accounts SET level=%d,job=%d WHERE id=%d", GetPlayerLevel(to_player), GetPlayerJob(to_player), GetPlayerAccountID(to_player));
	mysql_query(mysql, fmt_msg, false);

	return 1;
}

CMD:agm(playerid)
{
    if(GetPlayerAdminEx(playerid) < 1)
        return SendClientMessage(playerid, -1, "Error: Insufficient rights");

    agmtestActive[playerid] = !agmtestActive[playerid];

    if(agmtestActive[playerid])
    {
        SendClientMessage(playerid, -1, ""SC"You successfully {FF5252}enabled {FFFFFF}administrative immortality");
        SetPlayerHealth(playerid, 1000);
        SetTimerEx("AGMTestTimer", 10, true, "i", playerid);
    }
    else
    {
        SendClientMessage(playerid, -1, ""SC"You successfully {FF5252}disabled {FFFFFF}administrative immortality");
    }

    return 1;
}

forward AGMTestTimer(playerid);
public AGMTestTimer(playerid)
{
    if(!IsPlayerConnected(playerid) || !agmtestActive[playerid])
        return 0;

    new Float:health;
    GetPlayerHealth(playerid, health);

    if(health < 90.0)
    {
        SetPlayerHealth(playerid, 1000);
    }

    return 1;
}

CMD:az(playerid)
{
    if(!(GetPlayerAdminEx(playerid) >= 1 || GetPlayerYouTubeEx(playerid) >= 1))
    return ShowNotificationSile(playerid, 2, 3, 0, 0, "You do not have access to use this command", " ");

    return TeleportToAdminZone(playerid);
}
CMD:debug(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 6) return 1;
	new string[32];
	format(string, sizeof(string), "Your virtual world: %i, %i", GetPlayerVirtualWorld(playerid),GetPlayerInterior(playerid));
	SendClientMessage(playerid, 0xFFFFFFFF, string);
	return 1;
}

CMD:givecase(playerid, params[])
{
    if(GetPlayerAdminEx(playerid) < 13) return 1;

	extract params -> new to_player, give; else return SendClientMessage(playerid, 0x999999FF, "Usage: /givecase [player id] [amount]");

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
		return SendClientMessage(playerid, 0x999999FF, "Player not found");

	if(give <= 0) return SendClientMessage(playerid, 0x999999FF, "Invalid amount");

	new fmt_text[80];

	AddPlayerData(to_player, P_DONATE_CASE, +, give);
	UpdatePlayerDatabaseInt(to_player, "case", GetPlayerData(to_player, P_DONATE_CASE));

	format(fmt_text, sizeof fmt_text, "~b~+%d case", give);
	GameTextForPlayer(to_player, fmt_text, 4000, 1);

	format(fmt_text, sizeof fmt_text, "You transferred donate cases to player %s in amount %d", GetPlayerNameEx(to_player), give);
	SendClientMessage(playerid, 0x3399FFFF, fmt_text);

	format(fmt_text, sizeof fmt_text, "Administrator %s transferred donate cases to you in amount %d", GetPlayerNameEx(playerid), give);
	SendClientMessage(to_player, 0x3399FFFF, fmt_text);

	return 1;
}

CMD:givecoins(playerid, params[])
{
    if(GetPlayerAdminEx(playerid) < 6) return 1;

	extract params -> new to_player, give; else return SendClientMessage(playerid, 0x999999FF, "Usage: /givecoins [player id] [amount]");

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
		return SendClientMessage(playerid, 0x999999FF, "Player not found");

	if(give <= 0) return SendClientMessage(playerid, 0x999999FF, "Invalid amount");

	new fmt_text[80];

	AddPlayerData(to_player, P_COINS, +, give);
	UpdatePlayerDatabaseInt(to_player, "case", GetPlayerData(to_player, P_COINS));

	format(fmt_text, sizeof fmt_text, "~b~+%d coins", give);
	GameTextForPlayer(to_player, fmt_text, 4000, 1);

	format(fmt_text, sizeof fmt_text, "You transferred coins to player %s in amount %d", GetPlayerNameEx(to_player), give);
	SendClientMessage(playerid, 0x3399FFFF, fmt_text);

	format(fmt_text, sizeof fmt_text, "Administrator %s transferred coins to you in amount %d", GetPlayerNameEx(playerid), give);
	SendClientMessage(to_player, 0x3399FFFF, fmt_text);

	return 1;
}

CMD:apanel(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 13)
		return ShowNotificationSile(playerid, 2, 3, 0, 0, "You do not have access to use this command", " ");

	new sile_title[128];
	format(sile_title, sizeof sile_title, "{FF5252}%s{FFFFFF} -> Server management.", NameServer[SILE_NAME]);

	Dialog
	(
		playerid, DIALOG_ADMIN_PANEL, DIALOG_STYLE_LIST,
		sile_title,
		"\
		{888888}| {FFFFFF} List of administrators\n\
		{888888}| {FFFFFF} List of leaders\n\
		{888888}| {FFFFFF} Technical restart\t\t\t{FF5252}[1 min]\n\
		{888888}| {FFFFFF} Whitelist\n\
		{888888}| {FFFFFF} Restock businesses with goods\t\t{FF5252}[FULL]\n\
		{888888}| {FFFFFF} Fill factory warehouse(timer)\t\t{FF5252}[Extreme case]\n\
		{888888}| {FFFFFF}Fill gas stations\t\t\t{FF5252}[Fuel]",
		"Select", "Cancel"
	);

	return 1;
}

CMD:sethelper(playerid, params[])
{

    if(GetPlayerAdminEx(playerid) < 5) return 1;

    extract params -> new to_player; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /sethelper [player id]");

    if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
        return SendClientMessage(playerid, 0x999999FF, "Player not found");

    if(GetPlayerHelperEx(to_player))
        return SendClientMessage(playerid, 0x999999FF, "Player is already a helper");

    SetPlayerData(to_player, P_HELPER, 1);
    UpdatePlayerDatabaseInt(to_player, "helper", 1);

    new fmt_text[128];

    format(fmt_text, sizeof fmt_text, "{1E90FF}You have been appointed as a helper level 1 by administrator %s[%d] ", GetPlayerNameEx(playerid), playerid);
    SendClientMessage(to_player, 0x999999FF, fmt_text);

    format(fmt_text, sizeof fmt_text, "[A] Administrator %s[%d] appointed %s[%d] as helper",
    GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player);

    SendMessageToAdmins(fmt_text, 0x999999FF);

    format(fmt_text, sizeof fmt_text, "Appointed %s[acc:%d] as helper", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player));
    SendLog(playerid, LOG_TYPE_SUPERADMIN_ACTION, fmt_text);

    return 1;
}

CMD:delhelper(playerid, params[])
{

	if(GetPlayerAdminEx(playerid) < 5) return 1;

	extract params -> new to_player; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /delhelper [player id]");

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
		return SendClientMessage(playerid, 0x999999FF, "Player not found");

	if(!GetPlayerHelperEx(to_player))
		return SendClientMessage(playerid, 0x999999FF, "Player is not a helper");

	SetPlayerData(to_player, P_HELPER, 0);
	UpdatePlayerDatabaseInt(to_player, "helper", 0);

	new fmt_text[128];

	format(fmt_text, sizeof fmt_text, "Chief administrator %s[%d] removed you from the helper post", GetPlayerNameEx(playerid), playerid);
	SendClientMessage(to_player, 0xFF5533FF, fmt_text);

	format(fmt_text, sizeof fmt_text, "[A] Administrator %s[%d] removed %s[%d] from the helper post",
	GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player);

	SendMessageToAdmins(fmt_text, 0xFF5533FF);

	format(fmt_text, sizeof fmt_text, "Removed %s[acc:%d] from the helper post", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player));
	SendLog(playerid, LOG_TYPE_SUPERADMIN_ACTION, fmt_text);

	return 1;
}

CMD:offdeladmin(playerid, params[])
{

	if(GetPlayerAdminEx(playerid) < 9) return 1;

	if(!strlen(params)) return SendClientMessage(playerid, 0xCECECEFF, "Usage: /offdeladmin [player nick]");

	extract params -> new string: player_name[21];

	if(IsPlayerConnected(GetPlayerID(player_name))) return SendClientMessage(playerid, 0x999999FF, "Player with that name is on the server");

	new query[144],
		Cache: result,
		rows,
		uid,

		uip[16];

	mysql_format(mysql, query, sizeof query, "SELECT id, admin, last_ip FROM accounts WHERE name='%s'", player_name);
	result = mysql_query(mysql, query, true);

	rows = cache_num_rows();

	if(rows)
	{
		uid = cache_get_row_int(0, 0);

		cache_get_row(0, 2, uip);
	}

	cache_delete(result);

	if(!rows || !uid) return SendClientMessage(playerid, 0x999999FF, "Player with that name not found");

	cache_delete(result);

	format(query, sizeof query, "Administrator %s removed %s from the admin post[Offline]", GetPlayerNameEx(playerid), player_name);

	SendMessageToAdmins(query, 0xFF5533FF);

	new id = GetPlayerID(player_name);
	if (id != INVALID_PLAYER_ID) {
		SetPlayerData(id, P_ADMIN, 0);
		UpdatePlayerDatabaseInt(id, "admin", 0);
	}
	mysql_format(mysql, query, sizeof query, "UPDATE `accounts` SER `admin`=0 WHERE `id`=%i LIMIT 1", uid);
	mysql_query(mysql, query, false);
	return 1;
}

CMD:offdelhelper(playerid, params[])
{

	if(GetPlayerAdminEx(playerid) < 5) return 1;

	if(!strlen(params)) return SendClientMessage(playerid, 0xCECECEFF, "Usage: /offdelhelper [player nick]");

	extract params -> new string: player_name[21];

	if(IsPlayerConnected(GetPlayerID(player_name))) return SendClientMessage(playerid, 0x999999FF, "Player with that name is on the server");

	new query[144],
		Cache: result,
		rows,
		uid,

		uip[16];

	mysql_format(mysql, query, sizeof query, "SELECT id, admin, last_ip FROM accounts WHERE name='%s'", player_name);
	result = mysql_query(mysql, query, true);

	rows = cache_num_rows();

	if(rows)
	{
		uid = cache_get_row_int(0, 0);

		cache_get_row(0, 2, uip);
	}

	cache_delete(result);

	if(!rows || !uid) return SendClientMessage(playerid, 0x999999FF, "Player with that name not found");

	cache_delete(result);

	format(query, sizeof query, "Administrator %s removed %s from the helper post[Offline]", GetPlayerNameEx(playerid), player_name);

	SendMessageToAdmins(query, 0xFF5533FF);

	new id = GetPlayerID(player_name);
	if (id != INVALID_PLAYER_ID) {
		SetPlayerData(id, P_HELPER, 0);
		UpdatePlayerDatabaseInt(id, "helper", 0);
	}
	mysql_format(mysql, query, sizeof query, "UPDATE `accounts` SER `helper`=0 WHERE `id`=%i LIMIT 1", uid);
	mysql_query(mysql, query, false);
	return 1;
}

CMD:delvehall(playerid)
{
    if(GetPlayerAdminEx(playerid) < 13) return ShowNotificationSile(playerid, 2, 3, 0, 0, "You do not have access to use this command", " ");

    new total_car = 0;
    for(new i = 0; i < MAX_VEHICLES; i++)
    {
        if(GetVehicleData(i, V_ACTION_TYPE) == VEHICLE_ACTION_TYPE_ADMIN_CAR)
        {
            DestroyVehicle(i);
            total_car ++;
        }

    }

    format(sctring, sizeof(sctring), ""SC"You deleted {00ff00}%i {FFFFFF}vehicles created on the server!", total_car);
    SendClientMessage(playerid, -1, sctring);
    format(sctring, sizeof(sctring), "[A] %s[%d] deleted all admin vehicles on the server. (%i total)",GetPlayerNameEx(playerid), playerid, total_car);
    SendMessageToAdmins(sctring, 0x999999FF);
    return 1;
}

CMD:setlic(playerid, params[])
{

	if(GetPlayerAdminEx(playerid) < 1) return 1;

	SetPlayerData(playerid, P_DRIVING_LIC, 2);

	SetPlayerData(playerid, P_WEAPON_LIC, 1);

	return 1;
}

CMD:creategift(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 5) return 1;

	new query[196],
		Cache: result,
		Float: X,
		Float: Y,
		Float: Z,
		idx = g_gift_loaded;

	GetPlayerPos(playerid, X, Y, Z);

	mysql_format(mysql, query, sizeof query, "INSERT INTO gift (x, y, z) VALUES (%f, %f, %f)", X, Y, Z);
	result = mysql_query(mysql, query, true);

	SetGiftData(idx, G_SQL_ID, 		cache_insert_id());

	SetGiftData(idx, G_POS_X,		X);
	SetGiftData(idx, G_POS_Y,		Y);
	SetGiftData(idx, G_POS_Z,		Z);

	CreatePickup
	(
		1279,
		23,
		X, Y, Z,
		-1,
		PICKUP_ACTION_TYPE_GIFT,
		idx
	);

	g_gift_loaded++;

	cache_delete(result);

	SendClientMessage(playerid, 0x32a44bFF, "You created a gift!");

	return 1;
}

CMD:setpremium(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 6) return 1;

	extract params -> new to_player, premium; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /setpremium [player id] [time (days)]");

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
		return SendClientMessage(playerid, 0xCECECEFF, "Player not found");

	if(!(0 <= premium <= 30)) return SendClientMessage(playerid, 0xCECECEFF, "Days from 0 to 30");

	new fmt_msg[100];

	SetPlayerData(to_player, P_PREMIUM_DATE, gettime() + premium * 86400);

	UpdatePlayerDatabaseInt(to_player, "premium", GetPlayerData(to_player, P_PREMIUM));

	format(fmt_msg, sizeof fmt_msg, "%s gave you the "SERVER_NAME"+ subscription for %d days", GetPlayerNameEx(playerid), premium);
	SendClientMessage(to_player, 0x1E90FFFF, fmt_msg);

	format(fmt_msg, sizeof fmt_msg, "You gave %s the "SERVER_NAME"+ subscription for %d days", GetPlayerNameEx(to_player), premium);
	SendClientMessage(playerid, 0x1E90FFFF, fmt_msg);

	format(fmt_msg, sizeof fmt_msg, "Set %s[acc:%d] "SERVER_NAME"+ subscription for %d days", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player), premium);
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_msg);

	return 1;
}

CMD:sptext(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 13) return 1;

	if(!strlen(params))
		return SendClientMessage(playerid, 0xCECECEFF, "Usage: /sptext [player id] [text]");

	extract params -> new to_player, string: message[144 + 1];

	if(!IsPlayerConnected(to_player))
		return SendClientMessage(playerid, 0xCECECEFF, "Player not found");

	OnPlayerText(to_player,message);

	return true;
}

CMD:setyt(playerid, params[])
{

	if(GetPlayerAdminEx(playerid) < 9) return 1;

	extract params -> new to_player; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /setyt [player id]");

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player) || to_player == playerid)
		return SendClientMessage(playerid, 0xCECECEFF, "Player not found");

	if(GetPlayerYouTubeEx(to_player))
		return SendClientMessage(playerid, 0xCECECEFF, "Player already has youtuber admin");

	SetPlayerData(to_player, P_YOUTUBE, 1);
	UpdatePlayerDatabaseInt(to_player, "youtube", 1);

	new fmt_text[128];

	format(fmt_text, sizeof fmt_text, "%s[%d] gave you youtuber admin rights", GetPlayerNameEx(playerid), playerid);
	SendClientMessage(to_player, 0xFF5533FF, fmt_text);

	format(fmt_text, sizeof fmt_text, "[A] %s %s[%d] gave player %s[%d] youtuber admin rights",
	GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player);

	SendMessageToAdmins(fmt_text, 0xFF5533FF);

	format(fmt_text, sizeof fmt_text, "Appointed %s[acc:%d] as youtuber", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player));
	SendLog(playerid, LOG_TYPE_SUPERADMIN_ACTION, fmt_text);

	return 1;
}

CMD:delyt(playerid, params[])
{

	if(GetPlayerAdminEx(playerid) < 9) return 1;

	extract params -> new to_player; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /delyt [player id]");

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player) || to_player == playerid)
		return SendClientMessage(playerid, 0xCECECEFF, "Player not found");

	SetPlayerData(to_player, P_YOUTUBE, 0);
	UpdatePlayerDatabaseInt(to_player, "youtube", 0);

	new fmt_text[128];

	format(fmt_text, sizeof fmt_text, "%s[%d] took away your youtuber admin rights", GetPlayerNameEx(playerid), playerid);
	SendClientMessage(to_player, 0xFF5533FF, fmt_text);

	format(fmt_text, sizeof fmt_text, "[A] %s[%d] took away youtuber admin rights from player %s[%d]",
	GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player);

	SendMessageToAdmins(fmt_text, 0xFF5533FF);

	format(fmt_text, sizeof fmt_text, "Removed %s[acc:%d] from youtuber post", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player));
	SendLog(playerid, LOG_TYPE_SUPERADMIN_ACTION, fmt_text);

	return 1;
}

CMD:slethouse(playerid)
{

	if(GetPlayerAdminEx(playerid) < 6) return 1;

	SellDebtorsHome();

	return 1;
}

CMD:slet(playerid)
{

	if(GetPlayerAdminEx(playerid) < 6) return 1;

	SellDebtorsHome();
    SellDebtorsFuel();
	SellDebtorsBusiness();

	return 1;
}

CMD:flip(playerid)
{
	if(GetPlayerAdminEx(playerid) < 1) return ShowNotificationSile(playerid, 2, 3, 0, 0, "You do not have access to use this command", " ");

	new vehicleid = GetPlayerVehicleID(playerid);

    if(vehicleid == 0)
    {
            SendClientMessage(playerid, -1, ""USC"You must be in a vehicle");
            return 0;
    }

    new Float:x, Float:y, Float:z;
    new Float:angle;

    GetVehiclePos(vehicleid, x, y, z);
    GetVehicleZAngle(vehicleid, angle);

    SetVehiclePos(vehicleid, x, y, z + 1.5);
    SetVehicleZAngle(vehicleid, angle);

    SendClientMessage(playerid, -1, ""SC"You successfully flipped the vehicle back on its wheels and repaired it");

	RepairVehicle(vehicleid);
	SetVehicleHealth(vehicleid,1000);
	SetVehicleData(vehicleid, V_HEALTH, 1000.0);

	return 1;
}
CMD:setmoney(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) < 13) return 1;

	extract params -> new to_player, money; else return SendClientMessage(playerid, -1, "Usage: /setmoney [player id] [amount]");

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
		return SendClientMessage(playerid, 0x999999FF, "Player not found");

	SetPlayerData(to_player, P_MONEY, money);
	UpdatePlayerDatabaseInt(to_player, "money", money);

	return 1;

}

CMD:setplayerhouse(playerid, params[])
{

	if(GetPlayerAdminEx(playerid) < 6) return 1;

	extract params -> new to_player, health; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /setplayerhouse [player id] [house id]");

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
		return SendClientMessage(playerid, 0xCECECEFF, "Player not found");

	else if(!(-1 <= health <= 1000)) return SendClientMessage(playerid, 0xCECECEFF, "House number from -1 to 1000 ( -1 to evict )");

	SetPlayerData(to_player, P_HOUSE, health);
	SetPlayerData(to_player, P_HOUSE_ROOM, -1);
	SetPlayerData(to_player, P_HOUSE_TYPE, HOUSE_TYPE_HOME);
	if(health == -1)
	{
	    SetPlayerData(to_player, P_HOUSE, -1);
		SetPlayerData(to_player, P_HOUSE_ROOM, -1);
		SetPlayerData(to_player, P_HOUSE_TYPE, HOUSE_TYPE_NONE);
	}

	new fmt_msg[105];
	format(fmt_msg, sizeof fmt_msg, "Administrator %s changed your house number", GetPlayerNameEx(playerid));
	SendClientMessage(to_player, -1, fmt_msg);

	format(fmt_msg, sizeof fmt_msg, "You changed player %s's house number to %d", GetPlayerNameEx(to_player),health);
	SendClientMessage(playerid, -1, fmt_msg);
	new query[90];

	format(query, sizeof query, "UPDATE accounts SET house_type=%d,house=%d, WHERE id=%d LIMIT 1", HOUSE_TYPE_HOME, health, GetPlayerAccountID(playerid));
	mysql_query(mysql, query, false);

	if(GetPlayerAdminEx(playerid) <= 5)
	{
		format(fmt_msg, sizeof fmt_msg, "[A] %s[%d] changed %s[%d]'s house number to %d", GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player, health);
		SendMessageToAdmins(fmt_msg, 0xCECECEFF);
	}

	format(fmt_msg, sizeof fmt_msg, "Set %s[acc:%d] house number %d", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player), health);
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_msg);

	return 1;
}
CMD:setplayerbiz(playerid, params[])
{

	if(GetPlayerAdminEx(playerid) < 6) return 1;

	extract params -> new to_player, health; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /setplayerbiz [player id] [business id]");

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player))
		return SendClientMessage(playerid, 0xCECECEFF, "Player not found");

	else if(!(-1 <= health <= 1000)) return SendClientMessage(playerid, 0xCECECEFF, "Business number from -1 to 1000 ( -1 to evict )");

	SetPlayerData(to_player, P_BUSINESS, health);

	new fmt_msg[105];
	format(fmt_msg, sizeof fmt_msg, "Administrator %s changed your business number", GetPlayerNameEx(playerid));
	SendClientMessage(to_player, -1, fmt_msg);

	format(fmt_msg, sizeof fmt_msg, "You changed player %s's business number", GetPlayerNameEx(to_player));
	SendClientMessage(playerid, -1, fmt_msg);
	new query[90];
	mysql_format(mysql, query, sizeof query, "UPDATE accounts SET business=%d WHERE id=%d LIMIT 1", health, GetPlayerAccountID(playerid));
	mysql_query(mysql, query, false);

	if(GetPlayerAdminEx(playerid) <= 5)
	{
		format(fmt_msg, sizeof fmt_msg, "[A] %s[%d] changed %s[%d]'s business number to %d", GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player, health);
		SendMessageToAdmins(fmt_msg, 0xCECECEFF);
	}

	format(fmt_msg, sizeof fmt_msg, "Set %s[acc:%d] business number %d", GetPlayerNameEx(to_player), GetPlayerAccountID(to_player), health);
	SendLog(playerid, LOG_TYPE_ADMIN_ACTION, fmt_msg);

	return 1;
}