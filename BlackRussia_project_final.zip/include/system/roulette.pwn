// File: roulette.pwn
#define T_NONE		0
#define	T_MONEY		1
#define	T_LIC		2
#define	T_VIP		3
#define	T_CAR		4
#define	T_GUN		5
#define	T_EXP		6
#define	T_DONATE	7
#define	T_SLOT		8

enum R_STRUCT
{
	R_TYPE,
	R_NAME_TXD[48],
	R_NAME_TEXT[48],
    R_NAME_PRIZE[48],
	R_COUNT
}

enum WELSI_BLYAT
{
    last_player_name[24],
    id_ruletka_prize
};

new last_player_td[3][4] =
{
    {6,5,7,8},
    {11,9,10,12},
    {15,13,14,16}
};
new Text:casesda_TD[10];
new typecase[MAX_PLAYERS];
new Text:invdo_TD[24];
new last_player_ruletka[3][WELSI_BLYAT] =
{
    {"Nick_Name", 0},
    {"Nick_Name", 0},
    {"Nick_Name", 0}
};

new ruletka_prize[12][R_STRUCT] =//table of prizes: lower index = lower chance
{
    {T_CAR, "txd:brgiftsuncar", 	"Toyota_Mark_2", "Toyota Mark II",		547},
	{T_CAR, "txd:brgiftsuncar", 	"Ford_Mustang", "Ford Mustang GT",			603},
	{T_DONATE, "txd:brgiftsdonate", 		"up_to_150_donate", "up to 150 donate", 150},
    {T_MONEY, "txd:brgiftscash", 	"Up_to_500000_p.", "up to 500000 rubles",		500000},
	{T_SLOT, "txd:brgiftsfreeslot", 		"Vehicle_slot", 	"Vehicle slot",	1},
    {T_VIP, "txd:brgiftsgvip", 		"Gold-Vip", "GOLD-VIP for 15 days",			3},
    {T_LIC, "txd:brgiftslic", 		"License_package", 	"License package",	1},
    {T_MONEY, "txd:brgiftscash", 	"Up_to_100000_p.",  "up to 100000 rubles",	100000},
    {T_GUN, "txd:brgiftsgun", 		"Random_gun", 	"Random weapon",	25},
    {T_EXP, "txd:brgiftsexp", 	"15_EXP",  "15 EXP", 15},
    {T_EXP, "txd:brgiftsexp", 	"3_EXP",  "3 EXP", 3},
    {T_EXP, "txd:brgiftsexp", 	"1_EXP",  "1 EXP", 1}
};

new player_roulette_bronz[MAX_PLAYERS];
new menu_prize_player[MAX_PLAYERS][5];
new ruletka_count[MAX_PLAYERS];
new bool:animation_player[MAX_PLAYERS];
new timer_player_ruletka[MAX_PLAYERS];
new Text:welsirltk_TD[35];
new PlayerText:ruletka_PTD[MAX_PLAYERS][5];
new PlayerText:ruletka_PTD_t[MAX_PLAYERS][18];
new td_prize[12][2] =
{
    {5,6},
    {9,10},
    {11,12},
    {13,14},
    {15,16},
    {17,18},
    {19,20},
    {21,22},
    {23,24},
    {25,26},
    {27,28},
    {29,30}
};

#define T_NONE_1		0
#define	T_MONEY_1		1
#define	T_LIC_1		2
#define	T_VIP_1		3
#define	T_CAR_1		4
#define	T_GUN_1		5
#define	T_EXP_1		6
#define	T_DONATE_1	7
#define	T_SLOT_1		8
#define	T_AKS_1	9
#define	T_MED_1	10
#define	T_VOENN_1	11
enum R_STRUCT_1
{
	R_TYPE_1,
	R_NAME_TXD_1[48],
	R_NAME_TEXT_1[48],
    R_NAME_PRIZE_1[48],
	R_COUNT_1
}

enum WELSI_BLYAT_1
{
    last_player_name_1[24],
    id_ruletka_prize_1
};

new last_player_td_1[3][4] =
{
    {6,5,7,8},
    {11,9,10,12},
    {15,13,14,16}
};

new last_player_ruletka_1[3][WELSI_BLYAT_1] =
{
    {"Nick_Name", 0},
    {"Nick_Name", 0},
    {"Nick_Name", 0}
};

new ruletka_prize_1[15][R_STRUCT_1] =//table of prizes: lower index = lower chance
{
    {T_CAR_1, "txd:brgiftsuncar", 	"Volkswagen_Getta", "Volkswagen_Getta",		547},
	{T_CAR_1, "txd:brgiftsuncar", 	"Mercedes-Benz_C63s_AMG", "Mercedes-Benz C63s AMG",			603},
	{T_VIP_1, "txd:brgiftspvip", 		"5_days.", "Platinum VIP for 5 days",			3},
     {T_VIP_1, "txd:brgiftsgvip", 		"5_days.", "Gold VIP for 5 days",			3},
     {T_VIP_1, "txd:brgiftssvip", 		"5_days.", "Silver VIP for 5 days",			3},
	{T_DONATE_1, "txd:brgiftsdonate", "Any_weapon.", "Any weapon.", 150},
    {T_VOENN_1, "txd:brgiftscash", 	"Military_ticket.", "Military ticket",		500000},
	{T_SLOT_1, "txd:brgiftsfreeslot", 		"Extra_slot_for_car.", 	"Extra slot for car",	1},
   {T_MED_1, "txd:brgiftsmedcard", 		"Med_card", "Med card",			3},
    {T_AKS_1, "txd:brgiftsbag", 		"Supreme_bag", 	"Supreme bag",	1},
    {T_AKS_1, "txd:brgiftsbackpack", 	"LV_backpack.",  "LV backpack",	100000},
    {T_AKS_1, "txd:brgiftscap", 		"BlackRussia_cap", 	"BlackRussia cap",	25},
    {T_EXP_1, "txd:brgiftsexp", 	"16_EXP",  "16 EXP", 16},
    {T_EXP_1, "txd:brgiftsexp", 	"8_EXP",  "8 EXP", 8},
    {T_EXP_1, "txd:brgiftsexp", 	"4_EXP",  "4 EXP", 4}
};

new player_roulette_bronz_1[MAX_PLAYERS];
new menu_prize_player_1[MAX_PLAYERS][5];
new ruletka_count_1[MAX_PLAYERS];
new bool:animation_player_1[MAX_PLAYERS];
new timer_player_ruletka_1[MAX_PLAYERS];
new Text:welsirltk_TD_1[35];
new PlayerText:ruletka_PTD_1[MAX_PLAYERS][5];
new PlayerText:ruletka_PTD_t_1[MAX_PLAYERS][18];








//Roulette
#define T_NONE_2		0
#define	T_MONEY_2		1
#define	T_LIC_2		2
#define	T_VIP_2		3
#define	T_CAR_2		4
#define	T_GUN_2		5
#define	T_EXP_2		6
#define	T_DONATE_2	7
#define	T_SLOT_2		8

enum R_STRUCT_2
{
	R_TYPE_2,
	R_NAME_TXD_2[48],
	R_NAME_TEXT_2[48],
    R_NAME_PRIZE_2[48],
	R_COUNT_2
}

enum WELSI_BLYAT_2
{
    last_player_name_2[24],
    id_ruletka_prize_2
};

new last_player_td_2[3][4] =
{
    {6,5,7,8},
    {11,9,10,12},
    {15,13,14,16}
};

new last_player_ruletka_2[3][WELSI_BLYAT_2] =
{
    {"Nick_Name", 0},
    {"Nick_Name", 0},
    {"Nick_Name", 0}
};

new ruletka_prize_2[12][R_STRUCT_2] =//table of prizes: lower index = lower chance
{
    {T_CAR_2, "txd:brgiftsuncar", 	"Toyota_Mark_2", "Toyota Mark II",		547},
	{T_CAR_2, "txd:brgiftsuncar", 	"Toyota_Mark_2", "Ford Mustang GT",			603},
	{T_DONATE_2, "txd:brgiftsdonate", 		"Toyota_Mark_2-rub.", "up to 150 donate", 150},
    {T_MONEY_2, "txd:brgiftscash", 	"Up_to_500000_p.", "up to 500000 rubles",		500000},
	{T_SLOT_2, "txd:brgiftsfreeslot", 		"Toyota_Mark_2", 	"Vehicle slot",	1},
    {T_VIP_2, "txd:brgiftsgvip", 		"Toyota_Mark_2", "GOLD-VIP for 15 days",			3},
    {T_LIC_2, "txd:brgiftslic", 		"Toyota_Mark_2", 	"License package",	1},
    {T_MONEY_2, "txd:brgiftscash", 	"Up_to_100000_p.",  "up to 100000 rubles",	100000},
    {T_GUN_2, "txd:brgiftsgun", 		"Random_gun", 	"Random weapon",	25},
    {T_EXP_2, "txd:brgiftsexp", 	"15_EXP",  "15 EXP", 15},
    {T_EXP_2, "txd:brgiftsexp", 	"3_EXP",  "3 EXP", 3},
    {T_EXP_2, "txd:brgiftsexp", 	"1_EXP",  "1 EXP", 1}
};

new player_roulette_bronz_2[MAX_PLAYERS];
new menu_prize_player_2[MAX_PLAYERS][5];
new ruletka_count_2[MAX_PLAYERS];
new bool:animation_player_2[MAX_PLAYERS];
new timer_player_ruletka_2[MAX_PLAYERS];
new Text:welsirltk_TD_2[35];
new PlayerText:ruletka_PTD_2[MAX_PLAYERS][5];
new PlayerText:ruletka_PTD_t_2[MAX_PLAYERS][18];






//Roulette
#define T_NONE3		0
#define	T_MONEY3	1
#define	T_LIC3		2
#define	T_VIP3		3
#define	T_CAR3		4
#define	T_GUN3		5
#define	T_EXP3		6
#define	T_DONATE3	7
#define	T_SLOT3		8

enum R_STRUCT3
{
	R_TYPE3,
	R_NAME_TXD3[48],
	R_NAME_TEXT3[48],
    R_NAME_PRIZE3[48],
	R_COUNT3
}

enum WELSI_BLYAT3
{
    last_player_name3[24],
    id_ruletka_prize3
};

new last_player_td3[3][4] =
{
    {6,5,7,8},
    {11,9,10,12},
    {15,13,14,16}
};
new last_player_ruletka3[3][WELSI_BLYAT3] =
{
    {"Nick_Name", 0},
    {"Nick_Name", 0},
    {"Nick_Name", 0}
};

new ruletka_prize3[26][R_STRUCT3] =//table of prizes: lower index = lower chance
{
{T_CAR3, "txd:brgiftsuncar", 	"GAZ_69",  "GAZ_69", 500}, //gold
{T_CAR3, "txd:brgiftsuncar", 	"BMW_M5_F90(PPS)",  "BMW_M5_F90(PPS)", 596}, //gold
{T_CAR3, "txd:brgiftsuncar", 	"MERCEDES-BENZ_G63_AMG", "MERCEDES-BENZ_G63_AMG", 2573}, //gold
{T_CAR3, "txd:brgiftsuncar", 	"RAESR_TACHYON_2019",  "RAESR_TACHYON_2019", 2572}, //gold
{T_CAR3, "txd:brgiftsucar", 	"LAMBORGHINI_URUS",  "LAMBORGHINI_URUS", 2551},
{T_CAR3, "txd:brgiftsucar", 		"CADILLAC_ESCALADE_IV", 	"CADILLAC_ESCALADE_IV",	505},
{T_CAR3, "txd:brgiftsucar", 	"MERCEDES-BENZ_CLS63_AMG",  "MERCEDES-BENZ_CLS63_AMG",	2582},
{T_CAR3, "txd:brgiftsuncar", 	"BMW_M5_F90", "BMW_M5_F90",			466},
{T_CAR3, "txd:brgiftsucar", 		"NISSAN_GT-R_R35", "NISSAN_GT-R_R35",			502},
{T_CAR3, "txd:brgiftsucar", 		"TOYOTA_LAND_CRUISER_200", 	"TOYOTA_LAND_CRUISER_200",	2547},
{T_CAR3, "txd:brgiftsucar", 	"MERCEDES-BENZ_GT63S", "MERCEDES-BENZ_GT63S",		402},
{T_CAR3, "txd:brgiftsucar", 		"BMW_M4_F84", "BMW_M4_F84", 558},
{T_CAR3, "txd:brgiftsucar", 	"BMW_M8_F93_GRANCOUPE",  "BMW_M8_F93_GRANCOUPE", 2579},
{T_CAR3, "txd:brgiftsucar", 	"BMW_Z4_M40I",  "BMW_Z4_M40I", 480},
{T_CAR3, "txd:brgiftsucar", 	"CHEVROLET_CAMARO_ZL1",  "CHEVROLET_CAMARO_ZL1", 543},
{T_CAR3, "txd:brgiftsucar", 	"YAMAHA_FZ-10",  "YAMAHA_FZ-10", 523},
{T_CAR3, "txd:brgiftsucar", 	"DUCATI_XDIAVEL_S",  "DUCATI_XDIAVEL_S", 463},
{T_CAR3, "txd:brgiftsucar", 		"MERCEDES-BENZ_A45_AMG", 	"MERCEDES-BENZ_A45_AMG",	565},
{T_CAR3, "txd:brgiftsucar", 	"TOYOTA_SUPRA_A80",  "TOYOTA_SUPRA_A80",	2552},
{T_CAR3, "txd:brgiftsucar", 		"FORD_MUSTANG_GT", 	"FORD_MUSTANG_GT",	603},
{T_CAR3, "txd:brgiftsucar", 		"KIA_K5", "KIA_K5",			2584},
{T_CAR3, "txd:brgiftsucar", 		"TOYOTA_CAMRY_3.5", 	"TOYOTA_CAMRY_3.5",	550},
{T_CAR3, "txd:brgiftsucar", 	"SUBARU_WRX_STI", "SUBARU_WRX_STI",		560},
{T_CAR3, "txd:brgiftsucar", 		"BMW_M5_E60", "BMW_M5_E60", 2567},
{T_CAR3, "txd:brgiftsucar", 	"MITSUBISHI_LANCER_EVO_X", "MITSUBISHI_LANCER_EVO_X",		436},
{T_CAR3, "txd:brgiftsucar", 	"DUCATI_SUPERSPORT_S", "DUCATI_SUPERSPORT_S",		461}
};

new player_roulette_bronz3[MAX_PLAYERS];
new menu_prize_player3[MAX_PLAYERS][5];
new ruletka_count3[MAX_PLAYERS];
new bool:animation_player3[MAX_PLAYERS];
new timer_player_ruletka3[MAX_PLAYERS];
new Text:welsirltk_TD3[35];
new PlayerText:ruletka_PTD3[MAX_PLAYERS][5];
new PlayerText:ruletka_PTD_t3[MAX_PLAYERS][18];

public OnGameModeInit()
{
 RuletkaMenu();
    LoadPrizeRuletka();
    SetTimer("CreateTablistRoulette", 1500, false);
  RuletkaMenu_1();
    LoadPrizeRuletka_1();
    SetTimer("CreateTablistRoulette_1", 1500, false);
      RuletkaMenu_2();
    LoadPrizeRuletka_2();
    SetTimer("CreateTablistRoulette_2", 1500, false);
     RuletkaMenu3();
    LoadPrizeRuletka3();
    SetTimer("CreateTablistRoulette3", 1500, false);
       #if defined roulette_OnGameModeInit
        return roulette_OnGameModeInit();
    #else
        return 1;
    #endif
}
#if defined _ALS_OnGameModeInit
    #undef OnGameModeInit
#else
    #define _ALS_OnGameModeInit
#endif
#define OnGameModeInit roulette_OnGameModeInit
#if defined roulette_OnGameModeInit
    forward roulette_OnGameModeInit();
#endif

public OnDialogResponse(playerid, dialogid, response, listitem, inputtext[])
{
    	    if(dialogid == 12832)
    {
        if(response)
        {
            if(listitem == 0 || listitem == 1)
            {
                new count_listt3 = GetPVarInt(playerid, "count_list"), query3[94];

                if(!listitem) count_listt3++;
                else if(listitem == 1 && count_listt3 != 1) count_listt3--;


                mysql_format(mysql, query3, sizeof query3, "SELECT * FROM roulette_prize WHERE owner = %d", GetPlayerAccountID(playerid));
                new Cache:cache3 = mysql_query(mysql, query3);

                new list_max3 = count_listt3*10, rows3, prize_id3, id3, list3[52], dialog3[sizeof list3*10+54];

                strcat(dialog3, "Next page\nPrevious page\n");

                rows3 = cache_num_rows();

                if(rows3 >= list_max3) rows3 = list_max3;

                for(new i3 = list_max3 - 10, c3=2;i3 < rows3;i3++, c3++)
                {
                    prize_id3 = cache_get_field_content_int(i3, "prize");
                    id3 = cache_get_field_content_int(i3, "id");

                    format(list3, sizeof list3, "%d. %s\n", i3+1, ruletka_prize3[prize_id3][R_NAME_PRIZE3]);
                    strcat(dialog3, list3);
                    SetPlayerListitemValue(playerid, c3, prize_id3);
                    format(list3, sizeof list3, "rouletteid_%d", c3);
                    SetPVarInt(playerid, list3, id3);
                }

                cache_delete(cache3);
                SetPVarInt(playerid, "count_list", count_listt3);
                Dialog(playerid, 2832, DIALOG_STYLE_LIST, "{FF0000}Prizes from roulette", dialog3, "Next", "Exit");
                return 1;
            }

            new id3 = GetPlayerListitemValue(playerid, listitem), text3[134],count3;

            format(text3, sizeof text3, "");

            switch(id3)
            {
                case 0..25:
                {
                    if(GetPlayerOwnableCar(playerid) != INVALID_VEHICLE_ID)
                    return SendClientMessage(playerid, -1, "You already have a vehicle");
                    GivePlayerCarRoulette3(playerid, ruletka_prize3[id3][R_COUNT3], 0, 0);

                    format(text3, sizeof text3, "You received %s from the prize. Congratulations!",  ruletka_prize3[id3][R_NAME_PRIZE3]);
                }
            }

            SendClientMessage(playerid, -1, text3);

            format(text3, sizeof text3, "rouletteid_%d", listitem);
            new id_data3 = GetPVarInt(playerid, text3);
            mysql_format(mysql, text3, sizeof text3, "DELETE FROM roulette_prize WHERE id = %d", id_data3);
            mysql_query(mysql, text3, false);
            if(mysql_errno()) return SendClientMessage(playerid, -1, "Error in query.");
        }
    }
 if(dialogid == 21832)
    {
        if(response)
        {
            if(listitem == 0 || listitem == 1)
            {
                new count_listt_2 = GetPVarInt(playerid, "count_list"), query_2[94];

                if(!listitem) count_listt_2++;
                else if(listitem == 1 && count_listt_2 != 1) count_listt_2--;


                mysql_format(mysql, query_2, sizeof query_2, "SELECT * FROM roulette_prize WHERE owner = %d", GetPlayerAccountID(playerid));
                new Cache:cache_2 = mysql_query(mysql, query_2);

                new list_max_2 = count_listt_2*10, rows_2, prize_id_2, id_2, list_2[52], dialog_2[sizeof list_2*10+54];

                strcat(dialog_2, "Next page\nPrevious page\n");

                rows_2 = cache_num_rows();

                if(rows_2 >= list_max_2) rows_2 = list_max_2;

                for(new i_2 = list_max_2 - 10, c_2=2;i_2 < rows_2;i_2++, c_2++)
                {
                    prize_id_2 = cache_get_field_content_int(i_2, "prize");
                    id_2 = cache_get_field_content_int(i_2, "id");

                    format(list_2, sizeof list_2, "%d. %s\n", i_2+1, ruletka_prize_2[prize_id_2][R_NAME_PRIZE_2]);
                    strcat(dialog_2, list_2);
                    SetPlayerListitemValue(playerid, c_2, prize_id_2);
                    format(list_2, sizeof list_2, "rouletteid_%d", c_2);
                    SetPVarInt(playerid, list_2, id_2);
                }

                cache_delete(cache_2);
                SetPVarInt(playerid, "count_list", count_listt_2);
                Dialog(playerid, 2832, DIALOG_STYLE_LIST, "{FF0000}Prizes from roulette", dialog_2, "Next", "Exit");
                return 1;
            }

            new id_2 = GetPlayerListitemValue(playerid, listitem), text_2[134],count_2;

            format(text_2, sizeof text_2, "");

            switch(id_2)
            {
                case 0,1:
                {
                    if(GetPlayerOwnableCar(playerid) != INVALID_VEHICLE_ID)
                    return SendClientMessage(playerid, -1, "You already have a vehicle");
                    GivePlayerCarRoulette_2(playerid, ruletka_prize_2[id_2][R_COUNT_2], 0, 0);

                    format(text_2, sizeof text_2, "You received %s from the prize. Congratulations!",  ruletka_prize_2[id_2][R_NAME_PRIZE_2]);
                }
                case 2:
                {
                    count_2 = random(150)+1;

                    GivePlayerDonateRub(playerid, count_2);
                    format(text_2, sizeof text_2, "You received %d donate rubles from the prize. Congratulations!", count_2);
                }
                case 3,7:
                {
                    count_2 = random(ruletka_prize_2[id_2][R_COUNT_2])+1;

                    GivePlayerMoneyEx(playerid, count_2);
                    format(text_2, sizeof text_2, "You received %d rubles from the prize. Congratulations!", count_2);
                }
                case 4:
                {
                    AddPlayerData(playerid, P_CAR_SLOTS, +, 1);
                    UpdatePlayerDatabaseInt(playerid, "car_slots", GetPlayerData(playerid, P_CAR_SLOTS));

                    format(text_2, sizeof text_2, "You received %s from the prize. Congratulations!", ruletka_prize_2[id_2][R_NAME_PRIZE_2]);
                }
                case 5:
                {
                    new prem_day_2,prem_month_2,prem_year_2,premium_2 = GetPlayerPremium(playerid);
                    if(!premium_2)
                    {
                        AddPlayerData(playerid, P_CAR_SLOTS, +, 2);
                        SetPlayerData(playerid, P_PREMIUM, 3);
                        SetPlayerData(playerid, P_PREMIUM_DATE, gettime() + 15 * 86400);
                    }
                    else
                    {
                        AddPlayerData(playerid, P_PREMIUM_DATE, +, 15 * 86400);
                    }

                    timestamp_to_date(GetPlayerData(playerid, P_PREMIUM_DATE), prem_year_2, prem_month_2, prem_day_2);

                    format(text_2, sizeof text_2, "You received {FFEE00}VIP Gold{FFFFFF} until {F5D000}%02d.%02d.%d from the prize. Congratulations", prem_day_2, prem_month_2, prem_year_2);

                    UpdatePlayerDatabaseInt(playerid, "premium", 3);
                    UpdatePlayerDatabaseInt(playerid, "premium_date", GetPlayerData(playerid, P_PREMIUM_DATE));
                }
                case 6:
                {
                    SetPlayerData(playerid, P_DRIVING_LIC,	2);
                    SetPlayerData(playerid, P_WEAPON_LIC,	1);

                    UpdatePlayerDatabaseInt(playerid, "driving_lic", 2);
                    UpdatePlayerDatabaseInt(playerid, "weapon_lic", 1);

                    format(text_2, sizeof text_2, "You received %s from the prize. Congratulations!", ruletka_prize_2[id_2][R_NAME_PRIZE_2]);
                }
                case 8:
                {
                    new gun_2[7] = {23,24,25,29,30,31,33};

                    GivePlayerWeapon(playerid, gun_2[random(sizeof gun_2)], 1000);

                    format(text_2, sizeof text_2, "You received %s from the prize. Congratulations!", ruletka_prize_2[id_2][R_NAME_PRIZE_2]);
                }
                case 9,10,11:
                {
                    AddPlayerData(playerid, P_EXP, +, ruletka_prize_2[id_2][R_COUNT_2]);
				    UpdatePlayerDatabaseInt(playerid, "exp", GetPlayerData(playerid, P_EXP));

                    if(GetPlayerExp(playerid) > GetExpToNextLevel(playerid))
                    {
                        SetPlayerData(playerid, P_EXP, 0);
                        AddPlayerData(playerid, P_LEVEL, +, 1);

                        SetPlayerLevelInit(playerid);
                        SendClientMessage(playerid, -1, "Congratulations! Your level has been increased");
                    }

                    format(text_2, sizeof text_2, "You received %s from the prize. Congratulations!", ruletka_prize_2[id_2][R_NAME_PRIZE_2]);
                }
            }

            SendClientMessage(playerid, -1, text_2);

            format(text_2, sizeof text_2, "rouletteid_%d", listitem);
            new id_data_2 = GetPVarInt(playerid, text_2);
            mysql_format(mysql, text_2, sizeof text_2, "DELETE FROM roulette_prize WHERE id = %d", id_data_2);
            mysql_query(mysql, text_2, false);
            if(mysql_errno()) return SendClientMessage(playerid, -1, "Error in query.");
        }
    }


   if(dialogid == 28132)
    {
        if(response)
        {
            if(listitem == 0 || listitem == 1)
            {
                new count_listt = GetPVarInt(playerid, "count_list"), query[94];

                if(!listitem) count_listt++;
                else if(listitem == 1 && count_listt != 1) count_listt--;


                mysql_format(mysql, query, sizeof query, "SELECT * FROM roulette_prize WHERE owner = %d", GetPlayerAccountID(playerid));
                new Cache:cache = mysql_query(mysql, query);

                new list_max = count_listt*10, rows, prize_id, id, list[52], dialog[sizeof list*10+54];

                strcat(dialog, "Next page\nPrevious page\n");

                rows = cache_num_rows();

                if(rows >= list_max) rows = list_max;

                for(new i = list_max - 10, c=2;i < rows;i++, c++)
                {
                    prize_id = cache_get_field_content_int(i, "prize");
                    id = cache_get_field_content_int(i, "id");

                    format(list, sizeof list, "%d. %s\n", i+1, ruletka_prize_1[prize_id][R_NAME_PRIZE_1]);
                    strcat(dialog, list);
                    SetPlayerListitemValue(playerid, c, prize_id);
                    format(list, sizeof list, "rouletteid_%d", c);
                    SetPVarInt(playerid, list, id);
                }

                cache_delete(cache);
                SetPVarInt(playerid, "count_list", count_listt);
                Dialog(playerid, 2832, DIALOG_STYLE_LIST, "{FF0000}Prizes from roulette", dialog, "Next", "Exit");
                return 1;
            }

            new id = GetPlayerListitemValue(playerid, listitem), text[134],count;

            format(text, sizeof text, "");

            switch(id)
            {
                case 0,1:
                {
                    if(GetPlayerOwnableCar(playerid) != INVALID_VEHICLE_ID)
                    return SendClientMessage(playerid, -1, "You already have a vehicle");
                    GivePlayerCarRoulette_1(playerid, ruletka_prize_1[id][R_COUNT_1], 0, 0);

                    format(text, sizeof text, "You received %s from the prize. Congratulations!",  ruletka_prize_1[id][R_NAME_PRIZE_1]);
                }
                case 2..4:
                {
					AddPlayerData(playerid, P_PREMIUM_DATE, +, 15 * 86400);


                    format(text, sizeof text, "You received {FFEE00}VIP{FFFFFF} until {F5D000}%02d.%02d.%d from the prize. Congratulations", 1, 1, 1);

                    UpdatePlayerDatabaseInt(playerid, "premium", 3);
                    UpdatePlayerDatabaseInt(playerid, "premium_date", GetPlayerData(playerid, P_PREMIUM_DATE));
                }
                case 5:
                {
                                       new gun[7] = {23,24,25,29,30,31,33};

                    GivePlayerWeapon(playerid, gun[random(sizeof gun)], 1000);

                    format(text, sizeof text, "You received %s from the prize. Congratulations!", ruletka_prize_1[id][R_NAME_PRIZE_1]);
                }
                case 6:
                {

                        SendClientMessage(playerid, -1, "Congratulations! Military ticket is under development");
                 }
                case 7:
                {

                        SendClientMessage(playerid, -1, "Congratulations! Extra slot for car");
                 }
                 case 8:
                {

                        SendClientMessage(playerid, -1, "Congratulations! Med card");
                 }
                 case 9:
                {

                        SendClientMessage(playerid, -1, "Congratulations! Supreme bag");
                 }
                 case 10:
                {

                        SendClientMessage(playerid, -1, "Congratulations! LV backpack");
                 }
                 case 11:
                {

                        SendClientMessage(playerid, -1, "Congratulations! BlackRussia cap");
                 }
                 case 12:
                {

                        SendClientMessage(playerid, -1, "Congratulations! EXP 16");
                 }
                 case 13:
                {

                        SendClientMessage(playerid, -1, "Congratulations! EXP 8");
                 }
                 case 14:
                {

                        SendClientMessage(playerid, -1, "Congratulations! EXP 4");
                 }
			}



            SendClientMessage(playerid, -1, text);

            format(text, sizeof text, "rouletteid_%d", listitem);
            new id_data = GetPVarInt(playerid, text);
            mysql_format(mysql, text, sizeof text, "DELETE FROM roulette_prize WHERE id = %d", id_data);
            mysql_query(mysql, text, false);
            if(mysql_errno()) return SendClientMessage(playerid, -1, "Error in query.");
        }
    }

	if(dialogid == 2832)
    {
        if(response)
        {
            if(listitem == 0 || listitem == 1)
            {
                new count_listt = GetPVarInt(playerid, "count_list"), query[94];

                if(!listitem) count_listt++;
                else if(listitem == 1 && count_listt != 1) count_listt--;


                mysql_format(mysql, query, sizeof query, "SELECT * FROM roulette_prize WHERE owner = %d", GetPlayerAccountID(playerid));
                new Cache:cache = mysql_query(mysql, query);

                new list_max = count_listt*10, rows, prize_id, id, list[52], dialog[sizeof list*10+54];

                strcat(dialog, "Next page\nPrevious page\n");

                rows = cache_num_rows();

                if(rows >= list_max) rows = list_max;

                for(new i = list_max - 10, c=2;i < rows;i++, c++)
                {
                    prize_id = cache_get_field_content_int(i, "prize");
                    id = cache_get_field_content_int(i, "id");

                    format(list, sizeof list, "%d. %s\n", i+1, ruletka_prize[prize_id][R_NAME_PRIZE]);
                    strcat(dialog, list);
                    SetPlayerListitemValue(playerid, c, prize_id);
                    format(list, sizeof list, "rouletteid_%d", c);
                    SetPVarInt(playerid, list, id);
                }

                cache_delete(cache);
                SetPVarInt(playerid, "count_list", count_listt);
                Dialog(playerid, 2832, DIALOG_STYLE_LIST, "{FF0000}Prizes from roulette", dialog, "Next", "Exit");
                return 1;
            }

            new id = GetPlayerListitemValue(playerid, listitem), text[134],count;

            format(text, sizeof text, "");

            switch(id)
            {
                case 0,1:
                {
                    if(GetPlayerOwnableCar(playerid) != INVALID_VEHICLE_ID)
                    return SendClientMessage(playerid, -1, "You already have a vehicle");
                    GivePlayerCarRoulette(playerid, ruletka_prize[id][R_COUNT], 0, 0);

                    format(text, sizeof text, "You received %s from the prize. Congratulations!",  ruletka_prize[id][R_NAME_PRIZE]);
                }
                case 2:
                {
                    count = random(150)+1;

                    GivePlayerDonateRub(playerid, count);
                    format(text, sizeof text, "You received %d donate rubles from the prize. Congratulations!", count);
                }
                case 3,7:
                {
                    count = random(ruletka_prize[id][R_COUNT])+1;

                    GivePlayerMoneyEx(playerid, count);
                    format(text, sizeof text, "You received %d rubles from the prize. Congratulations!", count);
                }
                case 4:
                {
                    AddPlayerData(playerid, P_CAR_SLOTS, +, 1);
                    UpdatePlayerDatabaseInt(playerid, "car_slots", GetPlayerData(playerid, P_CAR_SLOTS));

                    format(text, sizeof text, "You received %s from the prize. Congratulations!", ruletka_prize[id][R_NAME_PRIZE]);
                }
                case 5:
                {
                    new prem_day,prem_month,prem_year,premium = GetPlayerPremium(playerid);
                    if(!premium)
                    {
                        AddPlayerData(playerid, P_CAR_SLOTS, +, 2);
                        SetPlayerData(playerid, P_PREMIUM, 3);
                        SetPlayerData(playerid, P_PREMIUM_DATE, gettime() + 15 * 86400);
                    }
                    else
                    {
                        AddPlayerData(playerid, P_PREMIUM_DATE, +, 15 * 86400);
                    }

                    timestamp_to_date(GetPlayerData(playerid, P_PREMIUM_DATE), prem_year, prem_month, prem_day);

                    format(text, sizeof text, "You received {FFEE00}VIP Gold{FFFFFF} until {F5D000}%02d.%02d.%d from the prize. Congratulations", prem_day, prem_month, prem_year);

                    UpdatePlayerDatabaseInt(playerid, "premium", 3);
                    UpdatePlayerDatabaseInt(playerid, "premium_date", GetPlayerData(playerid, P_PREMIUM_DATE));
                }
                case 6:
                {
                    SetPlayerData(playerid, P_DRIVING_LIC,	2);
                    SetPlayerData(playerid, P_WEAPON_LIC,	1);

                    UpdatePlayerDatabaseInt(playerid, "driving_lic", 2);
                    UpdatePlayerDatabaseInt(playerid, "weapon_lic", 1);

                    format(text, sizeof text, "You received %s from the prize. Congratulations!", ruletka_prize[id][R_NAME_PRIZE]);
                }
                case 8:
                {
                    new gun[7] = {23,24,25,29,30,31,33};

                    GivePlayerWeapon(playerid, gun[random(sizeof gun)], 1000);

                    format(text, sizeof text, "You received %s from the prize. Congratulations!", ruletka_prize[id][R_NAME_PRIZE]);
                }
                case 9,10,11:
                {
                    AddPlayerData(playerid, P_EXP, +, ruletka_prize[id][R_COUNT]);
				    UpdatePlayerDatabaseInt(playerid, "exp", GetPlayerData(playerid, P_EXP));

                    if(GetPlayerExp(playerid) > GetExpToNextLevel(playerid))
                    {
                        SetPlayerData(playerid, P_EXP, 0);
                        AddPlayerData(playerid, P_LEVEL, +, 1);

                        SetPlayerLevelInit(playerid);
                        SendClientMessage(playerid, -1, "Congratulations! Your level has been increased");
                    }

                    format(text, sizeof text, "You received %s from the prize. Congratulations!", ruletka_prize[id][R_NAME_PRIZE]);
                }
            }

            SendClientMessage(playerid, -1, text);

            format(text, sizeof text, "rouletteid_%d", listitem);
            new id_data = GetPVarInt(playerid, text);
            mysql_format(mysql, text, sizeof text, "DELETE FROM roulette_prize WHERE id = %d", id_data);
            mysql_query(mysql, text, false);
            if(mysql_errno()) return SendClientMessage(playerid, -1, "Error in query.");
        }
    }
        #if defined roulette_OnDialogResponse
        return roulette_OnDialogResponse(playerid, dialogid, response, listitem, inputtext);
    #endif
}
#if defined _ALS_OnDialogResponse
    #undef OnDialogResponse
#else
    #define _ALS_OnDialogResponse
#endif
#define OnDialogResponse roulette_OnDialogResponse
#if defined roulette_OnDialogResponse
    forward roulette_OnDialogResponse(playerid, dialogid, response, listitem, inputtext[]);
#endif

public OnPlayerDisconnect(playerid, reason)
{
     player_roulette_bronz_1[playerid] = 0;
    ruletka_count_1[playerid] = 0;
    animation_player_1[playerid] = false;
    timer_player_ruletka_1[playerid] = -1;
  player_roulette_bronz[playerid] = 0;
    ruletka_count[playerid] = 0;
    animation_player[playerid] = false;
    timer_player_ruletka[playerid] = -1;
     player_roulette_bronz_2[playerid] = 0;
    ruletka_count_2[playerid] = 0;
    animation_player_2[playerid] = false;
    timer_player_ruletka_2[playerid] = -1;
        player_roulette_bronz3[playerid] = 0;
    ruletka_count3[playerid] = 0;
    animation_player3[playerid] = false;
    timer_player_ruletka3[playerid] = -1;
	#if defined roulette_OnPlayerDisconnect
        return roulette_OnPlayerDisconnect(playerid, reason);
    #else
        return 1;
    #endif
}
#if defined _ALS_OnPlayerDisconnect
    #undef OnPlayerDisconnect
#else
    #define _ALS_OnPlayerDisconnect
#endif
#define OnPlayerDisconnect roulette_OnPlayerDisconnect
#if defined roulette_OnPlayerDisconnect
    forward roulette_OnPlayerDisconnect(playerid, reason);
#endif

public OnPlayerClickTextDraw(playerid, Text:clickedid)
{

if(clickedid == welsirltk_TD3[4])
	{
        if(animation_player3[playerid]) return SCM(playerid, -1, ""USC"Wait for the animation to finish.");
        if(GetPlayerDonateRub(playerid) >= 50)
        {
            player_roulette_bronz3[playerid]++;
            UpdatePlayerDatabaseInt(playerid, "roulette_auto", player_roulette_bronz3[playerid]);
            SendClientMessage(playerid, -1, "You bought an auto case!");
            GivePlayerDonateRub(playerid, -1000);

            new string3[10];
            format(string3, sizeof string3, "%d", player_roulette_bronz3[playerid]);
            PlayerTextDrawSetString(playerid, ruletka_PTD_t3[playerid][17], string3);
        }
        else SendClientMessage(playerid, -1, "Auto case costs 1000 donate rubles.");
	}
	if(clickedid == welsirltk_TD3[31])
	{
        UpdateLastPlayerRuletka3(playerid);
	}
	if(clickedid == welsirltk_TD3[33])
	{
        if(player_roulette_bronz3[playerid])
        {
            if(timer_player_ruletka3[playerid] == -1)
            {
                if(animation_player3[playerid]) return SCM(playerid, -1, ""USC"Wait for the animation to finish.");
                player_roulette_bronz3[playerid]--;
                UpdatePlayerDatabaseInt(playerid, "roulette_auto", player_roulette_bronz3[playerid]);

                new string3[10];
                format(string3, sizeof string3, "%d", player_roulette_bronz3[playerid]);
                PlayerTextDrawSetString(playerid, ruletka_PTD_t3[playerid][17], string3);

                animation_player3[playerid] = true;
                timer_player_ruletka3[playerid] = SetTimerEx("RunRuletka3", 500, true, "d", playerid);
            }
        }
        else SendClientMessage(playerid, -1, "You don't have auto cases.");
	}
	if(clickedid == welsirltk_TD3[32])
	{
		if(animation_player3[playerid]) return SCM(playerid, -1, ""USC"Wait for the animation to finish.");

		TogglePlayerControllable(playerid, true);
		ShowHud(playerid);
		for(new t3;t3 < sizeof welsirltk_TD3;t3++)
		{
			TextDrawHideForPlayer(playerid, welsirltk_TD3[t3]);
		}

        PlayerTextDrawHide(playerid, ruletka_PTD_t3[playerid][17]);

		for(new t3;t3 < 5;t3++)
		{
			PlayerTextDrawHide(playerid, ruletka_PTD3[playerid][t3]);
			PlayerTextDrawHide(playerid, ruletka_PTD_t3[playerid][t3]);
			menu_prize_player3[playerid][t3] = -1;
		}

        for(new i3; i3 < 3;i3++)
        {
            PlayerTextDrawHide(playerid, ruletka_PTD_t3[playerid][last_player_td3[i3][0]]);
            PlayerTextDrawHide(playerid, ruletka_PTD_t3[playerid][last_player_td3[i3][1]]);
            PlayerTextDrawHide(playerid, ruletka_PTD_t3[playerid][last_player_td3[i3][2]]);
            PlayerTextDrawHide(playerid, ruletka_PTD_t3[playerid][last_player_td3[i3][3]]);
        }

        CancelSelectTextDraw(playerid);
	}
if(clickedid == welsirltk_TD_2[4])
	{
        if(animation_player_2[playerid]) return SCM(playerid, -1, ""USC"Wait for the animation to finish.");
        if(GetPlayerDonateRub(playerid) >= 50)
        {
            player_roulette_bronz_2[playerid]++;
            UpdatePlayerDatabaseInt(playerid, "roulette_gold", player_roulette_bronz_2[playerid]);
            SendClientMessage(playerid, -1, "You bought a gold roulette");
            GivePlayerDonateRub(playerid, -50);

            new string_2[10];
            format(string_2, sizeof string_2, "%d", player_roulette_bronz_2[playerid]);
            PlayerTextDrawSetString(playerid, ruletka_PTD_t_2[playerid][17], string_2);
        }
        else SendClientMessage(playerid, -1, "Gold roulette costs 50 donate rubles.");
	}
	if(clickedid == welsirltk_TD_2[31])
	{
        UpdateLastPlayerRuletka_2(playerid);
	}
	if(clickedid == welsirltk_TD_2[33])
	{
        if(player_roulette_bronz_2[playerid])
        {
            if(timer_player_ruletka_2[playerid] == -1)
            {
                if(animation_player_2[playerid]) return SCM(playerid, -1, ""USC"Wait for the animation to finish.");
                player_roulette_bronz_2[playerid]--;
                UpdatePlayerDatabaseInt(playerid, "roulette_gold", player_roulette_bronz_2[playerid]);

                new string_2[10];
                format(string_2, sizeof string_2, "%d", player_roulette_bronz_2[playerid]);
                PlayerTextDrawSetString(playerid, ruletka_PTD_t_2[playerid][17], string_2);

                animation_player_2[playerid] = true;
                timer_player_ruletka_2[playerid] = SetTimerEx("RunRuletka_2", 500, true, "d", playerid);
            }
        }
        else SendClientMessage(playerid, -1, "You don't have gold roulettes.");
	}
	if(clickedid == welsirltk_TD_2[32])
	{
		if(animation_player_2[playerid]) return SCM(playerid, -1, ""USC"Wait for the animation to finish.");

		TogglePlayerControllable(playerid, true);
		ShowHud(playerid);
		for(new t_2;t_2 < sizeof welsirltk_TD_2;t_2++)
		{
			TextDrawHideForPlayer(playerid, welsirltk_TD_2[t_2]);
		}

        PlayerTextDrawHide(playerid, ruletka_PTD_t_2[playerid][17]);

		for(new t_2;t_2 < 5;t_2++)
		{
			PlayerTextDrawHide(playerid, ruletka_PTD_2[playerid][t_2]);
			PlayerTextDrawHide(playerid, ruletka_PTD_t_2[playerid][t_2]);
			menu_prize_player_2[playerid][t_2] = -1;
		}

        for(new i_2; i_2 < 3;i_2++)
        {
            PlayerTextDrawHide(playerid, ruletka_PTD_t_2[playerid][last_player_td_2[i_2][0]]);
            PlayerTextDrawHide(playerid, ruletka_PTD_t_2[playerid][last_player_td_2[i_2][1]]);
            PlayerTextDrawHide(playerid, ruletka_PTD_t_2[playerid][last_player_td_2[i_2][2]]);
            PlayerTextDrawHide(playerid, ruletka_PTD_t_2[playerid][last_player_td_2[i_2][3]]);
        }

        CancelSelectTextDraw(playerid);
	}


if(clickedid == welsirltk_TD_1[4])
	{
        if(animation_player_1[playerid]) return SCM(playerid, -1, ""USC"Wait for the animation to finish.");
        if(GetPlayerDonateRub(playerid) >= 250)
        {
            player_roulette_bronz_1[playerid]++;
            UpdatePlayerDatabaseInt(playerid, "roulette_silver", player_roulette_bronz_1[playerid]);
            SendClientMessage(playerid, -1, "You bought a silver roulette");
            GivePlayerDonateRub(playerid, -250);

            new string[10];
            format(string, sizeof string, "%d", player_roulette_bronz_1[playerid]);
            PlayerTextDrawSetString(playerid, ruletka_PTD_t_1[playerid][17], string);
        }
        else SendClientMessage(playerid, -1, "Silver roulette costs 250 donate rubles.");
	}
	if(clickedid == welsirltk_TD_1[31])
	{
        UpdateLastPlayerRuletka_1(playerid);
	}
	if(clickedid == welsirltk_TD_1[33])
	{
        if(player_roulette_bronz_1[playerid])
        {
            if(timer_player_ruletka_1[playerid] == -1)
            {
                if(animation_player_1[playerid]) return SCM(playerid, -1, ""USC"Wait for the animation to finish.");
                player_roulette_bronz_1[playerid]--;
                UpdatePlayerDatabaseInt(playerid, "roulette_silver", player_roulette_bronz_1[playerid]);

                new string[10];
                format(string, sizeof string, "%d", player_roulette_bronz_1[playerid]);
                PlayerTextDrawSetString(playerid, ruletka_PTD_t_1[playerid][17], string);

                animation_player_1[playerid] = true;
                timer_player_ruletka_1[playerid] = SetTimerEx("RunRuletka_1", 500, true, "d", playerid);
            }
        }
        else SendClientMessage(playerid, -1, "You don't have silver roulettes.");
	}
	if(clickedid == welsirltk_TD_1[32])
	{
		if(animation_player_1[playerid]) return SCM(playerid, -1, ""USC"Wait for the animation to finish.");

		TogglePlayerControllable(playerid, true);
		ShowHud(playerid);
		for(new t;t < sizeof welsirltk_TD_1;t++)
		{
			TextDrawHideForPlayer(playerid, welsirltk_TD_1[t]);
		}

        PlayerTextDrawHide(playerid, ruletka_PTD_t_1[playerid][17]);

		for(new t;t < 5;t++)
		{
			PlayerTextDrawHide(playerid, ruletka_PTD_1[playerid][t]);
			PlayerTextDrawHide(playerid, ruletka_PTD_t_1[playerid][t]);
			menu_prize_player_1[playerid][t] = -1;
		}

        for(new i; i < 3;i++)
        {
            PlayerTextDrawHide(playerid, ruletka_PTD_t_1[playerid][last_player_td_1[i][0]]);
            PlayerTextDrawHide(playerid, ruletka_PTD_t_1[playerid][last_player_td_1[i][1]]);
            PlayerTextDrawHide(playerid, ruletka_PTD_t_1[playerid][last_player_td_1[i][2]]);
            PlayerTextDrawHide(playerid, ruletka_PTD_t_1[playerid][last_player_td_1[i][3]]);
        }

        CancelSelectTextDraw(playerid);
	}
if(clickedid == welsirltk_TD[4])
	{
        if(animation_player[playerid]) return SCM(playerid, -1, ""USC"Wait for the animation to finish.");
        if(GetPlayerDonateRub(playerid) >= 50)
        {
            player_roulette_bronz[playerid]++;
            UpdatePlayerDatabaseInt(playerid, "roulette_bronz", player_roulette_bronz[playerid]);
            SendClientMessage(playerid, -1, "You bought a bronze roulette");
            GivePlayerDonateRub(playerid, -50);

            new string[10];
            format(string, sizeof string, "%d", player_roulette_bronz[playerid]);
            PlayerTextDrawSetString(playerid, ruletka_PTD_t[playerid][17], string);
        }
        else SendClientMessage(playerid, -1, "Bronze roulette costs 50 donate rubles.");
	}
	if(clickedid == welsirltk_TD[31])
	{
        UpdateLastPlayerRuletka(playerid);
	}
	if(clickedid == welsirltk_TD[33])
	{
        if(player_roulette_bronz[playerid])
        {
            if(timer_player_ruletka[playerid] == -1)
            {
                if(animation_player[playerid]) return SCM(playerid, -1, ""USC"Wait for the animation to finish.");
                player_roulette_bronz[playerid]--;
                UpdatePlayerDatabaseInt(playerid, "roulette_bronz", player_roulette_bronz[playerid]);

                new string[10];
                format(string, sizeof string, "%d", player_roulette_bronz[playerid]);
                PlayerTextDrawSetString(playerid, ruletka_PTD_t[playerid][17], string);

                animation_player[playerid] = true;
                timer_player_ruletka[playerid] = SetTimerEx("RunRuletka", 500, true, "d", playerid);
            }
        }
        else SendClientMessage(playerid, -1, "You don't have bronze roulettes.");
	}
	if(clickedid == welsirltk_TD[32])
	{
		if(animation_player[playerid]) return SCM(playerid, -1, ""USC"Wait for the animation to finish.");

		TogglePlayerControllable(playerid, true);
		ShowHud(playerid);
		for(new t;t < sizeof welsirltk_TD;t++)
		{
			TextDrawHideForPlayer(playerid, welsirltk_TD[t]);
		}

        PlayerTextDrawHide(playerid, ruletka_PTD_t[playerid][17]);

		for(new t;t < 5;t++)
		{
			PlayerTextDrawHide(playerid, ruletka_PTD[playerid][t]);
			PlayerTextDrawHide(playerid, ruletka_PTD_t[playerid][t]);
			menu_prize_player[playerid][t] = -1;
		}

        for(new i; i < 3;i++)
        {
            PlayerTextDrawHide(playerid, ruletka_PTD_t[playerid][last_player_td[i][0]]);
            PlayerTextDrawHide(playerid, ruletka_PTD_t[playerid][last_player_td[i][1]]);
            PlayerTextDrawHide(playerid, ruletka_PTD_t[playerid][last_player_td[i][2]]);
            PlayerTextDrawHide(playerid, ruletka_PTD_t[playerid][last_player_td[i][3]]);
        }

        CancelSelectTextDraw(playerid);
	}

	if(clickedid == casesda_TD[3])
    {
     TextDrawHideForPlayer(playerid, casesda_TD[1]);
	TextDrawHideForPlayer(playerid, casesda_TD[2]);
	TextDrawHideForPlayer(playerid, casesda_TD[9]);
	TextDrawShowForPlayer(playerid, casesda_TD[0]);

	TextDrawHideForPlayer(playerid, casesda_TD[7]);
	TextDrawSetString(casesda_TD[7], "pizda:brgiftsnugold");
	TextDrawShowForPlayer(playerid, casesda_TD[7]);

  	TextDrawHideForPlayer(playerid, casesda_TD[6]);
	TextDrawSetString(casesda_TD[6], "pizda:brgiftsnusilver");
	TextDrawShowForPlayer(playerid, casesda_TD[6]);

    TextDrawHideForPlayer(playerid, casesda_TD[5]);
	TextDrawSetString(casesda_TD[5], "pizda:brgiftsnubronza");
	TextDrawShowForPlayer(playerid, casesda_TD[5]);

	TextDrawHideForPlayer(playerid, casesda_TD[3]);
	TextDrawSetString(casesda_TD[3], "pizda:brgiftsuinfo");
	TextDrawShowForPlayer(playerid, casesda_TD[3]);

	TextDrawHideForPlayer(playerid, casesda_TD[8]);
	TextDrawSetString(casesda_TD[8], "pizda:brgiftsnuautocase");
	TextDrawShowForPlayer(playerid, casesda_TD[8]);
    SCM(playerid, -1,"DEBUG: Clickid = 3");
    }
    if(clickedid == casesda_TD[4])
    {
	TogglePlayerControllable(playerid, true);
 		for(new i; i < sizeof casesda_TD;i++)
		{
			TextDrawHideForPlayer(playerid, casesda_TD[i]);
		}
		TextDrawSetString(casesda_TD[7], "pizda:brgiftsnugold");
		TextDrawSetString(casesda_TD[8], "pizda:brgiftsnuautocase");
			TextDrawSetString(casesda_TD[6], "pizda:brgiftsnusilver");
			TextDrawSetString(casesda_TD[5], "pizda:brgiftsnubronza");
    typecase[playerid] = 0;
    SCM(playerid, -1,"DEBUG: Clickid = 4");
    }
    if(clickedid == casesda_TD[5])
    {
    typecase[playerid] = 1;
    TextDrawShowForPlayer(playerid, casesda_TD[1]);
	TextDrawShowForPlayer(playerid, casesda_TD[2]);
	TextDrawShowForPlayer(playerid, casesda_TD[9]);
	TextDrawHideForPlayer(playerid, casesda_TD[0]);

	TextDrawHideForPlayer(playerid, casesda_TD[7]);
	TextDrawSetString(casesda_TD[7], "pizda:brgiftsnugold");
	TextDrawShowForPlayer(playerid, casesda_TD[7]);

  	TextDrawHideForPlayer(playerid, casesda_TD[6]);
	TextDrawSetString(casesda_TD[6], "pizda:brgiftsnusilver");
	TextDrawShowForPlayer(playerid, casesda_TD[6]);

    TextDrawHideForPlayer(playerid, casesda_TD[5]);
	TextDrawSetString(casesda_TD[5], "pizda:brgiftsubronza");
	TextDrawShowForPlayer(playerid, casesda_TD[5]);

	TextDrawHideForPlayer(playerid, casesda_TD[3]);
	TextDrawSetString(casesda_TD[3], "pizda:brgiftsnuinfo");
	TextDrawShowForPlayer(playerid, casesda_TD[3]);

	TextDrawHideForPlayer(playerid, casesda_TD[8]);
	TextDrawSetString(casesda_TD[8], "pizda:brgiftsnuautocase");
	TextDrawShowForPlayer(playerid, casesda_TD[8]);

	TextDrawHideForPlayer(playerid, casesda_TD[2]);
	TextDrawSetString(casesda_TD[2], "75_P.");
	TextDrawShowForPlayer(playerid, casesda_TD[2]);

    SCM(playerid, -1,"DEBUG: Clickid = 5");
    }
    if(clickedid == casesda_TD[6])
    {
    TextDrawShowForPlayer(playerid, casesda_TD[1]);
	TextDrawShowForPlayer(playerid, casesda_TD[2]);
	TextDrawShowForPlayer(playerid, casesda_TD[9]);
 	TextDrawHideForPlayer(playerid, casesda_TD[0]);

   	TextDrawHideForPlayer(playerid, casesda_TD[7]);
	TextDrawSetString(casesda_TD[7], "pizda:brgiftsnugold");
	TextDrawShowForPlayer(playerid, casesda_TD[7]);

  	TextDrawHideForPlayer(playerid, casesda_TD[6]);
	TextDrawSetString(casesda_TD[6], "pizda:brgiftsusilver");
	TextDrawShowForPlayer(playerid, casesda_TD[6]);

    TextDrawHideForPlayer(playerid, casesda_TD[5]);
	TextDrawSetString(casesda_TD[5], "pizda:brgiftsnubronza");
	TextDrawShowForPlayer(playerid, casesda_TD[5]);

	TextDrawHideForPlayer(playerid, casesda_TD[3]);
	TextDrawSetString(casesda_TD[3], "pizda:brgiftsnuinfo");
	TextDrawShowForPlayer(playerid, casesda_TD[3]);

	TextDrawHideForPlayer(playerid, casesda_TD[8]);
	TextDrawSetString(casesda_TD[8], "pizda:brgiftsnuautocase");
	TextDrawShowForPlayer(playerid, casesda_TD[8]);

	TextDrawHideForPlayer(playerid, casesda_TD[2]);
	TextDrawSetString(casesda_TD[2], "250_P.");
	TextDrawShowForPlayer(playerid, casesda_TD[2]);

    typecase[playerid] = 2;
    SCM(playerid, -1,"DEBUG: Clickid = 6");
    }
    if(clickedid == casesda_TD[7])
    {
    TextDrawShowForPlayer(playerid, casesda_TD[1]);
	TextDrawShowForPlayer(playerid, casesda_TD[2]);
	TextDrawShowForPlayer(playerid, casesda_TD[9]);
 	TextDrawHideForPlayer(playerid, casesda_TD[0]);
   	TextDrawHideForPlayer(playerid, casesda_TD[7]);
	TextDrawSetString(casesda_TD[7], "pizda:brgiftsugold");
	TextDrawShowForPlayer(playerid, casesda_TD[7]);

  	TextDrawHideForPlayer(playerid, casesda_TD[6]);
	TextDrawSetString(casesda_TD[6], "pizda:brgiftsnusilver");
	TextDrawShowForPlayer(playerid, casesda_TD[6]);

    TextDrawHideForPlayer(playerid, casesda_TD[5]);
	TextDrawSetString(casesda_TD[5], "pizda:brgiftsnubronza");
	TextDrawShowForPlayer(playerid, casesda_TD[5]);

	TextDrawHideForPlayer(playerid, casesda_TD[3]);
	TextDrawSetString(casesda_TD[3], "pizda:brgiftsnuinfo");
	TextDrawShowForPlayer(playerid, casesda_TD[3]);

	TextDrawHideForPlayer(playerid, casesda_TD[8]);
	TextDrawSetString(casesda_TD[8], "pizda:brgiftsnuautocase");
	TextDrawShowForPlayer(playerid, casesda_TD[8]);

	TextDrawHideForPlayer(playerid, casesda_TD[2]);
	TextDrawSetString(casesda_TD[2], "500_P.");
	TextDrawShowForPlayer(playerid, casesda_TD[2]);

    typecase[playerid] = 3;
    SCM(playerid, -1,"DEBUG: Clickid = 7");
    }
    if(clickedid == casesda_TD[8])
    {
    TextDrawShowForPlayer(playerid, casesda_TD[1]);
	TextDrawShowForPlayer(playerid, casesda_TD[2]);
	TextDrawShowForPlayer(playerid, casesda_TD[9]);
 	TextDrawHideForPlayer(playerid, casesda_TD[0]);
   	TextDrawHideForPlayer(playerid, casesda_TD[7]);
	TextDrawSetString(casesda_TD[7], "pizda:brgiftsnugold");
	TextDrawShowForPlayer(playerid, casesda_TD[7]);

  	TextDrawHideForPlayer(playerid, casesda_TD[6]);
	TextDrawSetString(casesda_TD[6], "pizda:brgiftsnusilver");
	TextDrawShowForPlayer(playerid, casesda_TD[6]);

    TextDrawHideForPlayer(playerid, casesda_TD[5]);
	TextDrawSetString(casesda_TD[5], "pizda:brgiftsnubronza");
	TextDrawShowForPlayer(playerid, casesda_TD[5]);

	TextDrawHideForPlayer(playerid, casesda_TD[3]);
	TextDrawSetString(casesda_TD[3], "pizda:brgiftsnuinfo");
	TextDrawShowForPlayer(playerid, casesda_TD[3]);

	TextDrawHideForPlayer(playerid, casesda_TD[2]);
	TextDrawSetString(casesda_TD[2], "1000_P.");
	TextDrawShowForPlayer(playerid, casesda_TD[2]);

	TextDrawHideForPlayer(playerid, casesda_TD[8]);
	TextDrawSetString(casesda_TD[8], "pizda:brgiftsuautocase");
	TextDrawShowForPlayer(playerid, casesda_TD[8]);
    typecase[playerid] = 4 ;
    SCM(playerid, -1,"DEBUG: Clickid = 8");
    }
        if(clickedid == casesda_TD[9])
    {
	if(typecase[playerid] == 1)
	{
 		for(new i; i < sizeof casesda_TD;i++)
		{
			TextDrawHideForPlayer(playerid, casesda_TD[i]);
		}
		TextDrawSetString(casesda_TD[7], "pizda:brgiftsnugold");
		TextDrawSetString(casesda_TD[8], "pizda:brgiftsnuautocase");
			TextDrawSetString(casesda_TD[6], "pizda:brgiftsnusilver");
			TextDrawSetString(casesda_TD[5], "pizda:brgiftsnubronza");
    typecase[playerid] = 0;
	callcmd::openroulette(playerid, "");
    SCM(playerid, -1,"DEBUG: Clickid = 9");
	}
	else if(typecase[playerid] == 2)
	{
 		for(new i; i < sizeof casesda_TD;i++)
		{
			TextDrawHideForPlayer(playerid, casesda_TD[i]);
		}
		TextDrawSetString(casesda_TD[7], "pizda:brgiftsnugold");
		TextDrawSetString(casesda_TD[8], "pizda:brgiftsnuautocase");
			TextDrawSetString(casesda_TD[6], "pizda:brgiftsnusilver");
			TextDrawSetString(casesda_TD[5], "pizda:brgiftsnubronza");
    typecase[playerid] = 0;
	callcmd::openroulette_1(playerid, "");
    SCM(playerid, -1,"DEBUG: Clickid = 9");
	}
		else if(typecase[playerid] == 3)
	{
 		for(new i; i < sizeof casesda_TD;i++)
		{
			TextDrawHideForPlayer(playerid, casesda_TD[i]);
		}
		TextDrawSetString(casesda_TD[7], "pizda:brgiftsnugold");
		TextDrawSetString(casesda_TD[8], "pizda:brgiftsnuautocase");
			TextDrawSetString(casesda_TD[6], "pizda:brgiftsnusilver");
			TextDrawSetString(casesda_TD[5], "pizda:brgiftsnubronza");
    typecase[playerid] = 0;
	callcmd::openroulette_2(playerid, "");
    SCM(playerid, -1,"DEBUG: Clickid = 9");
	}
			else if(typecase[playerid] == 4)
	{
 		for(new i; i < sizeof casesda_TD;i++)
		{
			TextDrawHideForPlayer(playerid, casesda_TD[i]);
		}
		TextDrawSetString(casesda_TD[7], "pizda:brgiftsnugold");
		TextDrawSetString(casesda_TD[8], "pizda:brgiftsnuautocase");
			TextDrawSetString(casesda_TD[6], "pizda:brgiftsnusilver");
			TextDrawSetString(casesda_TD[5], "pizda:brgiftsnubronza");
    typecase[playerid] = 0;
	callcmd::openroulette3(playerid, "");
    SCM(playerid, -1,"DEBUG: Clickid = 9");
	}//roulette_1 openroulette_2 	callcmd::openroulette3(playerid, "");
    }
	#if defined roulette_OnPlayerClickTextDraw
        return roulette_OnPlayerClickTextDraw(playerid, clickedid);
    #else
        return 1;
    #endif
}
#if defined _ALS_OnPlayerClickTextDraw
    #undef OnPlayerClickTextDraw
#else
    #define _ALS_OnPlayerClickTextDraw
#endif
#define OnPlayerClickTextDraw roulette_OnPlayerClickTextDraw
#if defined roulette_OnPlayerClickTextDraw
    forward roulette_OnPlayerClickTextDraw(playerid, Text:clickedid);
#endif


stock addcarplayer(playerid, modelid, color_1, color_2, pos_x, pos_y, pos_z, angle)
{
new query[127];
new
   Cache: result;
 format
 (
  query, sizeof query,
  "INSERT INTO ownable_cars \
  (owner_id,model_id,color_1,color_2,pos_x,pos_y,pos_z,angle,create_time) \
  VALUES \
  ('%d','%d','%d','%d','%f','%f','%f','%f','%d')",
  GetPlayerAccountID(playerid),
  modelid,
  color_1,
  color_2,
  pos_x,
  pos_y,
  pos_z,
  angle,
  0
 );
 result = mysql_query(mysql, query, true);

 //SetOwnableCarData(idx, OC_SQL_ID, cache_insert_id());

 cache_delete(result);
}
stock addacs(playerid, modelid, x, y, z, rx, rz, ry, scale, slot, bone)
{
new
   Cache: result;
new query[127];
 format
 (
  query, sizeof query,
  "INSERT INTO accessories \
  (id,slot,modelid,bone,x,y,z,rX,rY,rZ,scale) \
  VALUES \
  ('%d','%d','%d','%d','%f','%f','%f','%d','%d','%d','%d')",
  GetPlayerAccountID(playerid),
  slot,
  modelid,
  bone,
  x,
  y,
  z,
  rx,
  rz,
  ry,
  scale
 );
 result = mysql_query(mysql, query, true);

 cache_delete(result);
}
stock randomexp(playerid)
{
    switch (random(6))
    {
        case 0:
        {
            new sqlMediumQuery[256],exp = 2;
            g_player[playerid][P_EXP] += exp;
            mysql_format(
    mysql, sqlMediumQuery, sizeof(sqlMediumQuery),
    "SELECT exp FROM `accounts` WHERE `exp` = '%d'",
    g_player[playerid][P_EXP]
);
        }
               case 1:
        {
            new sqlMediumQuery[256],exp = 10;
g_player[playerid][P_EXP] += exp;
            mysql_format(
    mysql, sqlMediumQuery, sizeof(sqlMediumQuery),
    "SELECT exp FROM `accounts` WHERE `exp` = '%d'",
    g_player[playerid][P_EXP]
);
        }
               case 2:
        {
            new sqlMediumQuery[256],exp = 7;
            g_player[playerid][P_EXP] += exp;
            mysql_format(
    mysql, sqlMediumQuery, sizeof(sqlMediumQuery),
    "SELECT exp FROM `accounts` WHERE `exp` = '%d'",
    g_player[playerid][P_EXP]
);
        }
               case 3:
        {
            new sqlMediumQuery[256],exp = 5;
            g_player[playerid][P_EXP] += exp;
            mysql_format(
    mysql, sqlMediumQuery, sizeof(sqlMediumQuery),
    "SELECT exp FROM `accounts` WHERE `exp` = '%d'",
    g_player[playerid][P_EXP]
);
        }
               case 4:
        {
            new sqlMediumQuery[256],exp = 8;
            g_player[playerid][P_EXP] += exp;
            mysql_format(
    mysql, sqlMediumQuery, sizeof(sqlMediumQuery),
    "SELECT exp FROM `accounts` WHERE `exp` = '%d'",
    g_player[playerid][P_EXP]
);
        }
                       case 5:
        {
            new sqlMediumQuery[127],exp = 9;
g_player[playerid][P_EXP] += exp;
            mysql_format(
    mysql, sqlMediumQuery, sizeof(sqlMediumQuery),
    "SELECT exp FROM `accounts` WHERE `exp` = '%d'",
    g_player[playerid][P_EXP]
);
        }

    }
    return 1;
}
stock randommoney(playerid)
{
    switch (random(6))
    {
        case 0:
        {
            GivePlayerMoneyEx(playerid, 60000);
        }
               case 1:
        {
            GivePlayerMoneyEx(playerid, 70000);
        }
               case 2:
        {
                GivePlayerMoneyEx(playerid, 80000);
        }
               case 3:
        {
                GivePlayerMoneyEx(playerid, 30000);
        }
               case 4:
        {
                GivePlayerMoneyEx(playerid, 100000);
        }
                       case 5:
        {
            GivePlayerMoneyEx(playerid, 50000);
        }

    }
    return 1;
}
stock givedonate(playerid, donate)
{
    new sqlMediumQuery[127];
g_player[playerid][P_DONATE] += donate;
mysql_format(
    mysql, sqlMediumQuery, sizeof(sqlMediumQuery),
    "SELECT donate FROM `accounts` WHERE `donate` = '%d'",
    g_player[playerid][P_DONATE]
);
}

cmd:casedonate(playerid)
{
for(new i; i < sizeof casesda_TD;i++)
{
TextDrawShowForPlayer(playerid, casesda_TD[i]);
TextDrawHideForPlayer(playerid, casesda_TD[1]);
TextDrawHideForPlayer(playerid, casesda_TD[2]);
TextDrawHideForPlayer(playerid, casesda_TD[9]);
}
TextDrawHideForPlayer(playerid, casesda_TD[3]);
TextDrawSetString(casesda_TD[3], "pizda:brgiftsuinfo");
TextDrawShowForPlayer(playerid, casesda_TD[3]);
SelectTextDraw(playerid, 0x009900FF);
}
CMD:openroulette(playerid)
{
	TogglePlayerControllable(playerid, false);
	HideHud(playerid);
	RuletkaPlayer(playerid);
    SelectTextDraw(playerid, -1);
	for(new i;i < 20;i++) SendClientMessage(playerid, -1, "");

	for(new t;t < sizeof welsirltk_TD;t++)
	{
		TextDrawShowForPlayer(playerid, welsirltk_TD[t]);
	}

	for(new t,welsi;t < 5;t++, welsi = random(12))
	{
		PlayerTextDrawSetString(playerid, ruletka_PTD[playerid][t], ruletka_prize[welsi][R_NAME_TXD]);
		PlayerTextDrawSetString(playerid, ruletka_PTD_t[playerid][t], ruletka_prize[welsi][R_NAME_TEXT]);
		PlayerTextDrawShow(playerid, ruletka_PTD[playerid][t]);
		PlayerTextDrawShow(playerid, ruletka_PTD_t[playerid][t]);
		menu_prize_player[playerid][t] = welsi;
	}

    UpdateLastPlayerRuletka(playerid);

    for(new i; i < 3;i++)
    {
        PlayerTextDrawShow(playerid, ruletka_PTD_t[playerid][last_player_td[i][0]]);
        PlayerTextDrawShow(playerid, ruletka_PTD_t[playerid][last_player_td[i][1]]);
        PlayerTextDrawShow(playerid, ruletka_PTD_t[playerid][last_player_td[i][2]]);
        PlayerTextDrawShow(playerid, ruletka_PTD_t[playerid][last_player_td[i][3]]);
    }

    new string[10];
    format(string, sizeof string, "%d", player_roulette_bronz[playerid]);
    PlayerTextDrawSetString(playerid, ruletka_PTD_t[playerid][17], string);

    PlayerTextDrawShow(playerid, ruletka_PTD_t[playerid][17]);
    return 1;
}
stock RuletkaMenu()
{
    welsirltk_TD[0] = TextDrawCreate(3.6665, 208.3332, "txd:brgiftsdownpanel"); // empty
    TextDrawTextSize(welsirltk_TD[0], 624.0000, 209.0000);
    TextDrawAlignment(welsirltk_TD[0], 1);
    TextDrawColor(welsirltk_TD[0], -1);
    TextDrawBackgroundColor(welsirltk_TD[0], 255);
    TextDrawFont(welsirltk_TD[0], 4);
    TextDrawSetProportional(welsirltk_TD[0], 0);
    TextDrawSetShadow(welsirltk_TD[0], 0);

    welsirltk_TD[1] = TextDrawCreate(47.2378, 11.6280, "txd:brgiftsbgspin"); // empty
    TextDrawTextSize(welsirltk_TD[1], 530.0000, 49.0000);
    TextDrawAlignment(welsirltk_TD[1], 1);
    TextDrawColor(welsirltk_TD[1], -1);
    TextDrawBackgroundColor(welsirltk_TD[1], 255);
    TextDrawFont(welsirltk_TD[1], 4);
    TextDrawSetProportional(welsirltk_TD[1], 0);
    TextDrawSetShadow(welsirltk_TD[1], 0);
    TextDrawSetSelectable(welsirltk_TD[1], true);

    welsirltk_TD[2] = TextDrawCreate(255.0950, 167.3733, "txd:brgiftsdostupno"); // empty
    TextDrawTextSize(welsirltk_TD[2], 87.0000, 27.0000);
    TextDrawAlignment(welsirltk_TD[2], 1);
    TextDrawColor(welsirltk_TD[2], -1);
    TextDrawBackgroundColor(welsirltk_TD[2], 255);
    TextDrawFont(welsirltk_TD[2], 4);
    TextDrawSetProportional(welsirltk_TD[2], 0);
    TextDrawSetShadow(welsirltk_TD[2], 0);

    welsirltk_TD[4] = TextDrawCreate(114.1427, 66.2651, "txd:brgiftsbuycase"); // empty
    TextDrawTextSize(welsirltk_TD[4], 105.0000, 70.0000);
    TextDrawAlignment(welsirltk_TD[4], 1);
    TextDrawColor(welsirltk_TD[4], -1);
    TextDrawBackgroundColor(welsirltk_TD[4], 255);
    TextDrawFont(welsirltk_TD[4], 4);
    TextDrawSetProportional(welsirltk_TD[4], 0);
    TextDrawSetShadow(welsirltk_TD[4], 0);
    TextDrawSetSelectable(welsirltk_TD[4], true);

    welsirltk_TD[5] = TextDrawCreate(553.9045, 366.4369, "txd:brgiftscash"); // empty
    TextDrawTextSize(welsirltk_TD[5], 70.0000, 44.0000);
    TextDrawAlignment(welsirltk_TD[5], 1);
    TextDrawColor(welsirltk_TD[5], -1);
    TextDrawBackgroundColor(welsirltk_TD[5], 255);
    TextDrawFont(welsirltk_TD[5], 4);
    TextDrawSetProportional(welsirltk_TD[5], 0);
    TextDrawSetShadow(welsirltk_TD[5], 0);

    welsirltk_TD[6] = TextDrawCreate(586.6188, 399.6828, "Up_to_100000_p."); // empty
    TextDrawLetterSize(welsirltk_TD[6], 0.1946, 0.7720);
    TextDrawTextSize(welsirltk_TD[6], 0.0000, -24.0000);
    TextDrawAlignment(welsirltk_TD[6], 2);
    TextDrawColor(welsirltk_TD[6], -1);
    TextDrawBackgroundColor(welsirltk_TD[6], 255);
    TextDrawFont(welsirltk_TD[6], 1);
    TextDrawSetProportional(welsirltk_TD[6], 1);
    TextDrawSetShadow(welsirltk_TD[6], 0);

    welsirltk_TD[7] = TextDrawCreate(196.6666, 288.5704, "txd:brgiftbronzatext"); // empty
    TextDrawTextSize(welsirltk_TD[7], 171.0000, 202.0000);
    TextDrawAlignment(welsirltk_TD[7], 1);
    TextDrawColor(welsirltk_TD[7], -1);
    TextDrawBackgroundColor(welsirltk_TD[7], 255);
    TextDrawFont(welsirltk_TD[7], 4);
    TextDrawSetProportional(welsirltk_TD[7], 0);
    TextDrawSetShadow(welsirltk_TD[7], 0);

    welsirltk_TD[8] = TextDrawCreate(239.3332, 219.0370, "BRONZE"); // empty
    TextDrawLetterSize(welsirltk_TD[8], 0.3193, 1.7368);
    TextDrawTextSize(welsirltk_TD[8], -6.0000, 0.0000);
    TextDrawAlignment(welsirltk_TD[8], 1);
    TextDrawColor(welsirltk_TD[8], -1);
    TextDrawBackgroundColor(welsirltk_TD[8], 255);
    TextDrawFont(welsirltk_TD[8], 2);
    TextDrawSetProportional(welsirltk_TD[8], 1);
    TextDrawSetShadow(welsirltk_TD[8], 0);

    welsirltk_TD[9] = TextDrawCreate(399.5713, 366.8517, "txd:brgiftscash"); // empty
    TextDrawTextSize(welsirltk_TD[9], 70.0000, 44.0000);
    TextDrawAlignment(welsirltk_TD[9], 1);
    TextDrawColor(welsirltk_TD[9], -1);
    TextDrawBackgroundColor(welsirltk_TD[9], 255);
    TextDrawFont(welsirltk_TD[9], 4);
    TextDrawSetProportional(welsirltk_TD[9], 0);
    TextDrawSetShadow(welsirltk_TD[9], 0);

    welsirltk_TD[10] = TextDrawCreate(433.2857, 400.5124, "Up_to_100000_p."); // empty
    TextDrawLetterSize(welsirltk_TD[10], 0.1946, 0.7720);
    TextDrawTextSize(welsirltk_TD[10], 0.0000, -24.0000);
    TextDrawAlignment(welsirltk_TD[10], 2);
    TextDrawColor(welsirltk_TD[10], -1);
    TextDrawBackgroundColor(welsirltk_TD[10], 255);
    TextDrawFont(welsirltk_TD[10], 1);
    TextDrawSetProportional(welsirltk_TD[10], 1);
    TextDrawSetShadow(welsirltk_TD[10], 0);

    welsirltk_TD[11] = TextDrawCreate(476.2379, 366.4370, "txd:brgiftscash"); // empty
    TextDrawTextSize(welsirltk_TD[11], 70.0000, 44.0000);
    TextDrawAlignment(welsirltk_TD[11], 1);
    TextDrawColor(welsirltk_TD[11], -1);
    TextDrawBackgroundColor(welsirltk_TD[11], 255);
    TextDrawFont(welsirltk_TD[11], 4);
    TextDrawSetProportional(welsirltk_TD[11], 0);
    TextDrawSetShadow(welsirltk_TD[11], 0);

    welsirltk_TD[12] = TextDrawCreate(509.6188, 400.5125, "Up_to_100000_p."); // empty
    TextDrawLetterSize(welsirltk_TD[12], 0.1946, 0.7720);
    TextDrawTextSize(welsirltk_TD[12], 0.0000, -24.0000);
    TextDrawAlignment(welsirltk_TD[12], 2);
    TextDrawColor(welsirltk_TD[12], -1);
    TextDrawBackgroundColor(welsirltk_TD[12], 255);
    TextDrawFont(welsirltk_TD[12], 1);
    TextDrawSetProportional(welsirltk_TD[12], 1);
    TextDrawSetShadow(welsirltk_TD[12], 0);

    welsirltk_TD[13] = TextDrawCreate(551.9046, 213.7850, "txd:brgiftscash"); // empty
    TextDrawTextSize(welsirltk_TD[13], 70.0000, 44.0000);
    TextDrawAlignment(welsirltk_TD[13], 1);
    TextDrawColor(welsirltk_TD[13], -1);
    TextDrawBackgroundColor(welsirltk_TD[13], 255);
    TextDrawFont(welsirltk_TD[13], 4);
    TextDrawSetProportional(welsirltk_TD[13], 0);
    TextDrawSetShadow(welsirltk_TD[13], 0);

    welsirltk_TD[14] = TextDrawCreate(585.9521, 247.4457, "Up_to_100000_p."); // empty
    TextDrawLetterSize(welsirltk_TD[14], 0.1946, 0.7720);
    TextDrawTextSize(welsirltk_TD[14], 0.0000, -24.0000);
    TextDrawAlignment(welsirltk_TD[14], 2);
    TextDrawColor(welsirltk_TD[14], -1);
    TextDrawBackgroundColor(welsirltk_TD[14], 255);
    TextDrawFont(welsirltk_TD[14], 1);
    TextDrawSetProportional(welsirltk_TD[14], 1);
    TextDrawSetShadow(welsirltk_TD[14], 0);

    welsirltk_TD[15] = TextDrawCreate(399.2380, 214.1998, "txd:brgiftscash"); // empty
    TextDrawTextSize(welsirltk_TD[15], 70.0000, 44.0000);
    TextDrawAlignment(welsirltk_TD[15], 1);
    TextDrawColor(welsirltk_TD[15], -1);
    TextDrawBackgroundColor(welsirltk_TD[15], 255);
    TextDrawFont(welsirltk_TD[15], 4);
    TextDrawSetProportional(welsirltk_TD[15], 0);
    TextDrawSetShadow(welsirltk_TD[15], 0);

    welsirltk_TD[16] = TextDrawCreate(432.9524, 247.8605, "Up_to_100000_p."); // empty

    TextDrawLetterSize(welsirltk_TD[16], 0.1946, 0.7720);
    TextDrawTextSize(welsirltk_TD[16], 0.0000, -24.0000);
    TextDrawAlignment(welsirltk_TD[16], 2);
    TextDrawColor(welsirltk_TD[16], -1);
    TextDrawBackgroundColor(welsirltk_TD[16], 255);
    TextDrawFont(welsirltk_TD[16], 1);
    TextDrawSetProportional(welsirltk_TD[16], 1);
    TextDrawSetShadow(welsirltk_TD[16], 0);

    welsirltk_TD[17] = TextDrawCreate(475.9046, 213.7850, "txd:brgiftscash"); // empty
    TextDrawTextSize(welsirltk_TD[17], 70.0000, 44.0000);
    TextDrawAlignment(welsirltk_TD[17], 1);
    TextDrawColor(welsirltk_TD[17], -1);
    TextDrawBackgroundColor(welsirltk_TD[17], 255);
    TextDrawFont(welsirltk_TD[17], 4);
    TextDrawSetProportional(welsirltk_TD[17], 0);
    TextDrawSetShadow(welsirltk_TD[17], 0);

    welsirltk_TD[34] = TextDrawCreate(580.9998, 2.0888, ""); // empty
    welsirltk_TD[18] = TextDrawCreate(509.2855, 247.8606, "Up_to_100000_p."); // empty
    TextDrawLetterSize(welsirltk_TD[18], 0.1946, 0.7720);
    TextDrawTextSize(welsirltk_TD[18], 0.0000, -24.0000);
    TextDrawAlignment(welsirltk_TD[18], 2);
    TextDrawColor(welsirltk_TD[18], -1);
    TextDrawBackgroundColor(welsirltk_TD[18], 255);
    TextDrawFont(welsirltk_TD[18], 1);
    TextDrawSetProportional(welsirltk_TD[18], 1);
    TextDrawSetShadow(welsirltk_TD[18], 0);

    TextDrawLetterSize(welsirltk_TD[34], 0.1480, 0.8740);
    TextDrawTextSize(welsirltk_TD[34], -101.0000, 0.0000);
    TextDrawAlignment(welsirltk_TD[34], 1);
    TextDrawColor(welsirltk_TD[34], -81);
    TextDrawBackgroundColor(welsirltk_TD[34], 255);
    TextDrawFont(welsirltk_TD[34], 1);
    TextDrawSetProportional(welsirltk_TD[34], 1);
    TextDrawSetShadow(welsirltk_TD[34], 0);

    welsirltk_TD[21] = TextDrawCreate(398.9046, 265.2220, "txd:brgiftscash"); // empty
    TextDrawTextSize(welsirltk_TD[21], 70.0000, 44.0000);
    TextDrawAlignment(welsirltk_TD[21], 1);
    TextDrawColor(welsirltk_TD[21], -1);
    TextDrawBackgroundColor(welsirltk_TD[21], 255);
    TextDrawFont(welsirltk_TD[21], 4);
    TextDrawSetProportional(welsirltk_TD[21], 0);
    TextDrawSetShadow(welsirltk_TD[21], 0);

    welsirltk_TD[22] = TextDrawCreate(432.6191, 298.8827, "Up_to_100000_p."); // empty
    TextDrawLetterSize(welsirltk_TD[22], 0.1946, 0.7720);
    TextDrawTextSize(welsirltk_TD[22], 0.0000, -24.0000);
    TextDrawAlignment(welsirltk_TD[22], 2);
    TextDrawColor(welsirltk_TD[22], -1);
    TextDrawBackgroundColor(welsirltk_TD[22], 255);
    TextDrawFont(welsirltk_TD[22], 1);
    TextDrawSetProportional(welsirltk_TD[22], 1);
    TextDrawSetShadow(welsirltk_TD[22], 0);

    welsirltk_TD[23] = TextDrawCreate(475.5713, 264.8073, "txd:brgiftscash"); // empty
    TextDrawTextSize(welsirltk_TD[23], 70.0000, 44.0000);
    TextDrawAlignment(welsirltk_TD[23], 1);
    TextDrawColor(welsirltk_TD[23], -1);
    TextDrawBackgroundColor(welsirltk_TD[23], 255);
    TextDrawFont(welsirltk_TD[23], 4);
    TextDrawSetProportional(welsirltk_TD[23], 0);
    TextDrawSetShadow(welsirltk_TD[23], 0);

    welsirltk_TD[24] = TextDrawCreate(508.9522, 298.8828, "Up_to_100000_p."); // empty
    TextDrawLetterSize(welsirltk_TD[24], 0.1946, 0.7720);
    TextDrawTextSize(welsirltk_TD[24], 0.0000, -24.0000);
    TextDrawAlignment(welsirltk_TD[24], 2);
    TextDrawColor(welsirltk_TD[24], -1);
    TextDrawBackgroundColor(welsirltk_TD[24], 255);
    TextDrawFont(welsirltk_TD[24], 1);
    TextDrawSetProportional(welsirltk_TD[24], 1);
    TextDrawSetShadow(welsirltk_TD[24], 0);

    welsirltk_TD[25] = TextDrawCreate(552.2379, 315.4146, "txd:brgiftscash"); // empty
    TextDrawTextSize(welsirltk_TD[25], 70.0000, 44.0000);
    TextDrawAlignment(welsirltk_TD[25], 1);
    TextDrawColor(welsirltk_TD[25], -1);
    TextDrawBackgroundColor(welsirltk_TD[25], 255);
    TextDrawFont(welsirltk_TD[25], 4);
    TextDrawSetProportional(welsirltk_TD[25], 0);
    TextDrawSetShadow(welsirltk_TD[25], 0);

    welsirltk_TD[26] = TextDrawCreate(586.2855, 349.0754, "Up_to_100000_p."); // empty
    TextDrawLetterSize(welsirltk_TD[26], 0.1946, 0.7720);
    TextDrawTextSize(welsirltk_TD[26], 0.0000, -24.0000);
    TextDrawAlignment(welsirltk_TD[26], 2);
    TextDrawColor(welsirltk_TD[26], -1);
    TextDrawBackgroundColor(welsirltk_TD[26], 255);
    TextDrawFont(welsirltk_TD[26], 1);
    TextDrawSetProportional(welsirltk_TD[26], 1);
    TextDrawSetShadow(welsirltk_TD[26], 0);

    welsirltk_TD[27] = TextDrawCreate(399.5713, 315.8294, "txd:brgiftscash"); // empty
    TextDrawTextSize(welsirltk_TD[27], 70.0000, 44.0000);
    TextDrawAlignment(welsirltk_TD[27], 1);
    TextDrawColor(welsirltk_TD[27], -1);
    TextDrawBackgroundColor(welsirltk_TD[27], 255);
    TextDrawFont(welsirltk_TD[27], 4);
    TextDrawSetProportional(welsirltk_TD[27], 0);
    TextDrawSetShadow(welsirltk_TD[27], 0);

    welsirltk_TD[28] = TextDrawCreate(433.2857, 349.4902, "Up_to_100000_p."); // empty
    TextDrawLetterSize(welsirltk_TD[28], 0.1946, 0.7720);
    TextDrawTextSize(welsirltk_TD[28], 0.0000, -24.0000);
    TextDrawAlignment(welsirltk_TD[28], 2);
    TextDrawColor(welsirltk_TD[28], -1);
    TextDrawBackgroundColor(welsirltk_TD[28], 255);
    TextDrawFont(welsirltk_TD[28], 1);
    TextDrawSetProportional(welsirltk_TD[28], 1);
    TextDrawSetShadow(welsirltk_TD[28], 0);

    welsirltk_TD[29] = TextDrawCreate(476.2379, 315.4147, "txd:brgiftscash"); // empty
    TextDrawTextSize(welsirltk_TD[29], 70.0000, 44.0000);
    TextDrawAlignment(welsirltk_TD[29], 1);
    TextDrawColor(welsirltk_TD[29], -1);
    TextDrawBackgroundColor(welsirltk_TD[29], 255);
    TextDrawFont(welsirltk_TD[29], 4);
    TextDrawSetProportional(welsirltk_TD[29], 0);
    TextDrawSetShadow(welsirltk_TD[29], 0);

    welsirltk_TD[30] = TextDrawCreate(509.6188, 349.4902, "Up_to_100000_p."); // empty
    TextDrawLetterSize(welsirltk_TD[30], 0.1946, 0.7720);
    TextDrawTextSize(welsirltk_TD[30], 0.0000, -24.0000);
    TextDrawAlignment(welsirltk_TD[30], 2);
    TextDrawColor(welsirltk_TD[30], -1);
    TextDrawBackgroundColor(welsirltk_TD[30], 255);
    TextDrawFont(welsirltk_TD[30], 1);
    TextDrawSetProportional(welsirltk_TD[30], 1);
    TextDrawSetShadow(welsirltk_TD[30], 0);

    welsirltk_TD[31] = TextDrawCreate(27.5713, 143.9302, "txd:brgiftsupdate"); // empty
    TextDrawTextSize(welsirltk_TD[31], 126.0000, 74.0000);
    TextDrawAlignment(welsirltk_TD[31], 1);
    TextDrawColor(welsirltk_TD[31], -1);
    TextDrawBackgroundColor(welsirltk_TD[31], 255);
    TextDrawFont(welsirltk_TD[31], 4);
    TextDrawSetProportional(welsirltk_TD[31], 0);
    TextDrawSetShadow(welsirltk_TD[31], 0);
    TextDrawSetSelectable(welsirltk_TD[31], true);

    welsirltk_TD[32] = TextDrawCreate(528.2379, 159.6932, "ruletka:brgiftsexit"); // empty
    TextDrawTextSize(welsirltk_TD[32], 91.0000, 56.0000);
    TextDrawAlignment(welsirltk_TD[32], 1);
    TextDrawColor(welsirltk_TD[32], -1);
    TextDrawBackgroundColor(welsirltk_TD[32], 255);
    TextDrawFont(welsirltk_TD[32], 4);
    TextDrawSetProportional(welsirltk_TD[32], 0);
    TextDrawSetShadow(welsirltk_TD[32], 0);
    TextDrawSetSelectable(welsirltk_TD[32], true);

    welsirltk_TD[33] = TextDrawCreate(259.6665, 68.3864, "ruletka:brgiftsspin"); // empty
    TextDrawTextSize(welsirltk_TD[33], 110.0000, 66.0000);
    TextDrawAlignment(welsirltk_TD[33], 1);
    TextDrawColor(welsirltk_TD[33], -1);
    TextDrawBackgroundColor(welsirltk_TD[33], 255);
    TextDrawFont(welsirltk_TD[33], 4);
    TextDrawSetProportional(welsirltk_TD[33], 0);
    TextDrawSetShadow(welsirltk_TD[33], 0);
    TextDrawSetSelectable(welsirltk_TD[33], true);
}

stock RuletkaPlayer(playerid)
{
	ruletka_PTD[playerid][0] = CreatePlayerTextDraw(playerid, 430.2377, 13.7539, "txd:brgiftslic"); // empty
	PlayerTextDrawTextSize(playerid, ruletka_PTD[playerid][0], 70.0000, 44.0000);
	PlayerTextDrawAlignment(playerid, ruletka_PTD[playerid][0], 1);
	PlayerTextDrawColor(playerid, ruletka_PTD[playerid][0], -1);
	PlayerTextDrawBackgroundColor(playerid, ruletka_PTD[playerid][0], 255);
	PlayerTextDrawFont(playerid, ruletka_PTD[playerid][0], 4);
	PlayerTextDrawSetProportional(playerid, ruletka_PTD[playerid][0], 0);
	PlayerTextDrawSetShadow(playerid, ruletka_PTD[playerid][0], 0);

	ruletka_PTD[playerid][1] = CreatePlayerTextDraw(playerid, 352.6664, 13.7340, "txd:brgiftsuncar"); // empty
	PlayerTextDrawTextSize(playerid, ruletka_PTD[playerid][1], 70.0000, 44.0000);
	PlayerTextDrawAlignment(playerid, ruletka_PTD[playerid][1], 1);
	PlayerTextDrawColor(playerid, ruletka_PTD[playerid][1], -1);
	PlayerTextDrawBackgroundColor(playerid, ruletka_PTD[playerid][1], 255);
	PlayerTextDrawFont(playerid, ruletka_PTD[playerid][1], 4);
	PlayerTextDrawSetProportional(playerid, ruletka_PTD[playerid][1], 0);
	PlayerTextDrawSetShadow(playerid, ruletka_PTD[playerid][1], 0);

	ruletka_PTD[playerid][2] = CreatePlayerTextDraw(playerid, 276.3807, 14.9784, "txd:brgiftsgvip"); // empty
	PlayerTextDrawTextSize(playerid, ruletka_PTD[playerid][2], 70.0000, 44.0000);
	PlayerTextDrawAlignment(playerid, ruletka_PTD[playerid][2], 1);
	PlayerTextDrawColor(playerid, ruletka_PTD[playerid][2], -1);
	PlayerTextDrawBackgroundColor(playerid, ruletka_PTD[playerid][2], 255);
	PlayerTextDrawFont(playerid, ruletka_PTD[playerid][2], 4);
	PlayerTextDrawSetProportional(playerid, ruletka_PTD[playerid][2], 0);
	PlayerTextDrawSetShadow(playerid, ruletka_PTD[playerid][2], 0);

	ruletka_PTD[playerid][4] = CreatePlayerTextDraw(playerid, 123.9045, 14.6739, "txd:brgiftscash"); // empty
	PlayerTextDrawTextSize(playerid, ruletka_PTD[playerid][4], 70.0000, 44.0000);
	PlayerTextDrawAlignment(playerid, ruletka_PTD[playerid][4], 1);
	PlayerTextDrawColor(playerid, ruletka_PTD[playerid][4], -1);
	PlayerTextDrawBackgroundColor(playerid, ruletka_PTD[playerid][4], 255);
	PlayerTextDrawFont(playerid, ruletka_PTD[playerid][4], 4);
	PlayerTextDrawSetProportional(playerid, ruletka_PTD[playerid][4], 0);
	PlayerTextDrawSetShadow(playerid, ruletka_PTD[playerid][4], 0);

	ruletka_PTD[playerid][3] = CreatePlayerTextDraw(playerid, 200.4284, 15.0650, "txd:brgiftsgun"); // empty
	PlayerTextDrawTextSize(playerid, ruletka_PTD[playerid][3], 70.0000, 44.0000);
	PlayerTextDrawAlignment(playerid, ruletka_PTD[playerid][3], 1);
	PlayerTextDrawColor(playerid, ruletka_PTD[playerid][3], -1);
	PlayerTextDrawBackgroundColor(playerid, ruletka_PTD[playerid][3], 255);
	PlayerTextDrawFont(playerid, ruletka_PTD[playerid][3], 4);
	PlayerTextDrawSetProportional(playerid, ruletka_PTD[playerid][3], 0);
	PlayerTextDrawSetShadow(playerid, ruletka_PTD[playerid][3], 0);

	ruletka_PTD_t[playerid][1] = CreatePlayerTextDraw(playerid, 389.3807, 44.9925, "BMW_M5_F90"); // empty
	PlayerTextDrawLetterSize(playerid, ruletka_PTD_t[playerid][1] , 0.1946, 0.7720);
	PlayerTextDrawTextSize(playerid, ruletka_PTD_t[playerid][1] , 0.0000, -24.0000);
	PlayerTextDrawAlignment(playerid, ruletka_PTD_t[playerid][1] , 2);
	PlayerTextDrawColor(playerid, ruletka_PTD_t[playerid][1] , -1);
	PlayerTextDrawBackgroundColor(playerid, ruletka_PTD_t[playerid][1] , 255);
	PlayerTextDrawFont(playerid, ruletka_PTD_t[playerid][1] , 1);
	PlayerTextDrawSetProportional(playerid, ruletka_PTD_t[playerid][1] , 1);
	PlayerTextDrawSetShadow(playerid, ruletka_PTD_t[playerid][1] , 0);

	ruletka_PTD_t[playerid][2]  = CreatePlayerTextDraw(playerid, 311.8570, 46.6399, "Gold-Vip"); // empty
	PlayerTextDrawLetterSize(playerid, ruletka_PTD_t[playerid][2] , 0.1946, 0.7720);
	PlayerTextDrawTextSize(playerid, ruletka_PTD_t[playerid][2] , 0.0000, -24.0000);
	PlayerTextDrawAlignment(playerid, ruletka_PTD_t[playerid][2] , 2);
	PlayerTextDrawColor(playerid, ruletka_PTD_t[playerid][2] , -1);
	PlayerTextDrawBackgroundColor(playerid, ruletka_PTD_t[playerid][2] , 255);
	PlayerTextDrawFont(playerid, ruletka_PTD_t[playerid][2] , 1);
	PlayerTextDrawSetProportional(playerid, ruletka_PTD_t[playerid][2] , 1);
	PlayerTextDrawSetShadow(playerid, ruletka_PTD_t[playerid][2] , 0);

	ruletka_PTD_t[playerid][3]  = CreatePlayerTextDraw(playerid, 235.2379, 47.0784, "Random weapon"); // empty
	PlayerTextDrawLetterSize(playerid, ruletka_PTD_t[playerid][3] , 0.1946, 0.7720);
	PlayerTextDrawTextSize(playerid, ruletka_PTD_t[playerid][3] , 0.0000, -24.0000);
	PlayerTextDrawAlignment(playerid, ruletka_PTD_t[playerid][3] , 2);
	PlayerTextDrawColor(playerid, ruletka_PTD_t[playerid][3] , -1);
	PlayerTextDrawBackgroundColor(playerid, ruletka_PTD_t[playerid][3] , 255);
	PlayerTextDrawFont(playerid, ruletka_PTD_t[playerid][3] , 1);
	PlayerTextDrawSetProportional(playerid, ruletka_PTD_t[playerid][3] , 1);
	PlayerTextDrawSetShadow(playerid, ruletka_PTD_t[playerid][3] , 0);

	ruletka_PTD_t[playerid][4]  = CreatePlayerTextDraw(playerid, 157.2856, 48.3346, "up to 100000 rub."); // empty
	PlayerTextDrawLetterSize(playerid, ruletka_PTD_t[playerid][4] , 0.1946, 0.7720);
	PlayerTextDrawTextSize(playerid, ruletka_PTD_t[playerid][4] , 0.0000, -24.0000);
	PlayerTextDrawAlignment(playerid, ruletka_PTD_t[playerid][4] , 2);
	PlayerTextDrawColor(playerid, ruletka_PTD_t[playerid][4] , -1);
	PlayerTextDrawBackgroundColor(playerid, ruletka_PTD_t[playerid][4] , 255);
	PlayerTextDrawFont(playerid, ruletka_PTD_t[playerid][4] , 1);
	PlayerTextDrawSetProportional(playerid, ruletka_PTD_t[playerid][4] , 1);
	PlayerTextDrawSetShadow(playerid, ruletka_PTD_t[playerid][4] , 0);

	ruletka_PTD_t[playerid][0]  = CreatePlayerTextDraw(playerid, 466.8570, 45.8340, "License package"); // empty
	PlayerTextDrawLetterSize(playerid, ruletka_PTD_t[playerid][0] , 0.1946, 0.7720);
	PlayerTextDrawTextSize(playerid, ruletka_PTD_t[playerid][0] , 0.0000, -24.0000);
	PlayerTextDrawAlignment(playerid, ruletka_PTD_t[playerid][0] , 2);
	PlayerTextDrawColor(playerid, ruletka_PTD_t[playerid][0] , -1);
	PlayerTextDrawBackgroundColor(playerid, ruletka_PTD_t[playerid][0] , 255);
	PlayerTextDrawFont(playerid, ruletka_PTD_t[playerid][0] , 1);
	PlayerTextDrawSetProportional(playerid, ruletka_PTD_t[playerid][0] , 1);
	PlayerTextDrawSetShadow(playerid, ruletka_PTD_t[playerid][0] , 0);

    ruletka_PTD_t[playerid][5] = CreatePlayerTextDraw(playerid, 11.6664, 358.4451, "txd:brgiftsuncar"); // empty
    PlayerTextDrawTextSize(playerid, ruletka_PTD_t[playerid][5], 70.0000, 44.0000);
    PlayerTextDrawAlignment(playerid, ruletka_PTD_t[playerid][5], 1);
    PlayerTextDrawColor(playerid, ruletka_PTD_t[playerid][5], -1);
    PlayerTextDrawBackgroundColor(playerid, ruletka_PTD_t[playerid][5], 255);
    PlayerTextDrawFont(playerid, ruletka_PTD_t[playerid][5], 4);
    PlayerTextDrawSetProportional(playerid, ruletka_PTD_t[playerid][5], 0);
    PlayerTextDrawSetShadow(playerid, ruletka_PTD_t[playerid][5], 0);

    ruletka_PTD_t[playerid][6] = CreatePlayerTextDraw(playerid, 99.6666, 361.7334, "Welsi_Developer"); // empty
    PlayerTextDrawLetterSize(playerid, ruletka_PTD_t[playerid][6], 0.2506, 1.2391);
    PlayerTextDrawTextSize(playerid, ruletka_PTD_t[playerid][6], -9.0000, 0.0000);
    PlayerTextDrawAlignment(playerid, ruletka_PTD_t[playerid][6], 1);
    PlayerTextDrawColor(playerid, ruletka_PTD_t[playerid][6], -1);
    PlayerTextDrawBackgroundColor(playerid, ruletka_PTD_t[playerid][6], 255);
    PlayerTextDrawFont(playerid, ruletka_PTD_t[playerid][6], 1);
    PlayerTextDrawSetProportional(playerid, ruletka_PTD_t[playerid][6], 1);
    PlayerTextDrawSetShadow(playerid, ruletka_PTD_t[playerid][6], 0);

    ruletka_PTD_t[playerid][7] = CreatePlayerTextDraw(playerid, 47.7141, 388.8739, "BMW_M5_F90"); // empty
    PlayerTextDrawLetterSize(playerid, ruletka_PTD_t[playerid][7], 0.1946, 0.7720);
    PlayerTextDrawTextSize(playerid, ruletka_PTD_t[playerid][7], 0.0000, -24.0000);
    PlayerTextDrawAlignment(playerid, ruletka_PTD_t[playerid][7], 2);
    PlayerTextDrawColor(playerid, ruletka_PTD_t[playerid][7], -1);
    PlayerTextDrawBackgroundColor(playerid, ruletka_PTD_t[playerid][7], 255);
    PlayerTextDrawFont(playerid, ruletka_PTD_t[playerid][7], 1);
    PlayerTextDrawSetProportional(playerid, ruletka_PTD_t[playerid][7], 1);
    PlayerTextDrawSetShadow(playerid, ruletka_PTD_t[playerid][7], 0);

    ruletka_PTD_t[playerid][8] = CreatePlayerTextDraw(playerid, 86.9999, 376.6668, "BRONZE CASE"); // empty
    PlayerTextDrawLetterSize(playerid, ruletka_PTD_t[playerid][8], 0.1793, 1.0897);
    PlayerTextDrawTextSize(playerid, ruletka_PTD_t[playerid][8], -9.0000, 0.0000);
    PlayerTextDrawAlignment(playerid, ruletka_PTD_t[playerid][8], 1);
    PlayerTextDrawColor(playerid, ruletka_PTD_t[playerid][8], -86);
    PlayerTextDrawBackgroundColor(playerid, ruletka_PTD_t[playerid][8], 255);
    PlayerTextDrawFont(playerid, ruletka_PTD_t[playerid][8], 2);
    PlayerTextDrawSetProportional(playerid, ruletka_PTD_t[playerid][8], 1);
    PlayerTextDrawSetShadow(playerid, ruletka_PTD_t[playerid][8], 0);

    ruletka_PTD_t[playerid][9] = CreatePlayerTextDraw(playerid, 10.9998, 305.7636, "txd:brgiftsuncar"); // empty
    PlayerTextDrawTextSize(playerid, ruletka_PTD_t[playerid][9], 70.0000, 44.0000);
    PlayerTextDrawAlignment(playerid, ruletka_PTD_t[playerid][9], 1);
    PlayerTextDrawColor(playerid, ruletka_PTD_t[playerid][9], -1);
    PlayerTextDrawBackgroundColor(playerid, ruletka_PTD_t[playerid][9], 255);
    PlayerTextDrawFont(playerid, ruletka_PTD_t[playerid][9], 4);
    PlayerTextDrawSetProportional(playerid, ruletka_PTD_t[playerid][9], 0);
    PlayerTextDrawSetShadow(playerid, ruletka_PTD_t[playerid][9], 0);

    ruletka_PTD_t[playerid][10] = CreatePlayerTextDraw(playerid, 47.3807, 336.1924, "BMW_M5_F90"); // empty
    PlayerTextDrawLetterSize(playerid, ruletka_PTD_t[playerid][10], 0.1946, 0.7720);
    PlayerTextDrawTextSize(playerid, ruletka_PTD_t[playerid][10], 0.0000, -24.0000);
    PlayerTextDrawAlignment(playerid, ruletka_PTD_t[playerid][10], 2);
    PlayerTextDrawColor(playerid, ruletka_PTD_t[playerid][10], -1);
    PlayerTextDrawBackgroundColor(playerid, ruletka_PTD_t[playerid][10], 255);
    PlayerTextDrawFont(playerid, ruletka_PTD_t[playerid][10], 1);
    PlayerTextDrawSetProportional(playerid, ruletka_PTD_t[playerid][10], 1);
    PlayerTextDrawSetShadow(playerid, ruletka_PTD_t[playerid][10], 0);

    ruletka_PTD_t[playerid][11] = CreatePlayerTextDraw(playerid, 99.6666, 308.2222, "Welsi_Developer"); // empty
    PlayerTextDrawLetterSize(playerid, ruletka_PTD_t[playerid][11], 0.2526, 1.2640);
    PlayerTextDrawTextSize(playerid, ruletka_PTD_t[playerid][11], -9.0000, 0.0000);
    PlayerTextDrawAlignment(playerid, ruletka_PTD_t[playerid][11], 1);
    PlayerTextDrawColor(playerid, ruletka_PTD_t[playerid][11], -1);
    PlayerTextDrawBackgroundColor(playerid, ruletka_PTD_t[playerid][11], 255);
    PlayerTextDrawFont(playerid, ruletka_PTD_t[playerid][11], 1);
    PlayerTextDrawSetProportional(playerid, ruletka_PTD_t[playerid][11], 1);
    PlayerTextDrawSetShadow(playerid, ruletka_PTD_t[playerid][11], 0);

    ruletka_PTD_t[playerid][12] = CreatePlayerTextDraw(playerid, 86.9999, 323.1556, "BRONZE CASE"); // empty
    PlayerTextDrawLetterSize(playerid, ruletka_PTD_t[playerid][12], 0.1813, 1.1146);
    PlayerTextDrawTextSize(playerid, ruletka_PTD_t[playerid][12], -9.0000, 0.0000);
    PlayerTextDrawAlignment(playerid, ruletka_PTD_t[playerid][12], 1);
    PlayerTextDrawColor(playerid, ruletka_PTD_t[playerid][12], -86);
    PlayerTextDrawBackgroundColor(playerid, ruletka_PTD_t[playerid][12], 255);
    PlayerTextDrawFont(playerid, ruletka_PTD_t[playerid][12], 2);
    PlayerTextDrawSetProportional(playerid, ruletka_PTD_t[playerid][12], 1);
    PlayerTextDrawSetShadow(playerid, ruletka_PTD_t[playerid][12], 0);

    ruletka_PTD_t[playerid][13] = CreatePlayerTextDraw(playerid,11.3331, 253.0822, "txd:brgiftsuncar"); // empty
    PlayerTextDrawTextSize(playerid, ruletka_PTD_t[playerid][13], 70.0000, 44.0000);
    PlayerTextDrawAlignment(playerid, ruletka_PTD_t[playerid][13], 1);
    PlayerTextDrawColor(playerid, ruletka_PTD_t[playerid][13], -1);
    PlayerTextDrawBackgroundColor(playerid, ruletka_PTD_t[playerid][13], 255);
    PlayerTextDrawFont(playerid, ruletka_PTD_t[playerid][13], 4);
    PlayerTextDrawSetProportional(playerid, ruletka_PTD_t[playerid][13], 0);
    PlayerTextDrawSetShadow(playerid, ruletka_PTD_t[playerid][13], 0);

    ruletka_PTD_t[playerid][14] = CreatePlayerTextDraw(playerid,47.7141, 283.5110, "BMW_M5_F90"); // empty
    PlayerTextDrawLetterSize(playerid, ruletka_PTD_t[playerid][14], 0.1946, 0.7720);
    PlayerTextDrawTextSize(playerid, ruletka_PTD_t[playerid][14], 0.0000, -24.0000);
    PlayerTextDrawAlignment(playerid, ruletka_PTD_t[playerid][14], 2);
    PlayerTextDrawColor(playerid, ruletka_PTD_t[playerid][14], -1);
    PlayerTextDrawBackgroundColor(playerid, ruletka_PTD_t[playerid][14], 255);
    PlayerTextDrawFont(playerid, ruletka_PTD_t[playerid][14], 1);
    PlayerTextDrawSetProportional(playerid, ruletka_PTD_t[playerid][14], 1);
    PlayerTextDrawSetShadow(playerid, ruletka_PTD_t[playerid][14], 0);

    ruletka_PTD_t[playerid][15] = CreatePlayerTextDraw(playerid,99.6666, 256.3703, "Welsi_Developer"); // empty
    PlayerTextDrawLetterSize(playerid, ruletka_PTD_t[playerid][15], 0.2526, 1.2640);
    PlayerTextDrawTextSize(playerid, ruletka_PTD_t[playerid][15], -9.0000, 0.0000);
    PlayerTextDrawAlignment(playerid, ruletka_PTD_t[playerid][15], 1);
    PlayerTextDrawColor(playerid, ruletka_PTD_t[playerid][15], -1);
    PlayerTextDrawBackgroundColor(playerid, ruletka_PTD_t[playerid][15], 255);
    PlayerTextDrawFont(playerid, ruletka_PTD_t[playerid][15], 1);
    PlayerTextDrawSetProportional(playerid, ruletka_PTD_t[playerid][15], 1);
    PlayerTextDrawSetShadow(playerid, ruletka_PTD_t[playerid][15], 0);

    ruletka_PTD_t[playerid][16] = CreatePlayerTextDraw(playerid,86.9999, 271.3037, "BRONZE CASE"); // empty
    PlayerTextDrawLetterSize(playerid, ruletka_PTD_t[playerid][16], 0.1813, 1.1146);
    PlayerTextDrawTextSize(playerid, ruletka_PTD_t[playerid][16], -9.0000, 0.0000);
    PlayerTextDrawAlignment(playerid, ruletka_PTD_t[playerid][16], 1);
    PlayerTextDrawColor(playerid, ruletka_PTD_t[playerid][16], -86);
    PlayerTextDrawBackgroundColor(playerid, ruletka_PTD_t[playerid][16], 255);
    PlayerTextDrawFont(playerid, ruletka_PTD_t[playerid][16], 2);
    PlayerTextDrawSetProportional(playerid, ruletka_PTD_t[playerid][16], 1);
    PlayerTextDrawSetShadow(playerid, ruletka_PTD_t[playerid][16], 0);

    ruletka_PTD_t[playerid][17] = CreatePlayerTextDraw(playerid, 317.3334, 173.8222, "4"); // empty
    PlayerTextDrawLetterSize(playerid, ruletka_PTD_t[playerid][17], 0.2939, 1.3386);
    PlayerTextDrawAlignment(playerid, ruletka_PTD_t[playerid][17], 1);
    PlayerTextDrawColor(playerid, ruletka_PTD_t[playerid][17], -1);
    PlayerTextDrawBackgroundColor(playerid, ruletka_PTD_t[playerid][17], 255);
    PlayerTextDrawFont(playerid, ruletka_PTD_t[playerid][17], 1);
    PlayerTextDrawSetProportional(playerid, ruletka_PTD_t[playerid][17], 1);
    PlayerTextDrawSetShadow(playerid, ruletka_PTD_t[playerid][17], 0);
}

public:RunRuletka(playerid)
{
	animation_player[playerid] = true;

	if(ruletka_count[playerid])
	{
		new text[135];

		if(ruletka_count[playerid] == 15)
		{
			format(text, sizeof text, "Congratulations! You won %s{FFFF00}.{FFFFFF} To take the prize {FFFF00}/roulette", ruletka_prize[menu_prize_player[playerid][2]][R_NAME_PRIZE]);
			SendClientMessage(playerid, -1, text);
            GivePrizeRoulette(playerid, menu_prize_player[playerid][2]);

			animation_player[playerid] = false;
			KillTimer(timer_player_ruletka[playerid]);
			timer_player_ruletka[playerid] = -1;
			ruletka_count[playerid]=0;

            format(last_player_ruletka[0][last_player_name], 24, last_player_ruletka[1][last_player_name]);
            last_player_ruletka[0][id_ruletka_prize] = last_player_ruletka[1][id_ruletka_prize];
            format(last_player_ruletka[1][last_player_name], 24, last_player_ruletka[2][last_player_name]);
            last_player_ruletka[1][id_ruletka_prize] = last_player_ruletka[2][id_ruletka_prize];
            format(last_player_ruletka[2][last_player_name], 24, GetPlayerNameEx(playerid));
            last_player_ruletka[2][id_ruletka_prize] = menu_prize_player[playerid][2];

			return 1;
		}
		else
		{
			ruletka_count[playerid]++;

			new o = 5;
			while(o > 1)
			{
				o--;
				PlayerTextDrawSetString(playerid, ruletka_PTD[playerid][o], ruletka_prize[menu_prize_player[playerid][o-1]][R_NAME_TXD]);
				PlayerTextDrawSetString(playerid, ruletka_PTD_t[playerid][o], ruletka_prize[menu_prize_player[playerid][o-1]][R_NAME_TEXT]);
				menu_prize_player[playerid][o] = menu_prize_player[playerid][o-1];

			}

            new array[] = {2,2,8,8,8,8,8,8,8,8,16,18};
			menu_prize_player[playerid][0] = random2(array);
			PlayerTextDrawSetString(playerid, ruletka_PTD[playerid][0], ruletka_prize[menu_prize_player[playerid][0]][R_NAME_TXD]);
			PlayerTextDrawSetString(playerid, ruletka_PTD_t[playerid][0], ruletka_prize[menu_prize_player[playerid][0]][R_NAME_TEXT]);
		}
	}
	else
	{
		ruletka_count[playerid]=1;
	}

	return 1;
}

stock UpdateLastPlayerRuletka(playerid)
{
    for(new i; i < 3;i++)
    {
        PlayerTextDrawSetString(playerid, ruletka_PTD_t[playerid][last_player_td[i][0]], last_player_ruletka[i][last_player_name]);
        PlayerTextDrawSetString(playerid, ruletka_PTD_t[playerid][last_player_td[i][1]], ruletka_prize[last_player_ruletka[i][id_ruletka_prize]][R_NAME_TXD]);
        PlayerTextDrawSetString(playerid, ruletka_PTD_t[playerid][last_player_td[i][2]], ruletka_prize[last_player_ruletka[i][id_ruletka_prize]][R_NAME_TEXT]);
    }

    return 1;
}

random2(array[], size_w = sizeof(array))
 {
	if(size_w < 1) return -1;
	new sum = 0, result = 0;

	for(new i = size_w - 1; i > -1; i--)
	{
		sum += array[i];
		 if(random(sum) < array[i])
		  {
			result = i;
		  }
	}
		    return result;
}

stock GivePrizeRoulette(playerid, prize_id)
{
    new query[94];
    mysql_format(mysql, query, sizeof query, "INSERT INTO roulette_prize (owner, prize) VALUES (%d,%d)", GetPlayerAccountID(playerid), prize_id);
    mysql_query(mysql, query, false);

    if(mysql_errno()) SendClientMessage(playerid, -1, "Error in query.");

    return 1;
}

public: CreateTablistRoulette()
{
    new Cache:cache = mysql_query(mysql, "SELECT * FROM roulette_prize", true);

    if(mysql_errno())
    {
        mysql_query(mysql, "CREATE TABLE .`roulette_prize` ( `id` INT NOT NULL AUTO_INCREMENT , `owner` INT NOT NULL , `prize` INT NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB", false);

        if(mysql_errno()) printf("%d error create tablist roulette_prize", mysql_errno());
    }


    cache_delete(cache);

    cache = mysql_query(mysql, "SELECT * FROM accounts WHERE roulette_bronz", true);

    if(mysql_errno())
    {
        mysql_query(mysql, "ALTER TABLE `accounts` ADD `roulette_bronz` INT NOT NULL DEFAULT '0' AFTER `money`", false);

        if(mysql_errno()) printf("%d error alter roulette_bronz", mysql_errno());
    }

    cache_delete(cache);

    return 1;
}

stock GivePlayerCarRoulette(playerid, modelid, color_1, color_2)
{
		new to_player = playerid;
		new Float:POS[3];
		GetPlayerPos(to_player, POS[0],POS[1],POS[2]);
		new Float: pos_x = POS[0];
		new Float: pos_y = POS[1];
		new Float: pos_z = POS[2];
		new Float: angle = 356.7986;
		new query[220],
			Cache: result,
			idx;

		idx = GetFreeOwnableCarID();
		SetOwnableCarData(idx, OC_OWNER_ID, 	GetPlayerAccountID(to_player));
		SetOwnableCarData(idx, OC_MODEL_ID, 	modelid);
		SetOwnableCarData(idx, OC_COLOR_1, 		color_1);
		SetOwnableCarData(idx, OC_COLOR_2, 		color_2);
		SetOwnableCarData(idx, OC_POS_X, 		pos_x);
		SetOwnableCarData(idx, OC_POS_Y, 		pos_y);
		SetOwnableCarData(idx, OC_POS_Z, 		pos_z);
		SetOwnableCarData(idx, OC_ANGLE, 		angle);
		strmid(g_ownable_car[idx][OC_NUMBER], "--------", 0, 8, 8);
		SetOwnableCarData(idx, OC_ALARM, 		false);
		SetOwnableCarData(idx, OC_KEY_IN, 		true);
		SetOwnableCarData(idx, OC_CREATE, 		gettime());
		/*new idt = GetFreeOwnableCarID();*/
		format(g_ownable_car[idx][OC_OWNER_NAME], 21, GetPlayerNameEx(playerid));
		//SetVehicleRuNumberPlate(vehicleid, g_ownable_car[idt][OC_NUMBER], "52");

		// ----------------------------------------------------------------------------------------

		new vehicleid = CreateVehicle
		(
			GetOwnableCarData(idx, OC_MODEL_ID),
			GetOwnableCarData(idx, OC_POS_X),
			GetOwnableCarData(idx, OC_POS_Y),
			GetOwnableCarData(idx, OC_POS_Z),
			GetOwnableCarData(idx, OC_ANGLE),
			GetOwnableCarData(idx, OC_COLOR_1),
			GetOwnableCarData(idx, OC_COLOR_2),
			-1,
			0,
			VEHICLE_ACTION_TYPE_OWNABLE_CAR,
			idx
		);
		if(vehicleid != INVALID_VEHICLE_ID)
		{
			format(g_ownable_car[idx][OC_NUMBER], 12, g_ownable_car[idx][OC_NUMBER]);
			SetVehicleRuNumberPlate(vehicleid, g_ownable_car[idx][OC_NUMBER], "17");
			SetVehicleParam(vehicleid, V_LOCK, false);

			SetVehicleData(vehicleid, V_MILEAGE, 0.0);
		}

		SetPlayerData(to_player, P_OWNABLE_CAR, vehicleid);

		format
		(
			query, sizeof query,
			"INSERT INTO ownable_cars \
			(owner_id,model_id,color_1,color_2,pos_x,pos_y,pos_z,angle,create_time) \
			VALUES \
			('%d','%d','%d','%d','%f','%f','%f','%f','%d')",
			GetPlayerAccountID(to_player),
			modelid,
			color_1,
			color_2,
			pos_x,
			pos_y,
			pos_z,
			angle,
			gettime()
		);
		result = mysql_query(mysql, query, true);
		SetOwnableCarData(idx, OC_SQL_ID, cache_insert_id());
		cache_delete(result);
}

CMD:roulette(playerid)
{
    new query[94];
    mysql_format(mysql, query, sizeof query, "SELECT * FROM roulette_prize WHERE owner = %d", GetPlayerAccountID(playerid));
    new Cache:cache = mysql_query(mysql, query);

    if(!cache_num_rows()) return SendClientMessage(playerid, -1, "You have no prizes from roulette.");

    new rows, prize_id,id, list[52], dialog[sizeof list*10+54];

    strcat(dialog, "Next page\nPrevious page\n");

    rows = cache_num_rows();

    if(rows >= 10) rows = 10;

    for(new i,c=2;i < rows;i++,c++)
    {
        prize_id = cache_get_field_content_int(i, "prize");
        id = cache_get_field_content_int(i, "id");

        format(list, sizeof list, "%d. %s\n", i+1, ruletka_prize[prize_id][R_NAME_PRIZE]);
        strcat(dialog, list);
        SetPlayerListitemValue(playerid, c, prize_id);
        format(list, sizeof list, "rouletteid_%d", c);
        SetPVarInt(playerid, list, id);
    }

    SetPVarInt(playerid, "count_list", 1);
    Dialog(playerid, 2832, DIALOG_STYLE_LIST, "{FF0000}Prizes from roulette", dialog, "Next", "Exit");
    return 1;
}

public:LoadRuletka(playerid)
{
    new text[124];
    mysql_format(mysql, text, sizeof text, "SELECT roulette_bronz FROM accounts WHERE id=%d", GetPlayerAccountID(playerid));
    new Cache:cache = mysql_query(mysql, text, true);
    if(mysql_errno()) SendClientMessage(playerid, -1, "Error in query.");

    player_roulette_bronz[playerid] = cache_get_row_int(0, 0);
    cache_delete(cache);
    return 1;
}