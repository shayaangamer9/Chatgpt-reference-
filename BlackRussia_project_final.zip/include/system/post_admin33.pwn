// File: post_admin33.pwn
enum struct_post_admin
{
    Post_Name[32],
    Post_Level,
    Post_Division,
}

#define Division_Junior 1
#define Division_Tracking 2
#define Division_Major_Tracking 3
#define Division_Technical  4
#define Division_Media  5
#define Division_Major  6
#define Division_Maj  7
#define Division_Pok  8


new post_admin[58][struct_post_admin] =
{
    {"Junior Moderator", 1, 0},                              //0
    {"Moderator", 2, Division_Junior},                              //1
    {"Senior Moderator", 3, Division_Junior},                  //2
    {"Administrator", 4, Division_Junior},                  //3
    {"Senior Administrator", 5, Division_Junior},                  //4
    {"Law Enforcement Overseer", 3, Division_Tracking},                   //5
    {"FSB Overseer", 3, Division_Tracking},                  //6
    {"Traffic Police Overseer", 3, Division_Tracking},                    //7
    {"Police Department Overseer", 3, Division_Tracking},                 //8
    {"Army Overseer", 3, Division_Tracking},                   //9
    {"Central Bank Overseer", 3, Division_Tracking},                   //10
    {"Media Overseer", 3, Division_Tracking},                  //11
    {"Arzamas Organized Crime Overseer", 33, Division_Tracking},                    //12
    {"Batyrevo Organized Crime Overseer", 3, Division_Tracking},                    //13
    {"Lytkarino Organized Crime Overseer", 3, Division_Tracking},                    //14
    {"Head of State Security Service", 6, Division_Major_Tracking},                    //15
    {"Head of Organized Crime Group", 6, Division_Major_Tracking},                 //16
    {"Head of Interagency Relations", 6, Division_Major_Tracking},                  //17
    {"Deputy Head of State Security Service", 5, Division_Major_Tracking},                   //18
    {"Deputy Head of Organized Crime", 5, Division_Major_Tracking},                    //19
    {"Deputy Head of Interagency Relations", 5, Division_Major_Tracking},                 //20
    {"Blogger", 3, Division_Media},                  //21
    {"Assistant PR Manager", 8, Division_Media},                 //22
    {"PR Manager", 9, Division_Media},                   //23
    {"Technical Specialist ", 6, Division_Technical},//24
    {"Deputy Technical Specialist Curator", 7, Division_Technical},//25
    {"Technical Specialist Curator", 8, Division_Technical},//26
    {"Deputy Chief Technical Specialist", 9, Division_Technical},//27
    {"Chief Technical Specialist", 10, Division_Technical},//28
    {"Administration Curator ", 8, Division_Major},//29
    {"Deputy Head Administrator", 9, Division_Major},//30
    {"Senior Deputy Head Administrator", 10, Division_Major},//31
    {"Head Administrator", 11, Division_Major},//32
    {"Deputy Special Administrator", 12, Division_Major},//33
    {"Special Administrator", 12, Division_Major},//34
    {"Prizma Developer", 13, Division_Major},//35
    {"Prizma Owner", 13, Division_Major},//36
    {"Interagency Relations Overseer", 4, Division_Tracking},//37
    {"Tester Intern", 1, Division_Maj},//38
    {"Junior Tester", 1, Division_Maj},//39
    {"Tester", 2, Division_Maj},//40
    {"Senior Tester", 4, Division_Maj},//41
    {"Testing Curator", 5, Division_Maj},//42
    {"Deputy Chief Tester", 7, Division_Maj},//43
    {"Chief Tester", 8, Division_Maj},//44
    {"Purchased Admin Level 1", 1, Division_Pok},//45
    {"Purchased Admin Level 2", 2, Division_Pok},//46
    {"Purchased Admin Level 3", 3, Division_Pok},//47
    {"Purchased Admin Level 4", 4, Division_Pok},//48
    {"Purchased Admin Level 5", 5, Division_Pok},//49
    {"Purchased Admin Level 6", 6, Division_Pok},//50
    {"Purchased Admin Level 7", 7, Division_Pok},//51
    {"Purchased Admin Level 8", 8, Division_Pok},//52
    {"Purchased Admin Level 9", 9, Division_Pok},//53
    {"Purchased Admin Level 10", 10, Division_Pok},//54
    {"Purchased Admin Level 11", 11, Division_Pok},//55
    {"Purchased Admin Level 12", 12, Division_Pok},//56
    {"Purchased Admin Level 13", 13, Division_Pok}//57
};

new admin_player_post[MAX_PLAYERS];

#define SetPlayerAdminPost(%0,%1)    admin_player_post[%0] = %1
#define GetPlayerAdminPost(%0)    admin_player_post[%0]


public OnDialogResponse(playerid, dialogid, response, listitem, inputtext[])
{
    if(dialogid == 1990)
    {
        if(response)
        {
            new division = listitem+1;

            new list[35], dialog[268];

            for(new i, c = -1;i < sizeof post_admin;i++)
            {
                if(post_admin[i][Post_Division] != division) continue;
                c++;

                format(list, sizeof list, "%d. %s\n", c+1, post_admin[i][Post_Name]);
                strcat(dialog, list);
                SetPlayerListitemValue(playerid, c, i);
            }

            Dialog(playerid, 1991, DIALOG_STYLE_LIST, "{FFCD55}PRIZMA | {FFFFFF}Administration positions", dialog, "Assign", "Exit");
        }
    }
    if(dialogid == 1991)
    {
        if(response)
        {
            new post = GetPlayerListitemValue(playerid, listitem);

            new to_player = GetPVarInt(playerid, "shablon_player");

            if(GetPlayerAdminEx(to_player) >= GetPlayerAdminEx(playerid))
                return SendClientMessage(playerid, 0xFF9900FF, "You cannot assign templates to an administrator of higher or equal level.");

            if(!IsPlayerConnected(playerid))
                return SendClientMessage(playerid,-1, "Player left the game.");

            SetPlayerAdminPost(to_player, post);
	    	SetPlayerData(to_player, P_ADMIN, post_admin[post][Post_Level]);
			UpdatePlayerDatabaseInt(to_player, "admin", post_admin[post][Post_Level]);
			UpdatePlayerDatabaseInt(to_player, "post", post);

            new text[158];
            format(text, sizeof text, "{d80000} %s gave %s admin rights (%s)",
             GetPlayerNameEx(playerid), GetPlayerNameEx(to_player), post_admin[post][Post_Name]);

            SendMessageToAdmins(text, -1);
        }
    }
    #if defined post_OnDialogResponse
return post_OnDialogResponse(playerid, dialogid, response, listitem, inputtext);
#endif
}
#if defined _ALS_OnDialogResponse
#undef OnDialogResponse
#else
#define _ALS_OnDialogResponse
#endif
#define OnDialogResponse post_OnDialogResponse
#if defined post_OnDialogResponse
forward post_OnDialogResponse(playerid, dialogid, response, listitem, inputtext[]);
#endif

public OnPlayerConnect(playerid)
{
    SetTimerEx("LoadAdminPost", 4000, false, "i", playerid);
    #if defined post_OnPlayerConnect
        return post_OnPlayerConnect(playerid);
    #else
        return 1;
    #endif
}
#if defined _ALS_OnPlayerConnect
    #undef OnPlayerConnect
#else
    #define _ALS_OnPlayerConnect
#endif
#define OnPlayerConnect post_OnPlayerConnect
#if defined post_OnPlayerConnect
    forward post_OnPlayerConnect(playerid);
#endif

public OnPlayerDisconnect(playerid, reason)
{
    SetPlayerAdminPost(playerid, 0);
    #if defined post_OnPlayerDisconnect
        return post_OnPlayerDisconnect(playerid, reason);
    #else
        return 1;
    #endif
}
#if defined _ALS_OnPlayerDisconnect
    #undef OnPlayerDisconnect
#else
    #define _ALS_OnPlayerDisconnect
#endif
#define OnPlayerDisconnect post_OnPlayerDisconnect
#if defined post_OnPlayerDisconnect
    forward post_OnPlayerDisconnect(playerid, reason);
#endif

public OnGameModeInit()
{
    print("[W_SYSTEM] /shablon command and position system loaded.");
    SetTimer("CheckAccountPost", 1500, false);
    #if defined post_OnGameModeInit
        return post_OnGameModeInit();
    #else
        return 1;
    #endif
}
   #if defined _ALS_OnGameModeInit
    #undef OnGameModeInit
#else
    #define _ALS_OnGameModeInit
#endif
#define OnGameModeInit post_OnGameModeInit
#if defined post_OnGameModeInit
    forward post_OnGameModeInit();
#endif

public:CheckAccountPost()
{
    mysql_query(mysql, "SELECT * FROM accounts WHERE post", false);

    if(mysql_errno())
    {
        mysql_query(mysql, "ALTER TABLE `accounts` ADD `post` INT NOT NULL  AFTER `admin`", false);

        if(!mysql_errno()) print("Query insert new `post`");
        return 1;
    }
    return 0;
}
CMD:admup(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) <= 8) return 1;

	extract params -> new to_player; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /admup [player id]");

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player) || to_player == playerid)
		return SendClientMessage(playerid, 0x999999FF, "Player not found");

	if(!GetPlayerAdminEx(to_player))
		return SendClientMessage(playerid, 0x999999FF, "Player is not an administrator");

	if(GetPlayerAdminEx(to_player) >= GetPlayerAdminEx(playerid))
		return SendClientMessage(playerid, 0x999999FF, "You cannot promote an administrator of higher or equal rank");

	AddPlayerData(to_player, P_ADMIN, +, 1);
	UpdatePlayerDatabaseInt(to_player, "admin", GetPlayerAdminEx(to_player));

	new fmt_text[128];

	format(fmt_text, sizeof fmt_text, "Administrator %s[%d] promoted your admin level to %d",
	GetPlayerNameEx(playerid), playerid, GetPlayerAdminEx(to_player));

	SendClientMessage(to_player, 0x3399FFFF, fmt_text);

	format(fmt_text, sizeof fmt_text, "[A] %s[%d] promoted administrator %s[%d] to level %d",
	GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player, GetPlayerAdminEx(to_player));

	SendMessageToAdmins(fmt_text, 0xFF5533FF);

	format(fmt_text, sizeof fmt_text, "Promoted %s[acc:%d] to admin level %d",
	GetPlayerNameEx(to_player), GetPlayerAccountID(to_player), GetPlayerAdminEx(to_player));

	SendLog(playerid, LOG_TYPE_SUPERADMIN_ACTION, fmt_text);

	return 1;
}

public: LoadAdminPost(playerid)
{
    if(GetPlayerAdminEx(playerid) != 0) return 1;
    new welsi[68], Cache:result;

    mysql_format(mysql, welsi, sizeof welsi, "SELECT * FROM accounts WHERE id = %d", GetPlayerAccountID(playerid));
    result = mysql_query(mysql, welsi);

    if(mysql_errno())
        return print("Add column post to accounts table | Error Sql Shablon");

    new text[124], post;

    post = cache_get_field_content_int(0, "post");

    SetPlayerAdminPost(playerid, post);
    SetPlayerData(playerid, P_ADMIN, post_admin[post][Post_Level]);
    printf("Player: %s Admin: %d | Post:%d PostP: %d", GetPlayerNameEx(playerid), GetPlayerAdminEx(playerid), post, GetPlayerAdminPost(playerid));


    if(!post)
    {
        switch(GetPlayerAdminEx(playerid))
        {
            case 1: SetPlayerAdminPost(playerid, 1);
            case 2: SetPlayerAdminPost(playerid, 2);
            case 3: SetPlayerAdminPost(playerid, 3);
            case 4: SetPlayerAdminPost(playerid, 4);
        }
    }

    new id = GetPlayerAdminPost(playerid);

    new color[12];

    switch(post_admin[id][Post_Division])
    {
        case Division_Junior:color = "{11FFFF}";
        case Division_Tracking:color = "{4444FF}";
        case Division_Major_Tracking:color = "{00FFFF}";
        case Division_Technical:color = "{FF5E00}";
        case Division_Media:color = "{FF0000}";
        case Division_Major:
        {
            switch(id)
            {
                case 29:color = "{5555FF}";
                case 35:color = "{00FFFF}";
                default:color = "{FFFF00}";
            }
        }
    }
                {
					format(text, sizeof text, "{2fdb07}[A-LOGIN]: {059142}%s [%d] {2fdb07} authorized as: {059142}%s%s", GetPlayerNameEx(playerid), playerid, post_admin[id][Post_Name]);
    SendMessageToAdmins(text, -1);
				}

    cache_delete(result);
    return 1;
}

CMD:shablon(playerid, params[])
{
    if(!(GetPlayerAdminEx(playerid) >= 9)) return 1;

    if(sscanf(params, "u", params[0]))
    return SendClientMessage(playerid, 0xFFFFFFFF, "{FFFF00}| {FFFFFF}Usage {FFFF00}/shablon {FFFFFF}[player ID]");

    if(!IsPlayerConnected(params[0]) || params[0] == playerid) return SendClientMessage(playerid, 0xFFFFFFFF, "{FFFF00}| {FFFFFF}Enter a valid player ID.");

    Dialog
    (
        playerid, 1990, DIALOG_STYLE_LIST,
        "Administration templates",
        "1. Admin rights\n"\
        "2. Supervisory admin template\n"\
        "3. Chief supervisory template\n"\
        "4. Technical specialists template\n"\
        "5. Media department template\n"\
        "6. Main administration template\n"\
        "7. Testers template\n"\
        "8. Purchased admin template",
        "Select", "Back"
    );

    SetPVarInt(playerid, "shablon_player", params[0]);
    return 1;
}

CMD:a(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) >= 1)
	{
		if(!strlen(params))
			return SendClientMessage(playerid, 0xCECECEFF, "Usage: /a [text]");

		new fmt_str[128];

		format(fmt_str, sizeof fmt_str, "{00FFFF}[%s] %s[%d]: %s", post_admin[GetPlayerAdminPost(playerid)][Post_Name], GetPlayerNameEx(playerid), playerid, params);
		SendMessageToAdmins(fmt_str, 0x0aeaf2);//admin chat color (0x0aeaf2)

		SendLog(playerid, LOG_TYPE_ADMIN_CHAT, params);
	}

	return 1;
}