// File: auction.pwn
#define MAX_AUCTION_SLOT 1024
#define MAX_AUCTION_LIST 256

#define TYPE_BUSINESS         1
#define TYPE_VEHICLE          2
#define TYPE_HOUSE            3
#define TYPE_VEHICLE_NUMBER   4
#define TYPE_SUM_NUMBER       5
#define TYPE_CLOTHES          6

#define AUCTION_WORLD       183

new enter_auction, exit_auction;

new type_slot[7][22] =
{
    {""},
    {"Business"},
    {"Vehicle"},
    {"Real estate"},
    {"License plate"},
    {"SIM card"},
    {"Clothes"}
};

new icon_slot[7][17] =
{
    {""},           //  none
    {"txd:braucbiz"},               //   business
    {"txd:brauccar"},               //   vehicle
    {"txd:brauchome"},               //   house/real estate
    {"txd:braucnumber"},            //   vehicle plate
    {"txd:braucsimcard"},           //   SIM card
    {"txd:brauccloth"}             //   clothes
};

new bool:load_business_action;
enum STRUCT_AUCTION_SLOT
{
    SLOT_TYPE,
    OWNER_SLOT_SQL,
    OWNER_SLOT_NAME[24],
    SLOT_NAME[24],
    OPISANIE_SLOT[124],
    OWNER_RATE,
    START_RATE,
    CURRENT_RATE,
    //TIMER_ID,
    TIMER_END,
    //database and server
    DATABASE_ID,
    SERVER_ID,
    //number vehicle and SUM
    NUMBER_VEHICLE[7],
    NUMBER_SUM
}

new auction_slot[MAX_AUCTION_SLOT][STRUCT_AUCTION_SLOT];

new player_cd_auction[MAX_PLAYERS];
new PlayerText:auction_PTD[MAX_PLAYERS][40];

new slot_td[4][3] = //td ids where slot info
{
    {11, 12, 13},
    {15, 16, 17},
    {19, 20, 21},
    {7, 8, 9}
};

enum STRUCT_AUCTION_PANEL
{
    bool:show_panel,
    count_list,
    select_slot,
    select_type,
    select_tab,
    filter_min_price,
    filter_max_price,
    filter_type,
    filter_tovar_type,
    filter_vehicle_model,
    bool:type_tovar,
    bool:price_tovar,
    bool:opisanie_tovar,
    bool:tovar,
}

new player_show_slot[MAX_PLAYERS][4];
new player_info_panel[MAX_PLAYERS][STRUCT_AUCTION_PANEL];

/*new type_panel_auction[3][14] =
{
    {"txd:braucbuy"},
    {"txd:braucsell"},
    {"txd:braucmy"}
};*/
new auction_button[8][2][20] =
{
    {"txd:braucnulist", "txd:brauculist"}, //slot
    {"txd:braucnubuy", "txd:braucubuy"}, //buy
    {"txd:braucnusell", "txd:braucusell"}, //sell
    {"txd:braucnumy", "txd:braucumy"}, //my tab
    {"txd:braucnutip", "txd:braucutip"}, //item type
    {"txd:braucnutovar", "txd:braucutovar"}, //select item
    {"txd:braucnuopisanie", "txd:braucuopisanie"}, //item description
    {"txd:braucnucost", "txd:braucucost"} //item price
};




public OnDialogResponse(playerid, dialogid, response, listitem, inputtext[])
{
    if(dialogid == 5990)
    {
        if(response)
        {
            new rate = strval(inputtext), id = GetPVarInt(playerid, "select_slot"), string[9];

            new percent = auction_slot[id][CURRENT_RATE] * 98 / 100;
            new da = auction_slot[id][CURRENT_RATE]  - percent;
            new price = da  + auction_slot[id][CURRENT_RATE], old_rate = auction_slot[id][OWNER_RATE];

            if(!(rate >= price)) return SendClientMessage(playerid, -1, ""SC" Your bid must exceed the minimum bid for the lot.");

            if(GetPlayerMoneyEx(playerid) >= rate)
            {
                if(old_rate != -1)
                {
                    new bool:give_money;

                    foreach(new i : Player)
                    {
                        if(GetPlayerAccountID(i) != old_rate) continue;

                        GivePlayerMoneyEx(i, auction_slot[id][CURRENT_RATE]);
                        give_money = true;
                        SendClientMessage(i, -1, ""SC" Your bid has been overbid. Money returned");
                        break;
                    }

                    if(!give_money)
                    {
                        new text[124];

                        format(text, sizeof text, "UPDATE accounts SET money = money + %d WHERE id = %d", auction_slot[id][CURRENT_RATE], auction_slot[id][OWNER_RATE]);
                        mysql_query(mysql, text);
                        if(mysql_errno()) return print("[ERROR AUCTION MYSQL] ID ERROR:: 1");
                    }


                }

                GivePlayerMoneyEx(playerid, -rate);

                default_select_slot(playerid);

                player_info_panel[playerid][select_slot] = 0;

                for(new i = 1; i < 6;i++ ) PlayerTextDrawSetString(playerid, auction_PTD[playerid][i], "-");

                auction_slot[id][OWNER_RATE] = GetPlayerAccountID(playerid);
                auction_slot[id][CURRENT_RATE] = rate;

                for(new td; td < 4; td++)
                {
                    if(player_show_slot[playerid][td] == -1) continue;
                    PlayerTextDrawSetString(playerid, auction_PTD[playerid][slot_td[td][0]], auction_slot[player_show_slot[playerid][td]][OWNER_SLOT_NAME]);
                    PlayerTextDrawSetString(playerid, auction_PTD[playerid][slot_td[td][1]], auction_slot[player_show_slot[playerid][td]][SLOT_NAME]);

                    valstr(string, auction_slot[player_show_slot[playerid][td]][CURRENT_RATE]);

                    PlayerTextDrawSetString(playerid, auction_PTD[playerid][slot_td[td][2]], string);
                }

                SendClientMessage(playerid, -1, ""SC" You have successfully placed a bid on the lot.");
            }
        }

    }
    if(dialogid == 5991)
    {
        if(!response) return 0;

        switch(GetPVarInt(playerid, "select_param"))
        {
            case 1://type
            {
                switch(listitem + 1)
                {
                    case 1:SetPVarInt(playerid, "type_param", TYPE_VEHICLE);
                    case 2:SetPVarInt(playerid, "type_param", TYPE_HOUSE);
                    case 3:SetPVarInt(playerid, "type_param", TYPE_BUSINESS);
                    case 4:SetPVarInt(playerid, "type_param", TYPE_VEHICLE_NUMBER);
                    case 5:SetPVarInt(playerid, "type_param", TYPE_SUM_NUMBER);
                    case 6:SetPVarInt(playerid, "type_param", TYPE_CLOTHES);
                }

                if(!player_info_panel[playerid][type_tovar])
                {
                    player_info_panel[playerid][type_tovar] = true;
                    PlayerTextDrawSetString(playerid, auction_PTD[playerid][29], auction_button[4][1]);
                }

                PlayerTextDrawSetString(playerid, auction_PTD[playerid][22], icon_slot[GetPVarInt(playerid, "type_param")]);
                PlayerTextDrawSetString(playerid, auction_PTD[playerid][1], type_slot[GetPVarInt(playerid, "type_param")]);
            }
            case 2: // opisanie
            {
                //if(!inputtext) return SendClientMessage(playerid, -1, ""USC" Description cannot be empty");

                SetPVarString(playerid, "opisanie_param", inputtext);

                if(!player_info_panel[playerid][opisanie_tovar])
                {
                    player_info_panel[playerid][opisanie_tovar] = true;
                    PlayerTextDrawSetString(playerid, auction_PTD[playerid][31], auction_button[6][1]);
                }
                PlayerTextDrawSetString(playerid, auction_PTD[playerid][3], "Yes");
            }
            case 3://price
            {
                new price;

                sscanf(inputtext, "d", price);

                if(price >= 1_000_000_001 || price <= 4_999) return SendClientMessage(playerid, -1, ""USC" Enter amount from 5000 rub to 1000000000 rub");

                SetPVarInt(playerid, "price_param", price);

                if(!player_info_panel[playerid][price_tovar])
                {
                    player_info_panel[playerid][price_tovar] = true;
                    PlayerTextDrawSetString(playerid, auction_PTD[playerid][28], auction_button[7][1]);
                }
                PlayerTextDrawSetString(playerid, auction_PTD[playerid][4], inputtext);
            }
        }
    }
    if(dialogid == 5992) // confirmation
    {
        if(!response) return 1;

        new text[124], name[24];

        switch(GetPVarInt(playerid, "type_param"))
        {
            case TYPE_VEHICLE_NUMBER:
            {
                new num[7];

                GetPVarString(playerid, "tovar_param_num", num, 7);

                if(num[0] == 0)
                {
                    new id_car = GetPlayerListitemValue(playerid, listitem), num_car[7], Cache:result;

                    printf("id_car: %d", id_car);

                    mysql_format(mysql, text, sizeof text, "SELECT * FROM ownable_cars WHERE id='%d' LIMIT 1", id_car);
                    result = mysql_query(mysql, text);
                    if(mysql_errno()) return print("[ERROR AUCTION MYSQL] ID ERROR:: 2");

                    if(!cache_num_rows()) return SendClientMessage(playerid, -1, "errror");

                    for(new i, sql = GetPlayerAccountID(playerid);i < MAX_AUCTION_SLOT;i++)
                    {
                        if(auction_slot[i][OWNER_SLOT_SQL] != sql) continue;

                        if(auction_slot[i][SLOT_NAME] == TYPE_VEHICLE && auction_slot[i][DATABASE_ID] == id_car)
                            return SendClientMessage(playerid, -1, ""SC" Vehicle is already on auction");


                    }
                    //new rows = cache_num_rows();

                    cache_get_field_content(0, "number", num_car, mysql, 7);

                    format(text, sizeof text, "You want to put the license plate %s on auction", num_car);

                    SetPVarString(playerid, "tovar_param_num", num_car);

                    format(name, 24, num_car);

                    Dialog
                    (
                        playerid, 5992, DIALOG_STYLE_MSGBOX,
                        "{FF0000}Sell",
                        text,
                        "Next", "Back"
                    );
                }
            }
            case TYPE_CLOTHES:
            {
                if(GetPVarInt(playerid, "tovar_param")) return 1;

                new id_clothers = GetPlayerListitemValue(playerid, listitem), Cache:result;

                mysql_format(mysql, text, sizeof text, "SELECT * FROM inventory_skins WHERE id='%d' LIMIT 1", id_clothers);
                result = mysql_query(mysql, text);
                if(mysql_errno()) return print("[ERROR AUCTION MYSQL] ID ERROR:: 3");

                if(!cache_num_rows()) return SendClientMessage(playerid, -1, "errror");

                new server = cache_get_field_content_int(0, "skin_id");

                format(text, sizeof text, "You want to put the clothing %s on auction", GetSkinInfo(server, S_NAME));

                SetPVarInt(playerid, "tovar_param", id_clothers);
                SetPVarInt(playerid, "tovar_param_server", server);

                format(name, 24, GetSkinInfo(server, S_NAME));

                Dialog
                (
                    playerid, 5992, DIALOG_STYLE_MSGBOX,
                    "{FF0000}Sell",
                    text,
                    "Next", "Back"
                );
            }
            case TYPE_BUSINESS:
                format(name, 24, GetBusinessData(GetPVarInt(playerid, "tovar_param_server"), B_NAME));

            case TYPE_HOUSE:
                format(name, 24, "House %d", GetPVarInt(playerid, "tovar_param_server"));

            case TYPE_SUM_NUMBER:
            {
                new string[6];
                valstr(string, GetPVarInt(playerid, "tovar_param"));

                format(name, 24, string);
            }
            case TYPE_VEHICLE:
            {
                new id = GetVehicleModel(GetPVarInt(playerid, "tovar_param_server")) - 400;
                format(name, 24, ProbelText(GetVehicleInfo(id, VI_NAME)));
            }
        }

        if(!player_info_panel[playerid][tovar])
        {
            player_info_panel[playerid][tovar] = true;
            PlayerTextDrawSetString(playerid, auction_PTD[playerid][30], auction_button[5][1]);
        }
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][2], name);

    }
    if(dialogid == 5993)
    {
        if(response)
        {
            if(GetPVarInt(playerid, "filter_select_veh"))
            {
                new model = GetPlayerListitemValue(playerid, listitem);

                player_info_panel[playerid][filter_vehicle_model] = model;
                player_info_panel[playerid][filter_tovar_type] = TYPE_VEHICLE;

                player_info_panel[playerid][count_list] = 1;
                LeafAuction(playerid, 3);
                DeletePVar(playerid, "filter_select_veh");

                return 1;
            }
            else if(player_info_panel[playerid][filter_type] == 2)
            {
                new min_price, max_price;

                if(sscanf(inputtext, "P<,>dd", min_price, max_price))
                {
                    SendClientMessage(playerid, 0x999999FF, "Invalid input");
                    player_info_panel[playerid][filter_type] = 0;

                    return OnDialogResponse(playerid, 5993, 1, 1, "");
                }
                else
                {
                    if(min_price >= max_price)
                    {
                        SendClientMessage(playerid, 0xFFFFFFFF, ""USC" Minimum price must be lower than maximum");
                        player_info_panel[playerid][filter_type] = 0;

                        return OnDialogResponse(playerid, 5993, 1, 1, "");
                    }
                    else if(min_price <= 999 || max_price >= 500_000_000)
                    {
                        SendClientMessage(playerid, 0xFFFFFFFF, ""USC" Price must be from 1000 rub to 500000000 rub");
                        player_info_panel[playerid][filter_type] = 0;

                        return OnDialogResponse(playerid, 5993, 1, 1, "");
                    }
                    else
                    {
                        player_info_panel[playerid][filter_type] = 2;
                        player_info_panel[playerid][filter_min_price] = min_price;
                        player_info_panel[playerid][filter_max_price] = max_price;

                        player_info_panel[playerid][count_list] = 1;
                        LeafAuction(playerid, 3);
                        return 1;
                    }
                }
            }
            else if(player_info_panel[playerid][filter_type] == 1)
            {
                if(player_info_panel[playerid][filter_tovar_type] == TYPE_VEHICLE)
                {
                    new dialog[284], list[54], market;

                    switch(listitem+1)
                    {
                        case 1:market = 1;
                        case 2:market = 3;
                        case 3:market = 2;
                    }

                    for(new v, model; v < 32;v++)
                    {
                        if(!car_market_data[market][v][0]) continue;

                        model = car_market_data[market][v][0]-400;

                        format(list, sizeof list, "%d. %s\n", v + 1, GetVehicleInfo(model, VI_NAME));
                        strcat(dialog, list);

                        SetPlayerListitemValue(playerid, v, model);
                    }

                    Dialog
                    (
                        playerid, 5993, DIALOG_STYLE_LIST,
                        "{FF0000}Filter",
                        dialog,
                        "Next", "Back"
                    );

                    SetPVarInt(playerid, "filter_select_veh", 1);

                    return 1;
                }
                else
                {
                    switch(listitem)
                    {
                        case 0:
                        {
                            Dialog
                            (
                                playerid, 5993, DIALOG_STYLE_LIST,
                                "{FF0000}Filter",
                                "1. Low class\n"\
                                "2. Medium class\n"\
                                "3. High class",
                                "Next", "Back"
                            );

                            player_info_panel[playerid][filter_tovar_type] = TYPE_VEHICLE;

                            return 1;
                        }
                        case 1:
                        {
                            player_info_panel[playerid][filter_tovar_type] = TYPE_HOUSE;

                            player_info_panel[playerid][count_list] = 1;
                            LeafAuction(playerid, 3);
                        }
                        case 2:
                        {
                            player_info_panel[playerid][filter_tovar_type] = TYPE_BUSINESS;

                            player_info_panel[playerid][count_list] = 1;
                            LeafAuction(playerid, 3);
                        }
                        case 3:
                        {
                            player_info_panel[playerid][filter_tovar_type] = TYPE_VEHICLE_NUMBER;

                            player_info_panel[playerid][count_list] = 1;
                            LeafAuction(playerid, 3);
                        }
                        case 4:
                        {
                            player_info_panel[playerid][filter_tovar_type] = TYPE_SUM_NUMBER;

                            player_info_panel[playerid][count_list] = 1;
                            LeafAuction(playerid, 3);
                        }
                        case 5:
                        {
                            player_info_panel[playerid][filter_tovar_type] = TYPE_CLOTHES;

                            player_info_panel[playerid][count_list] = 1;
                            LeafAuction(playerid, 3);
                        }
                    }
                }
            }
            else
            {
                switch(listitem)
                {
                    case 0:
                    {
                        Dialog
                        (
                            playerid, 5993, DIALOG_STYLE_LIST,
                            "{FF0000}Filter",
                            "1. Car\n"\
                            "2. Real estate\n"\
                            "3. Business\n"\
                            "4. License plate\n"\
                            "5. SIM card\n"\
                            "6. Clothes",
                            "Next", "Back"
                        );

                        player_info_panel[playerid][filter_type] = 1;
                        return 1;
                    }
                    case 1:
                    {
                        Dialog
                        (
                            playerid, 5993, DIALOG_STYLE_INPUT,
                            "{FF0000}Filter",
                            "Enter price range separated by comma (1000, 500000000)",
                            "Next", "Back"
                        );

                        player_info_panel[playerid][filter_type] = 2;
                        return 1;
                    }
                }
            }
        }
        else
        {
            player_info_panel[playerid][filter_type] = 0;
            player_info_panel[playerid][filter_tovar_type] = 0;
        }
    }
    #if defined auc_OnDialogResponse
        return auc_OnDialogResponse(playerid, dialogid, response, listitem, inputtext);
    #else
        return 0;
    #endif
}
#if defined _ALS_OnDialogResponse
#undef OnDialogResponse
#else
#define _ALS_OnDialogResponse
#endif
#define OnDialogResponse auc_OnDialogResponse
#if defined auc_OnDialogResponse
forward auc_OnDialogResponse(playerid, dialogid, response, listitem, inputtext[]);
#endif

public:PlayerTextDrawAuction(playerid)
{
    auction_PTD[playerid][0] = CreatePlayerTextDraw(playerid, 27.3333, 100.2444, "txd:braucbuy"); // background / base
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][0], 588.0000, 294.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][0], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][0], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][0], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][0], 4);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][0], 0);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][0], 0);

    auction_PTD[playerid][1] = CreatePlayerTextDraw(playerid, 490.6665, 211.9851, "-"); // slot owner name
    PlayerTextDrawLetterSize(playerid, auction_PTD[playerid][1], 0.2480, 1.3330);//0.3133, 1.2888
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][1], -21.0000, 0.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][1], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][1], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][1], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][1], 1);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][1], 1);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][1], 0);

    auction_PTD[playerid][2] = CreatePlayerTextDraw(playerid, 490.6665, 236.4593, "-"); // slot type
    PlayerTextDrawLetterSize(playerid, auction_PTD[playerid][2], 0.2480, 1.3330);
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][2], -21.0000, 0.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][2], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][2], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][2], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][2], 1);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][2], 1);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][2], 0);

    auction_PTD[playerid][3] = CreatePlayerTextDraw(playerid, 490.6665, 261.7631, "-"); // starting price
    PlayerTextDrawLetterSize(playerid, auction_PTD[playerid][3], 0.2480, 1.3330);
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][3], -21.0000, 0.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][3], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][3], -1107374134);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][3], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][3], 1);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][3], 1);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][3], 0);

    auction_PTD[playerid][4] = CreatePlayerTextDraw(playerid, 490.6665, 286.6520, "-"); // current price
    PlayerTextDrawLetterSize(playerid, auction_PTD[playerid][4], 0.2480, 1.3330);
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][4], -21.0000, 0.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][4], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][4], -1107374134);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][4], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][4], 1);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][4], 1);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][4], 0);

    auction_PTD[playerid][5] = CreatePlayerTextDraw(playerid, 490.6665, 311.5410, "-"); // time
    PlayerTextDrawLetterSize(playerid, auction_PTD[playerid][5], 0.2480, 1.3330);
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][5], -20.0000, 0.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][5], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][5], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][5], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][5], 1);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][5], 1);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][5], 0);

    auction_PTD[playerid][6] = CreatePlayerTextDraw(playerid, 174.6666, 293.9630, "txd:braucnulist"); // 4
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][6], 298.0000, 70.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][6], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][6], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][6], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][6], 4);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][6], 0);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][6], 0);
    PlayerTextDrawSetSelectable(playerid, auction_PTD[playerid][6], 1);

    auction_PTD[playerid][7] = CreatePlayerTextDraw(playerid, 193.3333, 316.5185, "-"); // empty
    PlayerTextDrawLetterSize(playerid, auction_PTD[playerid][7], 0.2350, 1.4262);
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][7], -70.0000, 0.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][7], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][7], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][7], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][7], 1);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][7], 1);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][7], 0);

    auction_PTD[playerid][8] = CreatePlayerTextDraw(playerid, 303.6669, 317.3482, "-"); // empty
    PlayerTextDrawLetterSize(playerid, auction_PTD[playerid][8], 0.2350, 1.4262);//0.3026, 1.2971
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][8], -70.0000, 0.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][8], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][8], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][8], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][8], 1);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][8], 1);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][8], 0);

    auction_PTD[playerid][9] = CreatePlayerTextDraw(playerid, 381.3334, 326.8889, "-"); // empty
    PlayerTextDrawLetterSize(playerid, auction_PTD[playerid][9], 0.2150, 1.3262);
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][9], -70.0000, 0.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][9], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][9], -1107374134);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][9], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][9], 1);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][9], 1);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][9], 0);

    auction_PTD[playerid][10] = CreatePlayerTextDraw(playerid, 174.6666, 144.6296, "txd:braucnulist"); // 1
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][10], 298.0000, 70.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][10], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][10], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][10], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][10], 4);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][10], 0);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][10], 0);
    PlayerTextDrawSetSelectable(playerid, auction_PTD[playerid][10], 1);

    auction_PTD[playerid][11] = CreatePlayerTextDraw(playerid, 193.3333, 167.1852, "-"); // empty
    PlayerTextDrawLetterSize(playerid, auction_PTD[playerid][11], 0.2350, 1.4262);
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][11], -70.0000, 0.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][11], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][11], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][11], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][11], 1);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][11], 1);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][11], 0);

    auction_PTD[playerid][12] = CreatePlayerTextDraw(playerid, 303.6669, 168.0148, "-"); // empty
    PlayerTextDrawLetterSize(playerid, auction_PTD[playerid][12], 0.2350, 1.4262);
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][12], -70.0000, 0.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][12], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][12], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][12], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][12], 1);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][12], 1);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][12], 0);

    auction_PTD[playerid][13] = CreatePlayerTextDraw(playerid, 381.3334, 177.5556, "-"); // empty
    PlayerTextDrawLetterSize(playerid, auction_PTD[playerid][13], 0.2150, 1.3262);
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][13], -70.0000, 0.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][13], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][13], -1107374134);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][13], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][13], 1);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][13], 1);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][13], 0);

    auction_PTD[playerid][14] = CreatePlayerTextDraw(playerid, 174.6666, 195.2370, "txd:braucnulist"); // 2
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][14], 298.0000, 70.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][14], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][14], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][14], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][14], 4);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][14], 0);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][14], 0);
    PlayerTextDrawSetSelectable(playerid, auction_PTD[playerid][14], 1);

    auction_PTD[playerid][15] = CreatePlayerTextDraw(playerid, 193.3333, 217.7926, "-"); // empty
    PlayerTextDrawLetterSize(playerid, auction_PTD[playerid][15], 0.2350, 1.4262);
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][15], -70.0000, 0.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][15], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][15], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][15], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][15], 1);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][15], 1);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][15], 0);

    auction_PTD[playerid][16] = CreatePlayerTextDraw(playerid, 303.6669, 218.6222, "-"); // empty
    PlayerTextDrawLetterSize(playerid, auction_PTD[playerid][16], 0.2350, 1.4262);
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][16], -70.0000, 0.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][16], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][16], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][16], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][16], 1);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][16], 1);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][16], 0);

    auction_PTD[playerid][17] = CreatePlayerTextDraw(playerid, 381.3334, 228.1630, "-"); // empty
    PlayerTextDrawLetterSize(playerid, auction_PTD[playerid][17], 0.2150, 1.3262);
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][17], -70.0000, 0.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][17], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][17], -1107374134);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][17], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][17], 1);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][17], 1);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][17], 0);

    auction_PTD[playerid][18] = CreatePlayerTextDraw(playerid, 174.6666, 244.6000, "txd:braucnulist"); // 3
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][18], 298.0000, 70.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][18], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][18], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][18], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][18], 4);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][18], 0);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][18], 0);
    PlayerTextDrawSetSelectable(playerid, auction_PTD[playerid][18], 1);

    auction_PTD[playerid][19] = CreatePlayerTextDraw(playerid, 193.3333, 267.1556, "-"); // empty
    PlayerTextDrawLetterSize(playerid, auction_PTD[playerid][19], 0.2350, 1.4262);
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][19], -70.0000, 0.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][19], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][19], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][19], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][19], 1);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][19], 1);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][19], 0);

    auction_PTD[playerid][20] = CreatePlayerTextDraw(playerid, 303.6669, 267.9852, "-"); // empty
    PlayerTextDrawLetterSize(playerid, auction_PTD[playerid][20], 0.2350, 1.4262);
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][20], -70.0000, 0.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][20], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][20], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][20], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][20], 1);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][20], 1);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][20], 0);

    auction_PTD[playerid][21] = CreatePlayerTextDraw(playerid, 381.3334, 277.5260, "-"); // empty
    PlayerTextDrawLetterSize(playerid, auction_PTD[playerid][21], 0.2150, 1.3262);
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][21], -70.0000, 0.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][21], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][21], -1107374134);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][21], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][21], 1);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][21], 1);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][21], 0);

    auction_PTD[playerid][22] = CreatePlayerTextDraw(playerid, 492.3333, 132.6000, "txd:brauchome"); // slot icon
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][22], 103.0000, 65.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][22], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][22], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][22], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][22], 4);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][22], 0);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][22], 0);

    auction_PTD[playerid][23] = CreatePlayerTextDraw(playerid, 43.3333, 125.1333, "txd:braucubuy"); // buy tab
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][23], 109.0000, 62.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][23], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][23], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][23], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][23], 4);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][23], 0);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][23], 0);
    PlayerTextDrawSetSelectable(playerid, auction_PTD[playerid][23], 1);

    auction_PTD[playerid][24] = CreatePlayerTextDraw(playerid, 43.3333, 170.3481, "txd:braucnusell"); // sell tab
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][24], 109.0000, 62.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][24], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][24], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][24], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][24], 4);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][24], 0);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][24], 0);
    PlayerTextDrawSetSelectable(playerid, auction_PTD[playerid][24], 1);

    auction_PTD[playerid][25] = CreatePlayerTextDraw(playerid, 43.6666, 216.8074, "txd:braucnumy"); // my tab
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][25], 109.0000, 61.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][25], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][25], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][25], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][25], 4);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][25], 0);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][25], 0);
    PlayerTextDrawSetSelectable(playerid, auction_PTD[playerid][25], 1);

    auction_PTD[playerid][26] = CreatePlayerTextDraw(playerid, 43.3333, 285.6667, "txd:braucexit"); // exit
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][26], 109.0000, 62.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][26], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][26], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][26], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][26], 4);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][26], 0);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][26], 0);
    PlayerTextDrawSetSelectable(playerid, auction_PTD[playerid][26], 1);

    auction_PTD[playerid][27] = CreatePlayerTextDraw(playerid, 94.3333, 368.3703, "1"); // page
    PlayerTextDrawLetterSize(playerid, auction_PTD[playerid][27], 0.3563, 1.6207);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][27], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][27], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][27], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][27], 1);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][27], 1);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][27], 0);

    auction_PTD[playerid][28] = CreatePlayerTextDraw(playerid, 172.0000, 289.4001, "txd:braucnucost"); // empty
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][28], 302.0000, 62.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][28], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][28], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][28], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][28], 4);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][28], 0);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][28], 0);
    PlayerTextDrawSetSelectable(playerid, auction_PTD[playerid][28], 1);

    auction_PTD[playerid][29] = CreatePlayerTextDraw(playerid,171.3333, 154.5852, "txd:braucnutip"); // item type
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][29], 302.0000, 62.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][29], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][29], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][29], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][29], 4);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][29], 0);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][29], 0);
    PlayerTextDrawSetSelectable(playerid, auction_PTD[playerid][29], 1);

    auction_PTD[playerid][30] = CreatePlayerTextDraw(playerid,172.0000, 200.2147, "txd:braucnutovar"); // item
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][30], 302.0000, 62.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][30], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][30], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][30], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][30], 4);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][30], 0);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][30], 0);
    PlayerTextDrawSetSelectable(playerid, auction_PTD[playerid][30], 1);

    auction_PTD[playerid][31] = CreatePlayerTextDraw(playerid,172.6666, 244.1851, "txd:braucnuopisanie"); // description
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][31], 302.0000, 63.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][31], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][31], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][31], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][31], 4);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][31], 0);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][31], 0);
    PlayerTextDrawSetSelectable(playerid, auction_PTD[playerid][31], 1);

    auction_PTD[playerid][32] = CreatePlayerTextDraw(playerid,491.9997, 310.7110, "0_RUB"); // promotion
    PlayerTextDrawLetterSize(playerid, auction_PTD[playerid][32], 0.2480, 1.3330);
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][32], 496.9997, 0.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][32], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][32], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][32], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][32], 1);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][32], 1);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][32], 0);

    auction_PTD[playerid][33] = CreatePlayerTextDraw(playerid, 240.3332, 132.1851, "txd:braucsale"); // empty
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][33], 158.0000, 197.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][33], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][33], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][33], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][33], 4);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][33], 0);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][33], 0);
    PlayerTextDrawSetSelectable(playerid, auction_PTD[playerid][33], 1);

    auction_PTD[playerid][34] = CreatePlayerTextDraw(playerid, 393.3332, 146.2888, "txd:braucpurchase"); // empty
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][34], 143.0000, 175.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][34], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][34], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][34], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][34], 4);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][34], 0);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][34], 0);
    PlayerTextDrawSetSelectable(playerid, auction_PTD[playerid][34], 1);

    auction_PTD[playerid][35] = CreatePlayerTextDraw(playerid, 140.0001, 362.5701, "txd:braucright"); // next list
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][35], 24.0000, 27.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][35], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][35], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][35], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][35], 4);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][35], 0);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][35], 0);
    PlayerTextDrawSetSelectable(playerid, auction_PTD[playerid][35], 1);

    auction_PTD[playerid][36] = CreatePlayerTextDraw(playerid, 39.3333, 362.9849, "txd:braucleft"); // previous list
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][36], 23.0000, 27.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][36], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][36], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][36], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][36], 4);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][36], 0);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][36], 0);
    PlayerTextDrawSetSelectable(playerid, auction_PTD[playerid][36], 1);

    auction_PTD[playerid][37] = CreatePlayerTextDraw(playerid, 482.3333, 319.6813, "txd:braucbet"); // place bid
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][37], 122.0000, 57.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][37], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][37], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][37], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][37], 4);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][37], 0);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][37], 0);
    PlayerTextDrawSetSelectable(playerid, auction_PTD[playerid][37], 1);

    auction_PTD[playerid][38] = CreatePlayerTextDraw(playerid, 439.0000, 115.1778, "txd:braucfilter"); // filter
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][38], 24.0000, 26.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][38], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][38], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][38], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][38], 4);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][38], 0);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][38], 0);
    PlayerTextDrawSetSelectable(playerid, auction_PTD[playerid][38], 1);

    auction_PTD[playerid][39] = CreatePlayerTextDraw(playerid, 482.3333, 319.6813, "txd:braucexpose"); // list
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][39], 122.0000, 57.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][39], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][39], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][39], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][39], 4);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][39], 0);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][39], 0);
    PlayerTextDrawSetSelectable(playerid, auction_PTD[playerid][39], 1);
}

public OnGameModeInit()
{
    for(new i;i < MAX_BUSINESS; i ++)
    {
        if(GetBusinessData(i, B_NAME)) continue;

        SetTimer("SetBusinessName", 1500, false);

        break;
    }

    CreateDynamic3DTextLabel("Enter command {FF0000}/auction{FFFFFF}\nTo use the auction", -1, 1000.000915,2508.325927,1497.994628, 5.0);
    enter_auction = CreateDynamicSphere(2092.610351,-2283.928955,23.096267, 1.0, 0, 0);
    exit_auction = CreateDynamicSphere(999.965148,2488.335205,1499.304687, 1.0, AUCTION_WORLD, 1);
    CreateDynamicPickup(19134, 23, 2092.610351,-2283.928955,23.096267, 0, 0);
    CreateDynamicPickup(19134, 23, 999.965148,2488.335205,1499.304687, AUCTION_WORLD, 1);
    Create3DTextLabel("{FFFF00}Auction entrance\n{FFFFFF}Approach to enter", -1, 2092.610351,-2283.928955,23.096267, 10.0, 0);//Author of this system https://t.me/welsistudio (Welsi Studio)

    defualt_slot();
    SetTimer("AuctionUpdate", 5000, false);
    #if defined auc_OnGameModeInit
        return auc_OnGameModeInit();
    #else
        return 1;
    #endif
}
   #if defined _ALS_OnGameModeInit
    #undef OnGameModeInit
#else
    #define _ALS_OnGameModeInit
#endif
#define OnGameModeInit auc_OnGameModeInit
#if defined auc_OnGameModeInit
    forward auc_OnGameModeInit();
#endif

public OnPlayerConnect(playerid)
{
    SetTimerEx("PlayerTextDrawAuction", 6000, false, "i", playerid);
    #if defined auc_OnPlayerConnect
        return auc_OnPlayerConnect(playerid);
    #else
        return 1;
    #endif
}
#if defined _ALS_OnPlayerConnect
    #undef OnPlayerConnect
#else
    #define _ALS_OnPlayerConnect
#endif
#define OnPlayerConnect auc_OnPlayerConnect
#if defined auc_OnPlayerConnect
    forward auc_OnPlayerConnect(playerid);
#endif

cmd:tpa(playerid){
    CallLocalFunction("OnPlayerEnterDynamicArea", "ii", playerid, enter_auction);
    return 1;
}

public OnPlayerEnterDynamicArea(playerid, areaid)
{
    if(areaid == enter_auction)
    {
        SetPlayerPosEx(playerid, 999.987854,2489.679443,1499.304687,359.335876, 1, AUCTION_WORLD);
    }
    if(areaid == exit_auction)
    {
        SetPlayerPosEx(playerid, 2090.941650,-2283.999511,23.101566,92.530944, 0, 0);
    }
    #if defined auc_OnPlayerEnterDynamicArea
        return auc_OnPlayerEnterDynamicArea(playerid, STREAMER_TAG_AREA:areaid);
    #else
        return 0;
    #endif
}
   #if defined _ALS_OnPlayerEnterDynamicArea
    #undef OnPlayerEnterDynamicArea
#else
    #define _ALS_OnPlayerEnterDynamicArea
#endif
#define OnPlayerEnterDynamicArea auc_OnPlayerEnterDynamicArea
#if defined auc_OnPlayerEnterDynamicArea
    forward auc_OnPlayerEnterDynamicArea(playerid, STREAMER_TAG_AREA:areaid);
#endif

stock default_select_slot(playerid)
{
    if(player_info_panel[playerid][select_slot] != 0)
    {
        new string[20];
        strcat(string, auction_button[0][0]);
        switch(player_info_panel[playerid][select_slot])
        {
            case 4:PlayerTextDrawSetString(playerid, auction_PTD[playerid][6], string);
            case 1:PlayerTextDrawSetString(playerid, auction_PTD[playerid][10], string);
            case 2:PlayerTextDrawSetString(playerid, auction_PTD[playerid][14], string);
            case 3:PlayerTextDrawSetString(playerid, auction_PTD[playerid][18], string);
        }
    }
    return 1;
}
public OnPlayerClickPlayerTextDraw(playerid, PlayerText:playertextid)
{
    printf("[TD] TextDraw:%d", _:auction_PTD[playerid][0]);
    if(playertextid == auction_PTD[playerid][6])
    {
        default_select_slot(playerid);
        new slot = player_show_slot[playerid][3];
        if(slot == -1) return 1;

        PlayerTextDrawSetString(playerid, auction_PTD[playerid][1], auction_slot[slot][OWNER_SLOT_NAME]);
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][2], type_slot[auction_slot[slot][SLOT_TYPE]]);
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][22], icon_slot[auction_slot[slot][SLOT_TYPE]]);

        new string[13];
        format(string, sizeof string, "%d_rub", auction_slot[slot][START_RATE]);
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][3], string);

        format(string, sizeof string, "%d_rub", auction_slot[slot][CURRENT_RATE]);
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][4], string);

        format(string, 9, "%d_h.",  ConvertUnixTime(auction_slot[slot][TIMER_END] - gettime(), CONVERT_TIME_TO_HOURS));

        PlayerTextDrawSetString(playerid, auction_PTD[playerid][5], string);


        player_info_panel[playerid][select_slot] = 4;
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][6], auction_button[0][1]);

        //SCM(playerid, -1, "SELECTED 4 SLOT");
    }
    if(playertextid == auction_PTD[playerid][10])
    {
        default_select_slot(playerid);

        new slot = player_show_slot[playerid][0];
        if(slot == -1) return 1;

        PlayerTextDrawSetString(playerid, auction_PTD[playerid][1], auction_slot[slot][OWNER_SLOT_NAME]);
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][2], type_slot[auction_slot[slot][SLOT_TYPE]]);
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][22], icon_slot[auction_slot[slot][SLOT_TYPE]]);

        new string[13];
        format(string, sizeof string, "%d_rub", auction_slot[slot][START_RATE]);
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][3], string);

        format(string, sizeof string, "%d_rub", auction_slot[slot][CURRENT_RATE]);
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][4], string);

        format(string, 9, "%d_h.",  ConvertUnixTime(auction_slot[slot][TIMER_END]- gettime(), CONVERT_TIME_TO_HOURS));

        PlayerTextDrawSetString(playerid, auction_PTD[playerid][5], string);


        player_info_panel[playerid][select_slot] = 1;
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][10], auction_button[0][1]);

        //SCM(playerid, -1, "SELECTED 1 SLOT");
    }
    if(playertextid == auction_PTD[playerid][14])
    {
        default_select_slot(playerid);
        new slot = player_show_slot[playerid][1];
        if(slot == -1) return 1;

        PlayerTextDrawSetString(playerid, auction_PTD[playerid][1], auction_slot[slot][OWNER_SLOT_NAME]);
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][2], type_slot[auction_slot[slot][SLOT_TYPE]]);
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][22], icon_slot[auction_slot[slot][SLOT_TYPE]]);

        new string[13];
        format(string, sizeof string, "%d_rub", auction_slot[slot][START_RATE]);
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][3], string);

        format(string, sizeof string, "%d_rub", auction_slot[slot][CURRENT_RATE]);
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][4], string);

        format(string, 9, "%d_h.",  ConvertUnixTime(auction_slot[slot][TIMER_END]- gettime(), CONVERT_TIME_TO_HOURS));

        PlayerTextDrawSetString(playerid, auction_PTD[playerid][5], string);

        player_info_panel[playerid][select_slot] = 2;
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][14], auction_button[0][1]);

        //SCM(playerid, -1, "SELECTED 2 SLOT");
    }
    if(playertextid == auction_PTD[playerid][18])
    {
        default_select_slot(playerid);
        new slot = player_show_slot[playerid][2];
        if(slot == -1) return 1;

        PlayerTextDrawSetString(playerid, auction_PTD[playerid][1], auction_slot[slot][OWNER_SLOT_NAME]);
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][2], type_slot[auction_slot[slot][SLOT_TYPE]]);
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][22], icon_slot[auction_slot[slot][SLOT_TYPE]]);

        new string[13];
        format(string, sizeof string, "%d_rub", auction_slot[slot][START_RATE]);
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][3], string);

        format(string, sizeof string, "%d_rub", auction_slot[slot][CURRENT_RATE]);
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][4], string);

        format(string, 9, "%d_h.",  ConvertUnixTime(auction_slot[slot][TIMER_END] - gettime(), CONVERT_TIME_TO_HOURS));

        PlayerTextDrawSetString(playerid, auction_PTD[playerid][5], string);

        player_info_panel[playerid][select_slot] = 3;
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][18], auction_button[0][1]);

        //SCM(playerid, -1, "SELECTED 3 SLOT");
    }
    if(playertextid == auction_PTD[playerid][23])
    {
        //SCM(playerid, -1, "BUY TAB");
        ShowTabBuy(playerid);
    }
    if(playertextid == auction_PTD[playerid][24])
    {
        //SCM(playerid, -1, "SELL TAB");
        ShowTabSell(playerid);
    }
    if(playertextid == auction_PTD[playerid][25])
    {
        //player_info_panel[playerid][select_tab] = 3;

        //SCM(playerid, -1, "MY TAB");
        ShowTabMy(playerid);
    }
    if(playertextid == auction_PTD[playerid][26])
    {
        HideTextDrawAuction(playerid);
        //SCM(playerid, -1, "EXIT");
    }
    if(playertextid == auction_PTD[playerid][28])
    {
        if(!player_info_panel[playerid][opisanie_tovar]) return SCM(playerid, -1, " First write a description");
        if(player_info_panel[playerid][price_tovar]) return 0;

        Dialog
        (
            playerid, 5991, DIALOG_STYLE_INPUT,
            "{FF0000} Sell",
            "Enter the starting price for your item: (5% auction commission from the final amount)",
            "Next","Back"
        );
        SetPVarInt(playerid, "select_param", 3);
        //SCM(playerid, -1, "PRICE");
    }
    if(playertextid == auction_PTD[playerid][29])
    {
        player_info_panel[playerid][filter_vehicle_model] = 0;
        player_info_panel[playerid][filter_tovar_type] = 0;
        player_info_panel[playerid][filter_type] = 0;
        player_info_panel[playerid][type_tovar] = false;
        player_info_panel[playerid][price_tovar] = false;
        player_info_panel[playerid][tovar] = false;
        player_info_panel[playerid][opisanie_tovar] = false;

        //if(GetPVarInt(playerid, "type_param")) return 1;
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][31], auction_button[6][0]);
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][30], auction_button[5][0]);
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][28], auction_button[7][0]);
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][29], auction_button[4][0]);

        for(new pon = 1; pon < 6;pon++)
        {
            PlayerTextDrawSetString(playerid, auction_PTD[playerid][pon], "-");
        }

        DeletePVar(playerid, "opisanie_param");
        DeletePVar(playerid, "tovar_param_num");
        if(GetPVarInt(playerid, "type_param"))DeletePVar(playerid, "type_param");
        if(GetPVarInt(playerid, "tovar_param_server"))DeletePVar(playerid, "tovar_param_server");
        if(GetPVarInt(playerid, "price_param"))DeletePVar(playerid, "price_param");
        if(GetPVarInt(playerid, "tovar_param"))DeletePVar(playerid, "tovar_param");
        if(GetPVarInt(playerid, "select_type"))DeletePVar(playerid, "select_type");

        Dialog
        (
            playerid, 5991, DIALOG_STYLE_LIST,
            "{FF0000}Sell",
            "1. Car\n"\
            "2. Real estate\n"\
            "3. Business\n"\
            "4. License plate\n"\
            "5. SIM card\n"\
            "6. Clothes",
            "Next", "Back"
        );

        SetPVarInt(playerid, "select_param", 1);
        //SCM(playerid, -1, "TYPE");
    }
    if(playertextid == auction_PTD[playerid][30])
    {
        if(!player_info_panel[playerid][type_tovar]) return SCM(playerid, -1, "First select the item type");
        if(player_info_panel[playerid][tovar]) return 0;

        new text[284];

        switch(GetPVarInt(playerid, "type_param"))
        {
            case TYPE_VEHICLE:
            {
                if(GetPlayerOwnableCar(playerid) != INVALID_VEHICLE_ID)
                {
                    new vehicle = GetPlayerOwnableCar(playerid);
                    new model = GetVehicleModel(vehicle) - 400;
                    new action = GetVehicleData(vehicle, V_ACTION_ID);

                    SetPVarInt(playerid, "tovar_param", GetOwnableCarData(action, OC_SQL_ID));
                    SetPVarInt(playerid, "tovar_param_server", vehicle);

                    format(text, sizeof text, "You want to put the vehicle %s [%d] on auction?", GetVehicleInfo(model, VI_NAME), GetOwnableCarData(action, OC_SQL_ID));

                    Dialog
                    (
                        playerid, 5992, DIALOG_STYLE_MSGBOX,
                        "{FF0000}Sell",
                        text,
                        "Next", "Back"
                    );
                }
                else SendClientMessage(playerid, -1, ""USC" Your vehicle is not loaded on the server");
            }
            case TYPE_BUSINESS:
            {
                if(GetPlayerBusiness(playerid) != -1)
                {
                    new business = GetPlayerBusiness(playerid);
                    new sql = GetBusinessData(business, B_SQL_ID);

                    SetPVarInt(playerid, "tovar_param", sql);
                    SetPVarInt(playerid, "tovar_param_server", business);

                    format(text, sizeof text, "You want to put the business %s on auction?", GetBusinessData(business, B_NAME), sql);

                    Dialog
                    (
                        playerid, 5992, DIALOG_STYLE_MSGBOX,
                        "{FF0000}Sell",
                        text,
                        "Next", "Back"
                    );
                }
                else SendClientMessage(playerid, -1, ""USC" You don't have a business");
            }
            case TYPE_HOUSE:
            {
                if(GetPlayerHouse(playerid) != -1)
                {
                    new house = GetPlayerHouse(playerid);
                    new sql = GetHouseData(house, H_SQL_ID);

                    SetPVarInt(playerid, "tovar_param", sql);
                    SetPVarInt(playerid, "tovar_param_server", house);

                    format(text, sizeof text, "You want to put House %d on auction?", house);

                    Dialog
                    (
                        playerid, 5992, DIALOG_STYLE_MSGBOX,
                        "{FF0000}Sell",
                        text,
                        "Next", "Back"
                    );
                }
                else SendClientMessage(playerid, -1, ""USC" You don't have real estate");
            }
            case TYPE_SUM_NUMBER:
            {
                if(GetPlayerPhone(playerid))
                {
                    new sum = GetPlayerPhone(playerid);

                    SetPVarInt(playerid, "tovar_param", sum);

                    format(text, sizeof text, "You want to put the SIM card %d on auction?", sum);

                    Dialog
                    (
                        playerid, 5992, DIALOG_STYLE_MSGBOX,
                        "{FF0000}Sell",
                        text,
                        "Next", "Back"
                    );
                }
                else SendClientMessage(playerid, -1, ""USC" You don't have a SIM card");
            }
            case TYPE_VEHICLE_NUMBER:
            {
                new Cache:result;

                mysql_format(mysql, text, sizeof text, "SELECT * FROM ownable_cars WHERE owner_id = %d AND number != '------'", GetPlayerAccountID(playerid));
                result = mysql_query(mysql, text);
                if(mysql_errno()) return print("[ERROR AUCTION MYSQL] ID ERROR:: 4");

                if(!cache_num_rows()) return SendClientMessage(playerid, -1, ""USC" You don't have a vehicle with a license plate");

                new rows = cache_num_rows(), query[54], id, model_id, car_number[7];

                format(text, sizeof text, "");

				for(new i = 0; i < rows; i ++)
				{
					id = cache_get_field_content_int(i, "id");
					model_id = cache_get_field_content_int(i, "model_id") - 400;
					cache_get_field_content(i, "number", car_number);

					format(query, sizeof query, "{FFFFFF}%d. %s - %s\n", i + 1, GetVehicleInfo(model_id, VI_NAME), car_number);
					strcat(text, query);
					SetPlayerListitemValue(playerid, i, id);
                    printf("lisitem: %d | id_car: %d", i, id);
				}

                Dialog
                (
                    playerid, 5992, DIALOG_STYLE_LIST,
                    "{FF0000}Sell",
                    text,
                    "Next", "Back"
                );
            }
            case TYPE_CLOTHES:
            {
                new Cache:result;
                format(text, sizeof text, "SELECT * FROM inventory_skins WHERE owner_skin = %d AND use_skin = 0", GetPlayerAccountID(playerid));
                result = mysql_query(mysql, text);
                if(mysql_errno()) return print("[ERROR AUCTION MYSQL] ID ERROR:: 4");

                if(!cache_num_rows()) return SendClientMessage(playerid, -1, ""USC" You don't have any free clothes");

                new rows = cache_num_rows(), query[54], id, model_id;

                format(text, sizeof text, "");

				for(new i = 0; i < rows; i ++)
				{
					id = cache_get_field_content_int(i, "id");
					model_id = cache_get_field_content_int(i, "skin_id");

					format(query, sizeof query, "{FFFFFF}%d. %s\n", i + 1, GetSkinInfo(model_id, S_NAME));
					strcat(text, query);
					SetPlayerListitemValue(playerid, i, id);
				}

                Dialog
                (
                    playerid, 5992, DIALOG_STYLE_LIST,
                    "{FF0000}Sell",
                    text,
                    "Next", "Back"
                );
            }
        }

        //SCM(playerid, -1, "ITEM");
    }
    if(playertextid == auction_PTD[playerid][31])
    {
        if(!player_info_panel[playerid][tovar]) return SCM(playerid, -1, "First select an item");
        if(player_info_panel[playerid][opisanie_tovar]) return 0;

        Dialog
        (
            playerid, 5991, DIALOG_STYLE_INPUT,
           "{FF0000}Sell",
           "Enter a description for your item, the better the description - the faster you can sell your item",
           "Next","Back"
        );

        SetPVarInt(playerid, "select_param", 2);
        //SCM(playerid, -1, "DESCRIPTION");
    }
    if(playertextid == auction_PTD[playerid][33])
    {
        new bool:have_sell, list[48], dialog[284];

        for(new c, account = GetPlayerAccountID(playerid);c < MAX_AUCTION_LIST;c++)
        {
            if(auction_slot[c][OWNER_SLOT_SQL] != account) continue;

            format(list, sizeof list, "%d. %s \t %d h.\n", c + 1, auction_slot[c][SLOT_NAME], ConvertUnixTime(auction_slot[c][TIMER_END] - gettime(), CONVERT_TIME_TO_HOURS));
            strcat(dialog, list);
            have_sell = true;
        }

        if(!have_sell) return ShowNotification(playerid, 2, "You have no active sales", 3, "", "");

        Dialog
        (
            playerid, -1, DIALOG_STYLE_LIST,
            "{FF0000}Sales",
            dialog,
            "Exit", ""
        );

        //SCM(playerid, -1, "MY SALES");
    }
    if(playertextid == auction_PTD[playerid][34])
    {
        new bool:have_buy, list[48], dialog[284];
        for(new c, account = GetPlayerAccountID(playerid);c < MAX_AUCTION_LIST;c++)
        {
            if(auction_slot[c][OWNER_RATE] != account) continue;

            format(list, sizeof list, "%d. %s \t %d h.\n", c + 1, auction_slot[c][SLOT_NAME], ConvertUnixTime(auction_slot[c][TIMER_END] - gettime(), CONVERT_TIME_TO_HOURS));
            strcat(dialog, list);
            have_buy = true;
        }

        if(!have_buy) return ShowNotification(playerid, 2, "You have no active bids", 3, "", "");

        Dialog
        (
            playerid, -1, DIALOG_STYLE_LIST,
            "{FF0000}Purchases",
            dialog,
            "Exit", ""
        );
        //SCM(playerid, -1, "MY PURCHASES");
    }
    if(playertextid == auction_PTD[playerid][37])
    {
        new id_slot, dialog[254];

        switch(player_info_panel[playerid][select_slot])
        {
            case 1:id_slot = player_show_slot[playerid][0];
            case 2:id_slot = player_show_slot[playerid][1];
            case 3:id_slot = player_show_slot[playerid][2];
            case 4:id_slot = player_show_slot[playerid][3];
        }

        if(!auction_slot[id_slot][SLOT_TYPE]) return 0;

        if(auction_slot[id_slot][TIMER_END] <= gettime()) return SendClientMessage(playerid, -1, ""SC" Time is up. The lot will be removed soon.");

        if(GetPlayerMoneyEx(playerid) < auction_slot[id_slot][CURRENT_RATE])
        {
            format(dialog, sizeof dialog, "You have %d, but need %d rubles", GetPlayerMoneyEx(playerid), auction_slot[id_slot][CURRENT_RATE]);
            ShowNotification(playerid, 2, dialog, 2, "", "");

            return 1;
        }
        else if(auction_slot[id_slot][OWNER_SLOT_SQL] == GetPlayerAccountID(playerid))
        {
            SendClientMessage(playerid, -1, ""SC" You cannot bid on your own lot.");
            return 1;
        }
        else if(auction_slot[id_slot][OWNER_RATE] == GetPlayerAccountID(playerid))
        {
            SendClientMessage(playerid, -1, ""SC" You have already placed a bid.");
            return 1;
        }

        switch(auction_slot[id_slot][SLOT_TYPE])
        {
            case TYPE_BUSINESS:
            {
                if(GetPlayerBusiness(playerid) != -1) return SendClientMessage(playerid, -1, ""SC" You already own a business");

                for(new i, account = GetPlayerAccountID(playerid); i < MAX_AUCTION_SLOT; i ++)
                {
                    if(auction_slot[i][SLOT_TYPE] != TYPE_BUSINESS) continue;
                    else if(auction_slot[i][OWNER_RATE] != account) continue;

                    SendClientMessage(playerid, -1, ""SC" You have already bid on another business.");
                    return 1;
                }
            }
            case TYPE_HOUSE:
            {
                if(GetPlayerHouse(playerid) != -1) return SendClientMessage(playerid, -1, ""SC" You already own real estate");

                for(new i, account = GetPlayerAccountID(playerid); i < MAX_AUCTION_SLOT; i ++)
                {
                    if(auction_slot[i][SLOT_TYPE] != TYPE_HOUSE) continue;
                    else if(auction_slot[i][OWNER_RATE] != account) continue;

                    SendClientMessage(playerid, -1, ""SC" You have already bid on another real estate.");
                    return 1;
                }
            }
            case TYPE_VEHICLE_NUMBER:
            {
                new query[128];
                new Cache: result, rows;

                mysql_format(mysql, query, sizeof query, "SELECT * FROM ownable_cars WHERE number = '------' AND owner_id='%d' LIMIT 1", GetPlayerAccountID(playerid));
                result = mysql_query(mysql, query);
                if(mysql_errno()) return print("[ERROR AUCTION MYSQL] ID ERROR:: 5");

                rows = cache_num_rows();

                if(!rows) return SendClientMessage(playerid, -1, ""SC" You don't have a vehicle without a license plate");

                cache_delete(result);
            }
            case TYPE_SUM_NUMBER:
            {
                if(GetPlayerPhone(playerid))
                {
                    for(new i; i < 5; i++) SendClientMessage(playerid, -1, ""USC" You already have a SIM card. Upon winning it will be replaced with a new one");
                }
            }
        }

        new percent = auction_slot[id_slot][CURRENT_RATE] * 98 / 100;
        new da = auction_slot[id_slot][CURRENT_RATE]  - percent;
        new price = da  + auction_slot[id_slot][CURRENT_RATE];

        format(dialog, sizeof dialog,
        "Description from {FFFF00}seller: {FFFFFF}%s\n\n"\
        "{FFFFFF}%s: {FFFF00}%s\n\n"\
        "{FFFFFF}Enter the amount you want to pay for this lot. Minimum bid: {FFFF00}%d rubles",
        auction_slot[id_slot][OPISANIE_SLOT], type_slot[auction_slot[id_slot][SLOT_TYPE]], auction_slot[id_slot][SLOT_NAME],
        price
        );

        Dialog
        (
            playerid, 5990, DIALOG_STYLE_INPUT,
            "{FF0000}Bid",
            dialog,
            "Next", "Back"
        );

        SetPVarInt(playerid, "select_slot", id_slot);

        //SCM(playerid, -1, "PLACE BID");
    }
    if(playertextid == auction_PTD[playerid][38])
    {
        Dialog
        (
            playerid, 5993, DIALOG_STYLE_LIST,
            "{FF0000}Filter",
            "1. Select purchase type\n"\
            "2. Select purchase price",
            "Next", "Back"
        );

        player_info_panel[playerid][filter_type] = 0;
        player_info_panel[playerid][filter_tovar_type] = 0;
        player_info_panel[playerid][count_list] = 1;
        LeafAuction(playerid, 3);
    }
    if(playertextid == auction_PTD[playerid][39])
    {
        if(!player_info_panel[playerid][price_tovar]) return SendClientMessage(playerid, -1, ""USC" First select everything");

        new type, opisanie[124], start, data_base, server_id, number_veh[7], number_phone;

        type = GetPVarInt(playerid, "type_param");

        if(type == TYPE_SUM_NUMBER) number_phone = GetPVarInt(playerid, "tovar_param");

        GetPVarString(playerid, "opisanie_param", opisanie, 124);
        GetPVarString(playerid, "tovar_param_num", number_veh, 7);

        data_base = GetPVarInt(playerid, "tovar_param");
        server_id = GetPVarInt(playerid, "tovar_param_server");
        if(type == TYPE_VEHICLE)
        {
            if(GetPlayerOwnableCar(playerid) != GetPVarInt(playerid, "tovar_param_server"))
                return SendClientMessage(playerid,-1, ""USC" Your vehicle is unloaded");

            server_id = GetVehicleModel(GetPVarInt(playerid, "tovar_param_server"));
        }

        start = GetPVarInt(playerid, "price_param");

        create_auction_slot(playerid, type, opisanie, start, data_base, server_id, number_veh, number_phone);
    }
    if(playertextid == auction_PTD[playerid][35])
    {
        if(player_info_panel[playerid][count_list] == 256) return 1;

        player_info_panel[playerid][count_list]++;

        new all_slot = player_info_panel[playerid][count_list]*4 - 1;

        LeafAuction(playerid, all_slot);
        //UpdateListSlot(playerid, player_info_panel[playerid][count_list]);
        //SCM(playerid, -1, "NEXT LIST");
    }
    if(playertextid == auction_PTD[playerid][36])
    {
        if(player_info_panel[playerid][count_list] == 1) return 1;

        player_info_panel[playerid][count_list]--;

        new all_slot = player_info_panel[playerid][count_list]*4 - 1;

        LeafAuction(playerid, all_slot);
        //UpdateListSlot(playerid, player_info_panel[playerid][count_list]);
        //SCM(playerid, -1, "PREVIOUS LIST");
    }
	#if defined auc_OnPlayerClickPlayer
		return auc_OnPlayerClickPlayer(playerid, playertextid);
	#else
	    return 0;
	#endif
}
#if defined _ALS_OnPlayerClickPlayerTextD
    #undef OnPlayerClickPlayerTextDraw
#else
    #define _ALS_OnPlayerClickPlayerTextD
#endif
#if defined auc_OnPlayerClickPlayer
	forward auc_OnPlayerClickPlayer(playerid, PlayerText:playertextid);
#endif
#define	OnPlayerClickPlayerTextDraw auc_OnPlayerClickPlayer


CMD:auction(playerid)
{
    new hour;

    gettime(hour);

   if(!(8 <= hour <= 21)) return SendClientMessage(playerid, -1, ""USC"Auction works from 8:00 to 22:00");

    if(GetPlayerVirtualWorld(playerid) != AUCTION_WORLD) return
        EnablePlayerGPS(playerid, 55, 2090.941650,-2283.999511,23.101566, "Auction location marked on the map.");

    HideTextDrawAuction(playerid);

    if(player_cd_auction[playerid] < gettime()) HideHud(playerid);

    ShowTabBuy(playerid);
    //SCM(playerid, -1, "Auction Welsi Studio");

    return 1;
}

stock HideTextDrawAuction(playerid)
{
    ShowHud(playerid);

    default_select_slot(playerid);
    switch(player_info_panel[playerid][select_tab])
    {
        case 1:HideTabBuy(playerid);
        case 2:HideTabSell(playerid);
        case 3:HideTabMy(playerid);
    }

    player_info_panel[playerid][count_list] = 1;
    player_info_panel[playerid][show_panel] = false;
    player_info_panel[playerid][select_slot] = 0;
    player_info_panel[playerid][select_type] = 0;
    player_info_panel[playerid][select_tab] = 0;
    player_info_panel[playerid][filter_min_price] = -1;
    player_info_panel[playerid][filter_max_price] = -1;
    player_info_panel[playerid][filter_vehicle_model] = 0;
    player_info_panel[playerid][filter_tovar_type] = 0;
    player_info_panel[playerid][filter_type] = 0;
    player_info_panel[playerid][type_tovar] = false;
    player_info_panel[playerid][price_tovar] = false;
    player_info_panel[playerid][tovar] = false;
    player_info_panel[playerid][opisanie_tovar] = false;

    TogglePlayerControllable(playerid, true);

    return 1;
}

stock ShowTabBuy(playerid)
{
    new time = gettime();
    if(player_cd_auction[playerid] > time) return SendClientMessage(playerid, -1, "Wait a moment...");

    player_cd_auction[playerid] = time+5;
    switch(player_info_panel[playerid][select_tab])
    {
        case 2:HideTabSell(playerid);
        case 3:HideTabMy(playerid);
        case 1:return 1;
    }

    SelectTextDraw(playerid, -1);

    player_info_panel[playerid][select_tab] = 1;

        //load slot auction

    if(player_info_panel[playerid][select_slot])
    {
        new string[34];
        strcat(string, auction_button[0][0]);

        PlayerTextDrawSetString(playerid, auction_PTD[playerid][6], string);
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][10], string);
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][14], string);
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][18], string);

        player_info_panel[playerid][select_slot] = 0;
    }

    for(new p = 1;p < 6;p++) PlayerTextDrawSetString(playerid, auction_PTD[playerid][p], "-");

    PlayerTextDrawSetString(playerid, auction_PTD[playerid][27], "1");
    PlayerTextDrawSetString(playerid, auction_PTD[playerid][0], "txd:braucbuy");

    PlayerTextDrawSetString(playerid, auction_PTD[playerid][23], auction_button[1][1]);
    PlayerTextDrawSetString(playerid, auction_PTD[playerid][24], auction_button[2][0]);
    PlayerTextDrawSetString(playerid, auction_PTD[playerid][25], auction_button[3][0]);

    //PlayerTextDrawShow(playerid, auction_PTD[playerid][0]);
    new all_slot = player_info_panel[playerid][count_list]*4 - 1;
    LeafAuction(playerid, all_slot);

    for(new t; t < 39; t++)
    {
        if(28 <= t <= 34) continue;

        PlayerTextDrawShow(playerid, auction_PTD[playerid][t]);
    }

    return 1;
}

stock ShowTabSell(playerid)
{
    new time = gettime();
    if(player_cd_auction[playerid] > time) return SendClientMessage(playerid, -1, "Wait a moment...");

    player_cd_auction[playerid] = time+5;
    switch(player_info_panel[playerid][select_tab])
    {
        case 1:HideTabBuy(playerid);
        case 3:HideTabMy(playerid);
        default:return 1;
    }

    SelectTextDraw(playerid, -1);

    player_info_panel[playerid][select_tab] = 2;

    PlayerTextDrawSetString(playerid, auction_PTD[playerid][0], "txd:braucsell");

    PlayerTextDrawSetString(playerid, auction_PTD[playerid][23], auction_button[1][0]);
    PlayerTextDrawSetString(playerid, auction_PTD[playerid][24], auction_button[2][1]);
    PlayerTextDrawSetString(playerid, auction_PTD[playerid][25], auction_button[3][0]);


    //PlayerTextDrawSetString(playerid, auction_TD[5]);

    for(new p = 1;p < 5;p++) PlayerTextDrawSetString(playerid, auction_PTD[playerid][p], "-");
    PlayerTextDrawColor(playerid, auction_PTD[playerid][3], -1);
    PlayerTextDrawSetString(playerid, auction_PTD[playerid][5], "No");
    PlayerTextDrawSetString(playerid, auction_PTD[playerid][32], "No");

    //PlayerTextDrawShow(playerid, auction_PTD[playerid][0]);

    for(new t; t < 5; t++)
    {
        PlayerTextDrawShow(playerid, auction_PTD[playerid][t]);
    }
    for(new t = 28; t < 33; t++)
    {
        PlayerTextDrawShow(playerid, auction_PTD[playerid][t]);
    }

    PlayerTextDrawShow(playerid, auction_PTD[playerid][22]);

    for(new b = 23;b < 27;b++) // loop to open tabs
    {
        PlayerTextDrawShow(playerid, auction_PTD[playerid][b]);
    }

    PlayerTextDrawShow(playerid, auction_PTD[playerid][39]);

    return 1;
}

stock HideTabSell(playerid)
{
    CancelSelectTextDraw(playerid);
    player_info_panel[playerid][type_tovar] = false;
    player_info_panel[playerid][price_tovar] = false;
    player_info_panel[playerid][tovar] = false;
    player_info_panel[playerid][opisanie_tovar] = false;

    PlayerTextDrawHide(playerid, auction_PTD[playerid][39]);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][3], -1107374134);

    for(new t; t < 6; t++)
    {
        PlayerTextDrawHide(playerid, auction_PTD[playerid][t]);
    }

    PlayerTextDrawHide(playerid, auction_PTD[playerid][22]);

    for(new t = 28; t < 33; t++)
    {
        PlayerTextDrawHide(playerid, auction_PTD[playerid][t]);
    }

    for(new b = 23;b < 27;b++) // loop to open tabs
    {
        PlayerTextDrawHide(playerid, auction_PTD[playerid][b]);
    }
    return 1;
}

stock HideTabBuy(playerid)
{
    default_select_slot(playerid);
    CancelSelectTextDraw(playerid);
    player_info_panel[playerid][count_list] = 1;
    player_info_panel[playerid][show_panel] = false;
    player_info_panel[playerid][select_slot] = 0;
    player_info_panel[playerid][select_type] = 0;
    player_info_panel[playerid][select_tab] = 0;
    player_info_panel[playerid][filter_min_price] = -1;
    player_info_panel[playerid][filter_max_price] = -1;

    for(new t = 35; t < 39; t++)
    {
        PlayerTextDrawHide(playerid, auction_PTD[playerid][t]);
    }

    for(new t; t < 28; t++)
    {
        PlayerTextDrawHide(playerid, auction_PTD[playerid][t]);
    }
    return 1;
}

stock HideTabMy(playerid)
{
    CancelSelectTextDraw(playerid);

    PlayerTextDrawDestroy(playerid, auction_PTD[playerid][0]);
    for(new i = 23;i < 27;i++) PlayerTextDrawDestroy(playerid, auction_PTD[playerid][i]);

    auction_PTD[playerid][0] = CreatePlayerTextDraw(playerid, 27.3333, 100.2444, "txd:braucbuy"); // background / base
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][0], 588.0000, 294.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][0], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][0], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][0], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][0], 4);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][0], 0);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][0], 0);

    auction_PTD[playerid][23] = CreatePlayerTextDraw(playerid, 43.3333, 125.1333, "txd:braucubuy"); // buy tab
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][23], 109.0000, 62.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][23], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][23], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][23], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][23], 4);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][23], 0);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][23], 0);
    PlayerTextDrawSetSelectable(playerid, auction_PTD[playerid][23], 1);

    auction_PTD[playerid][24] = CreatePlayerTextDraw(playerid, 43.3333, 170.3481, "txd:braucnusell"); // sell tab
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][24], 109.0000, 62.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][24], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][24], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][24], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][24], 4);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][24], 0);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][24], 0);
    PlayerTextDrawSetSelectable(playerid, auction_PTD[playerid][24], 1);

    auction_PTD[playerid][25] = CreatePlayerTextDraw(playerid, 43.6666, 216.8074, "txd:braucnumy"); // my tab
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][25], 109.0000, 61.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][25], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][25], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][25], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][25], 4);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][25], 0);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][25], 0);
    PlayerTextDrawSetSelectable(playerid, auction_PTD[playerid][25], 1);

    auction_PTD[playerid][26] = CreatePlayerTextDraw(playerid, 43.3333, 285.6667, "txd:braucexit"); // exit
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][26], 109.0000, 62.0000);
    PlayerTextDrawAlignment(playerid, auction_PTD[playerid][26], 1);
    PlayerTextDrawColor(playerid, auction_PTD[playerid][26], -1);
    PlayerTextDrawBackgroundColor(playerid, auction_PTD[playerid][26], 255);
    PlayerTextDrawFont(playerid, auction_PTD[playerid][26], 4);
    PlayerTextDrawSetProportional(playerid, auction_PTD[playerid][26], 0);
    PlayerTextDrawSetShadow(playerid, auction_PTD[playerid][26], 0);
    PlayerTextDrawSetSelectable(playerid, auction_PTD[playerid][26], 1);

    PlayerTextDrawHide(playerid, auction_PTD[playerid][0]);

    for(new t = 23; t < 27;t++)
    {
        PlayerTextDrawHide(playerid, auction_PTD[playerid][t]);
    }

    PlayerTextDrawHide(playerid, auction_PTD[playerid][33]);
    PlayerTextDrawHide(playerid, auction_PTD[playerid][34]);

    return 1;
}

stock ShowTabMy(playerid)
{
    new time = gettime();
    if(player_cd_auction[playerid] > time) return SendClientMessage(playerid, -1, "Wait a moment...");

    player_cd_auction[playerid] = time+5;
    switch(player_info_panel[playerid][select_tab])
    {
        case 1:HideTabBuy(playerid);
        case 2:HideTabSell(playerid);
        default:return 1;
    }

    SelectTextDraw(playerid, -1);

    player_info_panel[playerid][select_tab] = 3;

    PlayerTextDrawDestroy(playerid, auction_PTD[playerid][0]);
    for(new i = 23;i < 27;i++) PlayerTextDrawDestroy(playerid, auction_PTD[playerid][i]);

    auction_PTD[playerid][0] = CreatePlayerTextDraw(playerid, 83.9999, 103.5629, "txd:braucmy"); // empty
    PlayerTextDrawTextSize(playerid, auction_PTD[playerid][0], 462.0000, 256.0000);
    PlayerTextDrawAlignment(playerid,auction_PTD[playerid][0], 1);
    PlayerTextDrawColor(playerid,auction_PTD[playerid][0], -1);
    PlayerTextDrawBackgroundColor(playerid,auction_PTD[playerid][0], 255);
    PlayerTextDrawFont(playerid,auction_PTD[playerid][0], 4);
    PlayerTextDrawSetProportional(playerid,auction_PTD[playerid][0], 0);
    PlayerTextDrawSetShadow(playerid,auction_PTD[playerid][0], 0);

    auction_PTD[playerid][23] = CreatePlayerTextDraw(playerid,97.3332, 115.5925, "txd:braucnubuy"); // empty
    PlayerTextDrawTextSize(playerid,auction_PTD[playerid][23], 120.0000, 68.0000);
    PlayerTextDrawAlignment(playerid,auction_PTD[playerid][23], 1);
    PlayerTextDrawColor(playerid,auction_PTD[playerid][23], -1);
    PlayerTextDrawBackgroundColor(playerid,auction_PTD[playerid][23], 255);
    PlayerTextDrawFont(playerid,auction_PTD[playerid][23], 4);
    PlayerTextDrawSetProportional(playerid,auction_PTD[playerid][23], 0);
    PlayerTextDrawSetShadow(playerid,auction_PTD[playerid][23], 0);
    PlayerTextDrawSetSelectable(playerid,auction_PTD[playerid][23], 1);

    auction_PTD[playerid][24] = CreatePlayerTextDraw(playerid,97.6666, 164.5406, "txd:braucnusell"); // empty
    PlayerTextDrawTextSize(playerid,auction_PTD[playerid][24], 120.0000, 68.0000);
    PlayerTextDrawAlignment(playerid,auction_PTD[playerid][24], 1);
    PlayerTextDrawColor(playerid,auction_PTD[playerid][24], -1);
    PlayerTextDrawBackgroundColor(playerid,auction_PTD[playerid][24], 255);
    PlayerTextDrawFont(playerid,auction_PTD[playerid][24], 4);
    PlayerTextDrawSetProportional(playerid,auction_PTD[playerid][24], 0);
    PlayerTextDrawSetShadow(playerid,auction_PTD[playerid][24], 0);
    PlayerTextDrawSetSelectable(playerid,auction_PTD[playerid][24], 1);

    auction_PTD[playerid][25] = CreatePlayerTextDraw(playerid,97.6666, 213.4888, "txd:braucumy"); // empty
    PlayerTextDrawTextSize(playerid,auction_PTD[playerid][25], 120.0000, 68.0000);
    PlayerTextDrawAlignment(playerid,auction_PTD[playerid][25], 1);
    PlayerTextDrawColor(playerid,auction_PTD[playerid][25], -1);
    PlayerTextDrawBackgroundColor(playerid,auction_PTD[playerid][25], 255);
    PlayerTextDrawFont(playerid,auction_PTD[playerid][25], 4);
    PlayerTextDrawSetProportional(playerid,auction_PTD[playerid][25], 0);
    PlayerTextDrawSetShadow(playerid,auction_PTD[playerid][25], 0);
    PlayerTextDrawSetSelectable(playerid,auction_PTD[playerid][25], 1);

    auction_PTD[playerid][26] = CreatePlayerTextDraw(playerid,97.6666, 272.3926, "txd:braucexit"); // empty
    PlayerTextDrawTextSize(playerid,auction_PTD[playerid][26], 120.0000, 62.0000);
    PlayerTextDrawAlignment(playerid,auction_PTD[playerid][26], 1);
    PlayerTextDrawColor(playerid,auction_PTD[playerid][26], -1);
    PlayerTextDrawBackgroundColor(playerid,auction_PTD[playerid][26], 255);
    PlayerTextDrawFont(playerid,auction_PTD[playerid][26], 4);
    PlayerTextDrawSetProportional(playerid,auction_PTD[playerid][26], 0);
    PlayerTextDrawSetShadow(playerid,auction_PTD[playerid][26], 1);
    PlayerTextDrawSetSelectable(playerid,auction_PTD[playerid][26], 1);

    PlayerTextDrawShow(playerid, auction_PTD[playerid][0]);

    for(new t = 23; t < 27;t++)
    {
        PlayerTextDrawShow(playerid, auction_PTD[playerid][t]);
    }

    PlayerTextDrawShow(playerid, auction_PTD[playerid][33]);
    PlayerTextDrawShow(playerid, auction_PTD[playerid][34]);

    return 1;
}

public:AuctionUpdate()
{
    if(!load_business_action)
    {
        SetTimer("AuctionUpdate", 1000, true);
        LoadBusinessToAuction();
    }

    new hour;

    gettime(hour);

    //if(hour >= 22) return 0;

    for(new slot;slot < MAX_AUCTION_SLOT; slot++)
    {
        if(!auction_slot[slot][SLOT_TYPE]) continue;

        if(auction_slot[slot][TIMER_END] <= gettime()) finish_auction_slot(slot);
        else auction_slot[slot][TIMER_END]--;
    }

    return 1;
}

stock create_auction_slot(playerid, type, opisanie[124], start_rate, data_base, server_id, number_vehicle[7] = "", number_SUM = 0)
{
    new id = -1, bool:stop_create;

    PlayerTextDrawSetString(playerid, auction_PTD[playerid][31], auction_button[6][0]);
    PlayerTextDrawSetString(playerid, auction_PTD[playerid][30], auction_button[5][0]);
    PlayerTextDrawSetString(playerid, auction_PTD[playerid][28], auction_button[7][0]);
    PlayerTextDrawSetString(playerid, auction_PTD[playerid][29], auction_button[4][0]);

    DeletePVar(playerid, "opisanie_param");
    DeletePVar(playerid, "tovar_param_num");
    DeletePVar(playerid, "type_param");
    DeletePVar(playerid, "tovar_param_server");
    DeletePVar(playerid, "price_param");
    DeletePVar(playerid, "tovar_param");
    DeletePVar(playerid, "select_type");

    for(new pon = 1; pon < 6;pon++)
    {
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][pon], "-");
    }

    for(new s;s < MAX_AUCTION_SLOT;s++)
    {
        if(auction_slot[s][OWNER_SLOT_SQL] == GetPlayerAccountID(playerid))
        {
            if(auction_slot[s][DATABASE_ID] == data_base && auction_slot[s][SERVER_ID] == server_id)
            {
                if(auction_slot[s][SLOT_TYPE] == type)
                {
                    stop_create = true;
                    break;
                }

            }

            if(auction_slot[s][SLOT_TYPE] == TYPE_VEHICLE_NUMBER)
            {
                if(strfind(number_vehicle, auction_slot[s][NUMBER_VEHICLE], true) != -1)
                {
                    stop_create = true;
                    break;
                }
            }

            if(auction_slot[s][SLOT_TYPE] == TYPE_SUM_NUMBER)
            {
                if(auction_slot[s][NUMBER_SUM] == number_SUM)
                {
                    stop_create = true;
                    break;
                }
            }
        }

    }

    if(stop_create) return SendClientMessage(playerid, -1, ""USC" You have already listed this item.");

    for(new s; s < MAX_AUCTION_SLOT;s++)
    {
        if(auction_slot[s][SLOT_TYPE] >= 1) continue;

        id = s;
        break;
    }

    if(id == -1) return SendClientMessage(playerid, -1, ""SC" The auction slot limit has been reached at the moment.");

    auction_slot[id][OWNER_SLOT_SQL] = GetPlayerAccountID(playerid);
    auction_slot[id][SLOT_TYPE] = type;
    auction_slot[id][START_RATE] = start_rate;
    auction_slot[id][CURRENT_RATE] = start_rate;
    auction_slot[id][DATABASE_ID] = data_base;
    auction_slot[id][SERVER_ID] = server_id;
    format(auction_slot[id][OWNER_SLOT_NAME], 24, GetPlayerNameEx(playerid));
    format(auction_slot[id][OPISANIE_SLOT], 124, opisanie);

    new hour;

    gettime(hour);

    new hour_before_22 = 22 - hour;

    switch(hour_before_22)
    {
        case 0..3:
        {
            new hours, minutes, seconds;
            gettime(hours, minutes, seconds);

            new nh = 22 - hours;
            new nm = 59 - minutes;
            new ns = 59 - seconds;

            new time = (nh * 3600) + (nm * 60) + seconds - 3;

            auction_slot[id][TIMER_END] = gettime() + time;
        }
        default:
        {
             auction_slot[id][TIMER_END] = gettime() + 3600 * 3;
        }
    }

    switch(type)
    {
        case TYPE_BUSINESS:
        {
            for(new s;s < MAX_BUSINESS;s++)
            {
                if(GetBusinessData(s, B_SQL_ID) == data_base)
                {
                    auction_slot[id][SERVER_ID] = s;
                    format(auction_slot[id][SLOT_NAME], 24, GetBusinessData(s, B_NAME));
                    break;
                }
            }
        }
        case TYPE_VEHICLE:
        {

            new id_model = server_id - 400;

            format(auction_slot[id][SLOT_NAME], 24, ProbelText(GetVehicleInfo(id_model, VI_NAME)));
            UnloadPlayerOwnableCar(playerid);
        }
        case TYPE_HOUSE:
        {
            for(new s;s < MAX_HOUSES;s++)
            {
                if(GetHouseData(s, H_SQL_ID) == data_base)
                {
                    auction_slot[id][SERVER_ID] = s;
                    format(auction_slot[id][SLOT_NAME], 24, "House_(%d)", s);
                    break;
                }
            }
        }
        case TYPE_VEHICLE_NUMBER:
        {
            format(auction_slot[id][SLOT_NAME], 24, number_vehicle);
            format(auction_slot[id][NUMBER_VEHICLE], 7, number_vehicle);
        }
        case TYPE_SUM_NUMBER:
        {
            auction_slot[id][NUMBER_SUM] = number_SUM;

            new sum[6];
            valstr(sum, number_SUM);
            format(auction_slot[id][SLOT_NAME], 24, sum);
        }
        case TYPE_CLOTHES:
        {
            format(auction_slot[id][SLOT_NAME], 24, GetSkinName(server_id));
        }
    }



    SendClientMessage(playerid, -1, ""SC" You have listed a slot on the auction");

    return 1;
}

stock finish_auction_slot(slot)
{
    if(auction_slot[slot][OWNER_RATE] == -1) reset_slot_auction(slot);

    new bool:money_give;

    foreach(new i : Player)
    {
        if(auction_slot[slot][OWNER_SLOT_SQL] == GetPlayerAccountID(i))
        {
            SendClientMessage(i, -1, ""SC" Congratulations! You have received money for the auction slot");
            money_give = true;
            GivePlayerMoneyEx(i, auction_slot[slot][CURRENT_RATE] );
        }
    }

    new query[128];

    if(!money_give)
    {
        mysql_format(mysql, query, sizeof query, "UPDATE accounts SET money = money + %d WHERE id=%d", auction_slot[slot][CURRENT_RATE], auction_slot[slot][OWNER_SLOT_SQL]);
        mysql_query(mysql, query, false);
        if(mysql_errno()) return print("[ERROR AUCTION MYSQL] ID ERROR:: 6");
    }


    switch(auction_slot[slot][SLOT_TYPE])
    {
        case TYPE_BUSINESS:
        {
            foreach(new i : Player)
            {
                if(auction_slot[slot][OWNER_RATE] == GetPlayerAccountID(i)) SendClientMessage(i, -1, ""SC" Congratulations! You have received the business from the auction");
            }

            AuctionBusiness(auction_slot[slot][OWNER_RATE], slot);
        }
        case TYPE_HOUSE:
        {
            foreach(new i : Player)
            {
                if(auction_slot[slot][OWNER_RATE] == GetPlayerAccountID(i)) SendClientMessage(i, -1, ""SC" Congratulations! You have received the real estate from the auction");
            }

            AuctionHouse(slot,auction_slot[slot][OWNER_RATE], auction_slot[slot][SERVER_ID]);
        }
        case TYPE_VEHICLE:
        {
            foreach(new i : Player)
            {
                if(auction_slot[slot][OWNER_RATE] == GetPlayerAccountID(i)) SendClientMessage(i, -1, ""SC" Congratulations! You have received the vehicle from the auction");
            }

            mysql_format(mysql, query, sizeof query, "UPDATE ownable_cars SET owner_id=%d WHERE id=%d", auction_slot[slot][OWNER_RATE], auction_slot[slot][DATABASE_ID]);
            mysql_query(mysql, query, false);

            /*mysql_format(mysql, query, sizeof query, "UPDATE ownable_cars SET owner_id=%d WHERE id=%d", auction_slot[slot][OWNER_RATE], auction_slot[slot][DATABASE_ID]);
            mysql_query(mysql, query, false);*/

            reset_slot_auction(slot);
            if(mysql_errno()) return print("[ERROR AUCTION MYSQL] ID ERROR:: 7");
        }
        case TYPE_VEHICLE_NUMBER:
        {
            foreach(new i : Player)
            {
                if(GetPlayerAccountID(i) == auction_slot[slot][OWNER_RATE]) SendClientMessage(i, -1, ""SC" Congratulations! You have purchased the license plate");
                if(GetPlayerAccountID(i) == auction_slot[slot][OWNER_SLOT_SQL]) SendClientMessage(i, -1, ""SC" Congratulations! You have sold the license plate");
            }

            mysql_format(mysql, query, sizeof query, "UPDATE ownable_cars SET number='%s' WHERE owner_id='%d' AND number = '------' LIMIT 1", auction_slot[slot][NUMBER_VEHICLE], auction_slot[slot][OWNER_RATE]);
            mysql_query(mysql, query, false);
            if(mysql_errno()) return print("[ERROR AUCTION MYSQL] ID ERROR:: 8");

            mysql_format(mysql, query, sizeof query, "UPDATE ownable_cars SET number='------' WHERE owner_id='%d' AND number = '%s' LIMIT 1", auction_slot[slot][OWNER_SLOT_SQL], auction_slot[slot][NUMBER_VEHICLE]);
            mysql_query(mysql, query, false);

            if(mysql_errno()) return print("[ERROR AUCTION MYSQL] ID ERROR:: 8.1");

            reset_slot_auction(slot);
        }
        case TYPE_SUM_NUMBER:
        {

            foreach(new i : Player)
            {
                if(GetPlayerAccountID(i) == auction_slot[slot][OWNER_RATE])
                {
                    SetPlayerData(i, P_PHONE, auction_slot[slot][NUMBER_SUM]);
                    SendClientMessage(i, -1, ""SC" Congratulations! You have purchased the SIM card from the auction");
                }

                if(GetPlayerAccountID(i) == auction_slot[slot][OWNER_SLOT_SQL])
                {
                    SetPlayerData(i, P_PHONE, 0);
                    SendClientMessage(i, -1, ""SC" Congratulations! You have sold the SIM card from the auction");
                }
            }

            mysql_format(mysql, query, sizeof query, "UPDATE accounts SET phone = %d WHERE id = %d", auction_slot[slot][NUMBER_SUM], auction_slot[slot][OWNER_RATE]);
            mysql_query(mysql, query, false);
            if(mysql_errno()) return print("[ERROR AUCTION MYSQL] ID ERROR:: 9");

            mysql_format(mysql, query, sizeof query, "UPDATE accounts SET phone = 0 WHERE id = %d", auction_slot[slot][OWNER_SLOT_SQL]);
            mysql_query(mysql, query, false);
            if(mysql_errno()) return print("[ERROR AUCTION MYSQL] ID ERROR:: 9.1");

            reset_slot_auction(slot);
        }
        case TYPE_CLOTHES:
        {
            foreach(new i : Player)
            {
                if(GetPlayerAccountID(i) == auction_slot[slot][OWNER_RATE]) SendClientMessage(i, -1, ""SC" Congratulations! You have purchased the clothes from the auction");
                if(GetPlayerAccountID(i) == auction_slot[slot][OWNER_SLOT_SQL]) SendClientMessage(i, -1, ""SC" Congratulations! You have sold the clothes from the auction");
            }

            new fmt_text[144],
            Cache: result;

            mysql_format(mysql, query, sizeof query, "INSERT INTO inventory_skins (owner_skin,skin_id) VALUES (%d,%d)", auction_slot[slot][OWNER_RATE], auction_slot[slot][SERVER_ID]);
            mysql_query(mysql, query, false);
            if(mysql_errno()) return print("[ERROR AUCTION MYSQL] ID ERROR:: 10");

            mysql_format(mysql, query, sizeof query, "DELETE FROM inventory_skins WHERE id = %d", auction_slot[slot][DATABASE_ID]);
            mysql_query(mysql, query, false);
            if(mysql_errno()) return print("[ERROR AUCTION MYSQL] ID ERROR:: 10.1");

            reset_slot_auction(slot);
        }

    }
    return 1;
}

stock reset_slot_auction(slot)
{
    auction_slot[slot][SLOT_TYPE] = 0;
    auction_slot[slot][OWNER_SLOT_SQL] = -1;
    format(auction_slot[slot][OWNER_SLOT_NAME], 24, "-");
    format(auction_slot[slot][SLOT_NAME], 32, "-");
    format(auction_slot[slot][OPISANIE_SLOT], 124, "-");
    format(auction_slot[slot][NUMBER_VEHICLE], 7, "-");
    auction_slot[slot][OWNER_RATE] = -1;
    auction_slot[slot][START_RATE] = 0;
    auction_slot[slot][CURRENT_RATE] = 0;
    auction_slot[slot][TIMER_END] = 0;
    auction_slot[slot][DATABASE_ID] = -1;
    auction_slot[slot][SERVER_ID] = -1;
    auction_slot[slot][NUMBER_SUM] = 0;

    return 1;
}

stock AuctionBusiness(sql_id, slot)//Author of this system https://t.me/welsistudio (Welsi Studio)
{
        new query[256];
        new player = -1, businessid = auction_slot[slot][SERVER_ID];


        foreach(new i : Player)
        {
            if(sql_id == GetPlayerAccountID(i)) player = i;
        }

        foreach(new i : Player)
        {
            if(auction_slot[slot][OWNER_SLOT_SQL] == GetPlayerAccountID(i)) SetPlayerData(i, P_BUSINESS, -1);
        }


        mysql_format(mysql, query, sizeof query, "UPDATE accounts SET business=-1 WHERE id=%d", auction_slot[slot][OWNER_SLOT_SQL]);
        mysql_query(mysql, query, false);
        if(mysql_errno()) return print("[ERROR AUCTION MYSQL] ID ERROR:: 11");

        mysql_format(mysql, query, sizeof query, "UPDATE accounts a, business b SET a.business=%d,b.owner_id=%d WHERE a.id=%d AND b.id=%d", businessid, sql_id, sql_id, GetBusinessData(businessid, B_SQL_ID));
        mysql_query(mysql, query, false);
        if(mysql_errno()) return print("[ERROR AUCTION MYSQL] ID ERROR:: 11.1");
        printf("sql %s", query);

        if(!mysql_errno())
        {
            SetPlayerData(player, P_BUSINESS, businessid);

            SetBusinessData(businessid, B_OWNER_ID, sql_id);

            // TCompany wiring: the generic auction-win path above handles
            // every business type uniformly via B_OWNER_ID; trucking companies
            // additionally need a staff-table row + JOB_TRUCKER assignment.
            if(GetBusinessData(businessid, B_TYPE) == BUSINESS_TYPE_TRUCKING_COMPANY)
                TCompany_AuctionAssignOwner(sql_id, businessid);
            SetBusinessData(businessid, B_IMPROVEMENTS, 	0);

            new time = gettime();//Author of this system https://t.me/welsistudio (Welsi Studio)
            new rent_time = (time - (time % 86400)) + 86400;


            SetBusinessData(businessid,	B_PRODS, 		20);
            SetBusinessData(businessid,	B_PROD_PRICE, 	0);

            SetBusinessData(businessid,	B_ENTER_MUSIC, 	0);
            SetBusinessData(businessid,	B_ENTER_PRICE, 	0);

            SetBusinessData(businessid,	B_BALANCE, 		0);
            SetBusinessData(businessid,	B_RENT_DATE,	rent_time);
            SetBusinessData(businessid,	B_LOCK_STATUS,	false);

            new name[24], Cache:result;

            mysql_format(mysql, query, sizeof query, "SELECT name FROM accounts WHERE id = %d", sql_id);
            result = mysql_query(mysql, query);
            if(mysql_errno()) return print("[ERROR AUCTION MYSQL] ID ERROR:: 11.2");

            cache_get_row(0, 0, name);//Author of this system https://t.me/welsistudio (Welsi Studio)
            if(mysql_errno()) return print("error name label to business");

            format(g_business[businessid][B_OWNER_NAME], 21, name, 0);
            CallLocalFunction("UpdateBusinessLabel", "i", businessid);

            cache_delete(result);

            SendClientMessage(player, 0x66CC00FF, "Type {0099FF}/business {66CC00}to learn about possibilities");

            format(query, sizeof query, "UPDATE business SET improvements=0,products=%d,prod_price=%d,balance=%d,rent_time=%d,`lock`=%d WHERE id=%d LIMIT 1", GetBusinessData(businessid, B_PRODS), GetBusinessData(businessid, B_PROD_PRICE), GetBusinessData(businessid, B_BALANCE), GetBusinessData(businessid, B_RENT_DATE), GetBusinessData(businessid, B_LOCK_STATUS), GetBusinessData(businessid, B_SQL_ID));
            mysql_query(mysql, query, false);
            if(mysql_errno()) return print("[ERROR AUCTION MYSQL] ID ERROR:: 11.3");

            format(query, sizeof query, "UPDATE business_profit SET view=0 WHERE bid=%d AND view=1", GetBusinessData(businessid, B_SQL_ID));
            mysql_query(mysql, query, false);
            if(mysql_errno()) return print("[ERROR AUCTION MYSQL] ID ERROR:: 11.4");
            reset_slot_auction(slot);

            return 1;
        }

        return 0;
}//Author of this system https://t.me/welsistudio (Welsi Studio)

public: SetBusinessName()
{
    new text[124];

    mysql_format(mysql, text, sizeof text, "UPDATE business SET `name`='Store 24/7' WHERE `type` = 1");
    mysql_query(mysql, text, false);

    mysql_format(mysql, text, sizeof text, "UPDATE business SET `name`='Club' WHERE `type` = 2");
    mysql_query(mysql, text, false);

    mysql_format(mysql, text, sizeof text, "UPDATE business SET `name`='Statistics Management' WHERE `type` = 3");
    mysql_query(mysql, text, false);

    mysql_format(mysql, text, sizeof text, "UPDATE business SET `name`='Real Estate Agency' WHERE `type` = 4");
    mysql_query(mysql, text, false);

    mysql_format(mysql, text, sizeof text, "UPDATE business SET `name`='Clothing Store' WHERE `type` = 5");
    mysql_query(mysql, text, false);

    mysql_format(mysql, text, sizeof text, "UPDATE business SET `name`='Hotel' WHERE `type` = 6");
    mysql_query(mysql, text, false);

    mysql_format(mysql, text, sizeof text, "UPDATE business SET `name`='Dealership' WHERE `type` = 7");
    mysql_query(mysql, text, false);

    mysql_format(mysql, text, sizeof text, "UPDATE business SET `name`='Casino' WHERE `type` = 8");
    mysql_query(mysql, text, false);

    mysql_format(mysql, text, sizeof text, "UPDATE business SET `name`='Service Station' WHERE `type` = 10");
    mysql_query(mysql, text, false);

    mysql_format(mysql, text, sizeof text, "UPDATE business SET `name`='Mobile Phone Store' WHERE `type` = 9");
    mysql_query(mysql, text, false);

    mysql_format(mysql, text, sizeof text, "UPDATE business SET `name`='Gun Store' WHERE `type` = 11");
    mysql_query(mysql, text, false);

    if(mysql_errno()) print("ERROR AUCTION UPDATE NAME BUSINESS SQL");

}

public:LoadBusinessToAuction()
{
    load_business_action = true;

    new text[114], Cache:result;
    mysql_format(mysql, text, sizeof text, "SELECT * FROM business WHERE `owner_id` = 0");
    result = mysql_query(mysql, text, true);
    if(mysql_errno()) return print("[ERROR AUCTION MYSQL] ID ERROR:: 12");

    if(mysql_errno()) return print("error_sql auction business");

    new memory = cache_num_rows(), da = 1;

    if(!memory) return 1;

    for(new b;b < memory;b++)
    {
        if(auction_slot[b][SLOT_TYPE] != 0) continue;

        auction_slot[b][SLOT_TYPE] = 1;
        auction_slot[b][OWNER_SLOT_SQL] = -2;
        auction_slot[b][OWNER_RATE] = -1;

        format(auction_slot[b][OWNER_SLOT_NAME], 24, "State");

        cache_get_field_content(b, "name", auction_slot[b][SLOT_NAME], mysql, 24);

        //printf("name: %s", auction_slot[b][SLOT_NAME]);
        auction_slot[b][DATABASE_ID] = cache_get_field_content_int(b, "id");
        auction_slot[b][START_RATE] = cache_get_field_content_int(b, "price");
        auction_slot[b][CURRENT_RATE] = auction_slot[b][START_RATE];

        new hours, munite, seconds;

        gettime(hours, munite, seconds);

        //printf("%d %d %d ", hours, munite, seconds);

        //if(hours > 22) return 1;

        new h = 21 - hours;
        new m = 59 - munite;
        new s = 59 - seconds;

        new nh = (h*3600) + (m*60) + s - 10;

        if(nh <= 3600) nh = 1800;

        //printf("timer %d", nh);

        auction_slot[b][TIMER_END] = gettime() + nh;


        //new business_id;

        for(new sql;sql < MAX_BUSINESS;sql++)
        {
            if(GetBusinessData(sql, B_SQL_ID) == auction_slot[b][DATABASE_ID])
            {
                auction_slot[b][SERVER_ID] = sql;

                format(auction_slot[b][OPISANIE_SLOT], 124, "Business (%d)", sql);
                break;
            }
        }

        da++;
    }

    printf("%d", da);

    cache_delete(result);
//Author of this system https://t.me/welsistudio (Welsi Studio)
    return 1;
}

stock defualt_slot()
{
    for(new WELSI; WELSI < MAX_AUCTION_SLOT; WELSI++)
    {
        auction_slot[WELSI][SLOT_TYPE] = 0;
        auction_slot[WELSI][OWNER_SLOT_SQL] = -1;
        format(auction_slot[WELSI][OWNER_SLOT_NAME], 24, "-");
        format(auction_slot[WELSI][SLOT_NAME], 24, "-");
        format(auction_slot[WELSI][OPISANIE_SLOT], 124, "-");
        format(auction_slot[WELSI][NUMBER_VEHICLE], 7 , "-");
        auction_slot[WELSI][OWNER_RATE] = -1;
        auction_slot[WELSI][START_RATE] = 0;
        auction_slot[WELSI][CURRENT_RATE] = 0;
        auction_slot[WELSI][TIMER_END] = 0;
        auction_slot[WELSI][DATABASE_ID] = 0;
        auction_slot[WELSI][SERVER_ID] = 0;
        auction_slot[WELSI][NUMBER_SUM] = 0;
    }
}

stock AuctionHouse(slot, win_slot, houseid)
{
    new query[256];

    foreach(new i : Player)
    {
        if(auction_slot[slot][OWNER_SLOT_SQL] == GetPlayerAccountID(i))
        {
            SetPlayerData(i, P_HOUSE, -1);
            SetPlayerData(i, P_HOUSE_TYPE, -1);
        }
    }

    mysql_format(mysql, query, sizeof query, "UPDATE accounts SET house_type = -1, house = -1 WHERE id=%d", auction_slot[slot][OWNER_SLOT_SQL]);
    mysql_query(mysql, query, false);

    format(query, sizeof query, "UPDATE accounts a, houses h SET a.house_type=%d,a.house=%d,h.owner_id=%d WHERE a.id=%d AND h.id=%d", HOUSE_TYPE_HOME, houseid, win_slot, win_slot, GetHouseData(houseid, H_SQL_ID));
    mysql_query(mysql, query, false);
    if(mysql_errno()) return print("[ERROR AUCTION MYSQL] ID ERROR:: 13");
    printf("sql %s", query);

    if(!mysql_errno())
    {
        foreach(new i : Player)
        {
            if(GetPlayerAccountID(i) == win_slot)
            {
                SetPlayerData(i, P_HOUSE, 		houseid);
                SetPlayerData(i, P_HOUSE_TYPE, 	HOUSE_TYPE_HOME);
            }
        }


        SetHouseData(houseid, H_OWNER_ID, win_slot);
        SetHouseData(houseid, H_IMPROVEMENTS, 	0);

        SetHouseData(houseid, H_STORE_X, 0.0);
        SetHouseData(houseid, H_STORE_Y, 0.0);
        SetHouseData(houseid, H_STORE_Z, 0.0);

        new time = gettime();
        new rent_time = (time - (time % 86400)) + 86400;

        SetHouseData(houseid,	H_RENT_DATE,	rent_time);
        SetHouseData(houseid,	H_LOCK_STATUS,	false);

        new entranceid = GetHouseData(houseid, H_ENTRACE);
        if(entranceid != -1)
        {
            CallLocalFunction("EntranceStatusInit", "i", entranceid);
        }

        new Cache:result, name[24];

        mysql_format(mysql, query, sizeof query, "SELECT * FROM accounts WHERE id=%d LIMIT 1", win_slot);
        result = mysql_query(mysql, query, true);
        if(mysql_errno()) return print("[ERROR AUCTION MYSQL] ID ERROR:: 13.1");

        cache_get_field_content(0, "name", name, mysql, 24);

        format(g_house[houseid][H_OWNER_NAME], 21, name, 0);

        cache_delete(result);

        UpdateHouse(houseid);

        HouseHealthInit(houseid);
        HouseStoreInit(houseid);

        format(query, sizeof query, "UPDATE houses SET improvements=0,rent_time=%d,`lock`=%d,store_x=0.0,store_y=0.0,store_z=0.0 WHERE id=%d LIMIT 1", GetHouseData(houseid, H_RENT_DATE), GetHouseData(houseid, H_LOCK_STATUS), GetHouseData(houseid, H_SQL_ID));
        mysql_query(mysql, query, false);
        if(mysql_errno()) return print("[ERROR AUCTION MYSQL] ID ERROR:: 13.2");
        reset_slot_auction(slot);

        return 1;
    }

        return 0;
}

stock LeafAuction(playerid, all_slot)
{
    for(new p;p < 4;p++) player_show_slot[playerid][p] = -1;

    for(new td; td < 4; td++)
    {
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][slot_td[td][0]], "-");
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][slot_td[td][1]], "-");
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][slot_td[td][2]], "-");
    }

    for(new i = 1; i < 6;i++ ) PlayerTextDrawSetString(playerid, auction_PTD[playerid][i], "-");

    default_select_slot(playerid);

    player_info_panel[playerid][select_slot] = 0;

    for(new i;i < 4;i++) player_show_slot[playerid][i] = -1;

    new string[9];
    valstr(string, player_info_panel[playerid][count_list]);
    PlayerTextDrawSetString(playerid, auction_PTD[playerid][27], string);

    new active_slot_id[MAX_AUCTION_SLOT], slot = -1, filter = player_info_panel[playerid][filter_type],
    tovar_type = player_info_panel[playerid][filter_tovar_type];

    for(new c;c < MAX_AUCTION_SLOT;c++)
    {
        if(!auction_slot[c][SLOT_TYPE]) continue;

        switch(filter)
        {
            case 1:
            {
                switch(tovar_type)
                {
                    case TYPE_VEHICLE: if(auction_slot[c][SERVER_ID] != player_info_panel[playerid][filter_vehicle_model] && auction_slot[c][SLOT_TYPE] != TYPE_VEHICLE) continue;
                    case TYPE_BUSINESS: if(auction_slot[c][SLOT_TYPE] != TYPE_BUSINESS) continue;
                    case TYPE_HOUSE: if(auction_slot[c][SLOT_TYPE] != TYPE_HOUSE) continue;
                    case TYPE_VEHICLE_NUMBER: if(auction_slot[c][SLOT_TYPE] != TYPE_VEHICLE_NUMBER) continue;
                    case TYPE_SUM_NUMBER: if(auction_slot[c][SLOT_TYPE] != TYPE_SUM_NUMBER) continue;
                    case TYPE_CLOTHES: if(auction_slot[c][SLOT_TYPE] != TYPE_CLOTHES) continue;
                }
            }
            case 2:
            {
                if(auction_slot[c][CURRENT_RATE] < player_info_panel[playerid][filter_min_price]) continue;
                else if(auction_slot[c][CURRENT_RATE] > player_info_panel[playerid][filter_max_price]) continue;
            }
        }

        slot++;

        active_slot_id[slot] = c;

        if(slot == all_slot - 3) player_show_slot[playerid][0] = active_slot_id[slot];
        if(slot == all_slot - 2) player_show_slot[playerid][1] = active_slot_id[slot];
        if(slot == all_slot - 1) player_show_slot[playerid][2] = active_slot_id[slot];
        if(slot == all_slot)
        {
            player_show_slot[playerid][3] = active_slot_id[slot];
            break;
        }
    }

    for(new td; td < 4; td++)
    {
        if(player_show_slot[playerid][td] == -1) continue;

        PlayerTextDrawSetString(playerid, auction_PTD[playerid][slot_td[td][0]], auction_slot[player_show_slot[playerid][td]][OWNER_SLOT_NAME]);
        PlayerTextDrawSetString(playerid, auction_PTD[playerid][slot_td[td][1]], auction_slot[player_show_slot[playerid][td]][SLOT_NAME]);
        printf("%d | slot td = %d", td, player_show_slot[playerid][td]);

        valstr(string, auction_slot[player_show_slot[playerid][td]][CURRENT_RATE]);

        PlayerTextDrawSetString(playerid, auction_PTD[playerid][slot_td[td][2]], string);
    }
}

stock ProbelText(string[])
{
    new result[256];
    for (new i = 0; i < sizeof(result); i++)
    {
        switch(string[i])
        {
            case ' ':result[i] = '_';
            default: result[i] = string[i];
        }
    }
    return result;
}