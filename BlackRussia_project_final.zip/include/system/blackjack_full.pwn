#define MAX_BJ_LOBBY2 6

#define BLACK_JACK 61 // ��� ��� � ��� ������

// ���� ������� ��� ��� ��� �� ����� �������� � IPacket:��� ���� ������(playerid, BitStream:bs) 
// � case 13: (���� ����� ��) �������� �� ���� ������
/*
                    case BLACK_JACK:
					{
					    callcmd::blackjack(playerid);
					}
*/

#define SCMTA   SendClientMessageToAll
//------------------------------------------------------------------------------
#define	DSI	DIALOG_STYLE_INPUT
#define DSM	DIALOG_STYLE_MSGBOX
#define DSL	DIALOG_STYLE_LIST
#define DSP	DIALOG_STYLE_PASSWORD
#define DST	DIALOG_STYLE_TABLIST
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

forward ShowNotificationNew(playerid, type, duration, id, subId, caption[], btnCaption[]);

stock BJSetPlayerCleanChat(playerid, clean)
{
    new BitStream:bitstream = BS_New();
    BS_WriteValue(bitstream, PR_UINT8, 0);
    BS_WriteValue(bitstream, PR_UINT8, clean);
    PR_SendRPC(bitstream, playerid, 168, PR_LOW_PRIORITY, PR_RELIABLE_ORDERED);
    BS_Delete(bitstream);
    return 1;
}

new Text:bj_fon2;

new Text:bj_double2;
new Text:bj_stop2;
new Text:bj_play2;
new Text:bj_take2;
new Text:bj_exit2;
new Text:bj_dealer_score2;
new Text:bj_help2;

new Text:bj2_log_text[MAX_BJ_LOBBY2][2];
new Text:bj2_table_ready[MAX_BJ_LOBBY2][5];

new Text:bj2_text_bet[2];
new Text:bj_text_start_time2;
new Text:bj2_text_start_timer[MAX_BJ_LOBBY2];

new Text:bj2_text_bj_table[MAX_BJ_LOBBY2][4];
new Text:bj2_text_point_table[MAX_BJ_LOBBY2][4];

new Text:bj2_dealer_card[MAX_BJ_LOBBY2][4];
new Text:bj2_result_table[MAX_BJ_LOBBY2][4];

new PlayerText:bj2_bet[MAX_PLAYERS]; // ������
new PlayerText:bj2_money[MAX_PLAYERS]; // ������ ������

new PlayerText:bj2_dealer_point[MAX_PLAYERS];

new PlayerText:bj2_members_name[MAX_PLAYERS][4]; // ���� �������

new PlayerText:bj2_card_table[MAX_PLAYERS][5][4]; // ����� ������

new PlayerText:bj2_panel_info[MAX_PLAYERS];

new Text3D: BlackJackText2[MAX_BJ_LOBBY2];

new Float:BlackJackPos2[MAX_BJ_LOBBY2][3] =
{
	{2533.235595,2479.847900,2500.593750},
	{2537.765136,2476.914306,2500.593750},
	{2534.275878,2470.723876,2500.593750},
	{2539.574462,2470.245849,2500.593750},
	{2537.811523,2463.583984,2500.593750},
	{2533.137207,2460.757812,2500.593750}
};

new BlackJackSphere[MAX_BJ_LOBBY2]; // ������ ��� ID ����

enum BJ_Card_struct2
{
	Pointscore2,
	Cardtexture2[32]
}

// ���� � �����
new BlackJackCard2[13][4][BJ_Card_struct2] =
{
	{{2, "txd:cards2c"}, {2, "txd:cards2d"}, {2, "txd:cards2h"}, {2, "txd:cards2s"}}, //������
	{{3, "txd:cards3c"}, {3, "txd:cards3d"}, {3, "txd:cards3h"}, {3, "txd:cards3s"}}, //������
	{{4, "txd:cards4c"}, {4, "txd:cards4d"}, {4, "txd:cards4h"}, {4, "txd:cards4s"}}, //��������
	{{5, "txd:cards5c"}, {5, "txd:cards5d"}, {5, "txd:cards5h"}, {5, "txd:cards5s"}}, //�������
	{{6, "txd:cards6c"}, {6, "txd:cards6d"}, {6, "txd:cards6h"}, {6, "txd:cards6s"}}, //��������
	{{7, "txd:cards7c"}, {7, "txd:cards7d"}, {7, "txd:cards7h"}, {7, "txd:cards7s"}}, //�������
	{{8, "txd:cards8c"}, {8, "txd:cards8d"}, {8, "txd:cards8h"}, {8, "txd:cards8s"}}, //���������
	{{9, "txd:cards9c"}, {9, "txd:cards9d"}, {9, "txd:cards9h"}, {9, "txd:cards9s"}}, //�������
	{{10, "txd:cards10c"}, {10, "txd:cards10d"}, {10, "txd:cards10h"}, {10, "txd:cards10s"}}, //�������

	{{10, "txd:cardsjc"}, {10, "txd:cardsjd"}, {10, "txd:cardsjh"}, {10, "txd:cardsjs"}}, //�����
	{{10, "txd:cardsqc"}, {10, "txd:cardsqd"}, {10, "txd:cardsqh"}, {10, "txd:cardsqs"}}, //����
	{{10, "txd:cardskc"}, {10, "txd:cardskd"}, {10, "txd:cardskh"}, {10, "txd:cardsks"}}, //������
	{{11, "txd:cardsac"}, {11, "txd:cardsad"}, {11, "txd:cardsah"}, {11, "txd:cardsas"}}  //���
};


enum BJ_Lobby2
{
	bool:ActivedLobby2,
	bool:StartedLobby2,
	StartTimer2,
	StageLobby2,
	DealerPoint2,

	DealerTurnGived2,
	TableTurn2,
	TableTurnTime2,

	Table1Id2,
	Table2Id2,
	Table3Id2,
	Table4Id2,

	Table1Point2,
	Table2Point2,
	Table3Point2,
	Table4Point2,

	Table1Result2,
	Table2Result2,
	Table3Result2,
	Table4Result2,
}
new BlackJackLobby2[MAX_BJ_LOBBY2][BJ_Lobby2];

enum P_BJ_Info2
{
	bool:OnLobby2,
	pBJLobby2,
	pBJTable2,
	pBJBet2,

	pBJBehindSlot2,

	pBJTakedCard2,
}
new pBJInfo2[MAX_PLAYERS][P_BJ_Info2];

//==============================================================================

public OnPlayerDisconnect(playerid, reason)
{
	if(pBJInfo2[playerid][OnLobby2] == true)
	{
	    switch(pBJInfo2[playerid][pBJTable2])
	    {
	        case 1: { BlackJackLobby2[pBJInfo2[playerid][pBJLobby2]][Table1Id2] = -1; BlackJackLobby2[pBJInfo2[playerid][pBJLobby2]][Table1Point2] = 0; }
	        case 2: { BlackJackLobby2[pBJInfo2[playerid][pBJLobby2]][Table2Id2] = -1; BlackJackLobby2[pBJInfo2[playerid][pBJLobby2]][Table2Point2] = 0; }
	        case 3: { BlackJackLobby2[pBJInfo2[playerid][pBJLobby2]][Table3Id2] = -1; BlackJackLobby2[pBJInfo2[playerid][pBJLobby2]][Table3Point2] = 0; }
	        case 4: { BlackJackLobby2[pBJInfo2[playerid][pBJLobby2]][Table4Id2] = -1; BlackJackLobby2[pBJInfo2[playerid][pBJLobby2]][Table4Point2] = 0; }
	    }
	    pBJInfo2[playerid][pBJTable2] = 0;
	    pBJInfo2[playerid][pBJLobby2] = 10;
	    pBJInfo2[playerid][OnLobby2] = false;
	    

	}
	#if defined blackjack_OnPlayerDisconnect
        return blackjack_OnPlayerDisconnect(playerid, reason);
    #else
        return 1;
    #endif
}
#if defined _ALS_OnPlayerDisconnect
    #undef OnPlayerDisconnect
#else
    #define _ALS_OnPlayerDisconnect
#endif
#define OnPlayerDisconnect blackjack_OnPlayerDisconnect
#if defined blackjack_OnPlayerDisconnect
    forward blackjack_OnPlayerDisconnect(playerid, reason);
#endif

public OnPlayerClickTextDraw(playerid, Text:clickedid)
{
	if(clickedid == bj_help2)
    {
		SendClientMessage(playerid, 0xFFFFFFFF, "");
        CancelSelectTextDraw(playerid);

        new str[1024];
        format(str, sizeof str,
		  	"BLACKJACK (������ �����) - ���� �� ����� ���������� ��������� ���.\n"\
			"������ ������ - ������� ������� ���������� ����� ��� �����, �� �� ������ 21.\n"\
			"�������, ��� �����, ��������� ������ 21 ���� ����� ����������� ����,\n"\
			"�� ����������� ����� � ������� (���� � ������ ���� ������ 21 ����).\n"\
			"������� ���� ������� ��������� ����� ������ �� 2 �����. � ����������� ����� ����� ������,\n"\
			"����� ��� ����� ��� ���, ���������������� ��������: '�����' ��� '������' ��������������.\n");

  		format(str, sizeof str, "%s"\
			"���� ��� ������� ���� ���� ������ ������ 21 ���� - �� ������� BLACKJACK, �� �� ����� ����������,\n"\
			"���� BLACKJACK ����� �������� � �����, � ������ �� �������� ������! \n"\
			"� ����������� �� ����, �� ������ ������� ���� ������. \n"\
			"� ���� ������ ��� ����� ������ ���� �����, � ������ ����� ��������� � ��� ����. \n"\
			"�����, ���� ������ ������ ������ ����� ���, �� ������ ������������ ���� ������ �� �������� �����. \n", str);
		format(str, sizeof str, "%s"\
			"� ������, ���� � ������ ����� BL�CKJ�CK, �� �������� ��� ������ �����, �� ���� � ������ �� ����� 21 ���� - �� ���������� ��.\n"\
			"������ ��� ������� � ��������� ����! ������� � �����������!", str);

        SPD(playerid, 19998, DSM,"{FF6347}������", str, "�������", "");
        return 1;
    }
	if(clickedid == bj_play2)
    {
		SendClientMessage(playerid, 0xFFFFFFFF, "");
        SPD(playerid, 19999, DSI, "{FF6347}BlackJack", "������� ����� �� ������� ������ �������: (���������� 1000 ������, ����������� 1000000000 ������.)", "������", "�������");
        return 1;
    }

    if(clickedid == bj_double2)
	{
		SendClientMessage(playerid, 0xFFFFFFFF, "");
	    new lobby = pBJInfo2[playerid][pBJLobby2];
	    if(BlackJackLobby2[lobby][TableTurn2] == pBJInfo2[playerid][pBJTable2])
	    {
	        if(GetPlayerMoneyEx(playerid) < pBJInfo2[playerid][pBJBet2])
			{
				0;
				ShowNotificationNew(playerid, 2, 5, 1, 1, "� ��� ������������ ������� ����� ������� ������.", "");
				return 1;
			}

            new strTD[67];
            format(strTD, sizeof(strTD), "%s ������ ������", GetPlayerNameEx(playerid));

			TextDrawSetString(bj2_log_text[lobby][0], strTD);
			TextDrawColor(bj2_log_text[lobby][0], -65281);

			if(BlackJackLobby2[lobby][Table1Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table1Id2], bj2_log_text[lobby][0]);
			if(BlackJackLobby2[lobby][Table2Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table2Id2], bj2_log_text[lobby][0]);
			if(BlackJackLobby2[lobby][Table3Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table3Id2], bj2_log_text[lobby][0]);
			if(BlackJackLobby2[lobby][Table4Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table4Id2], bj2_log_text[lobby][0]);

			GivePlayerMoneyBjEx(playerid, -pBJInfo2[playerid][pBJBet2]);
			pBJInfo2[playerid][pBJBet2] = pBJInfo2[playerid][pBJBet2]*2;

			new str[15];
			format(str, sizeof str, "%d py�", pBJInfo2[playerid][pBJBet2]);
			PlayerTextDrawSetString(playerid, bj2_bet[playerid], str);

			format(str, sizeof str, "%d py�", GetPlayerMoneyEx(playerid));
			PlayerTextDrawSetString(playerid, bj2_money[playerid], str);


	        switch(pBJInfo2[playerid][pBJTable2])
			{
			    case 1:
			    {
					new suit = random(13);
					new type = random(4);

					BlackJackLobby2[lobby][Table1Point2] += BlackJackCard2[suit][type][Pointscore2];

					format(str, sizeof str, "����: %d", BlackJackLobby2[lobby][Table1Point2]);
					TextDrawSetString(bj2_text_point_table[lobby][0], str);

					ShowMembersCardBJL2(lobby, 1, 2+pBJInfo2[playerid][pBJTakedCard2], suit, type);

			    	pBJInfo2[playerid][pBJTakedCard2]++;
     				CheckTableBlackJack2(lobby, 1);
			    }
			    case 2:
			    {
					new suit = random(13);
					new type = random(4);

					BlackJackLobby2[lobby][Table2Point2] += BlackJackCard2[suit][type][Pointscore2];

					format(str, sizeof str, "����: %d", BlackJackLobby2[lobby][Table2Point2]);
					TextDrawSetString(bj2_text_point_table[lobby][1], str);

					ShowMembersCardBJL2(lobby, 2, 2+pBJInfo2[playerid][pBJTakedCard2], suit, type);

			    	pBJInfo2[playerid][pBJTakedCard2]++;
     				CheckTableBlackJack2(lobby, 2);
			    }
			    case 3:
			    {
					new suit = random(13);
					new type = random(4);

					BlackJackLobby2[lobby][Table3Point2] += BlackJackCard2[suit][type][Pointscore2];

					format(str, sizeof str, "����: %d", BlackJackLobby2[lobby][Table3Point2]);
					TextDrawSetString(bj2_text_point_table[lobby][2], str);

					ShowMembersCardBJL2(lobby, 3, 2+pBJInfo2[playerid][pBJTakedCard2], suit, type);

			    	pBJInfo2[playerid][pBJTakedCard2]++;
     				CheckTableBlackJack2(lobby, 3);
			    }
			    case 4:
			    {
					new suit = random(13);
					new type = random(4);

					BlackJackLobby2[lobby][Table4Point2] += BlackJackCard2[suit][type][Pointscore2];

					format(str, sizeof str, "����: %d", BlackJackLobby2[lobby][Table4Point2]);
					TextDrawSetString(bj2_text_point_table[lobby][3], str);

					ShowMembersCardBJL2(lobby, 4, 2+pBJInfo2[playerid][pBJTakedCard2], suit, type);

			    	pBJInfo2[playerid][pBJTakedCard2]++;
     				CheckTableBlackJack2(lobby, 4);
			    }
			}
	    }
	    else 
		{
			0;
			ShowNotificationNew(playerid, 2, 5, 1, 1, "������ �� ��� ���.", "");
		}

		BJAdvanceTurnIfCurrent(playerid, lobby);
		return 1;
	}
    if(clickedid == bj_take2)
	{
		SendClientMessage(playerid, 0xFFFFFFFF, "");
	    new lobby = pBJInfo2[playerid][pBJLobby2];
	    if(BlackJackLobby2[pBJInfo2[playerid][pBJLobby2]][TableTurn2] == pBJInfo2[playerid][pBJTable2])
	    {
			new str[64];
            format(str, sizeof(str), "%s ���� �����", GetPlayerNameEx(playerid));

			TextDrawSetString(bj2_log_text[lobby][0], str);
			TextDrawColor(bj2_log_text[lobby][0], -65281);

			if(BlackJackLobby2[lobby][Table1Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table1Id2], bj2_log_text[lobby][0]);
			if(BlackJackLobby2[lobby][Table2Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table2Id2], bj2_log_text[lobby][0]);
			if(BlackJackLobby2[lobby][Table3Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table3Id2], bj2_log_text[lobby][0]);
			if(BlackJackLobby2[lobby][Table4Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table4Id2], bj2_log_text[lobby][0]);

	        switch(pBJInfo2[playerid][pBJTable2])
			{
			    case 1:
			    {
			    	pBJInfo2[playerid][pBJTakedCard2]++;
					new suit = random(13);
					new type = random(4);

					BlackJackLobby2[lobby][Table1Point2] += BlackJackCard2[suit][type][Pointscore2];

					new str[10];
					format(str, sizeof str, "����: %d", BlackJackLobby2[lobby][Table1Point2]);
					TextDrawSetString(bj2_text_point_table[lobby][0], str);

					ShowMembersCardBJL2(lobby, 1, 2+pBJInfo2[playerid][pBJTakedCard2], suit, type);

     				CheckTableBlackJack2(lobby, 1);
			    }
			    case 2:
			    {
			    	pBJInfo2[playerid][pBJTakedCard2]++;
					new suit = random(13);
					new type = random(4);

					BlackJackLobby2[lobby][Table2Point2] += BlackJackCard2[suit][type][Pointscore2];

					new str[10];
					format(str, sizeof str, "����: %d", BlackJackLobby2[lobby][Table2Point2]);
					TextDrawSetString(bj2_text_point_table[lobby][1], str);

					ShowMembersCardBJL2(lobby, 2, 2+pBJInfo2[playerid][pBJTakedCard2], suit, type);

     				CheckTableBlackJack2(lobby, 2);
			    }
			    case 3:
			    {
			    	pBJInfo2[playerid][pBJTakedCard2]++;
					new suit = random(13);
					new type = random(4);

					BlackJackLobby2[lobby][Table3Point2] += BlackJackCard2[suit][type][Pointscore2];

					new str[10];
					format(str, sizeof str, "����: %d", BlackJackLobby2[lobby][Table3Point2]);
					TextDrawSetString(bj2_text_point_table[lobby][2], str);

					ShowMembersCardBJL2(lobby, 3, 2+pBJInfo2[playerid][pBJTakedCard2], suit, type);

     				CheckTableBlackJack2(lobby, 3);
			    }
			    case 4:
			    {
			    	pBJInfo2[playerid][pBJTakedCard2]++;
					new suit = random(13);
					new type = random(4);

					BlackJackLobby2[lobby][Table4Point2] += BlackJackCard2[suit][type][Pointscore2];

					new str[10];
					format(str, sizeof str, "����: %d", BlackJackLobby2[lobby][Table4Point2]);
					TextDrawSetString(bj2_text_point_table[lobby][3], str);

					ShowMembersCardBJL2(lobby, 4, 2+pBJInfo2[playerid][pBJTakedCard2], suit, type);

     				CheckTableBlackJack2(lobby, 4);
			    }
			}
	    }
	    else 
		{
			SendClientMessage(playerid, 0xFFFFFFFF, "");
			0;
			ShowNotificationNew(playerid, 2, 5, 1, 1, "������ �� ��� ���.", "");
		}

		BJAdvanceTurnIfCurrent(playerid, lobby);
		return 1;
	}
    if(clickedid == bj_stop2)
	{
		SendClientMessage(playerid, 0xFFFFFFFF, "");
	    new lobby = pBJInfo2[playerid][pBJLobby2];
	    if(BlackJackLobby2[lobby][TableTurn2] == pBJInfo2[playerid][pBJTable2])
	    {
			new str[64];
            format(str, sizeof(str), "%s �����������", GetPlayerNameEx(playerid));

			TextDrawSetString(bj2_log_text[lobby][0], str);
			TextDrawColor(bj2_log_text[lobby][0], -65281);

			if(BlackJackLobby2[lobby][Table1Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table1Id2], bj2_log_text[lobby][0]);
			if(BlackJackLobby2[lobby][Table2Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table2Id2], bj2_log_text[lobby][0]);
			if(BlackJackLobby2[lobby][Table3Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table3Id2], bj2_log_text[lobby][0]);
			if(BlackJackLobby2[lobby][Table4Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table4Id2], bj2_log_text[lobby][0]);

	        BJAdvanceTurnIfCurrent(playerid, lobby);
	    }
	    else 
		{
			0;
			ShowNotificationNew(playerid, 2, 5, 1, 1, "������ �� ��� ���.", "");
		}
		return 1;
	}
	if(clickedid == bj_exit2)
	{
		SendClientMessage(playerid, 0xFFFFFFFF, "");
   		new lobby = pBJInfo2[playerid][pBJLobby2];
   		new table = pBJInfo2[playerid][pBJTable2];
	    if(BlackJackLobby2[lobby][StartedLobby2]) 
		{
			0;
			ShowNotificationNew(playerid, 2, 5, 1, 1, "��������� ��������� ����.", "");
			return 1;
		}
	    else ExitPlayerLobby2(playerid, lobby, table);
	    return 1;
	}

	#if defined blackjack_OnPlayerClickTextDraw
        return blackjack_OnPlayerClickTextDraw(playerid, clickedid);
    #else
        return 1;
    #endif
}
#if defined _ALS_OnPlayerClickTextDraw
    #undef OnPlayerClickTextDraw
#else
    #define _ALS_OnPlayerClickTextDraw
#endif
#define OnPlayerClickTextDraw blackjack_OnPlayerClickTextDraw
#if defined blackjack_OnPlayerClickTextDraw
    forward blackjack_OnPlayerClickTextDraw(playerid, Text:clickedid);
#endif


public OnDialogResponse(playerid, dialogid, response, listitem, inputtext[])
{
    new str[128];
    if(dialogid == 19998)
    {
        if(pBJInfo2[playerid][OnLobby2]) SelectTextDraw(playerid, 0x00000001);
        #if defined blackjack_OnDialogResponse
            return blackjack_OnDialogResponse(playerid, dialogid, response, listitem, inputtext);
        #else
            return 1;
        #endif
    }
    if(dialogid == 19999)
    {
		SendClientMessage(playerid, 0xFFFFFFFF, "");
        if(response)
        {
            if(pBJInfo2[playerid][OnLobby2])
            {
                new bet;
                if(sscanf(inputtext,"d",bet))
                {
					0;
			        ShowNotificationNew(playerid, 2, 5, 1, 1, "������� ������ �� ������� ������ �������!", "");
                    SPD(playerid, 19999, DSI, "{FF6347}BlackJack", "������� ����� �� ������� ������ �������: (���������� 1000 ������, ����������� 1000000000 ������.)", "������", "�������");
                    return 0;
                }
                if(!(1000 < bet < 1000000001))
                {
					0;
			        ShowNotificationNew(playerid, 2, 5, 1, 1, "���������� 1000 ������, ����������� 1000000000 ������.", "");
                    SPD(playerid, 19999, DSI, "{FF6347}BlackJack", "������� ����� �� ������� ������ �������: (���������� 1000 ������, ����������� 1000000000 ������.)", "������", "�������");
                    return 0;
                }
                if(GetPlayerMoneyEx(playerid) < bet)
                {
					0;
			        ShowNotificationNew(playerid, 2, 5, 1, 1, "� ��� ������������ �������.", "");
                    SPD(playerid, 19999, DSI, "{FF6347}BlackJack", "������� ����� �� ������� ������ �������: (���������� 1000 ������, ����������� 1000000000 ������.)", "������", "�������");
                    return 0;
                }

                format(str, sizeof str, "%d py�", bet);
                PlayerTextDrawShow(playerid, bj2_bet[playerid]);
                PlayerTextDrawSetString(playerid, bj2_bet[playerid], str);
                pBJInfo2[playerid][pBJBet2] = bet;

                new lobby = pBJInfo2[playerid][pBJLobby2];
                new slot = pBJInfo2[playerid][pBJBehindSlot2];
				new apponent1 = BlackJackLobby2[lobby][Table1Id2];
				new apponent2 = BlackJackLobby2[lobby][Table2Id2];
				new apponent3 = BlackJackLobby2[lobby][Table3Id2];
				new apponent4 = BlackJackLobby2[lobby][Table4Id2];

                if(apponent1 != -1)
                {
                    TextDrawHideForPlayer(apponent1, bj2_table_ready[lobby][slot]);
                    TextDrawSetString(bj2_table_ready[lobby][slot], "�����");
                    TextDrawColor(bj2_table_ready[lobby][slot], 16711935);
                    TextDrawShowForPlayer(apponent1, bj2_table_ready[lobby][slot]);
                }
				if(apponent2 != -1)
                {
                    TextDrawHideForPlayer(apponent2, bj2_table_ready[lobby][slot]);
                    TextDrawSetString(bj2_table_ready[lobby][slot], "�����");
                    TextDrawColor(bj2_table_ready[lobby][slot], 16711935);
                    TextDrawShowForPlayer(apponent2, bj2_table_ready[lobby][slot]);
                }
				if(apponent3 != -1)
                {
                    TextDrawHideForPlayer(apponent3, bj2_table_ready[lobby][slot]);
                    TextDrawSetString(bj2_table_ready[lobby][slot], "�����");
                    TextDrawColor(bj2_table_ready[lobby][slot], 16711935);
                    TextDrawShowForPlayer(apponent3, bj2_table_ready[lobby][slot]);
                }
				if(apponent4 != -1)
                {
                    TextDrawHideForPlayer(apponent4, bj2_table_ready[lobby][slot]);
                    TextDrawSetString(bj2_table_ready[lobby][slot], "�����");
                    TextDrawColor(bj2_table_ready[lobby][slot], 16711935);
                    TextDrawShowForPlayer(apponent4, bj2_table_ready[lobby][slot]);
                }
                // ==========================

                TextDrawShowForPlayer(playerid, bj2_text_bet[0]);
                TextDrawShowForPlayer(playerid, bj2_text_bet[1]);
                SetTimerEx("TimerHideBetText2", 3000, false, "d", playerid);
            }
        }
    }
    #if defined blackjack_OnDialogResponse
        return blackjack_OnDialogResponse(playerid, dialogid, response, listitem, inputtext);
    #endif
}
#if defined _ALS_OnDialogResponse
    #undef OnDialogResponse
#else
    #define _ALS_OnDialogResponse
#endif
#define OnDialogResponse blackjack_OnDialogResponse
#if defined blackjack_OnDialogResponse
    forward blackjack_OnDialogResponse(playerid, dialogid, response, listitem, inputtext[]);
#endif

stock InitPlayerLobby2(playerid, lobby, table)
{
    pBJInfo2[playerid][pBJTable2] = table;
    BJSetPlayerCleanChat(playerid, 1);

    for(new a;a < 12;a++)  SendClientMessage(playerid, 0xFFFFFFFF, "");

	TextDrawShowForPlayer(playerid, bj_fon2);
	TextDrawShowForPlayer(playerid, bj_double2);
	TextDrawShowForPlayer(playerid, bj_stop2);
	TextDrawShowForPlayer(playerid, bj_play2);
	TextDrawShowForPlayer(playerid, bj_take2);
	TextDrawShowForPlayer(playerid, bj_exit2);

	TextDrawShowForPlayer(playerid, bj_help2);

	TextDrawShowForPlayer(playerid, bj_text_start_time2);
	TextDrawShowForPlayer(playerid, bj2_text_start_timer[lobby]);

	PlayerTextDrawShow(playerid, bj2_bet[playerid]);
	PlayerTextDrawSetString(playerid, bj2_bet[playerid], "0 py�");

	new money = GetPlayerMoneyEx(playerid);

	new str[24];
    format(str, sizeof str, "%d py�", money);
	PlayerTextDrawShow(playerid, bj2_money[playerid]);
	PlayerTextDrawSetString(playerid, bj2_money[playerid], str);

	TogglePlayerControllable(playerid, false);
	HideHud(playerid);

	foreach(new i : Player)
	{
	    ShowPlayerNameTagForPlayer(playerid, i, 0);
	}

	if(BlackJackLobby2[lobby][Table1Id2] != -1)
	{
	    new name[24];
		GetPlayerName(BlackJackLobby2[lobby][Table1Id2], name, 24);

		PlayerTextDrawShow(playerid, bj2_members_name[playerid][0]);
		PlayerTextDrawSetString(playerid, bj2_members_name[playerid][0], name);


		PlayerTextDrawShow(playerid, bj2_card_table[playerid][1][0]); PlayerTextDrawShow(playerid, bj2_card_table[playerid][1][1]); PlayerTextDrawShow(playerid, bj2_card_table[playerid][1][2]); PlayerTextDrawShow(playerid, bj2_card_table[playerid][1][3]);

		TextDrawShowForPlayer(playerid, bj2_table_ready[lobby][1]);
		TextDrawSetString(bj2_table_ready[lobby][1], "�� �����");
		TextDrawColor(bj2_table_ready[lobby][1], -16776961);

		new table1 = BlackJackLobby2[lobby][Table1Id2];

		GetPlayerName(playerid, name, 24);

		PlayerTextDrawShow(table1, bj2_members_name[table1][table-1]);
		PlayerTextDrawSetString(table1, bj2_members_name[table1][table-1], name);


		PlayerTextDrawShow(table1, bj2_card_table[table1][table][0]); PlayerTextDrawShow(table1, bj2_card_table[table1][table][1]); PlayerTextDrawShow(table1, bj2_card_table[table1][table][2]); PlayerTextDrawShow(table1, bj2_card_table[table1][table][3]);

		TextDrawShowForPlayer(table1, bj2_table_ready[lobby][table]);
		TextDrawSetString(bj2_table_ready[lobby][table], "�� �����");
		TextDrawColor(bj2_table_ready[lobby][table], -16776961);
	}
	if(BlackJackLobby2[lobby][Table2Id2] != -1)
	{
	    new name[24];
		GetPlayerName(BlackJackLobby2[lobby][Table2Id2], name, 24);

		PlayerTextDrawShow(playerid, bj2_members_name[playerid][1]);
		PlayerTextDrawSetString(playerid, bj2_members_name[playerid][1], name);


		PlayerTextDrawShow(playerid, bj2_card_table[playerid][2][0]); PlayerTextDrawShow(playerid, bj2_card_table[playerid][2][1]); PlayerTextDrawShow(playerid, bj2_card_table[playerid][2][2]); PlayerTextDrawShow(playerid, bj2_card_table[playerid][2][3]);

		TextDrawShowForPlayer(playerid, bj2_table_ready[lobby][2]);
		TextDrawSetString(bj2_table_ready[lobby][2], "�� �����");
		TextDrawColor(bj2_table_ready[lobby][2], -16776961);



		new table2 = BlackJackLobby2[lobby][Table2Id2];

		GetPlayerName(playerid, name, 24);

		PlayerTextDrawShow(table2, bj2_members_name[table2][table-1]);
		PlayerTextDrawSetString(table2, bj2_members_name[table2][table-1], name);


		PlayerTextDrawShow(table2, bj2_card_table[table2][table][0]); PlayerTextDrawShow(table2, bj2_card_table[table2][table][1]); PlayerTextDrawShow(table2, bj2_card_table[table2][table][2]); PlayerTextDrawShow(table2, bj2_card_table[table2][table][3]);

		TextDrawShowForPlayer(table2, bj2_table_ready[lobby][table]);
		TextDrawSetString(bj2_table_ready[lobby][table], "�� �����");
		TextDrawColor(bj2_table_ready[lobby][table], -16776961);
	}
	if(BlackJackLobby2[lobby][Table3Id2] != -1)
	{
	    new name[24];
		GetPlayerName(BlackJackLobby2[lobby][Table3Id2], name, 24);

		PlayerTextDrawShow(playerid, bj2_members_name[playerid][2]);
		PlayerTextDrawSetString(playerid, bj2_members_name[playerid][2], name);


		PlayerTextDrawShow(playerid, bj2_card_table[playerid][3][0]); PlayerTextDrawShow(playerid, bj2_card_table[playerid][3][1]); PlayerTextDrawShow(playerid, bj2_card_table[playerid][3][2]); PlayerTextDrawShow(playerid, bj2_card_table[playerid][3][3]);

		TextDrawShowForPlayer(playerid, bj2_table_ready[lobby][3]);
		TextDrawSetString(bj2_table_ready[lobby][3], "�� �����");
		TextDrawColor(bj2_table_ready[lobby][3], -16776961);



		new table3 = BlackJackLobby2[lobby][Table3Id2];

		GetPlayerName(playerid, name, 24);

		PlayerTextDrawShow(table3, bj2_members_name[table3][table-1]);
		PlayerTextDrawSetString(table3, bj2_members_name[table3][table-1], name);


		PlayerTextDrawShow(table3, bj2_card_table[table3][table][0]); PlayerTextDrawShow(table3, bj2_card_table[table3][table][1]); PlayerTextDrawShow(table3, bj2_card_table[table3][table][2]); PlayerTextDrawShow(table3, bj2_card_table[table3][table][3]);

		TextDrawShowForPlayer(table3, bj2_table_ready[lobby][table]);
		TextDrawSetString(bj2_table_ready[lobby][table], "�� �����");
		TextDrawColor(bj2_table_ready[lobby][table], -16776961);
	}
	if(BlackJackLobby2[lobby][Table4Id2] != -1)
	{
	    new name[24];
		GetPlayerName(BlackJackLobby2[lobby][Table4Id2], name, 24);

		PlayerTextDrawShow(playerid, bj2_members_name[playerid][3]);
		PlayerTextDrawSetString(playerid, bj2_members_name[playerid][3], name);


		PlayerTextDrawShow(playerid, bj2_card_table[playerid][4][0]); PlayerTextDrawShow(playerid, bj2_card_table[playerid][4][1]); PlayerTextDrawShow(playerid, bj2_card_table[playerid][4][2]); PlayerTextDrawShow(playerid, bj2_card_table[playerid][4][3]);

		TextDrawShowForPlayer(playerid, bj2_table_ready[lobby][4]);
		TextDrawSetString(bj2_table_ready[lobby][4], "�� �����");
		TextDrawColor(bj2_table_ready[lobby][4], -16776961);

		new table4 = BlackJackLobby2[lobby][Table4Id2];

		GetPlayerName(playerid, name, 24);

		PlayerTextDrawShow(table4, bj2_members_name[table4][table-1]);
		PlayerTextDrawSetString(table4, bj2_members_name[table4][table-1], name);


		PlayerTextDrawShow(table4, bj2_card_table[table4][table][0]); PlayerTextDrawShow(table4, bj2_card_table[table4][table][1]); PlayerTextDrawShow(table4, bj2_card_table[table4][table][2]); PlayerTextDrawShow(table4, bj2_card_table[table4][table][3]);

		TextDrawShowForPlayer(table4, bj2_table_ready[lobby][table]);
		TextDrawSetString(bj2_table_ready[lobby][table], "�� �����");
		TextDrawColor(bj2_table_ready[lobby][table], -16776961);
	}
	SelectTextDraw(playerid, 0x00000001);
	return 1;
}

stock ExitPlayerLobby2(playerid, lobby, table)
{
	SetTimerEx("ExitPlayerLobbyTimer", 1000, false, "iii", playerid, lobby, table);

    switch(table)
	{
	    case 1: BlackJackLobby2[lobby][Table1Id2] = -1;
	    case 2: BlackJackLobby2[lobby][Table2Id2] = -1;
	    case 3: BlackJackLobby2[lobby][Table3Id2] = -1;
	    case 4: BlackJackLobby2[lobby][Table4Id2] = -1;
	}
	pBJInfo2[playerid][OnLobby2] = false;
	pBJInfo2[playerid][pBJLobby2] = 10;
	pBJInfo2[playerid][pBJBet2] = 0;
	pBJInfo2[playerid][pBJTakedCard2] = 0;
	pBJInfo2[playerid][pBJBehindSlot2] = 0;

    TextDrawHideForPlayer(playerid, bj_fon2);
	TextDrawHideForPlayer(playerid, bj_double2);
	TextDrawHideForPlayer(playerid, bj_stop2);
	TextDrawHideForPlayer(playerid, bj_play2);
	TextDrawHideForPlayer(playerid, bj_take2);
	TextDrawHideForPlayer(playerid, bj_exit2);
	TextDrawHideForPlayer(playerid, bj_dealer_score2);
	PlayerTextDrawHide(playerid, bj2_dealer_point[playerid]);
	TextDrawHideForPlayer(playerid, bj_help2);
	TextDrawHideForPlayer(playerid, bj2_log_text[lobby][0]);
	TextDrawHideForPlayer(playerid, bj2_log_text[lobby][1]);

	TextDrawHideForPlayer(playerid, bj2_table_ready[lobby][1]);
	TextDrawHideForPlayer(playerid, bj2_table_ready[lobby][2]);
	TextDrawHideForPlayer(playerid, bj2_table_ready[lobby][3]);
	TextDrawHideForPlayer(playerid, bj2_table_ready[lobby][4]);

    PlayerTextDrawHide(playerid, bj2_panel_info[playerid]);
    PlayerTextDrawSetString(playerid, bj2_panel_info[playerid], "blackjack:brbjyouturn");

	TextDrawHideForPlayer(playerid, bj2_dealer_card[lobby][1]);
	TextDrawHideForPlayer(playerid, bj2_dealer_card[lobby][2]);
	TextDrawHideForPlayer(playerid, bj2_dealer_card[lobby][3]);

	TextDrawHideForPlayer(playerid, bj2_text_bet[0]);
	TextDrawHideForPlayer(playerid, bj2_text_bet[1]);

	TextDrawHideForPlayer(playerid, bj_text_start_time2);
	TextDrawHideForPlayer(playerid, bj2_text_start_timer[lobby]);

	PlayerTextDrawHide(playerid, bj2_bet[playerid]);
	PlayerTextDrawHide(playerid, bj2_money[playerid]);

	PlayerTextDrawHide(playerid, bj2_members_name[playerid][0]);
	PlayerTextDrawHide(playerid, bj2_members_name[playerid][1]);
	PlayerTextDrawHide(playerid, bj2_members_name[playerid][2]);
	PlayerTextDrawHide(playerid, bj2_members_name[playerid][3]);

	TextDrawHideForPlayer(playerid, bj2_text_point_table[lobby][0]);
	TextDrawHideForPlayer(playerid, bj2_text_point_table[lobby][1]);
	TextDrawHideForPlayer(playerid, bj2_text_point_table[lobby][2]);
	TextDrawHideForPlayer(playerid, bj2_text_point_table[lobby][3]);

    TextDrawHideForPlayer(playerid, bj2_result_table[lobby][0]);
    TextDrawHideForPlayer(playerid, bj2_result_table[lobby][1]);
    TextDrawHideForPlayer(playerid, bj2_result_table[lobby][2]);
    TextDrawHideForPlayer(playerid, bj2_result_table[lobby][3]);

	for(new i = 1; i <= 4; i++)
	{
		PlayerTextDrawHide(playerid, bj2_card_table[playerid][i][0]);
		PlayerTextDrawHide(playerid, bj2_card_table[playerid][i][1]);
		PlayerTextDrawHide(playerid, bj2_card_table[playerid][i][2]);
		PlayerTextDrawHide(playerid, bj2_card_table[playerid][i][3]);

		PlayerTextDrawSetString(playerid, bj2_card_table[playerid][i][0], "blackjack:cardscard");
		PlayerTextDrawSetString(playerid, bj2_card_table[playerid][i][1], "blackjack:cardscard");
		PlayerTextDrawSetString(playerid, bj2_card_table[playerid][i][2], "blackjack:cardscard");
		PlayerTextDrawSetString(playerid, bj2_card_table[playerid][i][3], "blackjack:cardscard");

		new apponent;
	    switch(i)
	    {
	        case 1:
			{
				if(BlackJackLobby2[lobby][Table1Id2] != -1) apponent = BlackJackLobby2[lobby][Table1Id2];
				else apponent = -1;
			}
	        case 2:
			{
				if(BlackJackLobby2[lobby][Table2Id2] != -1) apponent = BlackJackLobby2[lobby][Table2Id2];
				else apponent = -1;
			}
	        case 3:
			{
				if(BlackJackLobby2[lobby][Table3Id2] != -1) apponent = BlackJackLobby2[lobby][Table3Id2];
				else apponent = -1;
			}
	        case 4:
			{
				if(BlackJackLobby2[lobby][Table4Id2] != -1) apponent = BlackJackLobby2[lobby][Table4Id2];
				else apponent = -1;
			}
		}
		if(apponent != -1)
		{
			PlayerTextDrawHide(apponent, bj2_members_name[apponent][table-1]);
			PlayerTextDrawHide(apponent, bj2_card_table[apponent][table][0]);
			PlayerTextDrawHide(apponent, bj2_card_table[apponent][table][1]);
			PlayerTextDrawHide(apponent, bj2_card_table[apponent][table][2]);
			PlayerTextDrawHide(apponent, bj2_card_table[apponent][table][3]);

			TextDrawHideForPlayer(apponent, bj2_text_point_table[lobby][0]);
			TextDrawHideForPlayer(apponent, bj2_text_point_table[lobby][1]);
			TextDrawHideForPlayer(apponent, bj2_text_point_table[lobby][2]);
			TextDrawHideForPlayer(apponent, bj2_text_point_table[lobby][3]);
		}
	}

	TextDrawHideForPlayer(playerid, bj2_text_bj_table[lobby][0]);
	TextDrawHideForPlayer(playerid, bj2_text_bj_table[lobby][1]);
	TextDrawHideForPlayer(playerid, bj2_text_bj_table[lobby][2]);
	TextDrawHideForPlayer(playerid, bj2_text_bj_table[lobby][3]);

	/*TextDrawHideForPlayer(playerid, bj_text_start_time2);
	TextDrawHideForPlayer(playerid, bj2_text_start_timer[lobby]);

	TextDrawHideForPlayer(playerid, bj2_table_ready[lobby][1]);
	TextDrawHideForPlayer(playerid, bj2_table_ready[lobby][2]);
	TextDrawHideForPlayer(playerid, bj2_table_ready[lobby][3]);
	TextDrawHideForPlayer(playerid, bj2_table_ready[lobby][4]);*/

	CancelSelectTextDraw(playerid);
	ClearAnimations(playerid);
	TogglePlayerControllable(playerid, true);
	ShowHud(playerid);

	foreach(new i : Player)
	{
	    ShowPlayerNameTagForPlayer(playerid, i, 1);
	}
	return 1;
}

public ExitPlayerLobbyTimer(playerid, lobby, table)
{
    switch(table)
	{
	    case 1: BlackJackLobby2[lobby][Table1Id2] = -1;
	    case 2: BlackJackLobby2[lobby][Table2Id2] = -1;
	    case 3: BlackJackLobby2[lobby][Table3Id2] = -1;
	    case 4: BlackJackLobby2[lobby][Table4Id2] = -1;
	}
	pBJInfo2[playerid][OnLobby2] = false;
	pBJInfo2[playerid][pBJLobby2] = 10;
	pBJInfo2[playerid][pBJBet2] = 0;
	pBJInfo2[playerid][pBJTakedCard2] = 0;
	pBJInfo2[playerid][pBJBehindSlot2] = 0;

    TextDrawHideForPlayer(playerid, bj_fon2);
	TextDrawHideForPlayer(playerid, bj_double2);
	TextDrawHideForPlayer(playerid, bj_stop2);
	TextDrawHideForPlayer(playerid, bj_play2);
	TextDrawHideForPlayer(playerid, bj_take2);
	TextDrawHideForPlayer(playerid, bj_exit2);
	TextDrawHideForPlayer(playerid, bj_dealer_score2);
	PlayerTextDrawHide(playerid, bj2_dealer_point[playerid]);
	TextDrawHideForPlayer(playerid, bj_help2);
	TextDrawHideForPlayer(playerid, bj2_log_text[lobby][0]);
	TextDrawHideForPlayer(playerid, bj2_log_text[lobby][1]);

	TextDrawHideForPlayer(playerid, bj2_table_ready[lobby][1]);
	TextDrawHideForPlayer(playerid, bj2_table_ready[lobby][2]);
	TextDrawHideForPlayer(playerid, bj2_table_ready[lobby][3]);
	TextDrawHideForPlayer(playerid, bj2_table_ready[lobby][4]);

    PlayerTextDrawHide(playerid, bj2_panel_info[playerid]);
    PlayerTextDrawSetString(playerid, bj2_panel_info[playerid], "blackjack:brbjyouturn");

	TextDrawHideForPlayer(playerid, bj2_dealer_card[lobby][1]);
	TextDrawHideForPlayer(playerid, bj2_dealer_card[lobby][2]);
	TextDrawHideForPlayer(playerid, bj2_dealer_card[lobby][3]);

	TextDrawHideForPlayer(playerid, bj2_text_bet[0]);
	TextDrawHideForPlayer(playerid, bj2_text_bet[1]);

	TextDrawHideForPlayer(playerid, bj_text_start_time2);
	TextDrawHideForPlayer(playerid, bj2_text_start_timer[lobby]);

	PlayerTextDrawHide(playerid, bj2_bet[playerid]);
	PlayerTextDrawHide(playerid, bj2_money[playerid]);

	PlayerTextDrawHide(playerid, bj2_members_name[playerid][0]);
	PlayerTextDrawHide(playerid, bj2_members_name[playerid][1]);
	PlayerTextDrawHide(playerid, bj2_members_name[playerid][2]);
	PlayerTextDrawHide(playerid, bj2_members_name[playerid][3]);

	TextDrawHideForPlayer(playerid, bj2_text_point_table[lobby][0]);
	TextDrawHideForPlayer(playerid, bj2_text_point_table[lobby][1]);
	TextDrawHideForPlayer(playerid, bj2_text_point_table[lobby][2]);
	TextDrawHideForPlayer(playerid, bj2_text_point_table[lobby][3]);

    TextDrawHideForPlayer(playerid, bj2_result_table[lobby][0]);
    TextDrawHideForPlayer(playerid, bj2_result_table[lobby][1]);
    TextDrawHideForPlayer(playerid, bj2_result_table[lobby][2]);
    TextDrawHideForPlayer(playerid, bj2_result_table[lobby][3]);

	for(new i = 1; i <= 4; i++)
	{
		PlayerTextDrawHide(playerid, bj2_card_table[playerid][i][0]);
		PlayerTextDrawHide(playerid, bj2_card_table[playerid][i][1]);
		PlayerTextDrawHide(playerid, bj2_card_table[playerid][i][2]);
		PlayerTextDrawHide(playerid, bj2_card_table[playerid][i][3]);

		PlayerTextDrawSetString(playerid, bj2_card_table[playerid][i][0], "blackjack:cardscard");
		PlayerTextDrawSetString(playerid, bj2_card_table[playerid][i][1], "blackjack:cardscard");
		PlayerTextDrawSetString(playerid, bj2_card_table[playerid][i][2], "blackjack:cardscard");
		PlayerTextDrawSetString(playerid, bj2_card_table[playerid][i][3], "blackjack:cardscard");

		new apponent;
	    switch(i)
	    {
	        case 1:
			{
				if(BlackJackLobby2[lobby][Table1Id2] != -1) apponent = BlackJackLobby2[lobby][Table1Id2];
				else apponent = -1;
			}
	        case 2:
			{
				if(BlackJackLobby2[lobby][Table2Id2] != -1) apponent = BlackJackLobby2[lobby][Table2Id2];
				else apponent = -1;
			}
	        case 3:
			{
				if(BlackJackLobby2[lobby][Table3Id2] != -1) apponent = BlackJackLobby2[lobby][Table3Id2];
				else apponent = -1;
			}
	        case 4:
			{
				if(BlackJackLobby2[lobby][Table4Id2] != -1) apponent = BlackJackLobby2[lobby][Table4Id2];
				else apponent = -1;
			}
		}
		if(apponent != -1)
		{
			PlayerTextDrawHide(apponent, bj2_members_name[apponent][table-1]);
			PlayerTextDrawHide(apponent, bj2_card_table[apponent][table][0]);
			PlayerTextDrawHide(apponent, bj2_card_table[apponent][table][1]);
			PlayerTextDrawHide(apponent, bj2_card_table[apponent][table][2]);
			PlayerTextDrawHide(apponent, bj2_card_table[apponent][table][3]);

			TextDrawHideForPlayer(apponent, bj2_text_point_table[lobby][0]);
			TextDrawHideForPlayer(apponent, bj2_text_point_table[lobby][1]);
			TextDrawHideForPlayer(apponent, bj2_text_point_table[lobby][2]);
			TextDrawHideForPlayer(apponent, bj2_text_point_table[lobby][3]);
		}
	}

	TextDrawHideForPlayer(playerid, bj2_text_bj_table[lobby][0]);
	TextDrawHideForPlayer(playerid, bj2_text_bj_table[lobby][1]);
	TextDrawHideForPlayer(playerid, bj2_text_bj_table[lobby][2]);
	TextDrawHideForPlayer(playerid, bj2_text_bj_table[lobby][3]);

	CancelSelectTextDraw(playerid);
	ClearAnimations(playerid);
	TogglePlayerControllable(playerid, true);
	ShowHud(playerid);

	foreach(new i : Player)
	{
	    ShowPlayerNameTagForPlayer(playerid, i, 1);
	}
	return 1;
}

stock LoadBlackJack2()
{

	new tabletext[128];

    for(new lobby; lobby < MAX_BJ_LOBBY2; lobby++)
	{
	    format(tabletext, sizeof(tabletext), "{FFFF00}BlackJack ���� %d\n{FFFFFF}��������� ��� ��������������", lobby + 1);
        BlackJackText2[lobby] = CreateDynamic3DTextLabel(tabletext, -1, BlackJackPos2[lobby][0], BlackJackPos2[lobby][1], BlackJackPos2[lobby][2], 9.0);

		BlackJackSphere[lobby] = CreateDynamicSphere(BlackJackPos2[lobby][0], BlackJackPos2[lobby][1], BlackJackPos2[lobby][2], 4.0);
		ReloadTable2(lobby);
    	LoadBJLobbyTimer2(lobby);
    	LoadBJLobbyPoint2(lobby);
    	LoadBJLobbyReady2(lobby);
    	LoadBJLobbyDealerCard2(lobby);
    	LoadBJTextBlackJack2(lobby);
    	LoadBJLobbyResult2(lobby);

        LoadTextDrawBj();

		SetTimerEx("TimerSecondUpdateBJ2", 1000, true, "d", lobby);

		TextDrawSetString(bj2_text_point_table[lobby][0], "����: 0");
		TextDrawSetString(bj2_text_point_table[lobby][1], "����: 0");
		TextDrawSetString(bj2_text_point_table[lobby][2], "����: 0");
		TextDrawSetString(bj2_text_point_table[lobby][3], "����: 0");

        bj2_log_text[lobby][0] = TextDrawCreate(321.200073, 254.306640, "");
        TextDrawLetterSize(bj2_log_text[lobby][0], 0.377198, 1.353598);
        TextDrawAlignment(bj2_log_text[lobby][0], 2);
        TextDrawColor(bj2_log_text[lobby][0], -1);
        TextDrawSetShadow(bj2_log_text[lobby][0], 0);
        TextDrawSetOutline(bj2_log_text[lobby][0], 1);
        TextDrawBackgroundColor(bj2_log_text[lobby][0], 51);
        TextDrawFont(bj2_log_text[lobby][0], 1);
        TextDrawSetProportional(bj2_log_text[lobby][0], 1);

        bj2_log_text[lobby][1] = TextDrawCreate(321.200073, 270.306640, "");

		TextDrawLetterSize(bj2_log_text[lobby][1], 0.377198, 1.353598);
		TextDrawAlignment(bj2_log_text[lobby][1], 2);
		TextDrawColor(bj2_log_text[lobby][1], -65281);
		TextDrawSetShadow(bj2_log_text[lobby][1], 0);
		TextDrawSetOutline(bj2_log_text[lobby][1], 1);
		TextDrawBackgroundColor(bj2_log_text[lobby][1], 51);
		TextDrawFont(bj2_log_text[lobby][1], 1);
		TextDrawSetProportional(bj2_log_text[lobby][1], 1);
	}
}
stock LoadBJLobbyTimer2(lobby)
{
    BlackJackLobby2[lobby][StartTimer2] = 60;

    bj2_text_start_timer[lobby] = TextDrawCreate(316.199981, 237.693496, "00:60");
	TextDrawLetterSize(bj2_text_start_timer[lobby], 0.581197, 2.563199);
	TextDrawAlignment(bj2_text_start_timer[lobby], 2);
	TextDrawColor(bj2_text_start_timer[lobby], -1);
	TextDrawSetShadow(bj2_text_start_timer[lobby], 0);
	TextDrawSetOutline(bj2_text_start_timer[lobby], 1);
	TextDrawBackgroundColor(bj2_text_start_timer[lobby], 51);
	TextDrawFont(bj2_text_start_timer[lobby], 1);
	TextDrawSetProportional(bj2_text_start_timer[lobby], 1);
}

stock LoadBJLobbyPoint2(lobby)
{
	bj2_text_point_table[lobby][0] = TextDrawCreate(76.000015, 306.879913, "����: 0");
	TextDrawLetterSize(bj2_text_point_table[lobby][0], 0.356397, 1.174399);
	TextDrawAlignment(bj2_text_point_table[lobby][0], 2);
	TextDrawColor(bj2_text_point_table[lobby][0], -1);
	TextDrawSetShadow(bj2_text_point_table[lobby][0], 0);
	TextDrawSetOutline(bj2_text_point_table[lobby][0], 1);
	TextDrawBackgroundColor(bj2_text_point_table[lobby][0], 51);
	TextDrawFont(bj2_text_point_table[lobby][0], 1);
	TextDrawSetProportional(bj2_text_point_table[lobby][0], 1);

	bj2_text_point_table[lobby][1] = TextDrawCreate(205.799972, 146.599792, "����: 0");
	TextDrawLetterSize(bj2_text_point_table[lobby][1], 0.356397, 1.174399);
	TextDrawAlignment(bj2_text_point_table[lobby][1], 2);
	TextDrawColor(bj2_text_point_table[lobby][1], -1);
	TextDrawSetShadow(bj2_text_point_table[lobby][1], 0);
	TextDrawSetOutline(bj2_text_point_table[lobby][1], 1);
	TextDrawBackgroundColor(bj2_text_point_table[lobby][1], 51);
	TextDrawFont(bj2_text_point_table[lobby][1], 1);
	TextDrawSetProportional(bj2_text_point_table[lobby][1], 1);

	bj2_text_point_table[lobby][2] = TextDrawCreate(457.200195, 146.853118, "����: 0");
	TextDrawLetterSize(bj2_text_point_table[lobby][2], 0.356397, 1.174399);
	TextDrawAlignment(bj2_text_point_table[lobby][2], 2);
	TextDrawColor(bj2_text_point_table[lobby][2], -1);
	TextDrawSetShadow(bj2_text_point_table[lobby][2], 0);
	TextDrawSetOutline(bj2_text_point_table[lobby][2], 1);
	TextDrawBackgroundColor(bj2_text_point_table[lobby][2], 51);
	TextDrawFont(bj2_text_point_table[lobby][2], 1);
	TextDrawSetProportional(bj2_text_point_table[lobby][2], 1);

	bj2_text_point_table[lobby][3] = TextDrawCreate(560.200500, 307.133239, "����: 0");
	TextDrawLetterSize(bj2_text_point_table[lobby][3], 0.356397, 1.174399);
	TextDrawAlignment(bj2_text_point_table[lobby][3], 2);
	TextDrawColor(bj2_text_point_table[lobby][3], -1);
	TextDrawSetShadow(bj2_text_point_table[lobby][3], 0);
	TextDrawSetOutline(bj2_text_point_table[lobby][3], 1);
	TextDrawBackgroundColor(bj2_text_point_table[lobby][3], 51);
	TextDrawFont(bj2_text_point_table[lobby][3], 1);
	TextDrawSetProportional(bj2_text_point_table[lobby][3], 1);
}

stock LoadBJLobbyReady2(lobby)
{
	bj2_table_ready[lobby][1] = TextDrawCreate(77.600013, 320.319999, "�� �����");
	TextDrawLetterSize(bj2_table_ready[lobby][1], 0.365199, 1.219199);
	TextDrawAlignment(bj2_table_ready[lobby][1], 2);
	TextDrawColor(bj2_table_ready[lobby][1], -16776961);
	TextDrawSetShadow(bj2_table_ready[lobby][1], 0);
	TextDrawSetOutline(bj2_table_ready[lobby][1], 1);
	TextDrawBackgroundColor(bj2_table_ready[lobby][1], 51);
	TextDrawFont(bj2_table_ready[lobby][1], 1);
	TextDrawSetProportional(bj2_table_ready[lobby][1], 1);

	bj2_table_ready[lobby][2] = TextDrawCreate(206.800628, 160.293167, "�� �����");
	TextDrawLetterSize(bj2_table_ready[lobby][2], 0.365199, 1.219199);
	TextDrawAlignment(bj2_table_ready[lobby][2], 2);
	TextDrawColor(bj2_table_ready[lobby][2], -16776961);
	TextDrawSetShadow(bj2_table_ready[lobby][2], 0);
	TextDrawSetOutline(bj2_table_ready[lobby][2], 1);
	TextDrawBackgroundColor(bj2_table_ready[lobby][2], 51);
	TextDrawFont(bj2_table_ready[lobby][2], 1);
	TextDrawSetProportional(bj2_table_ready[lobby][2], 1);

	bj2_table_ready[lobby][3] = TextDrawCreate(458.200958, 160.293167, "�� �����");
	TextDrawLetterSize(bj2_table_ready[lobby][3], 0.365199, 1.219199);
	TextDrawAlignment(bj2_table_ready[lobby][3], 2);
	TextDrawColor(bj2_table_ready[lobby][3], -16776961);
	TextDrawSetShadow(bj2_table_ready[lobby][3], 0);
	TextDrawSetOutline(bj2_table_ready[lobby][3], 1);
	TextDrawBackgroundColor(bj2_table_ready[lobby][3], 51);
	TextDrawFont(bj2_table_ready[lobby][3], 1);
	TextDrawSetProportional(bj2_table_ready[lobby][3], 1);

	bj2_table_ready[lobby][4] = TextDrawCreate(561.800598, 320.319999, "�� �����");
	TextDrawLetterSize(bj2_table_ready[lobby][4], 0.365199, 1.219199);
	TextDrawAlignment(bj2_table_ready[lobby][4], 2);
	TextDrawColor(bj2_table_ready[lobby][4], -16776961);
	TextDrawSetShadow(bj2_table_ready[lobby][4], 0);
	TextDrawSetOutline(bj2_table_ready[lobby][4], 1);
	TextDrawBackgroundColor(bj2_table_ready[lobby][4], 51);
	TextDrawFont(bj2_table_ready[lobby][4], 1);
	TextDrawSetProportional(bj2_table_ready[lobby][4], 1);
}

stock LoadBJLobbyDealerCard2(lobby)
{
	bj2_dealer_card[lobby][1] = TextDrawCreate(209.799957, 191.399993, "blackjack:cardsas");
	TextDrawLetterSize(bj2_dealer_card[lobby][1], 0.000000, 0.000000);
	TextDrawTextSize(bj2_dealer_card[lobby][1], 132.000015, 174.719879);
	TextDrawAlignment(bj2_dealer_card[lobby][1], 1);
	TextDrawColor(bj2_dealer_card[lobby][1], -1);
	TextDrawSetShadow(bj2_dealer_card[lobby][1], 0);
	TextDrawSetOutline(bj2_dealer_card[lobby][1], 0);
	TextDrawFont(bj2_dealer_card[lobby][1], 4);

	bj2_dealer_card[lobby][2] = TextDrawCreate(235.600021, 191.653320, "blackjack:cardsas");
	TextDrawLetterSize(bj2_dealer_card[lobby][2], 0.000000, 0.000000);
	TextDrawTextSize(bj2_dealer_card[lobby][2], 132.000015, 174.719879);
	TextDrawAlignment(bj2_dealer_card[lobby][2], 1);
	TextDrawColor(bj2_dealer_card[lobby][2], -1);
	TextDrawSetShadow(bj2_dealer_card[lobby][2], 0);
	TextDrawSetOutline(bj2_dealer_card[lobby][2], 0);
	TextDrawFont(bj2_dealer_card[lobby][2], 4);

	bj2_dealer_card[lobby][3] = TextDrawCreate(314.200042, 191.906646, "blackjack:cardskd");
	TextDrawLetterSize(bj2_dealer_card[lobby][3], 0.000000, 0.000000);
	TextDrawTextSize(bj2_dealer_card[lobby][3], 132.000015, 174.719879);
	TextDrawAlignment(bj2_dealer_card[lobby][3], 1);
	TextDrawColor(bj2_dealer_card[lobby][3], -1);
	TextDrawSetShadow(bj2_dealer_card[lobby][3], 0);
	TextDrawSetOutline(bj2_dealer_card[lobby][3], 0);
	TextDrawFont(bj2_dealer_card[lobby][3], 4);
}

stock LoadBJTextBlackJack2(lobby)
{
    bj2_text_bj_table[lobby][0] = TextDrawCreate(31.200008, 312.106567, "blackjack:brbjblackjack");
	TextDrawLetterSize(bj2_text_bj_table[lobby][0], 0.000000, 0.000000);
	TextDrawTextSize(bj2_text_bj_table[lobby][0], 91.199974, 46.293384);
	TextDrawAlignment(bj2_text_bj_table[lobby][0], 1);
	TextDrawColor(bj2_text_bj_table[lobby][0], -1);
	TextDrawSetShadow(bj2_text_bj_table[lobby][0], 0);
	TextDrawSetOutline(bj2_text_bj_table[lobby][0], 0);
	TextDrawFont(bj2_text_bj_table[lobby][0], 4);

	bj2_text_bj_table[lobby][1] = TextDrawCreate(161.000030, 152.079727, "blackjack:brbjblackjack");
	TextDrawLetterSize(bj2_text_bj_table[lobby][1], 0.000000, 0.000000);
	TextDrawTextSize(bj2_text_bj_table[lobby][1], 91.199974, 46.293384);
	TextDrawAlignment(bj2_text_bj_table[lobby][1], 1);
	TextDrawColor(bj2_text_bj_table[lobby][1], -1);
	TextDrawSetShadow(bj2_text_bj_table[lobby][1], 0);
	TextDrawSetOutline(bj2_text_bj_table[lobby][1], 0);
	TextDrawFont(bj2_text_bj_table[lobby][1], 4);

	bj2_text_bj_table[lobby][2] = TextDrawCreate(412.400238, 152.079727, "blackjack:brbjblackjack");
	TextDrawLetterSize(bj2_text_bj_table[lobby][2], 0.000000, 0.000000);
	TextDrawTextSize(bj2_text_bj_table[lobby][2], 91.199974, 46.293384);
	TextDrawAlignment(bj2_text_bj_table[lobby][2], 1);
	TextDrawColor(bj2_text_bj_table[lobby][2], -1);
	TextDrawSetShadow(bj2_text_bj_table[lobby][2], 0);
	TextDrawSetOutline(bj2_text_bj_table[lobby][2], 0);
	TextDrawFont(bj2_text_bj_table[lobby][2], 4);

	bj2_text_bj_table[lobby][3] = TextDrawCreate(515.400390, 312.106567, "blackjack:brbjblackjack");
	TextDrawLetterSize(bj2_text_bj_table[lobby][3], 0.000000, 0.000000);
	TextDrawTextSize(bj2_text_bj_table[lobby][3], 91.199974, 46.293384);
	TextDrawAlignment(bj2_text_bj_table[lobby][3], 1);
	TextDrawColor(bj2_text_bj_table[lobby][3], -1);
	TextDrawSetShadow(bj2_text_bj_table[lobby][3], 0);
	TextDrawSetOutline(bj2_text_bj_table[lobby][3], 0);
	TextDrawFont(bj2_text_bj_table[lobby][3], 4);
}

stock LoadBJLobbyResult2(lobby)
{
//bj2_result_table

	bj2_result_table[lobby][0] = TextDrawCreate(88.800003, 187.666666, "blackjack:brbjwin");
 	TextDrawLetterSize(		bj2_result_table[lobby][0], 0.000000, 0.000000);
	TextDrawTextSize( 		bj2_result_table[lobby][0], 69.599975, 34.346652);
	TextDrawAlignment(		bj2_result_table[lobby][0], 1);
	TextDrawColor(			bj2_result_table[lobby][0], -1);
	TextDrawSetShadow(		bj2_result_table[lobby][0], 0);
	TextDrawSetOutline(		bj2_result_table[lobby][0], 0);
	TextDrawFont(			bj2_result_table[lobby][0], 4);

	bj2_result_table[lobby][1] = TextDrawCreate(215.400009, 27.133293, "blackjack:brbjlose");
 	TextDrawLetterSize(		bj2_result_table[lobby][1], 0.000000, 0.000000);
	TextDrawTextSize(		bj2_result_table[lobby][1], 69.599975, 34.346652);
	TextDrawAlignment(		bj2_result_table[lobby][1], 1);
	TextDrawColor(			bj2_result_table[lobby][1], -1);
	TextDrawSetShadow(		bj2_result_table[lobby][1], 0);
	TextDrawSetOutline(		bj2_result_table[lobby][1], 0);
	TextDrawFont(			bj2_result_table[lobby][1], 4);

	bj2_result_table[lobby][2] = TextDrawCreate(466.800170, 27.133293, "blackjack:brbjmydraw");
	TextDrawLetterSize(		bj2_result_table[lobby][2], 0.000000, 0.000000);
	TextDrawTextSize(		bj2_result_table[lobby][2], 69.599975, 34.346652);
	TextDrawAlignment(		bj2_result_table[lobby][2], 1);
	TextDrawColor(			bj2_result_table[lobby][2], -1);
	TextDrawSetShadow(		bj2_result_table[lobby][2], 0);
	TextDrawSetOutline(		bj2_result_table[lobby][2], 0);
	TextDrawFont(			bj2_result_table[lobby][2], 4);

	bj2_result_table[lobby][3] = TextDrawCreate(569.000610, 187.666666, "blackjack:brbjmydraw");
	TextDrawLetterSize(		bj2_result_table[lobby][3], 0.000000, 0.000000);
	TextDrawTextSize(		bj2_result_table[lobby][3], 69.599975, 34.346652);
	TextDrawAlignment(		bj2_result_table[lobby][3], 1);
	TextDrawColor(			bj2_result_table[lobby][3], -1);
	TextDrawSetShadow(		bj2_result_table[lobby][3], 0);
	TextDrawSetOutline(		bj2_result_table[lobby][3], 0);
	TextDrawFont(			bj2_result_table[lobby][3], 4);


}

stock ReloadTable2(lobby)
{
    BlackJackLobby2[lobby][Table1Id2] = -1;
    BlackJackLobby2[lobby][Table2Id2] = -1;
    BlackJackLobby2[lobby][Table3Id2] = -1;
    BlackJackLobby2[lobby][Table4Id2] = -1;
}


forward TimerSecondUpdateBJ2(lobby);
public TimerSecondUpdateBJ2(lobby)
{
	new bool:members;
	if(BlackJackLobby2[lobby][Table1Id2] != -1) members = true;
	else if(BlackJackLobby2[lobby][Table2Id2] != -1) members = true;
	else if(BlackJackLobby2[lobby][Table3Id2] != -1) members = true;
	else if(BlackJackLobby2[lobby][Table4Id2] != -1) members = true;

	if(members == true)
	{
		BlackJackLobby2[lobby][ActivedLobby2] = true;
	    if(BlackJackLobby2[lobby][StartedLobby2])
	    {
			switch(BlackJackLobby2[lobby][StageLobby2])
			{
			    case 1: //������� ��������� ����, ����� ����� ������, ������ �������
			    {

		     		if(BlackJackLobby2[lobby][Table1Id2] != -1)
					{
						for(new table; table < 4; table++)
						{
							PlayerTextDrawHide(BlackJackLobby2[lobby][Table1Id2], bj2_card_table[BlackJackLobby2[lobby][Table1Id2]][table][0]);
							PlayerTextDrawHide(BlackJackLobby2[lobby][Table1Id2], bj2_card_table[BlackJackLobby2[lobby][Table1Id2]][table][1]);
							PlayerTextDrawHide(BlackJackLobby2[lobby][Table1Id2], bj2_card_table[BlackJackLobby2[lobby][Table1Id2]][table][2]);
							PlayerTextDrawHide(BlackJackLobby2[lobby][Table1Id2], bj2_card_table[BlackJackLobby2[lobby][Table1Id2]][table][3]);
						}
						TextDrawHideForPlayer(BlackJackLobby2[lobby][Table1Id2], bj_play2);
						TextDrawShowForPlayer(BlackJackLobby2[lobby][Table1Id2], bj_dealer_score2);
						PlayerTextDrawShow(BlackJackLobby2[lobby][Table1Id2], bj2_dealer_point[BlackJackLobby2[lobby][Table1Id2]]);
						PlayerTextDrawSetString(BlackJackLobby2[lobby][Table1Id2], bj2_dealer_point[BlackJackLobby2[lobby][Table1Id2]], "0");

						TextDrawHideForPlayer(BlackJackLobby2[lobby][Table1Id2], bj2_table_ready[lobby][1]);
						TextDrawHideForPlayer(BlackJackLobby2[lobby][Table1Id2], bj2_table_ready[lobby][2]);
						TextDrawHideForPlayer(BlackJackLobby2[lobby][Table1Id2], bj2_table_ready[lobby][3]);
						TextDrawHideForPlayer(BlackJackLobby2[lobby][Table1Id2], bj2_table_ready[lobby][4]);

						TextDrawShowForPlayer(BlackJackLobby2[lobby][Table1Id2], bj2_log_text[lobby][0]);
						TextDrawShowForPlayer(BlackJackLobby2[lobby][Table1Id2], bj2_log_text[lobby][1]);

						TextDrawShowForPlayer(BlackJackLobby2[lobby][Table1Id2], bj2_text_point_table[lobby][0]);
						if(BlackJackLobby2[lobby][Table2Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table1Id2], bj2_text_point_table[lobby][1]);
						if(BlackJackLobby2[lobby][Table3Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table1Id2], bj2_text_point_table[lobby][2]);
						if(BlackJackLobby2[lobby][Table4Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table1Id2], bj2_text_point_table[lobby][3]);
					}
					if(BlackJackLobby2[lobby][Table2Id2] != -1)
					{
						for(new table; table < 4; table++)
						{
							PlayerTextDrawHide(BlackJackLobby2[lobby][Table2Id2], bj2_card_table[BlackJackLobby2[lobby][Table2Id2]][table][0]);
							PlayerTextDrawHide(BlackJackLobby2[lobby][Table2Id2], bj2_card_table[BlackJackLobby2[lobby][Table2Id2]][table][1]);
							PlayerTextDrawHide(BlackJackLobby2[lobby][Table2Id2], bj2_card_table[BlackJackLobby2[lobby][Table2Id2]][table][2]);
							PlayerTextDrawHide(BlackJackLobby2[lobby][Table2Id2], bj2_card_table[BlackJackLobby2[lobby][Table2Id2]][table][3]);
						}
						TextDrawHideForPlayer(BlackJackLobby2[lobby][Table2Id2], bj_play2);
						TextDrawShowForPlayer(BlackJackLobby2[lobby][Table2Id2], bj_dealer_score2);
						PlayerTextDrawShow(BlackJackLobby2[lobby][Table2Id2], bj2_dealer_point[BlackJackLobby2[lobby][Table2Id2]]);
						PlayerTextDrawSetString(BlackJackLobby2[lobby][Table2Id2], bj2_dealer_point[BlackJackLobby2[lobby][Table2Id2]], "0");

						TextDrawHideForPlayer(BlackJackLobby2[lobby][Table2Id2], bj2_table_ready[lobby][1]);
						TextDrawHideForPlayer(BlackJackLobby2[lobby][Table2Id2], bj2_table_ready[lobby][2]);
						TextDrawHideForPlayer(BlackJackLobby2[lobby][Table2Id2], bj2_table_ready[lobby][3]);
						TextDrawHideForPlayer(BlackJackLobby2[lobby][Table2Id2], bj2_table_ready[lobby][4]);

						TextDrawShowForPlayer(BlackJackLobby2[lobby][Table2Id2], bj2_log_text[lobby][0]);
						TextDrawShowForPlayer(BlackJackLobby2[lobby][Table2Id2], bj2_log_text[lobby][1]);

						if(BlackJackLobby2[lobby][Table1Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table2Id2], bj2_text_point_table[lobby][0]);
						TextDrawShowForPlayer(BlackJackLobby2[lobby][Table2Id2], bj2_text_point_table[lobby][1]);
						if(BlackJackLobby2[lobby][Table3Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table2Id2], bj2_text_point_table[lobby][2]);
						if(BlackJackLobby2[lobby][Table4Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table2Id2], bj2_text_point_table[lobby][3]);
					}
					if(BlackJackLobby2[lobby][Table3Id2] != -1)
					{
						for(new table; table < 4; table++)
						{
							PlayerTextDrawHide(BlackJackLobby2[lobby][Table3Id2], bj2_card_table[BlackJackLobby2[lobby][Table3Id2]][table][0]);
							PlayerTextDrawHide(BlackJackLobby2[lobby][Table3Id2], bj2_card_table[BlackJackLobby2[lobby][Table3Id2]][table][1]);
							PlayerTextDrawHide(BlackJackLobby2[lobby][Table3Id2], bj2_card_table[BlackJackLobby2[lobby][Table3Id2]][table][2]);
							PlayerTextDrawHide(BlackJackLobby2[lobby][Table3Id2], bj2_card_table[BlackJackLobby2[lobby][Table3Id2]][table][3]);
						}
						TextDrawHideForPlayer(BlackJackLobby2[lobby][Table3Id2], bj_play2);
						TextDrawShowForPlayer(BlackJackLobby2[lobby][Table3Id2], bj_dealer_score2);
						PlayerTextDrawShow(BlackJackLobby2[lobby][Table3Id2], bj2_dealer_point[BlackJackLobby2[lobby][Table3Id2]]);
						PlayerTextDrawSetString(BlackJackLobby2[lobby][Table3Id2], bj2_dealer_point[BlackJackLobby2[lobby][Table3Id2]], "0");

						TextDrawHideForPlayer(BlackJackLobby2[lobby][Table3Id2], bj2_table_ready[lobby][1]);
						TextDrawHideForPlayer(BlackJackLobby2[lobby][Table3Id2], bj2_table_ready[lobby][2]);
						TextDrawHideForPlayer(BlackJackLobby2[lobby][Table3Id2], bj2_table_ready[lobby][3]);
						TextDrawHideForPlayer(BlackJackLobby2[lobby][Table3Id2], bj2_table_ready[lobby][4]);

						TextDrawShowForPlayer(BlackJackLobby2[lobby][Table3Id2], bj2_log_text[lobby][0]);
						TextDrawShowForPlayer(BlackJackLobby2[lobby][Table3Id2], bj2_log_text[lobby][1]);

						if(BlackJackLobby2[lobby][Table1Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table3Id2], bj2_text_point_table[lobby][0]);
						if(BlackJackLobby2[lobby][Table2Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table3Id2], bj2_text_point_table[lobby][1]);
						TextDrawShowForPlayer(BlackJackLobby2[lobby][Table3Id2], bj2_text_point_table[lobby][2]);
						if(BlackJackLobby2[lobby][Table4Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table3Id2], bj2_text_point_table[lobby][3]);
					}
					if(BlackJackLobby2[lobby][Table4Id2] != -1)
					{
						for(new table; table < 4; table++)
						{
							PlayerTextDrawHide(BlackJackLobby2[lobby][Table4Id2], bj2_card_table[BlackJackLobby2[lobby][Table4Id2]][table][0]);
							PlayerTextDrawHide(BlackJackLobby2[lobby][Table4Id2], bj2_card_table[BlackJackLobby2[lobby][Table4Id2]][table][1]);
							PlayerTextDrawHide(BlackJackLobby2[lobby][Table4Id2], bj2_card_table[BlackJackLobby2[lobby][Table4Id2]][table][2]);
							PlayerTextDrawHide(BlackJackLobby2[lobby][Table4Id2], bj2_card_table[BlackJackLobby2[lobby][Table4Id2]][table][3]);
						}
						TextDrawHideForPlayer(BlackJackLobby2[lobby][Table4Id2], bj_play2);
						TextDrawShowForPlayer(BlackJackLobby2[lobby][Table4Id2], bj_dealer_score2);
						PlayerTextDrawShow(BlackJackLobby2[lobby][Table4Id2], bj2_dealer_point[BlackJackLobby2[lobby][Table4Id2]]);
						PlayerTextDrawSetString(BlackJackLobby2[lobby][Table4Id2], bj2_dealer_point[BlackJackLobby2[lobby][Table4Id2]], "0");

						TextDrawHideForPlayer(BlackJackLobby2[lobby][Table4Id2], bj2_table_ready[lobby][1]);
						TextDrawHideForPlayer(BlackJackLobby2[lobby][Table4Id2], bj2_table_ready[lobby][2]);
						TextDrawHideForPlayer(BlackJackLobby2[lobby][Table4Id2], bj2_table_ready[lobby][3]);
						TextDrawHideForPlayer(BlackJackLobby2[lobby][Table4Id2], bj2_table_ready[lobby][4]);

						TextDrawShowForPlayer(BlackJackLobby2[lobby][Table4Id2], bj2_log_text[lobby][0]);
						TextDrawShowForPlayer(BlackJackLobby2[lobby][Table4Id2], bj2_log_text[lobby][1]);

						if(BlackJackLobby2[lobby][Table1Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table4Id2], bj2_text_point_table[lobby][0]);
						if(BlackJackLobby2[lobby][Table2Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table4Id2], bj2_text_point_table[lobby][1]);
						if(BlackJackLobby2[lobby][Table3Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table4Id2], bj2_text_point_table[lobby][2]);
						TextDrawShowForPlayer(BlackJackLobby2[lobby][Table4Id2], bj2_text_point_table[lobby][3]);
					}

				 	BlackJackLobby2[lobby][StageLobby2]++; BlackJackLobby2[lobby][DealerTurnGived2]++; //+���
				}


				case 2: //������� ������ ���� ���������� � ������ //timerlobby
				{
				    switch(BlackJackLobby2[lobby][DealerTurnGived2])
				    {
				        case 1:
						{
							BlackJackLobby2[lobby][DealerTurnGived2] = 0; SetTimerEx("TimerDealerNext2", 2000, false, "d", lobby);
							TextDrawSetString(bj2_log_text[lobby][0], "����� ����� ���� �����");
							TextDrawColor(bj2_log_text[lobby][0], -1);
							TextDrawSetString(bj2_log_text[lobby][1], "");
							TextDrawColor(bj2_log_text[lobby][1], -65281);

					        new dealer_suit = random(13);
							new dealer_type = random(4);

							BlackJackLobby2[lobby][DealerPoint2] += BlackJackCard2[dealer_suit][dealer_type][Pointscore2];
							TextDrawSetString(bj2_dealer_card[lobby][1], BlackJackCard2[dealer_suit][dealer_type][Cardtexture2]);

							if(BlackJackLobby2[lobby][Table1Id2] != -1)
							{
								new str[2];
								format(str, sizeof str, "%d", BlackJackLobby2[lobby][DealerPoint2]);
								PlayerTextDrawSetString(BlackJackLobby2[lobby][Table1Id2], bj2_dealer_point[BlackJackLobby2[lobby][Table1Id2]], str);
								TextDrawShowForPlayer(BlackJackLobby2[lobby][Table1Id2], bj2_dealer_card[lobby][1]);
							}
							if(BlackJackLobby2[lobby][Table2Id2] != -1)
							{
								new str[2];
								format(str, sizeof str, "%d", BlackJackLobby2[lobby][DealerPoint2]);
								PlayerTextDrawSetString(BlackJackLobby2[lobby][Table2Id2], bj2_dealer_point[BlackJackLobby2[lobby][Table2Id2]], str);
								TextDrawShowForPlayer(BlackJackLobby2[lobby][Table2Id2], bj2_dealer_card[lobby][1]);
							}
							if(BlackJackLobby2[lobby][Table3Id2] != -1)
							{
								new str[2];
								format(str, sizeof str, "%d", BlackJackLobby2[lobby][DealerPoint2]);
								PlayerTextDrawSetString(BlackJackLobby2[lobby][Table3Id2], bj2_dealer_point[BlackJackLobby2[lobby][Table3Id2]], str);
								TextDrawShowForPlayer(BlackJackLobby2[lobby][Table3Id2], bj2_dealer_card[lobby][1]);
							}
							if(BlackJackLobby2[lobby][Table4Id2] != -1)
							{
								new str[2];
								format(str, sizeof str, "%d", BlackJackLobby2[lobby][DealerPoint2]);
								PlayerTextDrawSetString(BlackJackLobby2[lobby][Table4Id2], bj2_dealer_point[BlackJackLobby2[lobby][Table4Id2]], str);
								TextDrawShowForPlayer(BlackJackLobby2[lobby][Table4Id2], bj2_dealer_card[lobby][1]);
							}
						}
						case 2: BlackJackLobby2[lobby][DealerTurnGived2]++;
						case 3:
						{
							if(BlackJackLobby2[lobby][Table1Id2] != -1)
							{
	                            BlackJackLobby2[lobby][DealerTurnGived2]++;
								new str[10];
								format(str, sizeof str, "%d", BlackJackLobby2[lobby][DealerPoint2]);
								PlayerTextDrawSetString(BlackJackLobby2[lobby][Table1Id2], bj2_dealer_point[BlackJackLobby2[lobby][Table1Id2]], str);

								new suit = random(13);
								new type = random(4);

								BlackJackLobby2[lobby][Table1Point2] += BlackJackCard2[suit][type][Pointscore2];

								format(str, sizeof str, "����: %d", BlackJackLobby2[lobby][Table1Point2]);
								TextDrawSetString(bj2_text_point_table[lobby][0], str);
								//BlackJackLobby2[lobby][Table1Card][0] = class;
								//BlackJackLobby2[lobby][Table1Card][1] = type;

								ShowMembersCardBJL2(lobby, 1, 0, suit, type);

							}
							else BlackJackLobby2[lobby][DealerTurnGived2] = 5;
						}
						case 4: BlackJackLobby2[lobby][DealerTurnGived2]++;

						case 5:
						{
						    if(BlackJackLobby2[lobby][Table2Id2] != -1)
							{
		                      	BlackJackLobby2[lobby][DealerTurnGived2]++;
								new str[10];

								new suit = random(13);
								new type = random(4);

								BlackJackLobby2[lobby][Table2Point2] += BlackJackCard2[suit][type][Pointscore2];

								format(str, sizeof str, "����: %d", BlackJackLobby2[lobby][Table2Point2]);
								TextDrawSetString(bj2_text_point_table[lobby][1], str);
								//BlackJackLobby2[lobby][Table1Card][0] = class;
								//BlackJackLobby2[lobby][Table1Card][1] = type;

								ShowMembersCardBJL2(lobby, 2, 0, suit, type);

							}
							else BlackJackLobby2[lobby][DealerTurnGived2] = 7;

						}
						case 6: BlackJackLobby2[lobby][DealerTurnGived2]++;

						case 7:
						{
						    if(BlackJackLobby2[lobby][Table3Id2] != -1)
							{
	                            BlackJackLobby2[lobby][DealerTurnGived2]++;
								new str[10];

								new suit = random(13);
								new type = random(4);

								BlackJackLobby2[lobby][Table3Point2] += BlackJackCard2[suit][type][Pointscore2];

								format(str, sizeof str, "����: %d", BlackJackLobby2[lobby][Table3Point2]);
								TextDrawSetString(bj2_text_point_table[lobby][2], str);
								//BlackJackLobby2[lobby][Table1Card][0] = class;
								//BlackJackLobby2[lobby][Table1Card][1] = type;

								ShowMembersCardBJL2(lobby, 3, 0, suit, type);
							}
							else BlackJackLobby2[lobby][DealerTurnGived2] = 9;
						}
						case 8: BlackJackLobby2[lobby][DealerTurnGived2]++;

						case 9:
						{
							BlackJackLobby2[lobby][DealerTurnGived2] = 1; BlackJackLobby2[lobby][StageLobby2]++;
					 		if(BlackJackLobby2[lobby][Table4Id2] != -1)
							{
								new str[10];

								new suit = random(13);
								new type = random(4);

								BlackJackLobby2[lobby][Table4Point2] += BlackJackCard2[suit][type][Pointscore2];

								format(str, sizeof str, "����: %d", BlackJackLobby2[lobby][Table4Point2]);
								TextDrawSetString(bj2_text_point_table[lobby][3], str);
								//BlackJackLobby2[lobby][Table1Card][0] = class;
								//BlackJackLobby2[lobby][Table1Card][1] = type;

								ShowMembersCardBJL2(lobby, 4, 0, suit, type);
							}
						}
					}
				}


				case 3: //timerlobby
				{
				    switch(BlackJackLobby2[lobby][DealerTurnGived2])
				    {
				        case 1:
				        {

							//BlackJackLobby2[lobby][DealerPoint2] += BlackJackCard2[dealer_suit][dealer_type][Pointscore2];
							TextDrawSetString(bj2_dealer_card[lobby][2], "blackjack:cardscard");

							BlackJackLobby2[lobby][DealerTurnGived2]++;

							if(BlackJackLobby2[lobby][Table1Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table1Id2], bj2_dealer_card[lobby][2]);
							if(BlackJackLobby2[lobby][Table2Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table2Id2], bj2_dealer_card[lobby][2]);
							if(BlackJackLobby2[lobby][Table3Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table3Id2], bj2_dealer_card[lobby][2]);
							if(BlackJackLobby2[lobby][Table4Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table4Id2], bj2_dealer_card[lobby][2]);
						}
						case 2: BlackJackLobby2[lobby][DealerTurnGived2]++;
						case 3:
						{
							if(BlackJackLobby2[lobby][Table1Id2] != -1)
							{
	                            BlackJackLobby2[lobby][DealerTurnGived2]++;
								new str[10];
								format(str, sizeof str, "%d", BlackJackLobby2[lobby][DealerPoint2]);
								PlayerTextDrawSetString(BlackJackLobby2[lobby][Table1Id2], bj2_dealer_point[BlackJackLobby2[lobby][Table1Id2]], str);

								new suit = random(13);
								new type = random(4);

								BlackJackLobby2[lobby][Table1Point2] += BlackJackCard2[suit][type][Pointscore2];
								CheckTableBlackJack2(lobby, 1);



								format(str, sizeof str, "����: %d", BlackJackLobby2[lobby][Table1Point2]);
								TextDrawSetString(bj2_text_point_table[lobby][0], str);
								//BlackJackLobby2[lobby][Table1Card][0] = class;
								//BlackJackLobby2[lobby][Table1Card][1] = type;

								ShowMembersCardBJL2(lobby, 1, 1, suit, type);
							}
							else BlackJackLobby2[lobby][DealerTurnGived2] = 5;
						}
						case 4: BlackJackLobby2[lobby][DealerTurnGived2]++;

						case 5:
						{
						    if(BlackJackLobby2[lobby][Table2Id2] != -1)
							{
	                            BlackJackLobby2[lobby][DealerTurnGived2]++;
								new str[10];
								format(str, sizeof str, "%d", BlackJackLobby2[lobby][DealerPoint2]);
								PlayerTextDrawSetString(BlackJackLobby2[lobby][Table2Id2], bj2_dealer_point[BlackJackLobby2[lobby][Table2Id2]], str);

								new suit = random(13);
								new type = random(4);

								BlackJackLobby2[lobby][Table2Point2] += BlackJackCard2[suit][type][Pointscore2];
								CheckTableBlackJack2(lobby, 2);

								format(str, sizeof str, "����: %d", BlackJackLobby2[lobby][Table2Point2]);
								TextDrawSetString(bj2_text_point_table[lobby][1], str);
								//BlackJackLobby2[lobby][Table1Card][0] = class;
								//BlackJackLobby2[lobby][Table1Card][1] = type;

								ShowMembersCardBJL2(lobby, 2, 1, suit, type);
							}
							else BlackJackLobby2[lobby][DealerTurnGived2] = 7;

						}
						case 6: BlackJackLobby2[lobby][DealerTurnGived2]++;

						case 7:
						{
						    if(BlackJackLobby2[lobby][Table3Id2] != -1)
							{
		                  		BlackJackLobby2[lobby][DealerTurnGived2]++;
								new str[10];
								format(str, sizeof str, "%d", BlackJackLobby2[lobby][DealerPoint2]);
								PlayerTextDrawSetString(BlackJackLobby2[lobby][Table3Id2], bj2_dealer_point[BlackJackLobby2[lobby][Table3Id2]], str);

								new suit = random(13);
								new type = random(4);

								BlackJackLobby2[lobby][Table3Point2] += BlackJackCard2[suit][type][Pointscore2];
								CheckTableBlackJack2(lobby, 3);

								format(str, sizeof str, "����: %d", BlackJackLobby2[lobby][Table3Point2]);
								TextDrawSetString(bj2_text_point_table[lobby][2], str);
								//BlackJackLobby2[lobby][Table1Card][0] = class;
								//BlackJackLobby2[lobby][Table1Card][1] = type;

								ShowMembersCardBJL2(lobby, 3, 1, suit, type);
							}
							else BlackJackLobby2[lobby][DealerTurnGived2] = 9;
						}
						case 8: BlackJackLobby2[lobby][DealerTurnGived2]++;

						case 9:
						{
							BlackJackLobby2[lobby][DealerTurnGived2] = 0; BlackJackLobby2[lobby][StageLobby2]++; BlackJackLobby2[lobby][TableTurn2]++; //������� ����������
					 		if(BlackJackLobby2[lobby][Table4Id2] != -1)
							{
		                      	BlackJackLobby2[lobby][DealerTurnGived2]++;
								new str[10];
								format(str, sizeof str, "%d", BlackJackLobby2[lobby][DealerPoint2]);
								PlayerTextDrawSetString(BlackJackLobby2[lobby][Table4Id2], bj2_dealer_point[BlackJackLobby2[lobby][Table4Id2]], str);

								new suit = random(13);
								new type = random(4);

								BlackJackLobby2[lobby][Table4Point2] += BlackJackCard2[suit][type][Pointscore2];
								CheckTableBlackJack2(lobby, 4);

								format(str, sizeof str, "����: %d", BlackJackLobby2[lobby][Table4Point2]);
								TextDrawSetString(bj2_text_point_table[lobby][3], str);
								//BlackJackLobby2[lobby][Table1Card][0] = class;
								//BlackJackLobby2[lobby][Table1Card][1] = type;

								ShowMembersCardBJL2(lobby, 4, 1, suit, type);
							}
						}
					}


				}

                case 4: //timerlobby
				{
    				switch(BlackJackLobby2[lobby][TableTurn2])
    				{
        				case 1:
        				{
        				    if(BlackJackLobby2[lobby][Table1Id2] != -1)
        				    {
            				    if(BlackJackLobby2[lobby][Table1Point2] == 21 || BlackJackLobby2[lobby][Table1Point2] > 21) return BlackJackLobby2[lobby][TableTurnTime2] = 0, BlackJackLobby2[lobby][TableTurn2]++;
            				    if(BlackJackLobby2[lobby][TableTurnTime2] == 0)
            				    {
            				        BlackJackLobby2[lobby][TableTurnTime2] = 15;
            				        PlayerTextDrawSetString(BlackJackLobby2[lobby][Table1Id2], bj2_panel_info[BlackJackLobby2[lobby][Table1Id2]], "blackjack:brbjyouturn");
            				        PlayerTextDrawShow(BlackJackLobby2[lobby][Table1Id2], bj2_panel_info[BlackJackLobby2[lobby][Table1Id2]]);
            				        SetTimerEx("TimerHideYouTurn2", 2000, false, "d", BlackJackLobby2[lobby][Table1Id2]);

        				            new str[24];
        				            TextDrawSetString(bj2_log_text[lobby][0], "��� ��� 00:15");
        				            TextDrawColor(bj2_log_text[lobby][0], -1);
        				            GetPlayerName(BlackJackLobby2[lobby][Table1Id2], str, 24);
        				            TextDrawSetString(bj2_log_text[lobby][1], str);
        				            TextDrawColor(bj2_log_text[lobby][1], -65281);
        				        }
        				        else if(BlackJackLobby2[lobby][TableTurnTime2] == 1)
        				        {
        				            BlackJackLobby2[lobby][TableTurnTime2]--;
       				                BlackJackLobby2[lobby][TableTurn2]++;

        				            TextDrawSetString(bj2_log_text[lobby][0], "����� �������");
        				            TextDrawColor(bj2_log_text[lobby][0], -1);
        				        }
        				        else
        				        {
        				            BlackJackLobby2[lobby][TableTurnTime2]--;
        				            new str[24];
        				            format(str, sizeof str, "��� ��� 00:%02d", BlackJackLobby2[lobby][TableTurnTime2]);
        				            TextDrawSetString(bj2_log_text[lobby][0], str);
        				            TextDrawColor(bj2_log_text[lobby][0], -1);
        				        }
        				    }
        				    else BlackJackLobby2[lobby][TableTurn2]++;
        				}
        				case 2:
        				{
        				    if(BlackJackLobby2[lobby][Table2Id2] != -1)
        				    {
        				        if(BlackJackLobby2[lobby][Table2Point2] == 21 || BlackJackLobby2[lobby][Table2Point2] > 21) return BlackJackLobby2[lobby][TableTurnTime2] = 0, BlackJackLobby2[lobby][TableTurn2]++;
        				        if(BlackJackLobby2[lobby][TableTurnTime2] == 0)
        				        {
            				        BlackJackLobby2[lobby][TableTurnTime2] = 15;
        				            PlayerTextDrawSetString(BlackJackLobby2[lobby][Table2Id2], bj2_panel_info[BlackJackLobby2[lobby][Table2Id2]], "blackjack:brbjyouturn");
        				            PlayerTextDrawShow(BlackJackLobby2[lobby][Table2Id2], bj2_panel_info[BlackJackLobby2[lobby][Table2Id2]]);
        				            SetTimerEx("TimerHideYouTurn2", 2000, false, "d", BlackJackLobby2[lobby][Table2Id2]);

        				            new str[24];
        				            TextDrawSetString(bj2_log_text[lobby][0], "��� ��� 00:15");
        				            TextDrawColor(bj2_log_text[lobby][0], -1);
        				            GetPlayerName(BlackJackLobby2[lobby][Table2Id2], str, 24);
        				            TextDrawSetString(bj2_log_text[lobby][1], str);
        				            TextDrawColor(bj2_log_text[lobby][1], -65281);
        				        }
        				        else if(BlackJackLobby2[lobby][TableTurnTime2] == 1)
        				        {
        				            BlackJackLobby2[lobby][TableTurnTime2]--;
        				            BlackJackLobby2[lobby][TableTurn2]++;

        				            TextDrawSetString(bj2_log_text[lobby][0], "����� �������");
        				            TextDrawColor(bj2_log_text[lobby][0], -1);
        				        }
        				        else
        				        {
        				            BlackJackLobby2[lobby][TableTurnTime2]--;
        				            new str[24];
        				            format(str, sizeof str, "��� ��� 00:%02d", BlackJackLobby2[lobby][TableTurnTime2]);
        				            TextDrawSetString(bj2_log_text[lobby][0], str);
        				            TextDrawColor(bj2_log_text[lobby][0], -1);
        				        }
        				    }
        				    else BlackJackLobby2[lobby][TableTurn2]++;
        				}
        				case 3:
        				{
        				    if(BlackJackLobby2[lobby][Table3Id2] != -1)
        				    {
        				        if(BlackJackLobby2[lobby][Table3Point2] == 21 || BlackJackLobby2[lobby][Table3Point2] > 21) return BlackJackLobby2[lobby][TableTurnTime2] = 0, BlackJackLobby2[lobby][TableTurn2]++;
        				        if(BlackJackLobby2[lobby][TableTurnTime2] == 0)
        				        {
        				            BlackJackLobby2[lobby][TableTurnTime2] = 15;
        				            PlayerTextDrawSetString(BlackJackLobby2[lobby][Table3Id2], bj2_panel_info[BlackJackLobby2[lobby][Table3Id2]], "blackjack:brbjyouturn");
        				            PlayerTextDrawShow(BlackJackLobby2[lobby][Table3Id2], bj2_panel_info[BlackJackLobby2[lobby][Table3Id2]]);
        				            SetTimerEx("TimerHideYouTurn2", 2000, false, "d", BlackJackLobby2[lobby][Table3Id2]);

        				            new str[24];
        				            TextDrawSetString(bj2_log_text[lobby][0], "��� ��� 00:15");
        				            TextDrawColor(bj2_log_text[lobby][0], -1);
        				            GetPlayerName(BlackJackLobby2[lobby][Table3Id2], str, 24);
        				            TextDrawSetString(bj2_log_text[lobby][1], str);
        				            TextDrawColor(bj2_log_text[lobby][1], -65281);
        				        }
        				        else if(BlackJackLobby2[lobby][TableTurnTime2] == 1)
        				        {
        				            BlackJackLobby2[lobby][TableTurnTime2]--;
        				            BlackJackLobby2[lobby][TableTurn2]++;

        				            TextDrawSetString(bj2_log_text[lobby][0], "����� �������");
        				            TextDrawColor(bj2_log_text[lobby][0], -1);
        				        }
        				        else
        				        {
        				            BlackJackLobby2[lobby][TableTurnTime2]--;
        				            new str[24];
        				            format(str, sizeof str, "��� ��� 00:%02d", BlackJackLobby2[lobby][TableTurnTime2]);
                    				TextDrawSetString(bj2_log_text[lobby][0], str);
                    				TextDrawColor(bj2_log_text[lobby][0], -1);
                				}
            				}
            				else BlackJackLobby2[lobby][TableTurn2]++;
				        }
      				     case 4:
        				{
            				if(BlackJackLobby2[lobby][Table4Id2] != -1)
            				{
                				if(BlackJackLobby2[lobby][Table4Point2] == 21 || BlackJackLobby2[lobby][Table4Point2] > 21) return BlackJackLobby2[lobby][TableTurnTime2] = 0, BlackJackLobby2[lobby][TableTurn2]++;
                				if(BlackJackLobby2[lobby][TableTurnTime2] == 0)
                				{
                    				BlackJackLobby2[lobby][TableTurnTime2] = 15;
                    				PlayerTextDrawSetString(BlackJackLobby2[lobby][Table4Id2], bj2_panel_info[BlackJackLobby2[lobby][Table4Id2]], "blackjack:brbjyouturn");
                    				PlayerTextDrawShow(BlackJackLobby2[lobby][Table4Id2], bj2_panel_info[BlackJackLobby2[lobby][Table4Id2]]);
                    				SetTimerEx("TimerHideYouTurn2", 2000, false, "d", BlackJackLobby2[lobby][Table4Id2]);

                    				new str[24];
                    				TextDrawSetString(bj2_log_text[lobby][0], "��� ��� 00:15");
                    				TextDrawColor(bj2_log_text[lobby][0], -1);
                    				GetPlayerName(BlackJackLobby2[lobby][Table4Id2], str, 24);
                    				TextDrawSetString(bj2_log_text[lobby][1], str);
                    				TextDrawColor(bj2_log_text[lobby][1], -65281);
                				}
                				else if(BlackJackLobby2[lobby][TableTurnTime2] == 1)
                				{
                    				BlackJackLobby2[lobby][TableTurnTime2]--;
                    				BlackJackLobby2[lobby][TableTurn2]++;

                    				TextDrawSetString(bj2_log_text[lobby][0], "����� �������");
                    				TextDrawColor(bj2_log_text[lobby][0], -1);
                				}
                				else
                				{
                    				BlackJackLobby2[lobby][TableTurnTime2]--;
                    				new str[24];
                    				format(str, sizeof str, "��� ��� 00:%02d", BlackJackLobby2[lobby][TableTurnTime2]);
                    				TextDrawSetString(bj2_log_text[lobby][0], str);
                    				TextDrawColor(bj2_log_text[lobby][0], -1);
                				}
            				}
            				else BlackJackLobby2[lobby][TableTurn2]++;
        				}
        				case 5: { BlackJackLobby2[lobby][TableTurn2] = 0; BlackJackLobby2[lobby][TableTurnTime2] = 0; BlackJackLobby2[lobby][StageLobby2]++; }
    				}
				}

				case 5: //timerlobby //������� ������ ��������� �����
				{
    				TextDrawSetString(bj2_log_text[lobby][0], "����� ������ �����");
    				TextDrawColor(bj2_log_text[lobby][0], -1);
    				TextDrawSetString(bj2_log_text[lobby][1], "");
    				TextDrawColor(bj2_log_text[lobby][1], -65281);

    				new dealer_suit = random(13);
    				new dealer_type = random(4);

    				BlackJackLobby2[lobby][DealerPoint2] += BlackJackCard2[dealer_suit][dealer_type][Pointscore2];

    				TextDrawSetString(bj2_dealer_card[lobby][2], BlackJackCard2[dealer_suit][dealer_type][Cardtexture2]);

    				new str[10];
    				format(str, sizeof str, "%d", BlackJackLobby2[lobby][DealerPoint2]);

    				if(BlackJackLobby2[lobby][Table1Id2] != -1) PlayerTextDrawSetString(BlackJackLobby2[lobby][Table1Id2], bj2_dealer_point[BlackJackLobby2[lobby][Table1Id2]], str); TextDrawShowForPlayer(BlackJackLobby2[lobby][Table1Id2], bj2_dealer_card[lobby][2]);
    				if(BlackJackLobby2[lobby][Table2Id2] != -1) PlayerTextDrawSetString(BlackJackLobby2[lobby][Table2Id2], bj2_dealer_point[BlackJackLobby2[lobby][Table2Id2]], str); TextDrawShowForPlayer(BlackJackLobby2[lobby][Table2Id2], bj2_dealer_card[lobby][2]);
    				if(BlackJackLobby2[lobby][Table3Id2] != -1) PlayerTextDrawSetString(BlackJackLobby2[lobby][Table3Id2], bj2_dealer_point[BlackJackLobby2[lobby][Table3Id2]], str); TextDrawShowForPlayer(BlackJackLobby2[lobby][Table3Id2], bj2_dealer_card[lobby][2]);
    				if(BlackJackLobby2[lobby][Table4Id2] != -1) PlayerTextDrawSetString(BlackJackLobby2[lobby][Table4Id2], bj2_dealer_point[BlackJackLobby2[lobby][Table4Id2]], str); TextDrawShowForPlayer(BlackJackLobby2[lobby][Table4Id2], bj2_dealer_card[lobby][2]);

    				if(BlackJackLobby2[lobby][DealerPoint2] < 16) BlackJackLobby2[lobby][StageLobby2]++;
    				else BlackJackLobby2[lobby][StageLobby2] = 7;
				}
				case 6:
				{
    				new dealer_suit = random(13);
    				new dealer_type = random(4);

    				BlackJackLobby2[lobby][DealerPoint2] += BlackJackCard2[dealer_suit][dealer_type][Pointscore2];

    				TextDrawSetString(bj2_dealer_card[lobby][3], BlackJackCard2[dealer_suit][dealer_type][Cardtexture2]);

    				TextDrawSetString(bj2_log_text[lobby][0], "����� ���� ���� �����");
    				TextDrawColor(bj2_log_text[lobby][0], -1);

    				new str[10];
    				format(str, sizeof str, "%d", BlackJackLobby2[lobby][DealerPoint2]);

    				if(BlackJackLobby2[lobby][Table1Id2] != -1) PlayerTextDrawSetString(BlackJackLobby2[lobby][Table1Id2], bj2_dealer_point[BlackJackLobby2[lobby][Table1Id2]], str); TextDrawShowForPlayer(BlackJackLobby2[lobby][Table1Id2], bj2_dealer_card[lobby][3]);
    				if(BlackJackLobby2[lobby][Table2Id2] != -1) PlayerTextDrawSetString(BlackJackLobby2[lobby][Table2Id2], bj2_dealer_point[BlackJackLobby2[lobby][Table2Id2]], str); TextDrawShowForPlayer(BlackJackLobby2[lobby][Table2Id2], bj2_dealer_card[lobby][3]);
    				if(BlackJackLobby2[lobby][Table3Id2] != -1) PlayerTextDrawSetString(BlackJackLobby2[lobby][Table3Id2], bj2_dealer_point[BlackJackLobby2[lobby][Table3Id2]], str); TextDrawShowForPlayer(BlackJackLobby2[lobby][Table3Id2], bj2_dealer_card[lobby][3]);
   				    if(BlackJackLobby2[lobby][Table4Id2] != -1) PlayerTextDrawSetString(BlackJackLobby2[lobby][Table4Id2], bj2_dealer_point[BlackJackLobby2[lobby][Table4Id2]], str); TextDrawShowForPlayer(BlackJackLobby2[lobby][Table4Id2], bj2_dealer_card[lobby][3]);

  				    BlackJackLobby2[lobby][StageLobby2]++;
				}
				case 7: //timerlobby //���������� result
				{
					if(BlackJackLobby2[lobby][Table1Id2] != -1)
					{
					    if(BlackJackLobby2[lobby][DealerPoint2] == BlackJackLobby2[lobby][Table1Point2] || (BlackJackLobby2[lobby][DealerPoint2] > 21 && BlackJackLobby2[lobby][Table1Point2] > 21))
					    {
				            PlayerTextDrawSetString(BlackJackLobby2[lobby][Table1Id2], bj2_panel_info[BlackJackLobby2[lobby][Table1Id2]], "blackjack:brbjdraw");
					    	PlayerTextDrawShow(BlackJackLobby2[lobby][Table1Id2], bj2_panel_info[BlackJackLobby2[lobby][Table1Id2]]);
				            GivePlayerMoneyBjEx(BlackJackLobby2[lobby][Table1Id2], pBJInfo2[BlackJackLobby2[lobby][Table1Id2]][pBJBet2]);

					       	TextDrawSetString(bj2_result_table[lobby][0], "blackjack:brbjmydraw");
					    }
					    else if(BlackJackLobby2[lobby][DealerPoint2] < 21 && BlackJackLobby2[lobby][Table1Point2] < 21)
					    {
							if(BlackJackLobby2[lobby][DealerPoint2] > BlackJackLobby2[lobby][Table1Point2])
							{
					            PlayerTextDrawSetString(BlackJackLobby2[lobby][Table1Id2], bj2_panel_info[BlackJackLobby2[lobby][Table1Id2]], "blackjack:brbjyoulose");
						    	PlayerTextDrawShow(BlackJackLobby2[lobby][Table1Id2], bj2_panel_info[BlackJackLobby2[lobby][Table1Id2]]);

					            TextDrawSetString(bj2_result_table[lobby][0], "blackjack:brbjlose");
							}
							else
							{
					            PlayerTextDrawSetString(BlackJackLobby2[lobby][Table1Id2], bj2_panel_info[BlackJackLobby2[lobby][Table1Id2]], "blackjack:brbjyouwin");
						    	PlayerTextDrawShow(BlackJackLobby2[lobby][Table1Id2], bj2_panel_info[BlackJackLobby2[lobby][Table1Id2]]);
					            GivePlayerMoneyBjEx(BlackJackLobby2[lobby][Table1Id2], pBJInfo2[BlackJackLobby2[lobby][Table1Id2]][pBJBet2]*2);
                                BJNotifyWin(BlackJackLobby2[lobby][Table1Id2], pBJInfo2[BlackJackLobby2[lobby][Table1Id2]][pBJBet2]*2);

					            TextDrawSetString(bj2_result_table[lobby][0], "blackjack:brbjwin");
							}
					    }

					    else if((BlackJackLobby2[lobby][DealerPoint2] == 21 && BlackJackLobby2[lobby][Table1Point2] < 21) || (BlackJackLobby2[lobby][DealerPoint2] < 21 && BlackJackLobby2[lobby][Table1Point2] > 21))
					    {
					            PlayerTextDrawSetString(BlackJackLobby2[lobby][Table1Id2], bj2_panel_info[BlackJackLobby2[lobby][Table1Id2]], "blackjack:brbjyoulose");
						    	PlayerTextDrawShow(BlackJackLobby2[lobby][Table1Id2], bj2_panel_info[BlackJackLobby2[lobby][Table1Id2]]);

					            TextDrawSetString(bj2_result_table[lobby][0], "blackjack:brbjlose");
					    }
					    else if((BlackJackLobby2[lobby][DealerPoint2] < 21 && BlackJackLobby2[lobby][Table1Point2] == 21) || (BlackJackLobby2[lobby][DealerPoint2] > 21 && BlackJackLobby2[lobby][Table1Point2] < 21))
					    {
					            PlayerTextDrawSetString(BlackJackLobby2[lobby][Table1Id2], bj2_panel_info[BlackJackLobby2[lobby][Table1Id2]], "blackjack:brbjyouwin");
						    	PlayerTextDrawShow(BlackJackLobby2[lobby][Table1Id2], bj2_panel_info[BlackJackLobby2[lobby][Table1Id2]]);
					            GivePlayerMoneyBjEx(BlackJackLobby2[lobby][Table1Id2], pBJInfo2[BlackJackLobby2[lobby][Table1Id2]][pBJBet2]*2);
                                BJNotifyWin(BlackJackLobby2[lobby][Table1Id2], pBJInfo2[BlackJackLobby2[lobby][Table1Id2]][pBJBet2]*2);

					            TextDrawSetString(bj2_result_table[lobby][0], "blackjack:brbjwin");
					    }
					}

					if(BlackJackLobby2[lobby][Table2Id2] != -1)
					{
					    if(BlackJackLobby2[lobby][DealerPoint2] == BlackJackLobby2[lobby][Table2Point2] || (BlackJackLobby2[lobby][DealerPoint2] > 21 && BlackJackLobby2[lobby][Table2Point2] > 21))
					    {
				            PlayerTextDrawSetString(BlackJackLobby2[lobby][Table2Id2], bj2_panel_info[BlackJackLobby2[lobby][Table2Id2]], "blackjack:brbjdraw");
					    	PlayerTextDrawShow(BlackJackLobby2[lobby][Table2Id2], bj2_panel_info[BlackJackLobby2[lobby][Table2Id2]]);
				            GivePlayerMoneyBjEx(BlackJackLobby2[lobby][Table2Id2], pBJInfo2[BlackJackLobby2[lobby][Table2Id2]][pBJBet2]);

					       	TextDrawSetString(bj2_result_table[lobby][1], "blackjack:brbjmydraw");
					    }
					    else if(BlackJackLobby2[lobby][DealerPoint2] < 21 && BlackJackLobby2[lobby][Table2Point2] < 21)
					    {
							if(BlackJackLobby2[lobby][DealerPoint2] > BlackJackLobby2[lobby][Table2Point2])
							{
					            PlayerTextDrawSetString(BlackJackLobby2[lobby][Table2Id2], bj2_panel_info[BlackJackLobby2[lobby][Table2Id2]], "blackjack:brbjyoulose");
						    	PlayerTextDrawShow(BlackJackLobby2[lobby][Table2Id2], bj2_panel_info[BlackJackLobby2[lobby][Table2Id2]]);

					            TextDrawSetString(bj2_result_table[lobby][1], "blackjack:brbjlose");
							}
							else
							{
					            PlayerTextDrawSetString(BlackJackLobby2[lobby][Table2Id2], bj2_panel_info[BlackJackLobby2[lobby][Table2Id2]], "blackjack:brbjyouwin");
						    	PlayerTextDrawShow(BlackJackLobby2[lobby][Table2Id2], bj2_panel_info[BlackJackLobby2[lobby][Table2Id2]]);
					            GivePlayerMoneyBjEx(BlackJackLobby2[lobby][Table2Id2], pBJInfo2[BlackJackLobby2[lobby][Table2Id2]][pBJBet2]*2);
                                BJNotifyWin(BlackJackLobby2[lobby][Table2Id2], pBJInfo2[BlackJackLobby2[lobby][Table2Id2]][pBJBet2]*2);

					            TextDrawSetString(bj2_result_table[lobby][1], "blackjack:brbjwin");
							}
					    }

					    else if((BlackJackLobby2[lobby][DealerPoint2] == 21 && BlackJackLobby2[lobby][Table2Point2] < 21) || (BlackJackLobby2[lobby][DealerPoint2] < 21 && BlackJackLobby2[lobby][Table2Point2] > 21))
					    {
					            PlayerTextDrawSetString(BlackJackLobby2[lobby][Table2Id2], bj2_panel_info[BlackJackLobby2[lobby][Table2Id2]], "blackjack:brbjyoulose");
						    	PlayerTextDrawShow(BlackJackLobby2[lobby][Table2Id2], bj2_panel_info[BlackJackLobby2[lobby][Table2Id2]]);

					            TextDrawSetString(bj2_result_table[lobby][1], "blackjack:brbjlose");
					    }
					    else if((BlackJackLobby2[lobby][DealerPoint2] < 21 && BlackJackLobby2[lobby][Table2Point2] == 21) || (BlackJackLobby2[lobby][DealerPoint2] > 21 && BlackJackLobby2[lobby][Table2Point2] < 21))
					    {
					            PlayerTextDrawSetString(BlackJackLobby2[lobby][Table2Id2], bj2_panel_info[BlackJackLobby2[lobby][Table2Id2]], "blackjack:brbjyouwin");
						    	PlayerTextDrawShow(BlackJackLobby2[lobby][Table2Id2], bj2_panel_info[BlackJackLobby2[lobby][Table2Id2]]);
					            GivePlayerMoneyBjEx(BlackJackLobby2[lobby][Table2Id2], pBJInfo2[BlackJackLobby2[lobby][Table2Id2]][pBJBet2]*2);
                                BJNotifyWin(BlackJackLobby2[lobby][Table2Id2], pBJInfo2[BlackJackLobby2[lobby][Table2Id2]][pBJBet2]*2);

					            TextDrawSetString(bj2_result_table[lobby][1], "blackjack:brbjwin");
					    }
					}


					if(BlackJackLobby2[lobby][Table3Id2] != -1)
					{
					    if(BlackJackLobby2[lobby][DealerPoint2] == BlackJackLobby2[lobby][Table3Point2] || (BlackJackLobby2[lobby][DealerPoint2] > 21 && BlackJackLobby2[lobby][Table3Point2] > 21))
					    {
				            PlayerTextDrawSetString(BlackJackLobby2[lobby][Table3Id2], bj2_panel_info[BlackJackLobby2[lobby][Table3Id2]], "blackjack:brbjdraw");
					    	PlayerTextDrawShow(BlackJackLobby2[lobby][Table3Id2], bj2_panel_info[BlackJackLobby2[lobby][Table3Id2]]);
				            GivePlayerMoneyBjEx(BlackJackLobby2[lobby][Table3Id2], pBJInfo2[BlackJackLobby2[lobby][Table3Id2]][pBJBet2]);

					       	TextDrawSetString(bj2_result_table[lobby][2], "blackjack:brbjmydraw");
					    }
					    else if(BlackJackLobby2[lobby][DealerPoint2] < 21 && BlackJackLobby2[lobby][Table3Point2] < 21)
					    {
							if(BlackJackLobby2[lobby][DealerPoint2] > BlackJackLobby2[lobby][Table3Point2])
							{
					            PlayerTextDrawSetString(BlackJackLobby2[lobby][Table3Id2], bj2_panel_info[BlackJackLobby2[lobby][Table3Id2]], "blackjack:brbjyoulose");
						    	PlayerTextDrawShow(BlackJackLobby2[lobby][Table3Id2], bj2_panel_info[BlackJackLobby2[lobby][Table3Id2]]);

					            TextDrawSetString(bj2_result_table[lobby][2], "blackjack:brbjlose");
							}
							else
							{
					            PlayerTextDrawSetString(BlackJackLobby2[lobby][Table3Id2], bj2_panel_info[BlackJackLobby2[lobby][Table3Id2]], "blackjack:brbjyouwin");
						    	PlayerTextDrawShow(BlackJackLobby2[lobby][Table3Id2], bj2_panel_info[BlackJackLobby2[lobby][Table3Id2]]);
					            GivePlayerMoneyBjEx(BlackJackLobby2[lobby][Table3Id2], pBJInfo2[BlackJackLobby2[lobby][Table3Id2]][pBJBet2]*2);
                                BJNotifyWin(BlackJackLobby2[lobby][Table3Id2], pBJInfo2[BlackJackLobby2[lobby][Table3Id2]][pBJBet2]*2);

					            TextDrawSetString(bj2_result_table[lobby][2], "blackjack:brbjwin");
							}
					    }

					    else if((BlackJackLobby2[lobby][DealerPoint2] == 21 && BlackJackLobby2[lobby][Table3Point2] < 21) || (BlackJackLobby2[lobby][DealerPoint2] < 21 && BlackJackLobby2[lobby][Table3Point2] > 21))
					    {
					            PlayerTextDrawSetString(BlackJackLobby2[lobby][Table3Id2], bj2_panel_info[BlackJackLobby2[lobby][Table3Id2]], "blackjack:brbjyoulose");
						    	PlayerTextDrawShow(BlackJackLobby2[lobby][Table3Id2], bj2_panel_info[BlackJackLobby2[lobby][Table3Id2]]);

					            TextDrawSetString(bj2_result_table[lobby][2], "blackjack:brbjlose");
					    }
					    else if((BlackJackLobby2[lobby][DealerPoint2] < 21 && BlackJackLobby2[lobby][Table3Point2] == 21) || (BlackJackLobby2[lobby][DealerPoint2] > 21 && BlackJackLobby2[lobby][Table3Point2] < 21))
					    {
					            PlayerTextDrawSetString(BlackJackLobby2[lobby][Table3Id2], bj2_panel_info[BlackJackLobby2[lobby][Table3Id2]], "blackjack:brbjyouwin");
						    	PlayerTextDrawShow(BlackJackLobby2[lobby][Table3Id2], bj2_panel_info[BlackJackLobby2[lobby][Table3Id2]]);
					            GivePlayerMoneyBjEx(BlackJackLobby2[lobby][Table3Id2], pBJInfo2[BlackJackLobby2[lobby][Table3Id2]][pBJBet2]*2);
                                BJNotifyWin(BlackJackLobby2[lobby][Table3Id2], pBJInfo2[BlackJackLobby2[lobby][Table3Id2]][pBJBet2]*2);

					            TextDrawSetString(bj2_result_table[lobby][2], "blackjack:brbjwin");
					    }
					}

					if(BlackJackLobby2[lobby][Table4Id2] != -1)
					{
					    if(BlackJackLobby2[lobby][DealerPoint2] == BlackJackLobby2[lobby][Table4Point2] || (BlackJackLobby2[lobby][DealerPoint2] > 21 && BlackJackLobby2[lobby][Table4Point2] > 21))
					    {
				            PlayerTextDrawSetString(BlackJackLobby2[lobby][Table4Id2], bj2_panel_info[BlackJackLobby2[lobby][Table4Id2]], "blackjack:brbjdraw");
					    	PlayerTextDrawShow(BlackJackLobby2[lobby][Table4Id2], bj2_panel_info[BlackJackLobby2[lobby][Table4Id2]]);
				            GivePlayerMoneyBjEx(BlackJackLobby2[lobby][Table4Id2], pBJInfo2[BlackJackLobby2[lobby][Table4Id2]][pBJBet2]);

					       	TextDrawSetString(bj2_result_table[lobby][3], "blackjack:brbjmydraw");
					    }
					    else if(BlackJackLobby2[lobby][DealerPoint2] < 21 && BlackJackLobby2[lobby][Table4Point2] < 21)
					    {
							if(BlackJackLobby2[lobby][DealerPoint2] > BlackJackLobby2[lobby][Table4Point2])
							{
					            PlayerTextDrawSetString(BlackJackLobby2[lobby][Table4Id2], bj2_panel_info[BlackJackLobby2[lobby][Table4Id2]], "blackjack:brbjyoulose");
						    	PlayerTextDrawShow(BlackJackLobby2[lobby][Table4Id2], bj2_panel_info[BlackJackLobby2[lobby][Table4Id2]]);

					            TextDrawSetString(bj2_result_table[lobby][3], "blackjack:brbjlose");
							}
							else
							{
					            PlayerTextDrawSetString(BlackJackLobby2[lobby][Table4Id2], bj2_panel_info[BlackJackLobby2[lobby][Table4Id2]], "blackjack:brbjyouwin");
						    	PlayerTextDrawShow(BlackJackLobby2[lobby][Table4Id2], bj2_panel_info[BlackJackLobby2[lobby][Table4Id2]]);
					            GivePlayerMoneyBjEx(BlackJackLobby2[lobby][Table4Id2], pBJInfo2[BlackJackLobby2[lobby][Table4Id2]][pBJBet2]*2);
                                BJNotifyWin(BlackJackLobby2[lobby][Table4Id2], pBJInfo2[BlackJackLobby2[lobby][Table4Id2]][pBJBet2]*2);

					            TextDrawSetString(bj2_result_table[lobby][3], "blackjack:brbjwin");
							}
					    }

					    else if((BlackJackLobby2[lobby][DealerPoint2] == 21 && BlackJackLobby2[lobby][Table4Point2] < 21) || (BlackJackLobby2[lobby][DealerPoint2] < 21 && BlackJackLobby2[lobby][Table4Point2] > 21))
					    {
					            PlayerTextDrawSetString(BlackJackLobby2[lobby][Table4Id2], bj2_panel_info[BlackJackLobby2[lobby][Table4Id2]], "blackjack:brbjyoulose");
						    	PlayerTextDrawShow(BlackJackLobby2[lobby][Table4Id2], bj2_panel_info[BlackJackLobby2[lobby][Table4Id2]]);

					            TextDrawSetString(bj2_result_table[lobby][3], "blackjack:brbjlose");
					    }
					    else if((BlackJackLobby2[lobby][DealerPoint2] < 21 && BlackJackLobby2[lobby][Table4Point2] == 21) || (BlackJackLobby2[lobby][DealerPoint2] > 21 && BlackJackLobby2[lobby][Table4Point2] < 21))
					    {
					            PlayerTextDrawSetString(BlackJackLobby2[lobby][Table4Id2], bj2_panel_info[BlackJackLobby2[lobby][Table4Id2]], "blackjack:brbjyouwin");
						    	PlayerTextDrawShow(BlackJackLobby2[lobby][Table4Id2], bj2_panel_info[BlackJackLobby2[lobby][Table4Id2]]);
					            GivePlayerMoneyBjEx(BlackJackLobby2[lobby][Table4Id2], pBJInfo2[BlackJackLobby2[lobby][Table4Id2]][pBJBet2]*2);
                                BJNotifyWin(BlackJackLobby2[lobby][Table4Id2], pBJInfo2[BlackJackLobby2[lobby][Table4Id2]][pBJBet2]*2);

					            TextDrawSetString(bj2_result_table[lobby][3], "blackjack:brbjwin");
					    }
     				}


                    if(BlackJackLobby2[lobby][Table1Id2] != -1) BJUpdateMoneyLabel(BlackJackLobby2[lobby][Table1Id2]);
                    if(BlackJackLobby2[lobby][Table2Id2] != -1) BJUpdateMoneyLabel(BlackJackLobby2[lobby][Table2Id2]);
                    if(BlackJackLobby2[lobby][Table3Id2] != -1) BJUpdateMoneyLabel(BlackJackLobby2[lobby][Table3Id2]);
                    if(BlackJackLobby2[lobby][Table4Id2] != -1) BJUpdateMoneyLabel(BlackJackLobby2[lobby][Table4Id2]);
					BlackJackLobby2[lobby][StageLobby2]++;
				}
				case 8:
				{
     				if(BlackJackLobby2[lobby][Table1Id2] != -1)
			 		{
					 	TextDrawShowForPlayer(BlackJackLobby2[lobby][Table1Id2], bj2_result_table[lobby][0]);
					 	if(BlackJackLobby2[lobby][Table2Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table1Id2], bj2_result_table[lobby][1]);
					 	if(BlackJackLobby2[lobby][Table3Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table1Id2], bj2_result_table[lobby][2]);
					 	if(BlackJackLobby2[lobby][Table4Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table1Id2], bj2_result_table[lobby][3]);
				    }
     				if(BlackJackLobby2[lobby][Table2Id2] != -1)
			 		{
					 	if(BlackJackLobby2[lobby][Table1Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table2Id2], bj2_result_table[lobby][0]);
					 	TextDrawShowForPlayer(BlackJackLobby2[lobby][Table2Id2], bj2_result_table[lobby][1]);
					 	if(BlackJackLobby2[lobby][Table3Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table2Id2], bj2_result_table[lobby][2]);
					 	if(BlackJackLobby2[lobby][Table4Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table2Id2], bj2_result_table[lobby][3]);
				    }
     				if(BlackJackLobby2[lobby][Table3Id2] != -1)
			 		{
					 	if(BlackJackLobby2[lobby][Table1Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table3Id2], bj2_result_table[lobby][0]);
					 	if(BlackJackLobby2[lobby][Table2Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table3Id2], bj2_result_table[lobby][1]);
					 	TextDrawShowForPlayer(BlackJackLobby2[lobby][Table3Id2], bj2_result_table[lobby][2]);
					 	if(BlackJackLobby2[lobby][Table4Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table3Id2], bj2_result_table[lobby][3]);
				    }
     				if(BlackJackLobby2[lobby][Table4Id2] != -1)
			 		{
					 	if(BlackJackLobby2[lobby][Table1Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table4Id2], bj2_result_table[lobby][0]);
					 	if(BlackJackLobby2[lobby][Table2Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table4Id2], bj2_result_table[lobby][1]);
					 	if(BlackJackLobby2[lobby][Table3Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table4Id2], bj2_result_table[lobby][2]);
					 	TextDrawShowForPlayer(BlackJackLobby2[lobby][Table4Id2], bj2_result_table[lobby][3]);
				    }
					BlackJackLobby2[lobby][StageLobby2]++;
				}
				case 9: BlackJackLobby2[lobby][StageLobby2]++;
				case 10: BlackJackLobby2[lobby][StageLobby2]++;
				case 11: //end
				{
	            	TextDrawSetString(bj2_text_point_table[lobby][0], "����: 0");
					TextDrawSetString(bj2_text_point_table[lobby][1], "����: 0");
					TextDrawSetString(bj2_text_point_table[lobby][2], "����: 0");
					TextDrawSetString(bj2_text_point_table[lobby][3], "����: 0");

					BlackJackLobby2[lobby][Table1Result2] = 0;
					BlackJackLobby2[lobby][Table2Result2] = 0;
					BlackJackLobby2[lobby][Table3Result2] = 0;
					BlackJackLobby2[lobby][Table4Result2] = 0;

                    BlackJackLobby2[lobby][DealerPoint2] = 0;
                    BlackJackLobby2[lobby][Table1Point2] = 0;
                    BlackJackLobby2[lobby][Table2Point2] = 0;
                    BlackJackLobby2[lobby][Table3Point2] = 0;
                    BlackJackLobby2[lobby][Table4Point2] = 0;
                    BlackJackLobby2[lobby][TableTurn2] = 0;
                    BlackJackLobby2[lobby][TableTurnTime2] = 0;
                    BlackJackLobby2[lobby][DealerTurnGived2] = 0;

					BlackJackLobby2[lobby][StageLobby2]++;
				}
				case 12:
				{
					BlackJackLobby2[lobby][StageLobby2]++;
					if(BlackJackLobby2[lobby][Table1Id2] != -1) BJResetRoundPlayer(BlackJackLobby2[lobby][Table1Id2], lobby);
				}
				case 13:
				{
					BlackJackLobby2[lobby][StageLobby2]++;
					if(BlackJackLobby2[lobby][Table2Id2] != -1) BJResetRoundPlayer(BlackJackLobby2[lobby][Table2Id2], lobby);
				}
				case 14:
				{
					BlackJackLobby2[lobby][StageLobby2]++;
					if(BlackJackLobby2[lobby][Table3Id2] != -1) BJResetRoundPlayer(BlackJackLobby2[lobby][Table3Id2], lobby);
				}
				case 15:
				{
    				BlackJackLobby2[lobby][StageLobby2] = 0;
					BlackJackLobby2[lobby][StartedLobby2] = false;
					if(BlackJackLobby2[lobby][Table4Id2] != -1) BJResetRoundPlayer(BlackJackLobby2[lobby][Table4Id2], lobby);
				}
			}
	    }
		else
	    {
	        if(BlackJackLobby2[lobby][StartTimer2]-1 == 0)
			{
				BlackJackLobby2[lobby][StartedLobby2] = true; BlackJackLobby2[lobby][StageLobby2] = 1; SnowNotificarionBJL(lobby, "���� ��������!", 3);

				printf("���� 1: %d", BlackJackLobby2[lobby][Table1Id2]);
				printf("���� 2: %d", BlackJackLobby2[lobby][Table2Id2]);
				printf("���� 3: %d", BlackJackLobby2[lobby][Table3Id2]);
				printf("���� 4: %d", BlackJackLobby2[lobby][Table4Id2]);

				for(new a;a < 12;a++)  SendClientMessage(BlackJackLobby2[lobby][Table1Id2], 0xFFFFFFFF, "");
				for(new a;a < 12;a++)  SendClientMessage(BlackJackLobby2[lobby][Table2Id2], 0xFFFFFFFF, "");
				for(new a;a < 12;a++)  SendClientMessage(BlackJackLobby2[lobby][Table3Id2], 0xFFFFFFFF, "");
				for(new a;a < 12;a++)  SendClientMessage(BlackJackLobby2[lobby][Table4Id2], 0xFFFFFFFF, "");

				new str[96];

                if(BlackJackLobby2[lobby][Table1Id2] != -1) {
					if(!pBJInfo2[BlackJackLobby2[lobby][Table1Id2]][pBJBet2]) { SCM(BlackJackLobby2[lobby][Table1Id2], CYELLOW, "| "CW"���������� ������ ����� ������ �� ��� �������� ������"); ExitPlayerLobby2(BlackJackLobby2[lobby][Table1Id2], lobby, 1); }
					else { GivePlayerMoneyBjEx(BlackJackLobby2[lobby][Table1Id2], -pBJInfo2[BlackJackLobby2[lobby][Table1Id2]][pBJBet2], "BlackJack Bet", true, false); format(str, sizeof str, "�� ��������� %d ������", pBJInfo2[BlackJackLobby2[lobby][Table1Id2]][pBJBet2]); 0; ShowNotificationNew(BlackJackLobby2[lobby][Table1Id2], 2, 6, 0, 0, str, "qq"); BJUpdateMoneyLabel(BlackJackLobby2[lobby][Table1Id2]); }
				}
			    if(BlackJackLobby2[lobby][Table2Id2] != -1) {
					if(!pBJInfo2[BlackJackLobby2[lobby][Table2Id2]][pBJBet2]) { SCM(BlackJackLobby2[lobby][Table2Id2], CYELLOW, "| "CW"���������� ������ ����� ������ �� ��� �������� ������"); ExitPlayerLobby2(BlackJackLobby2[lobby][Table2Id2], lobby, 2); }
					else { GivePlayerMoneyBjEx(BlackJackLobby2[lobby][Table2Id2], -pBJInfo2[BlackJackLobby2[lobby][Table2Id2]][pBJBet2], "BlackJack Bet", true, false); format(str, sizeof str, "�� ��������� %d ������", pBJInfo2[BlackJackLobby2[lobby][Table2Id2]][pBJBet2]); 0; ShowNotificationNew(BlackJackLobby2[lobby][Table2Id2], 2, 6, 0, 0, str, "qq"); BJUpdateMoneyLabel(BlackJackLobby2[lobby][Table2Id2]); }
				}
			    if(BlackJackLobby2[lobby][Table3Id2] != -1) {
					if(!pBJInfo2[BlackJackLobby2[lobby][Table3Id2]][pBJBet2]) { SCM(BlackJackLobby2[lobby][Table3Id2], CYELLOW, "| "CW"���������� ������ ����� ������ �� ��� �������� ������"); ExitPlayerLobby2(BlackJackLobby2[lobby][Table3Id2], lobby, 3); }
					else { GivePlayerMoneyBjEx(BlackJackLobby2[lobby][Table3Id2], -pBJInfo2[BlackJackLobby2[lobby][Table3Id2]][pBJBet2], "BlackJack Bet", true, false); format(str, sizeof str, "�� ��������� %d ������", pBJInfo2[BlackJackLobby2[lobby][Table3Id2]][pBJBet2]); 0; ShowNotificationNew(BlackJackLobby2[lobby][Table3Id2], 2, 6, 0, 0, str, "qq"); BJUpdateMoneyLabel(BlackJackLobby2[lobby][Table3Id2]); }
				}
			    if(BlackJackLobby2[lobby][Table4Id2] != -1) {
					if(!pBJInfo2[BlackJackLobby2[lobby][Table4Id2]][pBJBet2]) { SCM(BlackJackLobby2[lobby][Table4Id2], CYELLOW, "| "CW"���������� ������ ����� ������ �� ��� �������� ������"); ExitPlayerLobby2(BlackJackLobby2[lobby][Table4Id2], lobby, 4); }
					else { GivePlayerMoneyBjEx(BlackJackLobby2[lobby][Table4Id2], -pBJInfo2[BlackJackLobby2[lobby][Table4Id2]][pBJBet2], "BlackJack Bet", true, false); format(str, sizeof str, "�� ��������� %d ������", pBJInfo2[BlackJackLobby2[lobby][Table4Id2]][pBJBet2]); 0; ShowNotificationNew(BlackJackLobby2[lobby][Table4Id2], 2, 6, 0, 0, str, "qq"); BJUpdateMoneyLabel(BlackJackLobby2[lobby][Table4Id2]); }
				}



				BlackJackLobby2[lobby][StartTimer2] = 60;

				if(BlackJackLobby2[lobby][Table1Id2] != -1) {
					TextDrawHideForPlayer(BlackJackLobby2[lobby][Table1Id2], bj_text_start_time2);
					TextDrawHideForPlayer(BlackJackLobby2[lobby][Table1Id2], bj2_text_start_timer[lobby]);
				}
				if(BlackJackLobby2[lobby][Table2Id2] != -1) {
					TextDrawHideForPlayer(BlackJackLobby2[lobby][Table2Id2], bj_text_start_time2);
					TextDrawHideForPlayer(BlackJackLobby2[lobby][Table2Id2], bj2_text_start_timer[lobby]);
				}
				if(BlackJackLobby2[lobby][Table3Id2] != -1) {
					TextDrawHideForPlayer(BlackJackLobby2[lobby][Table3Id2], bj_text_start_time2);
					TextDrawHideForPlayer(BlackJackLobby2[lobby][Table3Id2], bj2_text_start_timer[lobby]);
				}
				if(BlackJackLobby2[lobby][Table4Id2] != -1) {
					TextDrawHideForPlayer(BlackJackLobby2[lobby][Table4Id2], bj_text_start_time2);
					TextDrawHideForPlayer(BlackJackLobby2[lobby][Table4Id2], bj2_text_start_timer[lobby]);
				}
			}
		    else
			{
				BlackJackLobby2[lobby][StartTimer2]--;
			    new timer[6];
				format(timer, sizeof timer, "00:%02d", BlackJackLobby2[lobby][StartTimer2]);
				TextDrawSetString(bj2_text_start_timer[lobby], timer);
			}
	    }
	}
	else
	{ //timerdeath
	    BlackJackLobby2[lobby][ActivedLobby2] = false;
		BlackJackLobby2[lobby][StartedLobby2] = false;
		BlackJackLobby2[lobby][StartTimer2] = 60;
		BlackJackLobby2[lobby][StageLobby2] = 0;
		BlackJackLobby2[lobby][TableTurnTime2] = 0;
		BlackJackLobby2[lobby][TableTurn2] = 0;
	    BlackJackLobby2[lobby][DealerPoint2] = 0;

		TextDrawSetString(bj2_text_start_timer[lobby], "00:60");

		BlackJackLobby2[lobby][Table1Point2] = 0;
		BlackJackLobby2[lobby][Table2Point2] = 0;
		BlackJackLobby2[lobby][Table3Point2] = 0;
		BlackJackLobby2[lobby][Table4Point2] = 0;

		BlackJackLobby2[lobby][Table1Result2] = 0;
		BlackJackLobby2[lobby][Table2Result2] = 0;
		BlackJackLobby2[lobby][Table3Result2] = 0;
		BlackJackLobby2[lobby][Table4Result2] = 0;

        TextDrawSetString(bj2_log_text[lobby][0], "");
        TextDrawSetString(bj2_log_text[lobby][1], "");
	}
	return 1;
}

forward TimerDealerNext2(lobby);
public TimerDealerNext2(lobby)
{
	BlackJackLobby2[lobby][DealerTurnGived2] = 3;
}

forward TimerHideBetText2(playerid);
public TimerHideBetText2(playerid)
{
	TextDrawHideForPlayer(playerid, bj2_text_bet[0]);
	TextDrawHideForPlayer(playerid, bj2_text_bet[1]);
}
forward TimerHideYouTurn2(playerid);
public TimerHideYouTurn2(playerid) PlayerTextDrawHide(playerid, bj2_panel_info[playerid]);



stock BJAdvanceTurnIfCurrent(playerid, lobby)
{
    if(BlackJackLobby2[lobby][TableTurn2] == pBJInfo2[playerid][pBJTable2])
    {
        PlayerTextDrawHide(playerid, bj2_panel_info[playerid]);
        BlackJackLobby2[lobby][TableTurnTime2] = 0;
        BlackJackLobby2[lobby][TableTurn2]++;
    }
}
stock BJNotifyWin(playerid, amount)
{
    if(playerid == -1 || amount <= 0) return 1;
    new notify_str[96];
    format(notify_str, sizeof notify_str, "�� �������� %d ������", amount);
    ShowNotificationNew(playerid, 3, 6, 0, 0, notify_str, " ");
    return 1;
}

stock BJUpdateMoneyLabel(playerid)
{
	if(playerid == -1) return 1;
	new str[24];
	format(str, sizeof str, "%d py�", GetPlayerMoneyEx(playerid));
	PlayerTextDrawSetString(playerid, bj2_money[playerid], str);
	return 1;
}

stock BJResetRoundPlayer(playerid, lobby)
{
    if(playerid == -1) return 1;

    pBJInfo2[playerid][pBJBet2] = 0;
    pBJInfo2[playerid][pBJTakedCard2] = 0;

    PlayerTextDrawSetString(playerid, bj2_bet[playerid], "0 py�");
    PlayerTextDrawSetString(playerid, bj2_dealer_point[playerid], "0");
    BJUpdateMoneyLabel(playerid);

    PlayerTextDrawHide(playerid, bj2_panel_info[playerid]);
    PlayerTextDrawSetString(playerid, bj2_panel_info[playerid], "blackjack:brbjyouturn");

    TextDrawHideForPlayer(playerid, bj_dealer_score2);
    TextDrawHideForPlayer(playerid, bj2_log_text[lobby][0]);
    TextDrawHideForPlayer(playerid, bj2_log_text[lobby][1]);

    TextDrawHideForPlayer(playerid, bj2_dealer_card[lobby][1]);
    TextDrawHideForPlayer(playerid, bj2_dealer_card[lobby][2]);
    TextDrawHideForPlayer(playerid, bj2_dealer_card[lobby][3]);

    TextDrawHideForPlayer(playerid, bj2_result_table[lobby][0]);
    TextDrawHideForPlayer(playerid, bj2_result_table[lobby][1]);
    TextDrawHideForPlayer(playerid, bj2_result_table[lobby][2]);
    TextDrawHideForPlayer(playerid, bj2_result_table[lobby][3]);

    TextDrawHideForPlayer(playerid, bj2_text_bj_table[lobby][0]);
    TextDrawHideForPlayer(playerid, bj2_text_bj_table[lobby][1]);
    TextDrawHideForPlayer(playerid, bj2_text_bj_table[lobby][2]);
    TextDrawHideForPlayer(playerid, bj2_text_bj_table[lobby][3]);

    TextDrawHideForPlayer(playerid, bj2_text_point_table[lobby][0]);
    TextDrawHideForPlayer(playerid, bj2_text_point_table[lobby][1]);
    TextDrawHideForPlayer(playerid, bj2_text_point_table[lobby][2]);
    TextDrawHideForPlayer(playerid, bj2_text_point_table[lobby][3]);

    for(new i = 1; i <= 4; i++)
    {
        PlayerTextDrawHide(playerid, bj2_card_table[playerid][i][0]);
        PlayerTextDrawHide(playerid, bj2_card_table[playerid][i][1]);
        PlayerTextDrawHide(playerid, bj2_card_table[playerid][i][2]);
        PlayerTextDrawHide(playerid, bj2_card_table[playerid][i][3]);

        PlayerTextDrawSetString(playerid, bj2_card_table[playerid][i][0], "blackjack:cardscard");
        PlayerTextDrawSetString(playerid, bj2_card_table[playerid][i][1], "blackjack:cardscard");
        PlayerTextDrawSetString(playerid, bj2_card_table[playerid][i][2], "blackjack:cardscard");
        PlayerTextDrawSetString(playerid, bj2_card_table[playerid][i][3], "blackjack:cardscard");
    }

    InitPlayerLobby2(playerid, lobby, pBJInfo2[playerid][pBJTable2]);
    return 1;
}

stock SCMBJL2(lobby, color, const message[])
{
	if(BlackJackLobby2[lobby][Table1Id2] != -1) SCM(BlackJackLobby2[lobby][Table1Id2], color, message);
	if(BlackJackLobby2[lobby][Table2Id2] != -1) SCM(BlackJackLobby2[lobby][Table2Id2], color, message);
	if(BlackJackLobby2[lobby][Table3Id2] != -1) SCM(BlackJackLobby2[lobby][Table3Id2], color, message);
	if(BlackJackLobby2[lobby][Table4Id2] != -1) SCM(BlackJackLobby2[lobby][Table4Id2], color, message);
}

stock SnowNotificarionBJL(lobby, message[], type)
{
	if(BlackJackLobby2[lobby][Table1Id2] != -1) ShowNotificationNew(BlackJackLobby2[lobby][Table1Id2], type, 5, 1, 1, message, ""), 0;
	if(BlackJackLobby2[lobby][Table2Id2] != -1) ShowNotificationNew(BlackJackLobby2[lobby][Table2Id2], type, 5, 1, 1, message, ""), 0;
	if(BlackJackLobby2[lobby][Table3Id2] != -1) ShowNotificationNew(BlackJackLobby2[lobby][Table3Id2], type, 5, 1, 1, message, ""), 0;
	if(BlackJackLobby2[lobby][Table4Id2] != -1) ShowNotificationNew(BlackJackLobby2[lobby][Table4Id2], type, 5, 1, 1, message, ""), 0;
}

stock CheckTableBlackJack2(lobby, table)
{
	switch(table)
	{
	    case 1:
		{
			if(BlackJackLobby2[lobby][Table1Point2] == 21) GiveTableBlackJack2(lobby, BlackJackLobby2[lobby][Table1Id2], table);
			else if(BlackJackLobby2[lobby][Table1Point2] > 21) GiveTableLose2(lobby, BlackJackLobby2[lobby][Table1Id2]);
		}
	    case 2:
		{
			if(BlackJackLobby2[lobby][Table2Point2] == 21) GiveTableBlackJack2(lobby, BlackJackLobby2[lobby][Table2Id2], table);
			else if(BlackJackLobby2[lobby][Table2Point2] > 21) GiveTableLose2(lobby, BlackJackLobby2[lobby][Table2Id2]);
		}
	    case 3:
		{
			if(BlackJackLobby2[lobby][Table3Point2] == 21) GiveTableBlackJack2(lobby, BlackJackLobby2[lobby][Table3Id2], table);
			else if(BlackJackLobby2[lobby][Table3Point2] > 21) GiveTableLose2(lobby, BlackJackLobby2[lobby][Table3Id2]);
		}
	    case 4:
		{
			if(BlackJackLobby2[lobby][Table4Point2] == 21) GiveTableBlackJack2(lobby, BlackJackLobby2[lobby][Table4Id2], table);
			else if(BlackJackLobby2[lobby][Table4Point2] > 21) GiveTableLose2(lobby, BlackJackLobby2[lobby][Table4Id2]);
		}
	}

}

stock GiveTableBlackJack2(lobby, playerid, table)
{
	if(BlackJackLobby2[lobby][Table1Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table1Id2], bj2_text_bj_table[lobby][table-1]);  TextDrawShowForPlayer(BlackJackLobby2[lobby][Table1Id2], bj2_text_bj_table[lobby][table-1]);
	if(BlackJackLobby2[lobby][Table2Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table2Id2], bj2_text_bj_table[lobby][table-1]);  TextDrawShowForPlayer(BlackJackLobby2[lobby][Table2Id2], bj2_text_bj_table[lobby][table-1]);
	if(BlackJackLobby2[lobby][Table3Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table3Id2], bj2_text_bj_table[lobby][table-1]);  TextDrawShowForPlayer(BlackJackLobby2[lobby][Table3Id2], bj2_text_bj_table[lobby][table-1]);
	if(BlackJackLobby2[lobby][Table4Id2] != -1) TextDrawShowForPlayer(BlackJackLobby2[lobby][Table4Id2], bj2_text_bj_table[lobby][table-1]);  TextDrawShowForPlayer(BlackJackLobby2[lobby][Table4Id2], bj2_text_bj_table[lobby][table-1]);

    PlayerTextDrawSetString(playerid, bj2_panel_info[playerid], "blackjack:brbjyoubj");//GivePlayerMoney(BlackJackLobby2[lobby][Table1Id2], pBJInfo2[BlackJackLobby2[lobby][Table1Id2]][pBJBet2]*2);
    PlayerTextDrawHide(playerid, bj2_panel_info[playerid]);
    BlackJackLobby2[lobby][TableTurnTime2] = 0;
    BlackJackLobby2[lobby][TableTurn2]++;
}

stock GiveTableLose2(lobby, player)
{
	new str[32];
	format(str, sizeof str, "%s ��������", GetPlayerNameEx(player));
	SCMBJL2(lobby, CWHITE, str);
}

stock ShowMembersCardBJL2(lobby, table, card, suit, type)
{

	new apponent;
	switch(table)
	{
	    case 1: apponent = BlackJackLobby2[lobby][Table1Id2];
	    case 2: apponent = BlackJackLobby2[lobby][Table2Id2];
	    case 3: apponent = BlackJackLobby2[lobby][Table3Id2];
	    case 4: apponent = BlackJackLobby2[lobby][Table4Id2];
	}
    new give[96];
    format(give, sizeof give, "~w~����� ����� ����� ~y~%s", GetPlayerNameEx(apponent));
    TextDrawSetString(bj2_log_text[lobby][0], give);
    TextDrawColor(bj2_log_text[lobby][0], -1);
    TextDrawSetString(bj2_log_text[lobby][1], "");
    TextDrawColor(bj2_log_text[lobby][1], -65281);

	if(BlackJackLobby2[lobby][Table1Id2] != -1)
	{
		PlayerTextDrawShow(BlackJackLobby2[lobby][Table1Id2], bj2_card_table[BlackJackLobby2[lobby][Table1Id2]][table][card]);
        PlayerTextDrawSetString(BlackJackLobby2[lobby][Table1Id2], bj2_card_table[BlackJackLobby2[lobby][Table1Id2]][table][card], BlackJackCard2[suit][type][Cardtexture2]);
		PlayerTextDrawShow(BlackJackLobby2[lobby][Table1Id2], bj2_card_table[BlackJackLobby2[lobby][Table1Id2]][table][card]);
	}
	if(BlackJackLobby2[lobby][Table2Id2] != -1)
	{
		PlayerTextDrawShow(BlackJackLobby2[lobby][Table2Id2], bj2_card_table[BlackJackLobby2[lobby][Table2Id2]][table][card]);
        PlayerTextDrawSetString(BlackJackLobby2[lobby][Table2Id2], bj2_card_table[BlackJackLobby2[lobby][Table2Id2]][table][card], BlackJackCard2[suit][type][Cardtexture2]);
		PlayerTextDrawShow(BlackJackLobby2[lobby][Table2Id2], bj2_card_table[BlackJackLobby2[lobby][Table2Id2]][table][card]);
	}
	if(BlackJackLobby2[lobby][Table3Id2] != -1)
	{
		PlayerTextDrawShow(BlackJackLobby2[lobby][Table3Id2], bj2_card_table[BlackJackLobby2[lobby][Table3Id2]][table][card]);
        PlayerTextDrawSetString(BlackJackLobby2[lobby][Table3Id2], bj2_card_table[BlackJackLobby2[lobby][Table3Id2]][table][card], BlackJackCard2[suit][type][Cardtexture2]);
		PlayerTextDrawShow(BlackJackLobby2[lobby][Table3Id2], bj2_card_table[BlackJackLobby2[lobby][Table3Id2]][table][card]);
	}
	if(BlackJackLobby2[lobby][Table4Id2] != -1)
	{
		PlayerTextDrawShow(BlackJackLobby2[lobby][Table4Id2], bj2_card_table[BlackJackLobby2[lobby][Table4Id2]][table][card]);
        PlayerTextDrawSetString(BlackJackLobby2[lobby][Table4Id2], bj2_card_table[BlackJackLobby2[lobby][Table4Id2]][table][card], BlackJackCard2[suit][type][Cardtexture2]);
		PlayerTextDrawShow(BlackJackLobby2[lobby][Table4Id2], bj2_card_table[BlackJackLobby2[lobby][Table4Id2]][table][card]);
	}
}

stock LoadTextDrawBj()
{
	bj_fon2 = TextDrawCreate(0.000000, 0.000000, "blackjack:brbj");
	TextDrawLetterSize(bj_fon2, 0.000000, 0.000000);
	TextDrawTextSize(bj_fon2, 640.000000, 448.000000);
	TextDrawAlignment(bj_fon2, 1);
	TextDrawColor(bj_fon2, -1);
	TextDrawSetShadow(bj_fon2, 0);
	TextDrawSetOutline(bj_fon2, 0);
	TextDrawFont(bj_fon2, 4);

	bj_play2 = TextDrawCreate(268.399932, 389.773345, "blackjack:brbjplay");
	TextDrawLetterSize(bj_play2, 0.000000, 0.000000);
	TextDrawTextSize(bj_play2, 96.799949, 36.586669);
	TextDrawAlignment(bj_play2, 1);
	TextDrawColor(bj_play2, -1);
	TextDrawSetShadow(bj_play2, 0);
	TextDrawSetOutline(bj_play2, 0);
	TextDrawFont(bj_play2, 4);
	TextDrawSetSelectable(bj_play2, true);

	bj_double2 = TextDrawCreate(16.600013, 389.773345, "blackjack:brbjdouble");
	TextDrawLetterSize(bj_double2, 0.000000, 0.000000);
	TextDrawTextSize(bj_double2, 96.799949, 36.586669);
	TextDrawAlignment(bj_double2, 1);
	TextDrawColor(bj_double2, -1);
	TextDrawSetShadow(bj_double2, 0);
	TextDrawSetOutline(bj_double2, 0);
	TextDrawFont(bj_double2, 4);
	TextDrawSetSelectable(bj_double2, true);

	bj_stop2 = TextDrawCreate(121.600059, 389.773345, "blackjack:brbjstop");
	TextDrawLetterSize(bj_stop2, 0.000000, 0.000000);
	TextDrawTextSize(bj_stop2, 96.799949, 36.586669);
	TextDrawAlignment(bj_stop2, 1);
	TextDrawColor(bj_stop2, -1);
	TextDrawSetShadow(bj_stop2, 0);
	TextDrawSetOutline(bj_stop2, 0);
	TextDrawFont(bj_stop2, 4);
	TextDrawSetSelectable(bj_stop2, true);

	bj_take2 = TextDrawCreate(420.800231, 389.773345, "blackjack:brbjtake");
	TextDrawLetterSize(bj_take2, 0.000000, 0.000000);
	TextDrawTextSize(bj_take2, 96.799949, 36.586669);
	TextDrawAlignment(bj_take2, 1);
	TextDrawColor(bj_take2, -1);
	TextDrawSetShadow(bj_take2, 0);
	TextDrawSetOutline(bj_take2, 0);
	TextDrawFont(bj_take2, 4);
	TextDrawSetSelectable(bj_take2, true);

	bj_exit2 = TextDrawCreate(526.200256, 389.773345, "blackjack:brbjexit");
	TextDrawLetterSize(bj_exit2, 0.000000, 0.000000);
	TextDrawTextSize(bj_exit2, 96.799949, 36.586669);
	TextDrawAlignment(bj_exit2, 1);
	TextDrawColor(bj_exit2, -1);
	TextDrawSetShadow(bj_exit2, 0);
	TextDrawSetOutline(bj_exit2, 0);
	TextDrawFont(bj_exit2, 4);
	TextDrawSetSelectable(bj_exit2, true);

	bj_dealer_score2 = TextDrawCreate(259.000030, 388.280212, "blackjack:brbjscore");
	TextDrawLetterSize(bj_dealer_score2, 0.000000, 0.000000);
	TextDrawTextSize(bj_dealer_score2, 115.999938, 51.520008);
	TextDrawAlignment(bj_dealer_score2, 1);
	TextDrawColor(bj_dealer_score2, -1);
	TextDrawSetShadow(bj_dealer_score2, 0);
	TextDrawSetOutline(bj_dealer_score2, 0);
	TextDrawFont(bj_dealer_score2, 4);


	bj_help2 = TextDrawCreate(16.799999, 123.200004, "textures:button");
    TextDrawLetterSize(bj_help2, 0.000000, 0.000000);
    TextDrawTextSize(bj_help2, 104.000000, 36.586654);
    TextDrawAlignment(bj_help2, 1);
    TextDrawColor(bj_help2, 0xFFFFFF00);
    TextDrawSetShadow(bj_help2, 0);
    TextDrawSetOutline(bj_help2, 0);
    TextDrawFont(bj_help2, 4);
    TextDrawSetSelectable(bj_help2, true);



	bj2_text_bet[0] = TextDrawCreate(320.800018, 71.680015, "�� �������");
	TextDrawLetterSize(bj2_text_bet[0], 0.405198, 1.458132);
	TextDrawAlignment(bj2_text_bet[0], 2);
	TextDrawColor(bj2_text_bet[0], -65281);
	TextDrawSetShadow(bj2_text_bet[0], 0);
	TextDrawSetOutline(bj2_text_bet[0], 1);
	TextDrawBackgroundColor(bj2_text_bet[0], 51);
	TextDrawFont(bj2_text_bet[0], 1);
	TextDrawSetProportional(bj2_text_bet[0], 1);

	bj2_text_bet[1] = TextDrawCreate(320.200042, 86.120002, "��������� ������");
	TextDrawLetterSize(bj2_text_bet[1], 0.405198, 1.458132);
	TextDrawAlignment(bj2_text_bet[1], 2);
	TextDrawColor(bj2_text_bet[1], -65281);
	TextDrawSetShadow(bj2_text_bet[1], 0);
	TextDrawSetOutline(bj2_text_bet[1], 1);
	TextDrawBackgroundColor(bj2_text_bet[1], 51);
	TextDrawFont(bj2_text_bet[1], 1);
	TextDrawSetProportional(bj2_text_bet[1], 1);



	bj_text_start_time2 = TextDrawCreate(315.999969, 215.040039, "������� �� ������ ����");
	TextDrawLetterSize(bj_text_start_time2, 0.581197, 2.563199);
	TextDrawAlignment(bj_text_start_time2, 2);
	TextDrawColor(bj_text_start_time2, -1);
	TextDrawSetShadow(bj_text_start_time2, 0);
	TextDrawSetOutline(bj_text_start_time2, 1);
	TextDrawBackgroundColor(bj_text_start_time2, 51);
	TextDrawFont(bj_text_start_time2, 1);
	TextDrawSetProportional(bj_text_start_time2, 1);

	//bj2_text_start_timer � ����

}

stock LoadPlayerTextDraw(playerid)
{
    bj2_bet[playerid] = CreatePlayerTextDraw(playerid, 19.200004, 58.240013, "0 ���");
	PlayerTextDrawLetterSize(playerid, bj2_bet[playerid], 0.291599, 1.510398);
	PlayerTextDrawAlignment(playerid, bj2_bet[playerid], 1);
	PlayerTextDrawColor(playerid, bj2_bet[playerid], -1);
	PlayerTextDrawSetShadow(playerid, bj2_bet[playerid], 0);
	PlayerTextDrawSetOutline(playerid, bj2_bet[playerid], 1);
	PlayerTextDrawBackgroundColor(playerid, bj2_bet[playerid], 51);
	PlayerTextDrawFont(playerid, bj2_bet[playerid], 1);
	PlayerTextDrawSetProportional(playerid, bj2_bet[playerid], 1);

	bj2_money[playerid] = CreatePlayerTextDraw(playerid, 19.200004, 92.093315, "0 ���");
	PlayerTextDrawLetterSize(playerid, bj2_money[playerid], 0.291599, 1.510398);
	PlayerTextDrawAlignment(playerid, bj2_money[playerid], 1);
	PlayerTextDrawColor(playerid, bj2_money[playerid], -1);
	PlayerTextDrawSetShadow(playerid, bj2_money[playerid], 0);
	PlayerTextDrawSetOutline(playerid, bj2_money[playerid], 1);
	PlayerTextDrawBackgroundColor(playerid, bj2_money[playerid], 51);
	PlayerTextDrawFont(playerid, bj2_money[playerid], 1);
	PlayerTextDrawSetProportional(playerid, bj2_money[playerid], 1);


	bj2_dealer_point[playerid] = CreatePlayerTextDraw(playerid, 317.599853, 405.440093, "21");
	PlayerTextDrawLetterSize(playerid, bj2_dealer_point[playerid], 0.364398, 1.719465);
	PlayerTextDrawAlignment(playerid, bj2_dealer_point[playerid], 2);
	PlayerTextDrawColor(playerid, bj2_dealer_point[playerid], -1);
	PlayerTextDrawSetShadow(playerid, bj2_dealer_point[playerid], 0);
	PlayerTextDrawSetOutline(playerid, bj2_dealer_point[playerid], 1);
	PlayerTextDrawBackgroundColor(playerid, bj2_dealer_point[playerid], 51);
	PlayerTextDrawFont(playerid, bj2_dealer_point[playerid], 1);
	PlayerTextDrawSetProportional(playerid, bj2_dealer_point[playerid], 1);


	bj2_members_name[playerid][0] = CreatePlayerTextDraw(playerid, 19.600006, 197.626632, "Player");
	PlayerTextDrawLetterSize(playerid, 			bj2_members_name[playerid][0], 0.286798, 1.390933);
	PlayerTextDrawAlignment(playerid, 			bj2_members_name[playerid][0], 1);
	PlayerTextDrawColor(playerid, 				bj2_members_name[playerid][0], -1);
	PlayerTextDrawSetShadow(playerid, 			bj2_members_name[playerid][0], 0);
	PlayerTextDrawSetOutline(playerid, 			bj2_members_name[playerid][0], 1);
	PlayerTextDrawBackgroundColor(playerid, 	bj2_members_name[playerid][0], 51);
	PlayerTextDrawFont(playerid, 				bj2_members_name[playerid][0], 1);
	PlayerTextDrawSetProportional(playerid, 	bj2_members_name[playerid][0], 1);


	bj2_members_name[playerid][1] = CreatePlayerTextDraw(playerid, 147.200286, 40.586555, "Player");
	PlayerTextDrawLetterSize(playerid, 			bj2_members_name[playerid][1], 0.286798, 1.390933);
	PlayerTextDrawAlignment(playerid, 			bj2_members_name[playerid][1], 1);
	PlayerTextDrawColor(playerid, 				bj2_members_name[playerid][1], -1);
	PlayerTextDrawSetShadow(playerid, 			bj2_members_name[playerid][1], 0);
	PlayerTextDrawSetOutline(playerid, 			bj2_members_name[playerid][1], 1);
	PlayerTextDrawBackgroundColor(playerid, 	bj2_members_name[playerid][1], 51);
	PlayerTextDrawFont(playerid, 				bj2_members_name[playerid][1], 1);
	PlayerTextDrawSetProportional(playerid, 	bj2_members_name[playerid][1], 1);

	bj2_members_name[playerid][2] = CreatePlayerTextDraw(playerid, 397.800445, 40.586555, "Player");
	PlayerTextDrawLetterSize(playerid, 			bj2_members_name[playerid][2], 0.286798, 1.390933);
	PlayerTextDrawAlignment(playerid, 			bj2_members_name[playerid][2], 1);
	PlayerTextDrawColor(playerid, 				bj2_members_name[playerid][2], -1);
	PlayerTextDrawSetShadow(playerid,		 	bj2_members_name[playerid][2], 0);
	PlayerTextDrawSetOutline(playerid, 			bj2_members_name[playerid][2], 1);
	PlayerTextDrawBackgroundColor(playerid, 	bj2_members_name[playerid][2], 51);
	PlayerTextDrawFont(playerid, 				bj2_members_name[playerid][2], 1);
	PlayerTextDrawSetProportional(playerid, 	bj2_members_name[playerid][2], 1);

	bj2_members_name[playerid][3] = CreatePlayerTextDraw(playerid, 496.600280, 197.626632, "Player");
	PlayerTextDrawLetterSize(playerid, 			bj2_members_name[playerid][3], 0.286798, 1.390933);
	PlayerTextDrawAlignment(playerid, 			bj2_members_name[playerid][3], 1);
	PlayerTextDrawColor(playerid, 				bj2_members_name[playerid][3], -1);
	PlayerTextDrawSetShadow(playerid, 			bj2_members_name[playerid][3], 0);
	PlayerTextDrawSetOutline(playerid, 			bj2_members_name[playerid][3], 1);
	PlayerTextDrawBackgroundColor(playerid, 	bj2_members_name[playerid][3], 51);
	PlayerTextDrawFont(playerid, 				bj2_members_name[playerid][3], 1);
	PlayerTextDrawSetProportional(playerid, 	bj2_members_name[playerid][3], 1);

	bj2_card_table[playerid][1][0] = CreatePlayerTextDraw(playerid, 2.999999, 206.079971, "blackjack:cardscard");
	PlayerTextDrawLetterSize(playerid, bj2_card_table[playerid][1][0], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, bj2_card_table[playerid][1][0], 90.400009, 117.226631);
	PlayerTextDrawAlignment(playerid, bj2_card_table[playerid][1][0], 1);
	PlayerTextDrawColor(playerid, bj2_card_table[playerid][1][0], -1);
	PlayerTextDrawSetShadow(playerid, bj2_card_table[playerid][1][0], 0);
	PlayerTextDrawSetOutline(playerid, bj2_card_table[playerid][1][0], 0);
	PlayerTextDrawFont(playerid, bj2_card_table[playerid][1][0], 4);

	bj2_card_table[playerid][1][1] = CreatePlayerTextDraw(playerid, 22.999999, 206.079971, "blackjack:cardscard");
	PlayerTextDrawLetterSize(playerid, bj2_card_table[playerid][1][1], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, bj2_card_table[playerid][1][1], 90.400009, 117.226631);
	PlayerTextDrawAlignment(playerid, bj2_card_table[playerid][1][1], 1);
	PlayerTextDrawColor(playerid, bj2_card_table[playerid][1][1], -1);
	PlayerTextDrawSetShadow(playerid, bj2_card_table[playerid][1][1], 0);
	PlayerTextDrawSetOutline(playerid, bj2_card_table[playerid][1][1], 0);
	PlayerTextDrawFont(playerid, bj2_card_table[playerid][1][1], 4);

	bj2_card_table[playerid][1][2] = CreatePlayerTextDraw(playerid, 42.999999, 206.079971, "blackjack:cardscard");
	PlayerTextDrawLetterSize(playerid, bj2_card_table[playerid][1][2], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, bj2_card_table[playerid][1][2], 90.400009, 117.226631);
	PlayerTextDrawAlignment(playerid, bj2_card_table[playerid][1][2], 1);
	PlayerTextDrawColor(playerid, bj2_card_table[playerid][1][2], -1);
	PlayerTextDrawSetShadow(playerid, bj2_card_table[playerid][1][2], 0);
	PlayerTextDrawSetOutline(playerid, bj2_card_table[playerid][1][2], 0);
	PlayerTextDrawFont(playerid, bj2_card_table[playerid][1][2], 4);

	bj2_card_table[playerid][1][3] = CreatePlayerTextDraw(playerid, 62.999999, 206.079971, "blackjack:cardscard");
	PlayerTextDrawLetterSize(playerid, bj2_card_table[playerid][1][3], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, bj2_card_table[playerid][1][3], 90.400009, 117.226631);
	PlayerTextDrawAlignment(playerid, bj2_card_table[playerid][1][3], 1);
	PlayerTextDrawColor(playerid, bj2_card_table[playerid][1][3], -1);
	PlayerTextDrawSetShadow(playerid, bj2_card_table[playerid][1][3], 0);
	PlayerTextDrawSetOutline(playerid, bj2_card_table[playerid][1][3], 0);
	PlayerTextDrawFont(playerid, bj2_card_table[playerid][1][3], 4);





	bj2_card_table[playerid][2][0] = CreatePlayerTextDraw(playerid, 129.999999, 46.559913, "blackjack:cardscard");
	PlayerTextDrawLetterSize(playerid, bj2_card_table[playerid][2][0], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, bj2_card_table[playerid][2][0], 90.400009, 117.226631);
	PlayerTextDrawAlignment(playerid, bj2_card_table[playerid][2][0], 1);
	PlayerTextDrawColor(playerid, bj2_card_table[playerid][2][0], -1);
	PlayerTextDrawSetShadow(playerid, bj2_card_table[playerid][2][0], 0);
	PlayerTextDrawSetOutline(playerid, bj2_card_table[playerid][2][0], 0);
	PlayerTextDrawFont(playerid, bj2_card_table[playerid][2][0], 4);

	bj2_card_table[playerid][2][1] = CreatePlayerTextDraw(playerid, 149.999999, 46.559913, "blackjack:cardscard");
	PlayerTextDrawLetterSize(playerid, bj2_card_table[playerid][2][1], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, bj2_card_table[playerid][2][1], 90.400009, 117.226631);
	PlayerTextDrawAlignment(playerid, bj2_card_table[playerid][2][1], 1);
	PlayerTextDrawColor(playerid, bj2_card_table[playerid][2][1], -1);
	PlayerTextDrawSetShadow(playerid, bj2_card_table[playerid][2][1], 0);
	PlayerTextDrawSetOutline(playerid, bj2_card_table[playerid][2][1], 0);
	PlayerTextDrawFont(playerid, bj2_card_table[playerid][2][1], 4);

	bj2_card_table[playerid][2][2] = CreatePlayerTextDraw(playerid, 169.999999, 46.559913, "blackjack:cardscard");
	PlayerTextDrawLetterSize(playerid, bj2_card_table[playerid][2][2], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, bj2_card_table[playerid][2][2], 90.400009, 117.226631);
	PlayerTextDrawAlignment(playerid, bj2_card_table[playerid][2][2], 1);
	PlayerTextDrawColor(playerid, bj2_card_table[playerid][2][2], -1);
	PlayerTextDrawSetShadow(playerid, bj2_card_table[playerid][2][2], 0);
	PlayerTextDrawSetOutline(playerid, bj2_card_table[playerid][2][2], 0);
	PlayerTextDrawFont(playerid, bj2_card_table[playerid][2][2], 4);

	bj2_card_table[playerid][2][3] = CreatePlayerTextDraw(playerid, 189.999999, 46.559913, "blackjack:cardscard");
	PlayerTextDrawLetterSize(playerid, bj2_card_table[playerid][2][3], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, bj2_card_table[playerid][2][3], 90.400009, 117.226631);
	PlayerTextDrawAlignment(playerid, bj2_card_table[playerid][2][3], 1);
	PlayerTextDrawColor(playerid, bj2_card_table[playerid][2][3], -1);
	PlayerTextDrawSetShadow(playerid, bj2_card_table[playerid][2][3], 0);
	PlayerTextDrawSetOutline(playerid, bj2_card_table[playerid][2][3], 0);
	PlayerTextDrawFont(playerid, bj2_card_table[playerid][2][3], 4);





	bj2_card_table[playerid][3][0] = CreatePlayerTextDraw(playerid, 380.999999, 46.559913, "blackjack:cardscard");
	PlayerTextDrawLetterSize(playerid, bj2_card_table[playerid][3][0], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, bj2_card_table[playerid][3][0], 90.400009, 117.226631);
	PlayerTextDrawAlignment(playerid, bj2_card_table[playerid][3][0], 1);
	PlayerTextDrawColor(playerid, bj2_card_table[playerid][3][0], -1);
	PlayerTextDrawSetShadow(playerid, bj2_card_table[playerid][3][0], 0);
	PlayerTextDrawSetOutline(playerid, bj2_card_table[playerid][3][0], 0);
	PlayerTextDrawFont(playerid, bj2_card_table[playerid][3][0], 4);

	bj2_card_table[playerid][3][1] = CreatePlayerTextDraw(playerid, 400.999999, 46.559913, "blackjack:cardscard");
	PlayerTextDrawLetterSize(playerid, bj2_card_table[playerid][3][1], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, bj2_card_table[playerid][3][1], 90.400009, 117.226631);
	PlayerTextDrawAlignment(playerid, bj2_card_table[playerid][3][1], 1);
	PlayerTextDrawColor(playerid, bj2_card_table[playerid][3][1], -1);
	PlayerTextDrawSetShadow(playerid, bj2_card_table[playerid][3][1], 0);
	PlayerTextDrawSetOutline(playerid, bj2_card_table[playerid][3][1], 0);
	PlayerTextDrawFont(playerid, bj2_card_table[playerid][3][1], 4);

	bj2_card_table[playerid][3][2] = CreatePlayerTextDraw(playerid, 420.999999, 46.559913, "blackjack:cardscard");
	PlayerTextDrawLetterSize(playerid, bj2_card_table[playerid][3][2], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, bj2_card_table[playerid][3][2], 90.400009, 117.226631);
	PlayerTextDrawAlignment(playerid, bj2_card_table[playerid][3][2], 1);
	PlayerTextDrawColor(playerid, bj2_card_table[playerid][3][2], -1);
	PlayerTextDrawSetShadow(playerid, bj2_card_table[playerid][3][2], 0);
	PlayerTextDrawSetOutline(playerid, bj2_card_table[playerid][3][2], 0);
	PlayerTextDrawFont(playerid, bj2_card_table[playerid][3][2], 4);

	bj2_card_table[playerid][3][3] = CreatePlayerTextDraw(playerid, 440.999999, 46.559913, "blackjack:cardscard");
	PlayerTextDrawLetterSize(playerid, bj2_card_table[playerid][3][3], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, bj2_card_table[playerid][3][3], 90.400009, 117.226631);
	PlayerTextDrawAlignment(playerid, bj2_card_table[playerid][3][3], 1);
	PlayerTextDrawColor(playerid, bj2_card_table[playerid][3][3], -1);
	PlayerTextDrawSetShadow(playerid, bj2_card_table[playerid][3][3], 0);
	PlayerTextDrawSetOutline(playerid, bj2_card_table[playerid][3][3], 0);
	PlayerTextDrawFont(playerid, bj2_card_table[playerid][3][3], 4);




	bj2_card_table[playerid][4][0] = CreatePlayerTextDraw(playerid, 481.000000, 206.079971, "blackjack:cardscard");
	PlayerTextDrawLetterSize(playerid, bj2_card_table[playerid][4][0], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, bj2_card_table[playerid][4][0], 90.400009, 117.226631);
	PlayerTextDrawAlignment(playerid, bj2_card_table[playerid][4][0], 1);
	PlayerTextDrawColor(playerid, bj2_card_table[playerid][4][0], -1);
	PlayerTextDrawSetShadow(playerid, bj2_card_table[playerid][4][0], 0);
	PlayerTextDrawSetOutline(playerid, bj2_card_table[playerid][4][0], 0);
	PlayerTextDrawFont(playerid, bj2_card_table[playerid][4][0], 4);

	bj2_card_table[playerid][4][1] = CreatePlayerTextDraw(playerid, 502.000000, 206.079971, "blackjack:cardscard");
	PlayerTextDrawLetterSize(playerid, bj2_card_table[playerid][4][1], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, bj2_card_table[playerid][4][1], 90.400009, 117.226631);
	PlayerTextDrawAlignment(playerid, bj2_card_table[playerid][4][1], 1);
	PlayerTextDrawColor(playerid, bj2_card_table[playerid][4][1], -1);
	PlayerTextDrawSetShadow(playerid, bj2_card_table[playerid][4][1], 0);
	PlayerTextDrawSetOutline(playerid, bj2_card_table[playerid][4][1], 0);
	PlayerTextDrawFont(playerid, bj2_card_table[playerid][4][1], 4);

	bj2_card_table[playerid][4][2] = CreatePlayerTextDraw(playerid, 523.000000, 206.079971, "blackjack:cardscard");
	PlayerTextDrawLetterSize(playerid, bj2_card_table[playerid][4][2], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, bj2_card_table[playerid][4][2], 90.400009, 117.226631);
	PlayerTextDrawAlignment(playerid, bj2_card_table[playerid][4][2], 1);
	PlayerTextDrawColor(playerid, bj2_card_table[playerid][4][2], -1);
	PlayerTextDrawSetShadow(playerid, bj2_card_table[playerid][4][2], 0);
	PlayerTextDrawSetOutline(playerid, bj2_card_table[playerid][4][2], 0);
	PlayerTextDrawFont(playerid, bj2_card_table[playerid][4][2], 4);

	bj2_card_table[playerid][4][3] = CreatePlayerTextDraw(playerid, 544.000000, 206.079971, "blackjack:cardscard");
	PlayerTextDrawLetterSize(playerid, bj2_card_table[playerid][4][3], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, bj2_card_table[playerid][4][3], 90.400009, 117.226631);
	PlayerTextDrawAlignment(playerid, bj2_card_table[playerid][4][3], 1);
	PlayerTextDrawColor(playerid, bj2_card_table[playerid][4][3], -1);
	PlayerTextDrawSetShadow(playerid, bj2_card_table[playerid][4][3], 0);
	PlayerTextDrawSetOutline(playerid, bj2_card_table[playerid][4][3], 0);
	PlayerTextDrawFont(playerid, bj2_card_table[playerid][4][3], 4);



	bj2_panel_info[playerid] = CreatePlayerTextDraw(playerid, 155.146667, 249.386703, "blackjack:brbjyouturn");
	PlayerTextDrawLetterSize(playerid, bj2_panel_info[playerid], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, bj2_panel_info[playerid], 326.133239, 106.026657);
	PlayerTextDrawAlignment(playerid, bj2_panel_info[playerid], 1);
	PlayerTextDrawColor(playerid, bj2_panel_info[playerid], -1);
	PlayerTextDrawSetShadow(playerid, bj2_panel_info[playerid], 0);
	PlayerTextDrawSetOutline(playerid, bj2_panel_info[playerid], 0);
	PlayerTextDrawFont(playerid, bj2_panel_info[playerid], 4);

}

stock GivePlayerMoneyBjEx(playerid, money, description[]="None", bool:save=true, bool:game_text=true)
{
	if(money < 0 && GetPlayerMoneyEx(playerid) < money) return -1;

	new fmt_str[185];
	AddPlayerData(playerid, P_MONEY, +, money);
	GivePlayerMoney(playerid, money);

	format(fmt_str, sizeof fmt_str, "INSERT INTO money_log (uid,uip,time,money,description) VALUES (%d,'%s',%d,%d,'%s')", GetPlayerAccountID(playerid), GetPlayerIpEx(playerid), gettime(), money, description);
	mysql_query(mysql, fmt_str, false);


	if(save)
	{
		format(fmt_str, sizeof fmt_str, "UPDATE accounts SET money=%d WHERE id=%d LIMIT 1", GetPlayerMoneyEx(playerid), GetPlayerAccountID(playerid));
		mysql_query(mysql, fmt_str, false);
	}
	if(game_text)
    {
        new notification_amount_text[32];

        if(money < 0)
        {
            format(notification_amount_text, sizeof notification_amount_text, "%d ���.", money);
            ShowNotificationNew(playerid, 0, 5, 1, 1, notification_amount_text, "");
			0;
        }
        else
        {
            format(notification_amount_text, sizeof notification_amount_text, "+%d ���.", money);
			ShowNotificationNew(playerid, 1, 5, 1, 1, notification_amount_text, "");
			0;
        }
    }

	return 1;
}

public OnPlayerEnterDynamicArea(playerid, areaid)
{
    for(new lobby = 0; lobby < MAX_BJ_LOBBY2; lobby++)
    {
        if(areaid == BlackJackSphere[lobby])
        {
            0;
			ShowNotificationNew(playerid, 5, 5, BLACK_JACK, 1, "��������������", "");
            break;
        }
    }

    #if defined blackjack_OnPlayerEnterDynamicArea
        return blackjack_OnPlayerEnterDynamicArea(playerid, STREAMER_TAG_AREA:areaid);
    #else
        return 1;
    #endif
}
#if defined _ALS_OnPlayerEnterDynamicArea
    #undef OnPlayerEnterDynamicArea
#else
    #define _ALS_OnPlayerEnterDynamicArea
#endif
#define OnPlayerEnterDynamicArea blackjack_OnPlayerEnterDynamicArea
#if defined blackjack_OnPlayerEnterDynamicArea
    forward blackjack_OnPlayerEnterDynamicArea(playerid, STREAMER_TAG_AREA:areaid);
#endif

public OnGameModeInit()
{
	LoadBlackJack2();
    #if defined blackjack_OnGameModeInit
        return blackjack_OnGameModeInit();
    #else
        return 1;
    #endif
}
#if defined _ALS_OnGameModeInit
    #undef OnGameModeInit
#else
    #define _ALS_OnGameModeInit
#endif
#define OnGameModeInit blackjack_OnGameModeInit
#if defined blackjack_OnGameModeInit
    forward blackjack_OnGameModeInit();
#endif

public OnPlayerConnect(playerid)
{
	LoadPlayerTextDraw(playerid);
	for(new lobby; lobby < MAX_BJ_LOBBY2; lobby++)
	{
		TextDrawHideForPlayer(playerid, bj2_log_text[lobby][0]);
		TextDrawHideForPlayer(playerid, bj2_log_text[lobby][1]);
	}
	#if defined blackjack_OnPlayerConnect
        return blackjack_OnPlayerConnect(playerid);
    #else
        return 1;
    #endif
}
#if defined _ALS_OnPlayerConnect
    #undef OnPlayerConnect
#else
    #define _ALS_OnPlayerConnect
#endif
#define OnPlayerConnect blackjack_OnPlayerConnect
#if defined blackjack_OnPlayerConnect
    forward blackjack_OnPlayerConnect(playerid);
#endif

CMD:blackjack2(playerid)
{
	if(pBJInfo2[playerid][OnLobby2] == false)
	{
		new bool:distance;
		for(new i = 0; i < MAX_BJ_LOBBY2; i++)
		{
			if(IsPlayerInRangeOfPoint(playerid, 5.0, BlackJackPos2[i][0], BlackJackPos2[i][1], BlackJackPos2[i][2]))
		    {
	     		distance = true;
				if(BlackJackLobby2[i][StartedLobby2] == false)
				{
					if(BlackJackLobby2[i][Table1Id2] == -1) 	 { BlackJackLobby2[i][Table1Id2] = playerid; pBJInfo2[playerid][OnLobby2] = true; pBJInfo2[playerid][pBJLobby2] = i; pBJInfo2[playerid][pBJBehindSlot2] = 1; HideHud(playerid); InitPlayerLobby2(playerid, i, 1);}
					else if(BlackJackLobby2[i][Table2Id2] == -1) { BlackJackLobby2[i][Table2Id2] = playerid; pBJInfo2[playerid][OnLobby2] = true; pBJInfo2[playerid][pBJLobby2] = i; pBJInfo2[playerid][pBJBehindSlot2] = 2; HideHud(playerid); InitPlayerLobby2(playerid, i, 2);}
					else if(BlackJackLobby2[i][Table3Id2] == -1) { BlackJackLobby2[i][Table3Id2] = playerid; pBJInfo2[playerid][OnLobby2] = true; pBJInfo2[playerid][pBJLobby2] = i; pBJInfo2[playerid][pBJBehindSlot2] = 3; HideHud(playerid); InitPlayerLobby2(playerid, i, 3);}
					else if(BlackJackLobby2[i][Table4Id2] == -1) { BlackJackLobby2[i][Table4Id2] = playerid; pBJInfo2[playerid][OnLobby2] = true; pBJInfo2[playerid][pBJLobby2] = i; pBJInfo2[playerid][pBJBehindSlot2] = 4; HideHud(playerid); InitPlayerLobby2(playerid, i, 4);}
					else SCM(playerid, CLRED, "| "CW"������ ���� ��� �����.");
				}
				else SCM(playerid, CLRED, "| "CW"�� ���� ����� ��� �������� ����.");
		    }
		    else continue;
		}
		if(distance == false) SCM(playerid, CLRED, "| "CW"�� ���������� ������� ������ �� ���� �����");
	}
	return 1;
}









