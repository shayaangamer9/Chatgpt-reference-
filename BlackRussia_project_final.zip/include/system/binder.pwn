// File: binder.pwn
public: ShowPlayerLoginDialog(playerid, step, wrong_pass)
{
	if(GetPlayerData(playerid, P_ACCOUNT_STATE) != ACCOUNT_STATE_LOGIN) return 0;

	/*
	new request_type = REQUEST_TYPE_OFF;
	if(strcmp(GetPlayerIpEx(playerid), GetPlayerData(playerid, P_LAST_IP)) != 0)
	{
		request_type = REQUEST_TYPE_IP;
	}
	else
	{
		new subnet_last_ip[16], subnet_cur_ip[16];

		GetSubnet(subnet_cur_ip, GetPlayerIpEx(playerid));
		GetSubnet(subnet_last_ip, GetPlayerData(playerid, P_LAST_IP));

		if(strcmp(subnet_cur_ip, subnet_last_ip) != 0)
		{
			request_type = REQUEST_TYPE_SUBNET;
		}
	}
	*/

	new fmt_str[790];
	switch(step)
	{
		case LOGIN_STATE_CHECK_BAN:
		{
			new Cache: result;
			format(fmt_str, sizeof fmt_str, "SELECT * FROM ban_list WHERE user_id=%d LIMIT 1", GetPlayerAccountID(playerid));
			result = mysql_query(mysql, fmt_str, true);

			if (cache_num_rows())
			{
				new ban_time = cache_get_field_content_int(0, "time");
				new unban_time = cache_get_field_content_int(0, "ban_time");

				if (GetElapsedTime(unban_time, gettime(), CONVERT_TIME_TO_DAYS))
				{
					new admin_name[102] = "";
					new reason[1028] = "";

					cache_get_field_content(0, "admin", admin_name, mysql, sizeof(admin_name));
					cache_get_field_content(0, "description", reason, mysql, sizeof(reason));

					if (!strlen(reason))
						format(reason, sizeof reason, "No reason specified");

					new year, month, day, hour, minute, second;
					new unyear, unmonth, unday, unhour, unminute, unsecond;

					timestamp_to_date(ban_time, year, month, day, hour, minute, second);
					timestamp_to_date(unban_time, unyear, unmonth, unday, unhour, unminute, unsecond);

					format(fmt_str, sizeof fmt_str,
						"{FFFFFF}You are trying to log into an account that is currently banned\n"\
						"{FFFFFF}The ban is permanent. You cannot play on this account anymore.\n"\
						"{FFFFFF}The ban is issued by the administration of our project.\n\n"\
						""SC"Your nickname: {FFD700}%s\n"\
						""SC"Admin who banned you: {FFD700}%s\n"\
						""SC"Ban date: {FFD700}%02d.%02d.%d - %02d:%02d:%02d\n"\
						""SC"Ban expiry date: {FFD700}%02d.%02d.%d - %02d:%02d:%02d\n"\
						""SC"Ban reason: {FFD700}%s\n\n"\
						"{FFFFFF}You can try to resolve this issue with the administration and get unbanned\n"\
						"{FFFFFF}earlier or wait until the ban expires? In that case,\n"\
						"{FFFFFF}please contact the project administration on the official\n"\
						"{FFFFFF}forum or website: {FFD700}forum.xwenmobile.ru{FFFFFF}.\n\n"\
						"{FFFFFF}We do not recommend creating a new account to bypass the ban.",
						GetPlayerNameEx(playerid),
						admin_name,
						day, month, year, hour, minute, second,
						unday, unmonth, unyear, unhour, unminute, unsecond,
						reason
					);

					Dialog(playerid, INVALID_DIALOG_ID, DIALOG_STYLE_MSGBOX, "{FFD700}"SERVER_NAME" {FFFFFF}| Account banned", fmt_str, "Close", "");

					SetTimerEx("KickBannedPlayer", 5000, false, "i", playerid);
				}
				else
				{
					format(fmt_str, sizeof fmt_str, "DELETE FROM ban_list WHERE user_id=%d LIMIT 1", GetPlayerAccountID(playerid));
					mysql_tquery(mysql, fmt_str, "", "");

					CallLocalFunction("ShowPlayerLoginDialog", "iii", playerid, step + 1, false);
				}
			}
			else
			{
				CallLocalFunction("ShowPlayerLoginDialog", "iii", playerid, step + 1, false);
			}

			return cache_delete(result);
		}
		case LOGIN_STATE_PASSWORD:
		{
			format
			(
fmt_str, sizeof fmt_str,
"{FFFFFF}Welcome to {FFD700}"SERVER_NAME"{FF3366}!\n\n\
{FFFFFF}We hope you enjoy your time on our project!\n\n\
{A9E6FF}{FFFFFF}Your nickname: {33FF99}%s {A9E6FF}\n\
{FFFFFF}Ready to start the game?\n\n\
{FF0000}> {FFFFFF}The password is case sensitive! ",
GetPlayerNameEx(playerid)
			);
			if(wrong_pass)
			{
				new ch[3];
				new attemps = GetPlayerData(playerid, P_PASS_ATTEMPS);

				valstr(ch, attemps);

				strcat(fmt_str, "{FF3300}Incorrect password! Attempts left: ");
				strcat(fmt_str, ch);

				AddPlayerData(playerid, P_PASS_ATTEMPS, -, 1);
				switch(attemps)
				{
					case 0:
					{
						Dialog
						(
							playerid, INVALID_DIALOG_ID, DIALOG_STYLE_MSGBOX,
							"{FF9933}Limit of password attempts exceeded",
							"{FFFFFF}You have entered the password incorrectly 3 times in a row", // . Your IP will be saved
							"Close", ""
						);
						Kick:(playerid, " ");

						return 1;

						// BanEx(playerid, "Limit of password attempts exceeded");
						// return AddBan(0, gettime(), 1, GetPlayerIpEx(playerid), "Limit of password attempts exceeded", "The system is banning");
					}
					case 1:
					{
						SendClientMessage(playerid, 0xFF6600FF, "If you enter the password incorrectly, you will be banned");
					}
				}
				PlayerPlaySound(playerid, 10.812850, 2513.402099, 1541.041992);
			}
			else strcat(fmt_str, "{FFFFFF} Enter the password from the account:");

			Dialog(playerid, DIALOG_LOGIN, DIALOG_STYLE_INPUT, "{33FF99}XWEN MOBILE | {FFFFFF}Login to account", "Enter password", "Login");
		}
		case LOGIN_STATE_PHONE: // enter 5-digit code. phone confirmation
		{
			if(GetPlayerData(playerid, P_REQUEST_PHONE))
			{
				if(!wrong_pass)
				{
					new phone[13];

					strmid(phone, GetPlayerData(playerid, P_SETTING_PHONE), 0, strlen(GetPlayerData(playerid, P_SETTING_PHONE)) - 5);
					strcat(phone, "*****");

					format
					(
						fmt_str, sizeof fmt_str,
						"{FFFFFF}The system requires confirmation of the linked phone number\n"\
						"Your phone number\n\n{f23a71}%s\n\n"\
						"{FFFFFF}Enter the 5-digit code sent to your phone:",
						phone
					);
					Dialog(playerid, DIALOG_LOGIN, DIALOG_STYLE_INPUT, "{66CCFF}Phone confirmation", fmt_str, "Confirm", "Cancel");
				}
				else
				{
					SendClientMessage(playerid, 0xf23a3aFF, "The phone number confirmation code is incorrect. Try again");
					Kick:(playerid);
				}
			}
			else
			{
				return CallLocalFunction("ShowPlayerLoginDialog", "iii", playerid, step + 1, false);
			}
		}
		case LOGIN_STATE_PIN_CODE: // enter PIN
		{
			if(GetPlayerData(playerid, P_REQUEST_PIN))
			{
				if(wrong_pass)
				{
					SendClientMessage(playerid, 0xf23a3aFF, "PIN code is incorrect. Try again");
					Kick:(playerid);
				}
				else ShowPlayerPinCodePTD(playerid, PIN_CODE_STATE_LOGIN_CHECK);
			}
			else
			{
				return CallLocalFunction("ShowPlayerLoginDialog", "iii", playerid, step + 1, false);
			}
		}
		case LOGIN_STATE_LOAD_ACC:
		{
			SetPlayerData(playerid, P_AUTH_TIME, -1);
			LoadPlayerData(playerid);
		}
	}
	SetPlayerData(playerid, P_ACCOUNT_STEP_STATE, step);

	return 1;
}