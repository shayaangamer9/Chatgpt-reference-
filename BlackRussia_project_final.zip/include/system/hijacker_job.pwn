// File: hijacker_job.pwn
//Author of this system https://t.me/welsistudio (Welsi Studio)

new sphere_npc_hijacker;
//player
new player_order_hijacker[MAX_PLAYERS];
new player_hijacker_countdown[MAX_PLAYERS]; //cd removed on relog (didn't implement on db)
new player_timer_hijacker[MAX_PLAYERS][2];
new player_gang_zone_hijacker[MAX_PLAYERS];

enum STRUCT_HIJACKER
{
    HJ_PLAYER,
    HJ_VEHICLE, //Author of this system https://t.me/welsistudio (Welsi Studio)
    HJ_NET_ID,
    HJ_AREA_SEARCH,
    HJ_AREA_VEHICLE, //Author of this system https://t.me/welsistudio (Welsi Studio)

    Float:HJ_V_X,
    Float:HJ_V_Y,
    Float:HJ_V_Z,
    Float:HJ_V_A,

    Float:HJ_MIN_X,
    Float:HJ_MIN_Y,
    Float:HJ_MAX_X,
    Float:HJ_MAX_Y,
}
//Author of this system https://t.me/welsistudio (Welsi Studio)


new orders_hijacker[10][STRUCT_HIJACKER] =
{
    {-1, 426, -1, -1, -1,   1811.319458,2149.302978,15.158486,1.360892 ,     1713.771240,2027.524658,1959.103271,2346.62841},
    {-1, 490, -1, -1, -1,   490.803161,892.269592,11.254014,72.575027,       335.735992,780.646728,658.850952,1127.929077}, //Author of this system https://t.me/welsistudio (Welsi Studio)
    {-1, 466, -1, -1, -1,   21.750465,1070.200439,11.245204,169.182846,      -159.141586,950.674804,136.920562,1378.438232},
    {-1, 405, -1, -1, -1,   -2238.848144,-55.657539,25.997491,0.019704 ,     -2493.057617,-338.89932,-2160.443603,144.148910}, //Author of this system https://t.me/welsistudio (Welsi Studio)
    {-1, 529, -1, -1, -1,   95.806594,612.750000,11.308088,249.468963,       -65.915565,583.433044,444.726623,731.883850},
    {-1, 458, -1, -1, -1,   299.042877,689.258911,11.236943,339.11621,       17.148643,575.865417,462.426330,735.316650},
    {-1, 541, -1, -1, -1,   -441.778656,1329.811523,19.939584,181.514572,    -534.722717,1253.143920,-216.096328,1576.76611},
    {-1, 542, -1, -1, -1,   2423.073486,-2626.398925,21.372909,181.049209,   2131.563476,-2677.256103,2546.755371,-2137.126708}, //Author of this system https://t.me/welsistudio (Welsi Studio)
    {-1, 527, -1, -1, -1,   1761.047607,2329.895263,14.911863,269.820495,    1662.459106,2209.247802,1963.043457,2576.826660},
    {-1, 522, -1, -1, -1,   98.758666,916.508544,11.214806,338.377685,      -197.066696,953.113159,296.312744,1156.070312}
};

public OnDialogResponse(playerid, dialogid, response, listitem, inputtext[])
{
    if(dialogid == 2645)
    {
        if(response)
        {
            switch(listitem)
            {
                case 0:
                {
                    Dialog
                    (//Author of this system https://t.me/welsistudio (Welsi Studio)
                        playerid, -1, DIALOG_STYLE_MSGBOX,
                        "{FF4F43}"SERVER_NAME"{FFFFFF} | Basic information",
                        "{FAD201}Vehicle theft{FFFFFF} is one of the most interesting jobs on the server, which\n"\
                        "provides an opportunity to fully immerse yourself in the world of criminal organizations,\n"\
                        "experience some moments from their perspective, and ultimately earn decent money.\n\n"\
                        "It seems like you don't need to do anything special, steal cars - get money. But, in reality\n"\
                        "everything is not so simple, because it is very important to understand that this job is directly related to\n"\
                        "criminal activity, due to which law enforcement officers may clearly\n"\
                        "not like the direction of actions when attempting to steal a vehicle.\n\n"\
                        "Don't forget about the moment with breaking locks on vehicles - this is also\n"\
                        "quite a difficult process that requires attention, caution and of course,\n"\
                        "experience that will definitely come with time.",
                        "Back", ""
                    );
                }
                case 1:
                {
                    if(GetPlayerLevel(playerid) < 3) return SendClientMessage(playerid, -1, ""USC" First reach level 3.");

                    if(player_hijacker_countdown[playerid])
                    {
                        if(player_hijacker_countdown[playerid] >= gettime())
                        {
                            new countdown = player_hijacker_countdown[playerid] - gettime(), text[184];
                            format(text, sizeof text, ""SC" Again you? There are no tasks now, get lost. (Left {FAD201}%d:%d {FFFFFF}minutes)", ConvertUnixTime(countdown, CONVERT_TIME_TO_MINUTES), ConvertUnixTime(countdown, CONVERT_TIME_TO_SECONDS));
                            SendClientMessage(playerid, -1, text);
                            return 1;
                        }
                        else player_hijacker_countdown[playerid] = 0;
                    }

                    for(new h, count = -1, random_orders[sizeof orders_hijacker];h < sizeof orders_hijacker;h++)
                    {
                        if(orders_hijacker[h][HJ_PLAYER] != -1) continue;
//Author of this system https://t.me/welsistudio (Welsi Studio)
                        count++;

                        random_orders[count] = h;

                        if(h == sizeof orders_hijacker - 1)
                        {
                            orders_hijacker[random_orders[random(count)]][HJ_PLAYER] = playerid;
                            player_order_hijacker[playerid] = random_orders[random(count)];
                        }
                    }

                    if(player_order_hijacker[playerid] == -1) return SendClientMessage(playerid, -1, ""SC" No tasks at the moment.");

                    new orders = player_order_hijacker[playerid];

                    SendClientMessage(playerid, -1, ""SC" A large red zone is marked on the map where the vehicle was last seen.");
                    SendClientMessage(playerid, -1, ""SC" When you enter the zone where the vehicle was last seen, we will give you more information.");
                    SendClientMessage(playerid, -1, ""SC" You have {FAD201}25 minutes{FFFFFF} for all of the above, we hope that's enough, hurry up, otherwise the task will fail");
                    SendClientMessage(playerid, -1, ""SC" Use the command � {FAD201}/carjack{FFFFFF} to start the car lock picking process.");

                    player_timer_hijacker[playerid][1] = 1500;
                    player_timer_hijacker[playerid][0] = SetTimerEx("GameTextHijacker", 1000, true, "i", playerid);

                    player_gang_zone_hijacker[playerid] = GangZoneCreate(orders_hijacker[orders][HJ_MIN_X], orders_hijacker[orders][HJ_MIN_Y], orders_hijacker[orders][HJ_MAX_X], orders_hijacker[orders][HJ_MAX_Y]);
                    GangZoneShowForPlayer(playerid, player_gang_zone_hijacker[playerid], 0xFF0000D8A);

                    orders_hijacker[orders][HJ_NET_ID] = CreateVehicle(orders_hijacker[orders][HJ_VEHICLE], orders_hijacker[orders][HJ_V_X], orders_hijacker[orders][HJ_V_Y], orders_hijacker[orders][HJ_V_Z], orders_hijacker[orders][HJ_V_A],\
                    random(128), random(128), 0);
                }
                case 2:OrdinaryNewHijacker(playerid);
            }
        }
    }
    if(dialogid == 2646)
    {//Author of this system https://t.me/welsistudio (Welsi Studio)
        if(!response) return 1;

        new subsequence[5], subsequence_select[5], stage;

        GetPVarString(playerid, "subsequence_player", subsequence, 5);
        GetPVarString(playerid, "subsequence_select", subsequence_select, 5);

        if(GetPVarInt(playerid, "stage_dialog")) stage = GetPVarInt(playerid, "stage_dialog");

        subsequence_select[stage] = listitem + 1;

        if(subsequence[stage] == subsequence_select[stage]) stage++;
        else//Author of this system https://t.me/welsistudio (Welsi Studio)
        {
            stage = 0;
            subsequence_select = {0, 0, 0, 0, 0};
            SendClientMessage(playerid, -1, ""SC" A mistake was made, all pins returned to their original position.");
            SendClientMessage(playerid, -1, ""SC" Don't worry, the number of allowed mistakes is unlimited.");
        }

        if(stage == 5)
        {
            EnablePlayerGPS(playerid, 55, 2181.646484,-1838.352783,18.81676, "");
            SendClientMessage(playerid, -1, ""SC" Take this vehicle to the drop-off point and go to the bot {FAD201}(location on the map)");
            SendClientMessage(playerid, -1, ""SC" Be as careful as possible. Law enforcement officers are not sleeping.");
            SetPVarInt(playerid, "complete_jacker_veh", 1);
            return 1;
        }//Author of this system https://t.me/welsistudio (Welsi Studio)//Author of this system https://t.me/welsistudio (Welsi Studio)

        new text[128] = "", select_text[5][24] = {"One\n",  "Two\n", "Three\n", "Four\n", "Five"};

        for(new t; t < stage;t++)
        {
            switch(subsequence_select[t])
            {
                case 1:select_text[0] = "{FAD201} One\n";
                case 2:select_text[1] = "{FAD201} Two\n";
                case 3:select_text[2] = "{FAD201} Three\n";
                case 4:select_text[3] = "{FAD201} Four\n";
                case 5:select_text[4] = "{FAD201} Five";
            }
        }//Author of this system https://t.me/welsistudio (Welsi Studio)//Author of this system https://t.me/welsistudio (Welsi Studio)

        for(new p;p < 5;p++) strcat(text, select_text[p]);

        Dialog
        (
            playerid, 2646, DIALOG_STYLE_LIST,
            "Guess the sequence",
            text,
            "Press", "Cancel"
        );//Author of this system https://t.me/welsistudio (Welsi Studio)//Author of this system https://t.me/welsistudio (Welsi Studio)

        SetPVarString(playerid, "subsequence_select", subsequence_select);
        SetPVarInt(playerid, "stage_dialog", stage);


        //format(text, sizeof text, "%d %d %d %d %d | %d %d %d %d %d", subsequence[0], subsequence[1], subsequence[2], subsequence[3], subsequence[4], subsequence_select[0],  subsequence_select[1],  subsequence_select[2],  subsequence_select[3],  subsequence_select[4]);
        //SCM(playerid, -1, text);

    }//Author of this system https://t.me/welsistudio (Welsi Studio)//Author of this system https://t.me/welsistudio (Welsi Studio)
    #if defined hj_OnDialogResponse
return hj_OnDialogResponse(playerid, dialogid, response, listitem, inputtext);
#endif
}
#if defined _ALS_OnDialogResponse
#undef OnDialogResponse
#else
#define _ALS_OnDialogResponse
#endif
#define OnDialogResponse hj_OnDialogResponse
#if defined hj_OnDialogResponse
forward hj_OnDialogResponse(playerid, dialogid, response, listitem, inputtext[]);
#endif

/*public OnPlayerEnterCheckpoint(playerid)
{
    #if defined hj_OnPlayerEnterCheckpoint//Author of this system https://t.me/welsistudio (Welsi Studio)//Author of this system https://t.me/welsistudio (Welsi Studio)
        return hj_OnPlayerEnterCheckpoint(playerid);
    #else
        return 1;
    #endif
}
   #if defined _ALS_OnPlayerEnterCheckpoint
    #undef OnPlayerEnterCheckpoint
#else
    #define _ALS_OnPlayerEnterCheckpoint
#endif
#define OnPlayerEnterCheckpoint hj_OnPlayerEnterCheckpoint
#if defined hj_OnPlayerEnterCheckpoint
    forward hj_OnPlayerEnterCheckpoint(playerid);
#endif*/
//Author of this system https://t.me/welsistudio (Welsi Studio)

public OnPlayerEnterVehicle(playerid, vehicleid, ispassenger)
{
    for(new v;v<sizeof orders_hijacker;v++)
    {
        if(orders_hijacker[v][HJ_NET_ID] == vehicleid)
        {
            if(!GetPVarInt(playerid, "complete_jacker_veh")) ClearAnimations(playerid);
            break;
        }
    }
    #if defined hj_OnPlayerEnterVehicle
        return hj_OnPlayerEnterVehicle(playerid, vehicleid, ispassenger);
    #else
        return 1;//Author of this system https://t.me/welsistudio (Welsi Studio)
    #endif
}
   #if defined _ALS_OnPlayerEnterVehicle
    #undef OnPlayerEnterVehicle
#else
    #define _ALS_OnPlayerEnterVehicle
#endif
#define OnPlayerEnterVehicle hj_OnPlayerEnterVehicle
#if defined hj_OnPlayerEnterVehicle
    forward hj_OnPlayerEnterVehicle(playerid, vehicleid, ispassenger);
#endif
//Author of this system https://t.me/welsistudio (Welsi Studio)
public OnPlayerEnterDynamicArea(playerid, areaid)
{
    if(areaid == sphere_npc_hijacker)
    {
        if(player_order_hijacker[playerid] != -1)
        {
            if(GetPVarInt(playerid, "complete_jacker_veh"))
            {
                new txt_salary[84], salary = 600000 + random(100000);

                SendClientMessage(playerid, -1, ""SC" You successfully delivered the required vehicle to the drop-off point.");
                format(txt_salary, sizeof txt_salary, ""SC" Your salary is %d rubles", salary);
                SendClientMessage(playerid, -1, txt_salary);

                format(txt_salary, sizeof txt_salary, ""SC" You received %d rubles", salary);
                ShowNotification(playerid, 2, txt_salary, 2, "", "");

                GivePlayerMoneyEx(playerid, salary);

                OrdinaryNewHijacker(playerid);

                player_hijacker_countdown[playerid] = gettime() + 420;
//Author of this system https://t.me/welsistudio (Welsi Studio)
                return 1;
            }
        }

        DialogHijacker
        (
            playerid, 2645, DIALOG_STYLE_TABLIST_HEADERS,
            "{FF4F43}"SERVER_NAME" {FFFFFF}| Car thief",
            "{7E7E7E}##\t{7E7E7E}Name\t{7E7E7E}Action\n"\
            "{FF4F43}#1\t{FFFFFF}Basic information\t{FFFFFF}Click to interact\n"\
            "{FF4F43}#2\t{FFFFFF}Take task\t{FFFFFF}Click to interact\n"\
            "{FF4F43}#3\t{FFFFFF}Cancel task\t{FFFFFF}Click to interact",
            "Select", "Cancel"
        );
        //else SendClientMessage(playerid, -1, "{FAD201}Vova:{FFFFFF} Bro, this job is from level 3!");
    }
    if(orders_hijacker[0][HJ_AREA_SEARCH] <= areaid <= orders_hijacker[sizeof orders_hijacker - 1][HJ_AREA_SEARCH])
    {
        if(player_order_hijacker[playerid] != -1)
        {
        new text[194  + 99], veh = orders_hijacker[player_order_hijacker[playerid]][HJ_VEHICLE] - 400;
//Author of this system https://t.me/welsistudio (Welsi Studio)
        format(text, sizeof text, "Your task is to break into and deliver the vehicle � {FAD201}%s.", g_vehicle_info[veh][VI_NAME]);
        SendClientMessage(playerid, -1, text);
        }
    }
    #if defined hj_OnPlayerEnterDynamicArea
        return hj_OnPlayerEnterDynamicArea(playerid, STREAMER_TAG_AREA:areaid);
    #else
        return 0;
    #endif
}
   #if defined _ALS_OnPlayerEnterDynamicArea
    #undef OnPlayerEnterDynamicArea
#else
    #define _ALS_OnPlayerEnterDynamicArea
#endif
#define OnPlayerEnterDynamicArea hj_OnPlayerEnterDynamicArea
#if defined hj_OnPlayerEnterDynamicArea
    forward hj_OnPlayerEnterDynamicArea(playerid, STREAMER_TAG_AREA:areaid);
#endif
//Author of this system https://t.me/welsistudio (Welsi Studio)

public OnGameModeInit()
{
    CreateHijacker();
    print("[LAIRD_SYSTEM] Car thief job loaded.");
    #if defined hj_OnGameModeInit
        return hj_OnGameModeInit();
    #else
        return 1;
    #endif
}
   #if defined _ALS_OnGameModeInit
    #undef OnGameModeInit
#else
    #define _ALS_OnGameModeInit
#endif
#define OnGameModeInit hj_OnGameModeInit
#if defined hj_OnGameModeInit
    forward hj_OnGameModeInit();
#endif

public OnPlayerDisconnect(playerid, reason)
{//Author of this system https://t.me/welsistudio (Welsi Studio)
    OrdinaryNewHijacker(playerid);
    #if defined hj_OnPlayerDisconnect
        return hj_OnPlayerDisconnect(playerid, reason);
    #else
        return 1;
    #endif
}//Author of this system https://t.me/welsistudio (Welsi Studio)
#if defined _ALS_OnPlayerDisconnect
    #undef OnPlayerDisconnect
#else//Author of this system https://t.me/welsistudio (Welsi Studio)
    #define _ALS_OnPlayerDisconnect
#endif
#define OnPlayerDisconnect hj_OnPlayerDisconnect
#if defined hj_OnPlayerDisconnect
    forward hj_OnPlayerDisconnect(playerid, reason);
#endif
//Author of this system https://t.me/welsistudio (Welsi Studio)
public OnPlayerConnect(playerid)
{
    OrdinaryNewHijacker(playerid);
    #if defined hj_OnPlayerConnect
        return hj_OnPlayerConnect(playerid);
    #else
        return 1;
    #endif
}
#if defined _ALS_OnPlayerConnect
    #undef OnPlayerConnect
#else
    #define _ALS_OnPlayerConnect
#endif
#define OnPlayerConnect hj_OnPlayerConnect
#if defined hj_OnPlayerConnect
    forward hj_OnPlayerConnect(playerid);
#endif
//Author of this system https://t.me/welsistudio (Welsi Studio)
public OnPlayerSpawn(playerid)
{
    OrdinaryNewHijacker(playerid);
    #if defined hj_OnPlayerSpawn
        return hj_OnPlayerSpawn(playerid);
    #else//Author of this system https://t.me/welsistudio (Welsi Studio)
        return 1;
    #endif
}
#if defined _ALS_OnPlayerSpawn
    #undef OnPlayerSpawn
#else
    #define _ALS_OnPlayerSpawn
#endif
#define OnPlayerSpawn hj_OnPlayerSpawn
#if defined hj_OnPlayerSpawn
    forward hj_OnPlayerSpawn(playerid);
#endif
//Author of this system https://t.me/welsistudio (Welsi Studio)
stock CreateHijacker()//Author of this system https://t.me/welsistudio (Welsi Studio)
{
    for(new h;h < sizeof orders_hijacker;h++)
    {
        orders_hijacker[h][HJ_AREA_SEARCH] = CreateDynamicRectangle(orders_hijacker[h][HJ_MIN_X], orders_hijacker[h][HJ_MIN_Y], orders_hijacker[h][HJ_MAX_X], orders_hijacker[h][HJ_MAX_Y], 0, 0);
    }//Author of this system https://t.me/welsistudio (Welsi Studio)

    CreateActorEx("{FFFFFF}Car thief\n{FAD201}Artem\n", "{FFFFFF}Approach for {FAD201}interaction", 103, 2165.000488,-1859.087280,18.814174,50.157138);
    CreateDynamicPickup(1239, 23, 2164.181396,-1858.483032,18.814174, 0, 0);
    sphere_npc_hijacker = CreateDynamicSphere(2164.181396,-1858.483032,18.814174, 2.0);//Author of this system https://t.me/welsistudio (Welsi Studio)

}

stock OrdinaryNewHijacker(playerid)
{
    if(player_timer_hijacker[playerid][0] != -1) KillTimer(player_timer_hijacker[playerid][0]);

    player_timer_hijacker[playerid][0] = -1;

    player_timer_hijacker[playerid][1] = 0;

    player_hijacker_countdown[playerid] = 0;

    if(player_gang_zone_hijacker[playerid] != -1)
    {//Author of this system https://t.me/welsistudio (Welsi Studio)
        GangZoneHideForPlayer(playerid, player_gang_zone_hijacker[playerid]);
        GangZoneDestroy(player_gang_zone_hijacker[playerid]);
    }

    player_gang_zone_hijacker[playerid] = -1;

    if(player_order_hijacker[playerid] != -1)
    {
        if(IsPlayerLogged(playerid))
        {
            DestroyVehicle(orders_hijacker[player_order_hijacker[playerid]][HJ_NET_ID]);

            orders_hijacker[player_order_hijacker[playerid]][HJ_PLAYER] = -1;
        }

    }//Author of this system https://t.me/welsistudio (Welsi Studio)

    player_order_hijacker[playerid] = -1;

    if(GetPVarInt(playerid, "complete_jacker_veh")) DeletePVar(playerid, "complete_jacker_veh");
}

stock DialogHijacker(playerid, dialogid, style, const title[], const text[], const button[], const button2[])
{
  if(style == 5)
  {
     ShowPlayerDialog(playerid, 0, DIALOG_STYLE_LIST, "...", "...", "...", "");
  }
  ShowPlayerDialog(playerid, dialogid, style, title, text, button, button2);
  return 1;
}//Author of this system https://t.me/welsistudio (Welsi Studio)

public: GameTextHijacker(playerid)
{
    if(player_timer_hijacker[playerid][1] != 0)
    {
        player_timer_hijacker[playerid][1]--;

        new text[56];

        format(text, sizeof text, "~n~~n~~n~~n~~n~~n~~n~~n~~n~~n~~n~~b~%d ~g~sec.", player_timer_hijacker[playerid][1]);
        GameTextForPlayer(playerid, text, 900, 3);
    }
    else
    {
        SendClientMessage(playerid, -1, ""SC" You didn't manage to steal the vehicle in time. Task failed.");
        OrdinaryNewHijacker(playerid);
    }
}

CMD:carjack(playerid)
{//Author of this system https://t.me/welsistudio (Welsi Studio)
    if(player_order_hijacker[playerid] != -1)
    {
        new Float:x, Float:y, Float:z;

        foreach(new i : Vehicle)
        {
            if(orders_hijacker[player_order_hijacker[playerid]][HJ_NET_ID] != i) continue;

            GetVehiclePos(i, x, y, z);
//Author of this system https://t.me/welsistudio (Welsi Studio)
            if(GetPlayerDistanceFromPoint(playerid, x, y, z) <= 3.5)//Author of this system https://t.me/welsistudio (Welsi Studio)
            {
                new array[5], number[] = {1, 2, 3, 4, 5}, none[5];//Author of this system https://t.me/welsistudio (Welsi Studio)

                RandomArrayHijacker(number, array);

                SetPVarString(playerid, "subsequence_player", array);
                SetPVarString(playerid, "subsequence_select", none);

                //format(text, sizeof text, "%d %d %d %d %d", array[0], array[1], array[2], array[3], array[4]);
                //SCM(playerid, -1, text);

                Dialog
                (
                    playerid, 2646, DIALOG_STYLE_LIST,
                    "Guess the sequence",
                    "One\n"\
                    "Two\n"\
                    "Three\n"\
                    "Four\n"\
                    "Five",
                    "Press", "Cancel"
                );
            }
            else SendClientMessage(playerid, -1, ""SC" You are too far from the vehicle.");
        }
    }
    else SendClientMessage(playerid, -1, ""SC" First take an order from Artem.");
//Author of this system https://t.me/welsistudio (Welsi Studio)
}

stock RandomArrayHijacker(numbers[], array[], size_numbers = sizeof(numbers), const size_array = sizeof(array))
{//Author of this system https://t.me/welsistudio (Welsi Studio)
    new index;

    for (new i; i < size_array; i++)
    {
        index = random(size_numbers);

        array[i] = numbers[index];

        numbers[index] = numbers[-- size_numbers];
    }
}
//Author of this system https://t.me/welsistudio (Welsi Studio)
