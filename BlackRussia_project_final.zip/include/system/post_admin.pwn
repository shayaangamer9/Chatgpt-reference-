// File: post_admin.pwn
enum struct_post_admin
{
    Post_Name[46],
    Post_Level,
    Post_Division,
}

#define Division_Junior 1
#define Division_Tracking 2
#define Division_Major_Tracking 3
#define Division_Technical  4
#define Division_Media  5
#define Division_Major  6
#define Division_Maj  7
#define Division_Pok  8


new post_admin[46][struct_post_admin] =
{
    {"{57c970}Junior Moderator", 3, 0},                              //0
    {"{57c970}Moderator", 4, Division_Junior},                              //1
    {"{57c970}Senior Moderator", 5, Division_Junior},                  //2
    {"{edbd45}Administrator", 6, Division_Junior},                  //3
    {"{edbd45}Senior Administrator", 7, Division_Junior},                  //4
    {"{8eed45}Law Enforcement Overseer", 3, Division_Tracking},                   //5
    {"{5b45ed}FSB Overseer", 3, Division_Tracking},                  //6
    {"{5b45ed}Traffic Police Overseer", 3, Division_Tracking},                    //7
    {"{5b45ed}Police Department Overseer", 3, Division_Tracking},                 //8
    {"{7f521f}Army Overseer", 3, Division_Tracking},                   //9
    {"{d952c2}Central Bank Overseer", 3, Division_Tracking},                   //10
    {"{ffa31a}Media Overseer", 3, Division_Tracking},                  //11
    {"{1aff30}Arzamas Organized Crime Overseer", 3, Division_Tracking},                    //12
    {"{5b45ed}Batyrevo Organized Crime Overseer", 3, Division_Tracking},                    //13
    {"{e09c12}Lytkarino Organized Crime Overseer", 3, Division_Tracking},                    //14
    {"{1272e0}GOC Head of State Security Service", 7, Division_Major_Tracking},                    //15
    {"{1aff30}Head of Organized Crime Group", 7, Division_Major_Tracking},                 //16
    {"{edbd45}Head of Interagency Relations", 7, Division_Major_Tracking},                  //17
    {"{1272e0}Deputy Head of State Security Service", 7, Division_Major_Tracking},                   //18
    {"{1aff30}Deputy Head of Organized Crime", 7, Division_Major_Tracking},                    //19
    {"{edbd45}Deputy Head of Interagency Relations", 7, Division_Major_Tracking},                 //20
    {"{d952c2}Blogger", 2, Division_Media},                  //21
    {"{d952c2}Assistant PR Manager", 10, Division_Media},                 //22
    {"{d952c2}PR Manager", 10, Division_Media},                   //23
    {"{f29407}Technical Specialist ", 9, Division_Technical},//24
    {"{f29407}Deputy Technical Specialist Curator", 10, Division_Technical},//25
    {"{f29407}Technical Specialist Curator", 10, Division_Technical},//26
    {"{fc12ca}Deputy Chief Technical Specialist", 11, Division_Technical},//27
    {"{f29407}Chief Technical Specialist", 11, Division_Technical},//28
    {"{c454f7}Administration Curator ", 9, Division_Major},//29
    {"{fc1212}Deputy Head Administrator", 10, Division_Major},//30
    {"{fc1212}Senior Deputy Head Administrator", 10, Division_Major},//31
    {"{fc1212}Head Administrator", 11, Division_Major},//32
    {"{fc1212}Deputy Special Administrator", 12, Division_Major},//33
    {"{fc1212}Special Administrator", 12, Division_Major},//34
    {"{12a6fc}Project Developer", 13, Division_Major},//35
    {"{fc1212}Project Director", 13, Division_Major},//36
    {"{edbd45}Interagency Relations Overseer", 4, Division_Tracking},//37
    {"{12fced}Tester Intern", 1, Division_Maj},//38
    {"{12fced}Junior Tester", 1, Division_Maj},//39
    {"{12fced}Tester", 2, Division_Maj},//40
    {"{12fced}Senior Tester", 4, Division_Maj},//41
    {"{12fced}Testing Curator", 5, Division_Maj},//42
    {"{12fced}Deputy Chief Tester", 7, Division_Maj},//43
    {"{12fced}Chief Tester", 8, Division_Maj},//44
    {"{fcf512}Project Owner", 13, Division_Major}//45
};

new admin_player_post[MAX_PLAYERS];

#define SetPlayerAdminPost(%0,%1)    admin_player_post[%0] = %1
#define GetPlayerAdminPost(%0)    admin_player_post[%0]


public OnDialogResponse(playerid, dialogid, response, listitem, inputtext[])
{
    if(dialogid == 1990)
    {
        if(response)
        {
            new division = listitem+1;

            new list[35], dialog[268];

            for(new i, c = -1;i < sizeof post_admin;i++)
            {
                if(post_admin[i][Post_Division] != division) continue;
                c++;

                format(list, sizeof list, "%d. %s\n", c+1, post_admin[i][Post_Name]);
                strcat(dialog, list);
                SetPlayerListitemValue(playerid, c, i);
            }

            Dialog(playerid, 1991, DIALOG_STYLE_LIST, "{FFCD55}SILE RUSSIA | {FFFFFF}Assign admin prefix", dialog, "Assign", "Exit");
        }
    }
    if(dialogid == 1991)
    {
        if(response)
        {
            new post = GetPlayerListitemValue(playerid, listitem);

            new to_player = GetPVarInt(playerid, "shablon_player");

            if(GetPlayerAdminEx(to_player) >= GetPlayerAdminEx(playerid))
                return SendClientMessage(playerid, 0xFF9900FF, "You cannot assign a prefix to an administrator of higher or equal level.");

            if(!IsPlayerConnected(playerid))
                return SendClientMessage(playerid,-1, "Player left the game.");

            SetPlayerAdminPost(to_player, post);
	    	SetPlayerData(to_player, P_ADMIN, post_admin[post][Post_Level]);
			UpdatePlayerDatabaseInt(to_player, "admin", post_admin[post][Post_Level]);
			UpdatePlayerDatabaseInt(to_player, "post", post);

            new text[158];
            format(text, sizeof text, "{eb0000}%s changed the position of administrator %s. New position (%s)",
             GetPlayerNameEx(playerid), GetPlayerNameEx(to_player), post_admin[post][Post_Name]);

            SendMessageToAdmins(text, -1);
        }
    }
    #if defined post_OnDialogResponse
return post_OnDialogResponse(playerid, dialogid, response, listitem, inputtext);
#endif
}
#if defined _ALS_OnDialogResponse
#undef OnDialogResponse
#else
#define _ALS_OnDialogResponse
#endif
#define OnDialogResponse post_OnDialogResponse
#if defined post_OnDialogResponse
forward post_OnDialogResponse(playerid, dialogid, response, listitem, inputtext[]);
#endif

public OnPlayerSpawn(playerid)
{
    if(!GetPlayerAdminPost(playerid) && GetPlayerAdminEx(playerid)) LoadAdminPost(playerid);
    #if defined post_OnPlayerSpawn
        return post_OnPlayerSpawn(playerid);
    #else
        return 1;
    #endif
}
#if defined _ALS_OnPlayerSpawn
    #undef OnPlayerSpawn
#else
    #define _ALS_OnPlayerSpawn
#endif
#define OnPlayerSpawn post_OnPlayerSpawn
#if defined post_OnPlayerSpawn
    forward post_OnPlayerSpawn(playerid);
#endif

public OnPlayerDisconnect(playerid, reason)
{
    SetPlayerAdminPost(playerid, 0);
    #if defined post_OnPlayerDisconnect
        return post_OnPlayerDisconnect(playerid, reason);
    #else
        return 1;
    #endif
}
#if defined _ALS_OnPlayerDisconnect
    #undef OnPlayerDisconnect
#else
    #define _ALS_OnPlayerDisconnect
#endif
#define OnPlayerDisconnect post_OnPlayerDisconnect
#if defined post_OnPlayerDisconnect
    forward post_OnPlayerDisconnect(playerid, reason);
#endif

public OnGameModeInit()
{
    print("[W_SYSTEM] /shablon command and position system loaded.");
    SetTimer("CheckAccountPost", 1500, false);
    #if defined post_OnGameModeInit
        return post_OnGameModeInit();
    #else
        return 1;
    #endif
}
   #if defined _ALS_OnGameModeInit
    #undef OnGameModeInit
#else
    #define _ALS_OnGameModeInit
#endif
#define OnGameModeInit post_OnGameModeInit
#if defined post_OnGameModeInit
    forward post_OnGameModeInit();
#endif

public:CheckAccountPost()
{
    mysql_query(mysql, "SELECT * FROM accounts WHERE post", false);

    if(mysql_errno())
    {
        mysql_query(mysql, "ALTER TABLE `accounts` ADD `post` INT NOT NULL  AFTER `admin`", false);

        if(!mysql_errno()) print("Query insert new `post`");
        return 1;
    }
    return 0;
}
CMD:admup(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) <= 8) return 1;

	extract params -> new to_player; else return SendClientMessage(playerid, 0xCECECEFF, "Usage: /admup [player id]");

	if(!IsPlayerConnected(to_player) || !IsPlayerLogged(to_player) || to_player == playerid)
		return SendClientMessage(playerid, 0x999999FF, "Player not found");

	if(!GetPlayerAdminEx(to_player))
		return SendClientMessage(playerid, 0x999999FF, "Player is not an administrator");

	if(GetPlayerAdminEx(to_player) >= GetPlayerAdminEx(playerid))
		return SendClientMessage(playerid, 0x999999FF, "You cannot promote an administrator of higher or equal rank");

	AddPlayerData(to_player, P_ADMIN, +, 1);
	UpdatePlayerDatabaseInt(to_player, "admin", GetPlayerAdminEx(to_player));

	new fmt_text[128];

	format(fmt_text, sizeof fmt_text, "Administrator %s[%d] promoted your admin level to %d",
	GetPlayerNameEx(playerid), playerid, GetPlayerAdminEx(to_player));

	SendClientMessage(to_player, 0x3399FFFF, fmt_text);

	format(fmt_text, sizeof fmt_text, "[A] %s[%d] promoted administrator %s[%d] to level %d",
	GetPlayerNameEx(playerid), playerid, GetPlayerNameEx(to_player), to_player, GetPlayerAdminEx(to_player));

	SendMessageToAdmins(fmt_text, 0xFF5533FF);

	format(fmt_text, sizeof fmt_text, "Promoted %s[acc:%d] to admin level %d",
	GetPlayerNameEx(to_player), GetPlayerAccountID(to_player), GetPlayerAdminEx(to_player));

	SendLog(playerid, LOG_TYPE_SUPERADMIN_ACTION, fmt_text);

	return 1;
}

stock LoadAdminPost(playerid)
{
    new welsi[68], Cache:result;

    mysql_format(mysql, welsi, sizeof welsi, "SELECT * FROM accounts WHERE id='%d'", GetPlayerAccountID(playerid));
    result = mysql_query(mysql, welsi);

    if(mysql_errno())
        return print("Add column post to accounts table | Error Sql Shablon");

    new text[124], post;

    post = cache_get_field_content_int(0, "post");

    SetPlayerAdminPost(playerid, post);
    SetPlayerData(playerid, P_ADMIN, post_admin[post][Post_Level]);

    if(!post)
    {
        switch(GetPlayerAdminEx(playerid))
        {
            case 1: SetPlayerAdminPost(playerid, 1);
            case 2: SetPlayerAdminPost(playerid, 2);
            case 3: SetPlayerAdminPost(playerid, 3);
            case 4: SetPlayerAdminPost(playerid, 4);
        }
    }

    new id = GetPlayerAdminPost(playerid);
    if(GetPlayerAdminEx(playerid) >= 1)
    {
        format(text, sizeof text, "{ffffff}[A] %s %s[%d] {ffffff} authorized [IP: HIDDEN] [R-IP: HIDDEN]", post_admin[id][Post_Name], GetPlayerNameEx(playerid), playerid);
        SendMessageToAdmins(text, -1);
    }

    new color[12];

    switch(post_admin[id][Post_Division])
    {
        case Division_Junior:color = "{11FFFF}";
        case Division_Tracking:color = "{4444FF}";
        case Division_Major_Tracking:color = "{00FFFF}";
        case Division_Technical:color = "{FF5E00}";
        case Division_Media:color = "{FF0000}";
        case Division_Major:
        {
            switch(id)
            {
                case 29:color = "{5555FF}";
                case 35:color = "{00FFFF}";
                default:color = "{FFFF00}";
            }
        }
    }

    cache_delete(result);
    return 1;
}

CMD:shablon(playerid, params[])
{
    if(!(GetPlayerAdminEx(playerid) >= 9)) return 1;

    if(sscanf(params, "u", params[0]))
    return SendClientMessage(playerid, 0xFFFFFFFF, "{FFFF00}| {FFFFFF}Usage {FFFF00}/shablon {FFFFFF}[player ID]");

    if(!IsPlayerConnected(params[0]) || params[0] == playerid) return SendClientMessage(playerid, 0xFFFFFFFF, "{FFFF00}| {FFFFFF}Enter a valid player ID.");

    Dialog
    (
        playerid, 1990, DIALOG_STYLE_LIST,
        "Administration templates",
        "1. Admin rights\n"\
        "2. Supervisory admin template\n"\
        "3. Chief supervisory template\n"\
        "4. Technical specialists template\n"\
        "5. Media department template\n"\
        "6. Main administration template\n"\
        "7. Testers template\n"\
        "8. Purchased admin template",
        "Select", "Back"
    );

    SetPVarInt(playerid, "shablon_player", params[0]);
    return 1;
}

CMD:a(playerid, params[])
{
	if(GetPlayerAdminEx(playerid) >= 1)
	{
		if(!strlen(params))
			return SendClientMessage(playerid, 0xCECECEFF, "Usage: /a [text]");

		new fmt_str[128];

		format(fmt_str, sizeof fmt_str, "{00FFFF}[%s] %s[%d]: %s", post_admin[GetPlayerAdminPost(playerid)][Post_Name], GetPlayerNameEx(playerid), playerid, params);
		SendMessageToAdmins(fmt_str, 0x0aeaf2);//admin chat color (0x0aeaf2)

		SendLog(playerid, LOG_TYPE_ADMIN_CHAT, params);
	}

	return 1;
}