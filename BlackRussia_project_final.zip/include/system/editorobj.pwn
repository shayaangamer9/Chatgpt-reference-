// File: editorobj.pwn
#if defined _visual_editor_included
    #endinput
#endif
#define _visual_editor_included

#define MAX_VISUAL_OBJECTS 500

enum e_VisualObject
{
    obj_modelid,
    Float:obj_x,
    Float:obj_y,
    Float:obj_z,
    Float:obj_rx,
    Float:obj_ry,
    Float:obj_rz,
    obj_world,
    obj_interior,
    obj_streamid
}

static VisualObjects[MAX_VISUAL_OBJECTS][e_VisualObject];
static bool:obj_used[MAX_VISUAL_OBJECTS];
static PlayerTempObject[MAX_PLAYERS] = {-1, ...};
static PlayerSelectedObject[MAX_PLAYERS] = {-1, ...};
static PlayerTempEditObject[MAX_PLAYERS] = {INVALID_OBJECT_ID, ...};

// Create object
stock CreateVisualObject(playerid, modelid, Float:x, Float:y, Float:z,
                         Float:rx = 0.0, Float:ry = 0.0, Float:rz = 0.0,
                         world = -1, interior = -1)
{
    new freeid = -1;

    for(new i = 0; i < MAX_VISUAL_OBJECTS; i++)
    {
        if(!obj_used[i])
        {
            freeid = i;
            break;
        }
    }

    if(freeid == -1) return -1;

    VisualObjects[freeid][obj_modelid] = modelid;
    VisualObjects[freeid][obj_x] = x;
    VisualObjects[freeid][obj_y] = y;
    VisualObjects[freeid][obj_z] = z;
    VisualObjects[freeid][obj_rx] = rx;
    VisualObjects[freeid][obj_ry] = ry;
    VisualObjects[freeid][obj_rz] = rz;
    VisualObjects[freeid][obj_world] = world;
    VisualObjects[freeid][obj_interior] = interior;

    VisualObjects[freeid][obj_streamid] = CreateDynamicObject(modelid, x, y, z, rx, ry, rz, world, interior, playerid, 300.0);
    obj_used[freeid] = true;

    return freeid;
}

// Delete object
stock DeleteVisualObject(objectid)
{
    if(objectid < 0 || objectid >= MAX_VISUAL_OBJECTS || !obj_used[objectid]) return 0;

    DestroyDynamicObject(VisualObjects[objectid][obj_streamid]);
    obj_used[objectid] = false;

    return 1;
}

// Edit position
stock EditVisualObjectPosition(playerid, objectid)
{
    if(objectid < 0 || objectid >= MAX_VISUAL_OBJECTS || !obj_used[objectid]) return 0;

    PlayerTempObject[playerid] = objectid;

    new Float:x, Float:y, Float:z;
    GetDynamicObjectPos(VisualObjects[objectid][obj_streamid], x, y, z);

    // Create temporary object for editing
    new tmpobj = CreateObject(VisualObjects[objectid][obj_modelid], x, y, z, 0.0, 0.0, 0.0);
    PlayerTempEditObject[playerid] = tmpobj;
    EditObject(playerid, tmpobj);

    return 1;
}

// Edit rotation
stock EditVisualObjectRotation(playerid, objectid)
{
    if(objectid < 0 || objectid >= MAX_VISUAL_OBJECTS || !obj_used[objectid]) return 0;

    PlayerTempObject[playerid] = objectid;

    new Float:x, Float:y, Float:z;
    GetDynamicObjectPos(VisualObjects[objectid][obj_streamid], x, y, z);

    // Create temporary object for editing with current rotation
    new tmpobj = CreateObject(VisualObjects[objectid][obj_modelid], x, y, z,
                              VisualObjects[objectid][obj_rx],
                              VisualObjects[objectid][obj_ry],
                              VisualObjects[objectid][obj_rz]);
    PlayerTempEditObject[playerid] = tmpobj;
    EditObject(playerid, tmpobj);

    return 1;
}

// Dialog to select object for editing
stock ShowEditObjectDialog(playerid)
{
    new dialog[1024], objlist[500], count;

    for(new i = 0; i < MAX_VISUAL_OBJECTS; i++)
    {
        if(obj_used[i])
        {
            format(objlist, sizeof(objlist), "%d - Model: %d (Pos: %.1f, %.1f, %.1f)\n",
                   i, VisualObjects[i][obj_modelid],
                   VisualObjects[i][obj_x], VisualObjects[i][obj_y], VisualObjects[i][obj_z]);
            strcat(dialog, objlist);
            count++;
        }
    }

    if(count == 0)
    {
        SendClientMessage(playerid, 0xFF0000FF, "[ERROR] No objects to edit!");
        return 0;
    }

    ShowPlayerDialog(playerid, 5001, DIALOG_STYLE_LIST, "Select object to edit", dialog, "Select", "Cancel");
    return 1;
}

// Commands
CMD:createobj(playerid, params[])
{
    new modelid, Float:x, Float:y, Float:z;

    if(sscanf(params, "dfff", modelid, x, y, z))
    {
        SendClientMessage(playerid, 0xFFFF00AA, "Usage: /createobj [modelid] [x] [y] [z]");
        return 1;
    }

    new objid = CreateVisualObject(playerid, modelid, x, y, z);

    if(objid != -1)
    {
        new msg[128];
        format(msg, sizeof(msg), "[INFO] Object ID %d created! Model: %d", objid, modelid);
        SendClientMessage(playerid, 0x00FF00AA, msg);
    }
    else
    {
        SendClientMessage(playerid, 0xFF0000AA, "[ERROR] Failed to create object (limit)");
    }

    return 1;
}

CMD:editobj(playerid, params[])
{
    new objectid;

    if(sscanf(params, "d", objectid))
    {
        ShowEditObjectDialog(playerid);
        return 1;
    }

    if(objectid < 0 || objectid >= MAX_VISUAL_OBJECTS || !obj_used[objectid])
    {
        SendClientMessage(playerid, 0xFF0000AA, "[ERROR] Invalid object ID!");
        return 1;
    }

    PlayerSelectedObject[playerid] = objectid;
    ShowPlayerDialog(playerid, 5002, DIALOG_STYLE_MSGBOX, "Editing object",
                     "What do you want to edit?", "Position", "Rotation");

    return 1;
}

CMD:delobj(playerid, params[])
{
    new objectid;

    if(sscanf(params, "d", objectid))
    {
        SendClientMessage(playerid, 0xFFFF00AA, "Usage: /delobj [objectid]");
        return 1;
    }

    if(objectid < 0 || objectid >= MAX_VISUAL_OBJECTS || !obj_used[objectid])
    {
        SendClientMessage(playerid, 0xFF0000AA, "[ERROR] Invalid object ID!");
        return 1;
    }

    DeleteVisualObject(objectid);

    new msg[128];
    format(msg, sizeof(msg), "[INFO] Object ID %d deleted", objectid);
    SendClientMessage(playerid, 0x00FF00AA, msg);

    return 1;
}

CMD:objlist(playerid, params[])
{
    new msg[256], count;

    SendClientMessage(playerid, 0x00FFFFAA, "=== Object list ===");

    for(new i = 0; i < MAX_VISUAL_OBJECTS; i++)
    {
        if(obj_used[i])
        {
            format(msg, sizeof(msg), "ID: %d | Model: %d | Pos: %.1f, %.1f, %.1f",
                   i, VisualObjects[i][obj_modelid],
                   VisualObjects[i][obj_x], VisualObjects[i][obj_y], VisualObjects[i][obj_z]);
            SendClientMessage(playerid, 0xFFFFFFFF, msg);
            count++;
        }
    }

    format(msg, sizeof(msg), "Total objects: %d", count);
    SendClientMessage(playerid, 0x00FFFFAA, msg);

    return 1;
}

// Dialog handling
public OnDialogResponse(playerid, dialogid, response, listitem, inputtext[])
{
    switch(dialogid)
    {
        case 5001: // Select object
        {
            if(response)
            {
                new objectid, count;

                for(new i = 0; i < MAX_VISUAL_OBJECTS; i++)
                {
                    if(obj_used[i])
                    {
                        if(count == listitem)
                        {
                            objectid = i;
                            break;
                        }
                        count++;
                    }
                }

                PlayerSelectedObject[playerid] = objectid;
                ShowPlayerDialog(playerid, 5002, DIALOG_STYLE_MSGBOX, "Editing object",
                                 "What do you want to edit?", "Position", "Rotation");
            }
            return 1;
        }

        case 5002: // Select edit type
        {
            if(response)
            {
                new objectid = PlayerSelectedObject[playerid];

                if(listitem == 0)
                {
                    EditVisualObjectPosition(playerid, objectid);
                    SendClientMessage(playerid, 0xFFFF00AA, "[INFO] Edit position. Press ESC to save.");
                }
                else
                {
                    EditVisualObjectRotation(playerid, objectid);
                    SendClientMessage(playerid, 0xFFFF00AA, "[INFO] Edit rotation. Press ESC to save.");
                }
            }
            return 1;
        }
    }

    #if defined vis_OnDialogResponse
        return vis_OnDialogResponse(playerid, dialogid, response, listitem, inputtext);
    #else
        return 0;
    #endif
}

// Fixed edit finish handler
public OnPlayerEditObject(playerid, playerobject, objectid, response, Float:x, Float:y, Float:z, Float:rx, Float:ry, Float:rz)
{
    new visualid = PlayerTempObject[playerid];

    if(visualid != -1 && obj_used[visualid])
    {
        if(response == EDIT_RESPONSE_FINAL)
        {
            // Save changes
            DestroyDynamicObject(VisualObjects[visualid][obj_streamid]);

            VisualObjects[visualid][obj_x] = x;
            VisualObjects[visualid][obj_y] = y;
            VisualObjects[visualid][obj_z] = z;
            VisualObjects[visualid][obj_rx] = rx;
            VisualObjects[visualid][obj_ry] = ry;
            VisualObjects[visualid][obj_rz] = rz;

            VisualObjects[visualid][obj_streamid] = CreateDynamicObject(
                VisualObjects[visualid][obj_modelid], x, y, z, rx, ry, rz,
                VisualObjects[visualid][obj_world],
                VisualObjects[visualid][obj_interior],
                playerid, 300.0);

            SendClientMessage(playerid, 0x00FF00AA, "[INFO] Object saved!");
        }
        else if(response == EDIT_RESPONSE_CANCEL)
        {
            SendClientMessage(playerid, 0xFF0000AA, "[INFO] Editing canceled");
        }

        // Delete temporary object
        if(PlayerTempEditObject[playerid] != INVALID_OBJECT_ID)
        {
            DestroyObject(PlayerTempEditObject[playerid]);
            PlayerTempEditObject[playerid] = INVALID_OBJECT_ID;
        }

        PlayerTempObject[playerid] = -1;
    }

    #if defined vis_OnPlayerEditObject
        return vis_OnPlayerEditObject(playerid, playerobject, objectid, response, x, y, z, rx, ry, rz);
    #else
        return 1;
    #endif
}

// Hooks for compatibility
#if defined _ALS_OnDialogResponse
    #undef OnDialogResponse
#else
    #define _ALS_OnDialogResponse
#endif
#define OnDialogResponse vis_OnDialogResponse

#if defined _ALS_OnPlayerEditObject
    #undef OnPlayerEditObject
#else
    #define _ALS_OnPlayerEditObject
#endif
#define OnPlayerEditObject vis_OnPlayerEditObject

#if defined vis_OnDialogResponse
    forward vis_OnDialogResponse(playerid, dialogid, response, listitem, inputtext[]);
#endif
#if defined vis_OnPlayerEditObject
    forward vis_OnPlayerEditObject(playerid, playerobject, objectid, response, Float:x, Float:y, Float:z, Float:rx, Float:ry, Float:rz);
#endif