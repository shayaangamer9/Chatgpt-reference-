// File: new_promo.pwn
// Maximum promo code length
#define MAX_PROMO_CODE_LENGTH 32
// Maximum number of promo codes loaded into memory
#define MAX_PROMO_CODES_ARRAY_SIZE 100
// Maximum number of simultaneously active temporary prizes for one player
#define MAX_CONCURRENT_PLAYER_PROMO_PRIZES 5

// YOU CAN CHANGE SETTINGS FOR EACH PROMO LEVEL HERE

new PROMO_LEVEL_DATA[11][5] = {
// {promo level, number of activations to reach this level, number of prizes, donate amount to upgrade, money owner gets per activation}
    {0, 0, 0, 0, 0},
    {1, 20, 1, 0, 10000},
    {2, 20, 2, 250, 15000},
    {3, 100, 3, 500, 20000},
    {4, 500, 3, 1000, 25000},
    {5, 1000, 3, 1500, 30000},
    {6, 1500, 3, 2000, 37000},
    {7, 2000, 4, 2500, 43000},
    {8, 2700, 4, 3200, 50000},
    {9, 4000, 5, 5500, 65000},
    {10, 5000, 5, 50000, 100000}
};

// {prize type (0-money, 1-donate, 2-car, 3-EXP), prize amount or car id, duration in hours, 0 means permanent}
new PromoLevelPrizes_1[1][3] = {
    {0, 15000, 0}
};

new PromoLevelPrizes_2[2][3] = {
    {3, 3, 0},
    {0, 30000, 0}
};

new PromoLevelPrizes_3[3][3] = {
    {3, 5, 0},
    {0, 30000, 0},
    {2, 489, 3}
};

new PromoLevelPrizes_4[3][3] = {
    {3, 5, 0},
    {0, 45000, 0},
    {2, 466, 6}
};

new PromoLevelPrizes_5[3][3] = {
    {3, 7, 0},
    {0, 50000, 0},
    {2, 494, 6}
};

new PromoLevelPrizes_6[3][3] = {
    {3, 10, 0},
    {0, 55000, 0},
    {2, 451, 8}
};

new PromoLevelPrizes_7[4][3] = {
    {3, 10, 0},
    {0, 55000, 0},
    {2, 451, 10},
    {2, 503, 8}
};

new PromoLevelPrizes_8[4][3] = {
    {3, 12, 0},
    {0, 62000, 0},
    {2, 541, 12},
    {2, 502, 8}
};

new PromoLevelPrizes_9[5][3] = {
    {3, 14, 0},
    {0, 65000, 0},
    {2, 505, 16},
    {2, 402, 10},
    {2, 400, 6}
};

new PromoLevelPrizes_10[5][3] = {
    {3, 20, 0},
    {0, 75000, 0},
    {2, 415, 24},
    {2, 579, 14},
    {2, 505, 10}
};

new PlayerDialogPromoData[MAX_PLAYERS];

#define DIALOG_PROMO_PRIZE_INFO         12345 // For displaying activation result
#define DIALOG_ADDPROMO_CODE            12346 // Enter promo code name
#define DIALOG_ADDPROMO_USES_LIMIT      12347 // Enter promo code usage limit (total)
#define DIALOG_ADDPROMO_PRIZE_COUNT     12348 // Enter number of prizes (1-5)
#define DIALOG_ADDPROMO_SINGLE_PRIZE_TYPE 12349 // Select individual prize type (money, donate, car)
#define DIALOG_ADDPROMO_SINGLE_PRIZE_VALUE 12350 // Enter individual prize value (amount/model)
#define DIALOG_ADDPROMO_SINGLE_PRIZE_DURATION 12351 // Select individual prize duration (temporary/permanent)
#define DIALOG_ADDPROMO_SINGLE_PRIZE_DURATION_HOURS 12352 // Enter hours for temporary prize
#define DIALOG_APPLY_PROMO_CODE         12353 // Enter promo code to activate
#define DIALOG_CONFIRM_PROMO_CREATION   12354 // Confirm promo code creation
#define DIALOG_ACT_PROMO                12355 // Main promo code dialog
#define DIALOG_ADDPROMO_CODE_BY_PLAYER  12356 // Dialog for player to create promo code
// #define DIALOG_ADDPROMO_PRIZE_MONEY_BY_PLAYER 12357 // OLD SYSTEM for entering money prize amount when creating promo code by player
#define DIALOG_ACT_PROMO_PRIZES         12358 // Dialog to display active prizes of player
#define DIALOG_PROMO_INFO               12359 // Dialog with info about promo codes
#define DIALOG_PROMO_MANAGEMENT         12360 // Dialog to manage own promo code
// #define DIALOG_PROMO_PRIZE_SETTINGS  12361 // ALSO OLD for prize settings
#define DIALOG_PROMO_UPGRADE_LEVELS     12362 // Dialog for selecting level to upgrade
#define DIALOG_PROMO_UPGRADE_CONFIRM    12363 // Dialog for confirming upgrade
#define DIALOG_PROMO_STATS              12364 // Dialog for info about balance and etc.

enum E_PRIZE_TYPE
{
    PRIZE_TYPE_MONEY,
    PRIZE_TYPE_DONATE,
    PRIZE_TYPE_CAR,
    PRIZE_TYPE_EXP
}

enum E_PROMO_DATA
{
    PromoID,            // Promo code ID in DB (promocodes.id)
    String:PromoCode[MAX_PROMO_CODE_LENGTH], // The promo code itself
    PromoUses,          // How many times the promo code can be used (total limit)
    UsesLeft,           // Remaining uses (total limit)
    NumPrizes,          // Number of prizes in this promo code
    _E_PROMO_DATA_SIZE
}
#define PROMO_DATA_SIZE _E_PROMO_DATA_SIZE

new PromoCodes[MAX_PROMO_CODES_ARRAY_SIZE][E_PROMO_DATA];
new g_iLoadedPromoCodes = 0;

enum E_NEW_PROMO_CREATION_DATA
{
    String:NewPromoCodeString[MAX_PROMO_CODE_LENGTH],
    NewPromoPrizeCount,        // Selected number of prizes for the current promo code being created
    NewPromoCurrentPrizeIndex, // Index of the currently configured prize (0 to 4)
    NewPromoUsesLimit,         // Usage limit for the main promo code
}
new PlayerPromoCreationData[MAX_PLAYERS][E_NEW_PROMO_CREATION_DATA];

enum E_TEMP_PRIZE_DATA
{
    TempPrizeType,     // Prize type (PRIZE_TYPE_MONEY, etc.)
    TempPrizeValue,    // Prize value (amount of money/donate, vehicle model ID)
    TempPrizeDuration, // Duration in hours (0 for permanent)
}
new PlayerTempPrizes[MAX_PLAYERS][5][E_TEMP_PRIZE_DATA];

enum E_PLAYER_PROMO_TIMER_DATA
{
    pPromoTimerID,      // SA:MP timer ID
    pPlayerPromoSQLID,  // ID of the record from player_promos (primary key)
}
new PlayerPromoTimers[MAX_PLAYERS][MAX_CONCURRENT_PLAYER_PROMO_PRIZES][E_PLAYER_PROMO_TIMER_DATA];
new g_iPlayerPromoTimersCount[MAX_PLAYERS];

// Function prototypes, verton didn't bother (I might have missed some, but this is for my convenience)
forward CheckAndCreatePromoTables();
forward LoadPromoCodesFromDatabase();
forward CheckUsePromoCode(playerid, accountId, promoSqlId);
forward OnPromoCodeCheckComplete(playerid, const promoCode[]);
forward HasPlayerCreatedPromo(playerid); // Function to check if player has a promo code
stock GetPlayerIDFromAccountID(accountId);
stock ShowPromoCreationConfirmation(playerid);
stock CreatePromoCodeInDatabase(playerid);
forward OnPromoTimerTick(playerPromoSQLID); // Changed: now takes player_promos.id
stock SetPlayerPromoTimer(playerid, playerPromoSQLID, durationHours); // Changed: now works with player_promos.id
stock StopPlayerPromoTimer(playerid); // Changed: stops all timers for player
stock RevokePromoPrize(accountId, prizeType, prizeValue, promoIdForCarRevoke); // Changed: for revoking ONE prize
stock GetPromoCodeDataByID(promoId, promoData[E_PROMO_DATA]);
stock GetPromoCodeDataByString(const promoCode[], promoData[E_PROMO_DATA]);
stock GetPromoCodeIndexByString(const promoCode[]);
stock GivePromoCar(playerid, modelid, promoSqlId);

stock SavePromoLevelPrizes(playerid, promoId, level); // this updates promo level prizes
stock GetPromoLevel(playerid, promoSQL_id); // gets promo level by id
stock GetPromoLevelForOwner(playerid); // gets promo level by player id

forward AddPlayerActivatedPromo(account_id, promo_id); // records which promo code was activated by whom (additional solution by verton)

public OnGameModeInit()
{
    print("[WERTON_SYSTEM] Promo code system loaded.");
    SetTimer("CheckAndCreatePromoTables", 1500, false);
    SetTimer("LoadPromoCodesFromDatabase", 3000, false);
    #if defined prom_OnGameModeInit
        return prom_OnGameModeInit();
    #else
        return 1;
    #endif
}
#if defined _ALS_OnGameModeInit
    #undef OnGameModeInit
#else
    #define _ALS_OnGameModeInit
#endif
#define OnGameModeInit prom_OnGameModeInit
#if defined prom_OnGameModeInit
    forward prom_OnGameModeInit();
#endif

public OnPromoTimerTick(playerPromoSQLID)
{
    new query[256];
    new Cache:result;
    new accountId, prizeType, prizeValue, promoIdForCarRevoke = 0;
    new playerid = INVALID_PLAYER_ID;

    mysql_format(mysql, query, sizeof(query), "SELECT pp.account_id, pp.start_time, pp.remaining_time, ppz.prize_type, ppz.prize_value, ppz.prize_duration, ppz.promo_id FROM player_promos pp JOIN promo_prizes ppz ON pp.promo_prize_sql_id = ppz.id WHERE pp.id = %d", playerPromoSQLID);
    result = mysql_query(mysql, query, true);

    if(mysql_errno() != 0 || cache_num_rows(result) == 0)
    {
        printf("[WERTON_PROMO] Error: Could not find player_promos data (SQL ID: %d) for timer. errno: %d", playerPromoSQLID, mysql_errno());

        for(new p = 0; p < MAX_PLAYERS; p++)
        {
            if(!IsPlayerConnected(p)) continue;
            for(new i = 0; i < g_iPlayerPromoTimersCount[p]; i++)
            {
                if(PlayerPromoTimers[p][i][pPlayerPromoSQLID] == playerPromoSQLID)
                {
                    KillTimer(PlayerPromoTimers[p][i][pPromoTimerID]);
                    for(new j = i; j < g_iPlayerPromoTimersCount[p] - 1; j++)
                    {
                        PlayerPromoTimers[p][j][pPromoTimerID] = PlayerPromoTimers[p][j+1][pPromoTimerID];
                        PlayerPromoTimers[p][j][pPlayerPromoSQLID] = PlayerPromoTimers[p][j+1][pPlayerPromoSQLID];
                    }
                    g_iPlayerPromoTimersCount[p]--;
                    break;
                }
            }
        }
        cache_delete(result);
        return 0;
    }

    accountId = cache_get_field_content_int(0, "account_id");
    new startTime = cache_get_field_content_int(0, "start_time");
    prizeType = cache_get_field_content_int(0, "prize_type");
    prizeValue = cache_get_field_content_int(0, "prize_value");
    new prizeDurationHours = cache_get_field_content_int(0, "prize_duration");
    promoIdForCarRevoke = cache_get_field_content_int(0, "promo_id");

    new remainingTime = prizeDurationHours * 3600 - (gettime() - startTime);

    if(remainingTime <= 0)
    {
        playerid = GetPlayerIDFromAccountID(accountId);
        if(playerid != INVALID_PLAYER_ID)
        {
            RevokePromoPrize(accountId, prizeType, prizeValue, promoIdForCarRevoke);
            SendClientMessage(playerid, -1, "{ff2400}| {ffffff}The temporary prize has expired!");
        }

        mysql_format(mysql, query, sizeof(query), "DELETE FROM player_promos WHERE id = %d", playerPromoSQLID);
        mysql_query(mysql, query, false);

        for(new p = 0; p < MAX_PLAYERS; p++)
        {
            if(!IsPlayerConnected(p)) continue;
            for(new i = 0; i < g_iPlayerPromoTimersCount[p]; i++)
            {
                if(PlayerPromoTimers[p][i][pPlayerPromoSQLID] == playerPromoSQLID)
                {
                    KillTimer(PlayerPromoTimers[p][i][pPromoTimerID]);
                    for(new j = i; j < g_iPlayerPromoTimersCount[p] - 1; j++)
                    {
                        PlayerPromoTimers[p][j][pPromoTimerID] = PlayerPromoTimers[p][j+1][pPromoTimerID];
                        PlayerPromoTimers[p][j][pPlayerPromoSQLID] = PlayerPromoTimers[p][j+1][pPlayerPromoSQLID];
                    }
                    g_iPlayerPromoTimersCount[p]--;
                    break;
                }
            }
        }
    }
    else
    {
        mysql_format(mysql, query, sizeof(query),
            "UPDATE player_promos SET remaining_time = %d WHERE id = %d",
            remainingTime, playerPromoSQLID);
        mysql_query(mysql, query, false);
    }
    cache_delete(result);
    return 1;
}

public CheckAndCreatePromoTables()
{
    new Cache:cache;
    new query[512];

    mysql_format(mysql, query, sizeof(query), "SELECT * FROM promocodes LIMIT 1");
    cache = mysql_query(mysql, query, true);
    if(mysql_errno() != 0)
    {
        printf("[WERTON_PROMO] Table 'promocodes' not found. Creating new structure...");
        mysql_format(mysql, query, sizeof(query), "CREATE TABLE `promocodes` (`id` INT NOT NULL AUTO_INCREMENT,`code` VARCHAR(%d) NOT NULL UNIQUE,`uses_limit` INT NOT NULL DEFAULT 1,`uses_left` INT NOT NULL DEFAULT 1,`num_prizes` TINYINT(1) NOT NULL DEFAULT 1,`activations` INT NOT NULL DEFAULT 0, `promo_level` INT NOT NULL DEFAULT -1, `promo_balance` INT NOT NULL DEFAULT 0,`creator_account_id` INT NOT NULL DEFAULT 0,`creation_cost` INT NOT NULL DEFAULT 0,`created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`)) ENGINE = InnoDB", MAX_PROMO_CODE_LENGTH);
        mysql_query(mysql, query, false);
        if(mysql_errno() != 0)
        {
            printf("[WERTON_PROMO] Error creating table 'promocodes': %d", mysql_errno());
        }
        else
        {
            printf("[WERTON_PROMO] Table 'promocodes' successfully created with new structure.");
        }
    }
    cache_delete(cache);

    mysql_format(mysql, query, sizeof(query), "SELECT * FROM `activated_promos` LIMIT 1");
    cache = mysql_query(mysql, query, true);

    if(mysql_errno() != 0)
    {
        printf("[WERTON_PROMO] Table 'activated_promos' not found. Creating new structure...");
        mysql_format(mysql, query, sizeof(query), "CREATE TABLE IF NOT EXISTS `activated_promos` (`id` INT(11) NOT NULL AUTO_INCREMENT, `account_id` INT(11) NOT NULL, `promo_id` INT(11) NOT NULL, `activated_at` DATETIME NOT NULL, PRIMARY KEY (`id`), UNIQUE KEY `account_promo` (`account_id`, `promo_id`)) ENGINE=InnoDB;");
        mysql_query(mysql, query, false);

        if(mysql_errno() != 0)
        {
            printf("[WERTON_PROMO] Error creating table 'activated_promos': %d", mysql_errno());
        }
        else
        {
            printf("[WERTON_PROMO] Table 'activated_promos' successfully created.");
        }
    }
    cache_delete(cache);

    mysql_format(mysql, query, sizeof(query), "SELECT * FROM promo_prizes LIMIT 1");
    cache = mysql_query(mysql, query, true);
    if(mysql_errno() != 0)
    {
        printf("[WERTON_PROMO] Table 'promo_prizes' not found. Creating...");
        mysql_format(mysql, query, sizeof(query), "CREATE TABLE `promo_prizes` (`id` INT NOT NULL AUTO_INCREMENT,`promo_id` INT NOT NULL,`prize_index` TINYINT(1) NOT NULL,`prize_type` TINYINT(1) NOT NULL DEFAULT '0',`prize_value` INT NOT NULL DEFAULT '0',`prize_duration` INT NOT NULL DEFAULT '0', PRIMARY KEY (`id`), UNIQUE KEY `promo_prize_unique` (`promo_id`, `prize_index`), FOREIGN KEY (`promo_id`) REFERENCES `promocodes`(`id`) ON DELETE CASCADE) ENGINE = InnoDB");
        mysql_query(mysql, query, false);
        if(mysql_errno() != 0)
        {
            printf("[WERTON_PROMO] Error creating table 'promo_prizes': %d", mysql_errno());
        }
        else
        {
            printf("[WERTON_PROMO] Table 'promo_prizes' successfully created.");
        }
    }
    cache_delete(cache);

    mysql_format(mysql, query, sizeof(query), "SELECT * FROM player_promos LIMIT 1");
    cache = mysql_query(mysql, query, true);

    if(mysql_errno() != 0 || cache_num_fields(cache) != 5)
    {
        printf("[WERTON_PROMO] Table 'player_promos' not found or has old structure. Creating new...");

        if(mysql_errno() == 0) {
            mysql_query(mysql, "DROP TABLE IF EXISTS `player_promos`", false);
            printf("[WERTON_PROMO] Old table 'player_promos' dropped.");
        }
        mysql_format(mysql, query, sizeof(query), "CREATE TABLE `player_promos` (`id` INT NOT NULL AUTO_INCREMENT,`account_id` INT NOT NULL,`promo_prize_sql_id` INT NOT NULL, `start_time` INT NOT NULL, `remaining_time` INT NOT NULL, PRIMARY KEY (`id`), UNIQUE KEY `account_promo_prize_unique` (`account_id`, `promo_prize_sql_id`), FOREIGN KEY (`promo_prize_sql_id`) REFERENCES `promo_prizes`(`id`) ON DELETE CASCADE) ENGINE = InnoDB");
        mysql_query(mysql, query, false);
        if(mysql_errno() != 0)
        {
            printf("[WERTON_PROMO] Error creating table 'player_promos': %d", mysql_errno());
        }
        else
        {
            printf("[WERTON_PROMO] Table 'player_promos' successfully created with new structure.");
        }
    }
    cache_delete(cache);

    mysql_format(mysql, query, sizeof(query), "SHOW COLUMNS FROM `ownable_cars` LIKE 'promo_id'");
    cache = mysql_query(mysql, query, true);
    if(cache_num_rows() == 0)
    {
        printf("[WERTON_PROMO] Column 'promo_id' in 'ownable_cars' not found. Adding...");
        mysql_format(mysql, query, sizeof(query), "ALTER TABLE `ownable_cars` ADD `promo_id` INT NOT NULL DEFAULT '0' AFTER `create_time`");
        mysql_query(mysql, query, false);
        if(mysql_errno() != 0)
        {
            printf("[WERTON_PROMO] Error adding column 'promo_id': %d", mysql_errno());
        }
        else
        {
            printf("[WERTON_PROMO] Column 'promo_id' successfully added.");
        }
    }
    cache_delete(cache);

    mysql_format(mysql, query, sizeof(query), "SHOW COLUMNS FROM `ownable_cars` LIKE 'promo_status_car'");
    cache = mysql_query(mysql, query, true);
    if(cache_num_rows() == 0)
    {
        printf("[WERTON_PROMO] Column 'promo_status_car' in 'ownable_cars' not found. Adding...");
        mysql_format(mysql, query, sizeof(query), "ALTER TABLE `ownable_cars` ADD `promo_status_car` TINYINT(1) NOT NULL DEFAULT '0' AFTER `promo_id`");
        mysql_query(mysql, query, false);
        if(mysql_errno() != 0)
        {
            printf("[WERTON_PROMO] Error adding column 'promo_status_car': %d", mysql_errno());
        }
        else
        {
            printf("[WERTON_PROMO] Column 'promo_status_car' successfully added.");
        }
    }
    cache_delete(cache);
}

public LoadPromoCodesFromDatabase()
{
    printf("[DEBUG] --- START LoadPromoCodesFromDatabase ---");
    new Cache:result;
    new query[128];

    mysql_format(mysql, query, sizeof(query), "SELECT id, code, uses_limit, uses_left, num_prizes FROM promocodes");
    printf("[DEBUG] Executing SQL query: %s", query);

    result = mysql_query(mysql, query, true);
    printf("[DEBUG] SQL query executed. errno: %d", mysql_errno());

    if(mysql_errno() != 0) {
        printf("[DEBUG] MySQL ERROR while loading promo codes: %d", mysql_errno());
        cache_delete(result);
        return 0;
    }

    g_iLoadedPromoCodes = cache_num_rows(result);
    printf("[DEBUG] Number of rows in result (cache_num_rows): %d", g_iLoadedPromoCodes);

    if(g_iLoadedPromoCodes > MAX_PROMO_CODES_ARRAY_SIZE)
    {
        printf("[WERTON_PROMO] WARNING: Number of promo codes (%d) exceeds array size (%d). Loaded only %d.", g_iLoadedPromoCodes, MAX_PROMO_CODES_ARRAY_SIZE, MAX_PROMO_CODES_ARRAY_SIZE);
        g_iLoadedPromoCodes = MAX_PROMO_CODES_ARRAY_SIZE;
    }
    else if(g_iLoadedPromoCodes == 0) {
        printf("[WERTON_PROMO] No promo codes in database to load.");
    }

    for(new i = 0; i < g_iLoadedPromoCodes; i++)
    {
        PromoCodes[i][PromoID] = cache_get_field_content_int(i, "id");
        cache_get_field_content(i, "code", PromoCodes[i][PromoCode], MAX_PROMO_CODE_LENGTH);
        PromoCodes[i][PromoUses] = cache_get_field_content_int(i, "uses_limit");
        PromoCodes[i][UsesLeft] = cache_get_field_content_int(i, "uses_left");
        PromoCodes[i][NumPrizes] = cache_get_field_content_int(i, "num_prizes");
    }
    cache_delete(result);
    printf("[WERTON_PROMO] All promo codes successfully loaded. Loaded: %d", g_iLoadedPromoCodes);
    printf("[DEBUG] --- END LoadPromoCodesFromDatabase ---");
    return 1;
}

public OnPlayerConnect(playerid)
{
    g_iPlayerPromoTimersCount[playerid] = 0;
    for(new i = 0; i < MAX_CONCURRENT_PLAYER_PROMO_PRIZES; i++)
    {
        PlayerPromoTimers[playerid][i][pPromoTimerID] = 0;
        PlayerPromoTimers[playerid][i][pPlayerPromoSQLID] = 0;
    }
    OnPlayerLogin(playerid);
    #if defined prom_OnPlayerConnect
        return prom_OnPlayerConnect(playerid);
    #else
        return 1;
    #endif
}
#if defined _ALS_OnPlayerConnect
    #undef OnPlayerConnect
#else
    #define _ALS_OnPlayerConnect
#endif
#define OnPlayerConnect prom_OnPlayerConnect
#if defined prom_OnPlayerConnect
    forward prom_OnPlayerConnect(playerid);
#endif

public OnPlayerLogin(playerid)
{
    new accountId = GetPlayerAccountID(playerid);
    new Cache:result;
    new query[256];

    mysql_format(mysql, query, sizeof(query), "SELECT pp.id, pp.start_time, pp.remaining_time, ppz.prize_duration, ppz.prize_type, ppz.prize_value, ppz.promo_id FROM player_promos pp JOIN promo_prizes ppz ON pp.promo_prize_sql_id = ppz.id WHERE pp.account_id = %d AND ppz.prize_duration > 0", accountId);
    result = mysql_query(mysql, query, true);

    new rows = cache_num_rows();
    if(rows > 0)
    {
        for(new i = 0; i < rows; i++)
        {
            new playerPromoSQLID = cache_get_field_content_int(i, "id");
            new startTime = cache_get_field_content_int(i, "start_time");
            new remainingTimeFromDB = cache_get_field_content_int(i, "remaining_time");
            new prizeDurationHours = cache_get_field_content_int(i, "prize_duration");
            new prizeType = cache_get_field_content_int(i, "prize_type");
            new prizeValue = cache_get_field_content_int(i, "prize_value");
            new promoIdForCarRevoke = cache_get_field_content_int(i, "promo_id");

            new actualRemainingTime = prizeDurationHours * 3600 - (gettime() - startTime);

            if(actualRemainingTime > 0)
            {
                mysql_format(mysql, query, sizeof(query), "UPDATE player_promos SET remaining_time = %d WHERE id = %d", actualRemainingTime, playerPromoSQLID);
                mysql_query(mysql, query, false);

                SetPlayerPromoTimer(playerid, playerPromoSQLID, prizeDurationHours);
            }
            else
            {
                RevokePromoPrize(accountId, prizeType, prizeValue, promoIdForCarRevoke);

                mysql_format(mysql, query, sizeof(query), "DELETE FROM player_promos WHERE id = %d", playerPromoSQLID);
                mysql_query(mysql, query, false);
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}The temporary prize has expired!");
            }
        }
    }
    cache_delete(result);
    return 1;
}

public OnPlayerDisconnect(playerid, reason)
{
    StopPlayerPromoTimer(playerid);
    #if defined prom_OnPlayerDisconnect
        return prom_OnPlayerDisconnect(playerid, reason);
    #else
        return 1;
    #endif
}
#if defined _ALS_OnPlayerDisconnect
    #undef OnPlayerDisconnect
#else
    #define _ALS_OnPlayerDisconnect
#endif
#define OnPlayerDisconnect prom_OnPlayerDisconnect
#if defined prom_OnPlayerDisconnect
    forward prom_OnPlayerDisconnect(playerid, reason);
#endif

stock GetPlayerIDFromAccountID(accountId)
{
    for(new i = 0; i < MAX_PLAYERS; i++)
    {
        if(IsPlayerConnected(i) && GetPlayerAccountID(i) == accountId)
        {
            return i;
        }
    }
    return INVALID_PLAYER_ID;
}

stock SetPlayerPromoTimer(playerid, playerPromoSQLID, durationHours)
{
    if(g_iPlayerPromoTimersCount[playerid] >= MAX_CONCURRENT_PLAYER_PROMO_PRIZES)
    {
        printf("[WERTON_PROMO] Player %s (ID: %d) reached limit of active temporary prizes (%d). Timer for prize %d not set.",
            GetPlayerNameEx(playerid), GetPlayerAccountID(playerid), MAX_CONCURRENT_PLAYER_PROMO_PRIZES, playerPromoSQLID);
        return 0;
    }

    new index = g_iPlayerPromoTimersCount[playerid];
    PlayerPromoTimers[playerid][index][pPlayerPromoSQLID] = playerPromoSQLID;
    PlayerPromoTimers[playerid][index][pPromoTimerID] = SetTimerEx("OnPromoTimerTick", 60000, true, "i", playerPromoSQLID);
    g_iPlayerPromoTimersCount[playerid]++;

    printf("[WERTON_PROMO] Player %s (ID: %d) timer set for prize from player_promos.id: %d for %d hours.",
        GetPlayerNameEx(playerid), GetPlayerAccountID(playerid), playerPromoSQLID, durationHours);
    return 1;
}

stock StopPlayerPromoTimer(playerid)
{
    new query[256];
    new Cache:result;
    new accountId = GetPlayerAccountID(playerid);

    for(new i = 0; i < g_iPlayerPromoTimersCount[playerid]; i++)
    {
        new playerPromoSQLID = PlayerPromoTimers[playerid][i][pPlayerPromoSQLID];
        new timerId = PlayerPromoTimers[playerid][i][pPromoTimerID];

        KillTimer(timerId);

        mysql_format(mysql, query, sizeof(query), "SELECT start_time, remaining_time FROM player_promos WHERE id = %d", playerPromoSQLID);
        result = mysql_query(mysql, query, true);

        if(mysql_errno() == 0 && cache_num_rows(result) > 0)
        {
            new startTime = cache_get_field_content_int(0, "start_time");
            new remainingTimeFromDB = cache_get_field_content_int(0, "remaining_time");

            new prizeDurationHours = 0;
            new Cache:prizeResult;
            new query2[128];
            mysql_format(mysql, query2, sizeof(query2), "SELECT ppz.prize_duration FROM player_promos pp JOIN promo_prizes ppz ON pp.promo_prize_sql_id = ppz.id WHERE pp.id = %d", playerPromoSQLID);
            prizeResult = mysql_query(mysql, query2, true);
            if(mysql_errno() == 0 && cache_num_rows(prizeResult) > 0)
            {
                prizeDurationHours = cache_get_field_content_int(0, "prize_duration");
            }
            cache_delete(prizeResult);

            new calculatedRemainingTime = prizeDurationHours * 3600 - (gettime() - startTime);
            if(calculatedRemainingTime < 0) calculatedRemainingTime = 0;

            new finalRemainingTime = min(remainingTimeFromDB, calculatedRemainingTime);
            if(finalRemainingTime < 0) finalRemainingTime = 0;

            mysql_format(mysql, query, sizeof(query),
                "UPDATE player_promos SET remaining_time = %d WHERE id = %d",
                finalRemainingTime, playerPromoSQLID);
            mysql_query(mysql, query, false);
            printf("[WERTON_PROMO] Timer for prize (player_promos.id: %d) of player %s (ID: %d) stopped and time saved. Remaining: %d seconds.",
                playerPromoSQLID, GetPlayerNameEx(playerid), accountId, finalRemainingTime);
        }
        cache_delete(result);
    }
    g_iPlayerPromoTimersCount[playerid] = 0;
}

stock RevokePromoPrize(accountId, prizeType, prizeValue, promoIdForCarRevoke)
{
    new playerid = GetPlayerIDFromAccountID(accountId);
    if(playerid == INVALID_PLAYER_ID) return 0;

    new query[256];
    new Cache:result;

    switch(prizeType)
    {
        case PRIZE_TYPE_MONEY:
        {
            new playerMoney = GetPlayerData(playerid, P_MONEY);
            new newMoney = playerMoney - prizeValue;

            if(newMoney < 0)
            {
                SetPlayerData(playerid, P_MONEY, 0);
                UpdatePlayerDatabaseInt(playerid, "money", 0);
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}You had {ff2400}%d${ffffff} revoked due to prize expiry. Your balance set to 0$.", prizeValue);
            }
            else
            {
                GivePlayerMoneyEx(playerid, -prizeValue);
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}You had {ff2400}%d${ffffff} revoked due to prize expiry.", prizeValue);
            }
        }
        case PRIZE_TYPE_DONATE:
        {
            new playerDonate = GetPlayerData(playerid, P_DONATE_RUB);
            new newDonate = playerDonate - prizeValue;

            if(newDonate < 0)
            {
                GivePlayerDonateRub(playerid, -GetPlayerData(playerid, P_DONATE_RUB));
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}You had {ff2400}%d donate{ffffff} revoked due to prize expiry. Your donate balance set to 0.", prizeValue);
            }
            else
            {
                GivePlayerDonateRub(playerid, -prizeValue);
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}You had {ff2400}%d donate{ffffff} revoked due to prize expiry.", prizeValue);
            }
        }
        case PRIZE_TYPE_CAR:
        {
            mysql_format(mysql, query, sizeof(query),
                "SELECT id, vehicle_id FROM ownable_cars WHERE owner_id = %d AND promo_status_car = 1 AND promo_id = %d AND model_id = %d",
                accountId, promoIdForCarRevoke, prizeValue);
            result = mysql_query(mysql, query, true);

            new rows = cache_num_rows();
            if(rows > 0)
            {
                new carSqlId = cache_get_field_content_int(0, "id");
                new vehicleIdInGame = cache_get_field_content_int(0, "vehicle_id");

                mysql_format(mysql, query, sizeof(query), "DELETE FROM ownable_cars WHERE id = %d", carSqlId);
                mysql_query(mysql, query, false);

                if(IsValidVehicle(vehicleIdInGame))
                {
                    DestroyVehicle(vehicleIdInGame);
                }
                else
                {
                    #if defined MAX_OWNABLE_CARS && defined g_ownable_car && defined OC_SQL_ID && defined OC_VEHICLE_ID
                    for(new j = 0; j < MAX_OWNABLE_CARS; j++)
                    {
                        if(g_ownable_car[j][OC_SQL_ID] == carSqlId && IsValidVehicle(g_ownable_car[j][OC_VEHICLE_ID]))
                        {
                            DestroyVehicle(g_ownable_car[j][OC_VEHICLE_ID]);
                            break;
                        }
                    }
                    #endif
                }
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Your vehicle obtained via promo code has been revoked.");
                printf("[WERTON_PROMO] Vehicle (SQL ID: %d, Model: %d) revoked from player %s (ID: %d) due to prize expiry.",
                    carSqlId, prizeValue, GetPlayerNameEx(playerid), accountId);
            }
            cache_delete(result);
        }
        case PRIZE_TYPE_EXP:
        {
            return 1; // no need to remove EXP
        }
    }
    printf("[WERTON_PROMO] Prize type %d (value %d) revoked from player %s (ID: %d).", prizeType, prizeValue, GetPlayerNameEx(playerid), accountId);
    return 1;
}

stock GetPromoCodeDataByID(promoId, promoData[E_PROMO_DATA])
{
    for(new i = 0; i < g_iLoadedPromoCodes; i++)
    {
        if(PromoCodes[i][PromoID] == promoId)
        {
            promoData[PromoID] = PromoCodes[i][PromoID];
            strmid(promoData[PromoCode], PromoCodes[i][PromoCode], 0, MAX_PROMO_CODE_LENGTH);
            promoData[PromoUses] = PromoCodes[i][PromoUses];
            promoData[UsesLeft] = PromoCodes[i][UsesLeft];
            promoData[NumPrizes] = PromoCodes[i][NumPrizes];
            return 1;
        }
    }
    return 0;
}

stock GetPromoCodeDataByString(const promoCode[], promoData[E_PROMO_DATA])
{
    for(new i = 0; i < g_iLoadedPromoCodes; i++)
    {
        if(strcmp(PromoCodes[i][PromoCode], promoCode, true) == 0)
        {
            promoData[PromoID] = PromoCodes[i][PromoID];
            strmid(promoData[PromoCode], PromoCodes[i][PromoCode], 0, MAX_PROMO_CODE_LENGTH);
            promoData[PromoUses] = PromoCodes[i][PromoUses];
            promoData[UsesLeft] = PromoCodes[i][UsesLeft];
            promoData[NumPrizes] = PromoCodes[i][NumPrizes];
            return 1;
        }
    }
    return 0;
}

stock GetPromoCodeIndexByString(const promoCode[])
{
    for(new i = 0; i < g_iLoadedPromoCodes; i++)
    {
        if(strcmp(PromoCodes[i][PromoCode], promoCode, true) == 0)
        {
            return i;
        }
    }
    return -1;
}

stock GivePromoCar(playerid, modelid, promoSqlId)
{
    new color_1 = 0, color_2 = 0;
    new Float:POS[3];
    GetPlayerPos(playerid, POS[0],POS[1],POS[2]);
    new Float: pos_x = POS[0];
    new Float: pos_y = POS[1];
    new Float: pos_z = POS[2];
    new Float: angle = 356.7986;
    new query[256], Cache: result, idx;
    /*idx = GetFreeOwnableCarID();

    SetOwnableCarData(idx, OC_OWNER_ID,  GetPlayerAccountID(playerid));
    SetOwnableCarData(idx, OC_MODEL_ID,  modelid);
    SetOwnableCarData(idx, OC_COLOR_1,   color_1);
    SetOwnableCarData(idx, OC_COLOR_2,   color_2);
    SetOwnableCarData(idx, OC_POS_X,     pos_x);
    SetOwnableCarData(idx, OC_POS_Y,     pos_y);
    SetOwnableCarData(idx, OC_POS_Z,     pos_z);
    SetOwnableCarData(idx, OC_ANGLE,     angle);
    strmid(g_ownable_car[idx][OC_NUMBER], "------", 0, 8, 8);
    SetOwnableCarData(idx, OC_ALARM,     false);
    SetOwnableCarData(idx, OC_KEY_IN,    false);
    SetOwnableCarData(idx, OC_CREATE,    gettime());
    format(g_ownable_car[idx][OC_OWNER_NAME], 21, GetPlayerNameEx(playerid));

    SetOwnableCarData(idx, OC_PROMO_STATUS_CAR, 1);
    SetOwnableCarData(idx, OC_PROMO_ID, promoSqlId);

    new vehicleid = CreateVehicle ( GetOwnableCarData(idx, OC_MODEL_ID), GetOwnableCarData(idx, OC_POS_X), GetOwnableCarData(idx, OC_POS_Y), GetOwnableCarData(idx, OC_POS_Z), GetOwnableCarData(idx, OC_ANGLE), GetOwnableCarData(idx, OC_COLOR_1), GetOwnableCarData(idx, OC_COLOR_2), -1, 0, VEHICLE_ACTION_TYPE_OWNABLE_CAR, idx ); // Assuming VEHICLE_ACTION_TYPE_OWNABLE_CAR exists

    if(vehicleid != INVALID_VEHICLE_ID)
    {
        format(g_ownable_car[idx][OC_NUMBER], 12, g_ownable_car[idx][OC_NUMBER]);
        SetVehicleRuNumberPlate(vehicleid, g_ownable_car[idx][OC_NUMBER], "17");
        SetVehicleParam(vehicleid, V_LOCK, false);
        SetVehicleData(vehicleid, V_MILEAGE, 0.0);
        PutPlayerInVehicle(playerid, vehicleid, 0);
    }
    SetPlayerData(playerid, P_OWNABLE_CAR, vehicleid);*/

    format ( query, sizeof query, "INSERT INTO ownable_cars \
    (owner_id,model_id,color_1,color_2,pos_x,pos_y,pos_z,angle,create_time,promo_status_car,promo_id) \
    VALUES \
    ('%d','%d','%d','%d','%f','%f','%f','%f','%d','%d','%d')",
    GetPlayerAccountID(playerid), modelid, color_1, color_2, pos_x, pos_y, pos_z, angle, gettime(), 1, promoSqlId );

    result = mysql_query(mysql, query, true);
    //SetOwnableCarData(idx, OC_SQL_ID, cache_insert_id(result));
    cache_delete(result);
    return 1;
}

stock ShowPromoCreationConfirmation(playerid)
{
    new szMessage[1024];
    new szTemp[256];
    new promoCode[MAX_PROMO_CODE_LENGTH];
    strmid(promoCode, PlayerPromoCreationData[playerid][NewPromoCodeString], 0, MAX_PROMO_CODE_LENGTH);
    new prizeCount = PlayerPromoCreationData[playerid][NewPromoPrizeCount];
    new usesLimit = PlayerPromoCreationData[playerid][NewPromoUsesLimit];

    format(szMessage, sizeof(szMessage), "{FF6347}"SERVER_NAME" {FFFFFF}| Confirm promo code creation:\n\n");
    format(szTemp, sizeof(szTemp), "{ffffff}Promo code: {ffff00}%s\n", promoCode);
    strcat(szMessage, szTemp);

    new szUsesLimitText[32];
    if(usesLimit == 0) {
        format(szUsesLimitText, sizeof(szUsesLimitText), "Unlimited");
    } else {
        format(szUsesLimitText, sizeof(szUsesLimitText), "%d", usesLimit);
    }
    format(szTemp, sizeof(szTemp), "{ffffff}Usage limit: {ffff00}%s\n\n", szUsesLimitText);

    strcat(szMessage, szTemp);

    strcat(szMessage, "{ffffff}Configured prizes:\n");
    for(new i = 0; i < prizeCount; i++)
    {
        new prizeType = PlayerTempPrizes[playerid][i][TempPrizeType];
        new prizeValue = PlayerTempPrizes[playerid][i][TempPrizeValue];
        new prizeDuration = PlayerTempPrizes[playerid][i][TempPrizeDuration];

        new szPrizeDetails[128];
        new szDurationText[64];

        if(prizeDuration == 0)
        {
            format(szDurationText, sizeof(szDurationText), "permanent");
        }
        else
        {
            format(szDurationText, sizeof(szDurationText), "for %d h.", prizeDuration);
        }

        switch (prizeType)
        {
            case PRIZE_TYPE_MONEY:
            {
                format(szPrizeDetails, sizeof(szPrizeDetails), "{ffffff}%d. Money: {ffff00}%d rub. {888888}(%s)\n", i + 1, prizeValue, szDurationText);
            }
            case PRIZE_TYPE_DONATE:
            {
                format(szPrizeDetails, sizeof(szPrizeDetails), "{ffffff}%d. Donate: {ffff00}%d donate {888888}(%s)\n", i + 1, prizeValue, szDurationText);
            }
            case PRIZE_TYPE_CAR:
            {
                format(szPrizeDetails, sizeof(szPrizeDetails), "{ffffff}%d. Vehicle: {ffff00}%s (model ID: %d) {888888}(%s)\n", i + 1, GetVehicleInfo(prizeValue - 400, VI_NAME), prizeValue, szDurationText);
            }
        }
        strcat(szMessage, szPrizeDetails);
    }

    ShowPlayerDialog(playerid, DIALOG_CONFIRM_PROMO_CREATION, DIALOG_STYLE_MSGBOX,
        "{FF6347}"SERVER_NAME" {FFFFFF}| Confirm promo code creation", szMessage, "Create", "Cancel"
    );
}

stock CreatePromoCodeInDatabase(playerid)
{
    new query[1024];
    new promoCode[MAX_PROMO_CODE_LENGTH];
    strmid(promoCode, PlayerPromoCreationData[playerid][NewPromoCodeString], 0, MAX_PROMO_CODE_LENGTH);
    new prizeCount = PlayerPromoCreationData[playerid][NewPromoPrizeCount];
    new usesLimit = PlayerPromoCreationData[playerid][NewPromoUsesLimit];
    new promoId;
    new Cache:result;
    new szMsg[256];

    mysql_format(mysql, query, sizeof(query),
        "INSERT INTO `promocodes` (`code`, `uses_limit`, `uses_left`, `num_prizes`) VALUES ('%e', %d, %d, %d)",
        promoCode, usesLimit, usesLimit, prizeCount);

    result = mysql_query(mysql, query, true);
    if(mysql_errno() != 0)
    {
        format(szMsg, sizeof(szMsg), "{ff2400}| {ffffff}Error creating promo code (main record): %d", mysql_errno());
        SendClientMessage(playerid, -1, szMsg);
        printf("[WERTON_PROMO] Error creating promo code (promocodes table): %d", mysql_errno());
        cache_delete(result);
        return 0;
    }
    promoId = cache_insert_id(result);
    cache_delete(result);

    if(promoId == 0)
    {
        SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Error: Could not get ID of new promo code.");
        printf("[WERTON_PROMO] Error: cache_insert_id returned 0 for promo code '%s'.", promoCode);
        return 0;
    }

    for(new i = 0; i < prizeCount; i++)
    {
        new prizeType = PlayerTempPrizes[playerid][i][TempPrizeType];
        new prizeValue = PlayerTempPrizes[playerid][i][TempPrizeValue];
        new prizeDuration = PlayerTempPrizes[playerid][i][TempPrizeDuration];

        mysql_format(mysql, query, sizeof(query),
            "INSERT INTO `promo_prizes` (`promo_id`, `prize_index`, `prize_type`, `prize_value`, `prize_duration`) VALUES (%d, %d, %d, %d, %d)",
            promoId, i, prizeType, prizeValue, prizeDuration);

        mysql_query(mysql, query, false);
        if(mysql_errno() != 0)
        {
            format(szMsg, sizeof(szMsg), "{ff2400}| {ffffff}Error adding prize %d for promo code: %d", i + 1, mysql_errno());
            SendClientMessage(playerid, -1, szMsg);
            printf("[WERTON_PROMO] Error adding prize (promo_prizes table) for promo code ID %d, prize %d: %d", promoId, i, mysql_errno());
        }
    }

    format(szMsg, sizeof(szMsg), "{00FF00}| {ffffff}Promo code '%s' successfully created with %d prizes!", promoCode, prizeCount);
    SendClientMessage(playerid, -1, szMsg);
    LoadPromoCodesFromDatabase();

    PlayerPromoCreationData[playerid][NewPromoPrizeCount] = 0;
    PlayerPromoCreationData[playerid][NewPromoCurrentPrizeIndex] = 0;
    PlayerPromoCreationData[playerid][NewPromoUsesLimit] = 0;

    return 1;
}

public OnDialogResponse(playerid, dialogid, response, listitem, inputtext[])
{
    switch(dialogid)
    {
        case DIALOG_PROMO_MANAGEMENT:
        {
            if(response)
            {
                switch(listitem)
                {
                    case 0:
                    {
                        callcmd::mypromo(playerid, "");
                    }
                    /*case 1:
                    {
                        new level_text[500];
                        new current_level = GetPromoLevelForOwner(playerid);
                        new level_status[11][32];

                        for(new i = 0; i < 11; i++)
                        {
                            if(i <= current_level - 1)
                            {
                                format(level_status[i], sizeof(level_status[]), "{66CC33}open");
                            }
                            else
                            {
                                format(level_status[i], sizeof(level_status[]), "{FF6347}locked");
                            }
                        }


                        format(level_text, sizeof(level_text), "{EB4C42} #1.\t\t\t\t{FFFFFF}Level 1 %s\n"\
                        "{EB4C42} #2.\t\t\t\t{FFFFFF}Level 2 %s\n"\
                        "{EB4C42} #3.\t\t\t\t{FFFFFF}Level 3 %s\n"\
                        "{EB4C42} #4.\t\t\t\t{FFFFFF}Level 4 %s\n"\
                        "{EB4C42} #5.\t\t\t\t{FFFFFF}Level 5 %s\n"\
                        "{EB4C42} #6.\t\t\t\t{FFFFFF}Level 6 %s\n"\
                        "{EB4C42} #7.\t\t\t\t{FFFFFF}Level 7 %s\n"\
                        "{EB4C42} #8.\t\t\t\t{FFFFFF}Level 8 %s\n"\
                        "{EB4C42} #9.\t\t\t\t{FFFFFF}Level 9 %s\n"\
                        "{EB4C42} #10.\t\t\t\t{FFFFFF}Level 10 %s",
                        level_status[0], level_status[1], level_status[2], level_status[3], level_status[4], level_status[5], level_status[6], level_status[7], level_status[8], level_status[9]);

                        ShowPlayerDialog(playerid, DIALOG_PROMO_UPGRADE_LEVELS, DIALOG_STYLE_LIST, "{FF0000} Levels", level_text, "Upgrade", "Back");
                    }*/
                    case 1:
                    {
                        new level_text[1024];
                        new current_level = GetPromoLevelForOwner(playerid);
                        new level_status[32];
                        new level_name[10][32] = {
                            "Level 1", "Level 2", "Level 3", "Level 4", "Level 5",
                            "Level 6", "Level 7", "Level 8", "Level 9", "Level 10"
                        };

                        level_text[0] = EOS;

                        for(new i = 0; i < 10; i++)
                        {
                            if(i <= current_level - 1)
                            {
                                format(level_status, sizeof(level_status), "{66CC33}open");
                            }
                            else
                            {
                                format(level_status, sizeof(level_status), "{FF6347}locked");
                            }
                            format(level_text, sizeof(level_text), "%s{EB4C42} #%d.\t\t\t\t{FFFFFF}%s %s\n", level_text, i + 1, level_name[i], level_status);
                        }

                        if(strlen(level_text) > 0)
                        {
                            level_text[strlen(level_text) - 1] = EOS;
                        }

                        ShowPlayerDialog(playerid, DIALOG_PROMO_UPGRADE_LEVELS, DIALOG_STYLE_LIST, "{FF0000} Levels", level_text, "Upgrade", "Back");
                    }
                    case 2:
                    {
                        ShowPlayerDialog(playerid, DIALOG_PROMO_INFO, DIALOG_STYLE_MSGBOX,
                            "{FF0000} Promo code",
                            "{ffff00}Promo code{ffffff} - a unique set of characters allowing users to use it during registration and receive bonuses\nPromo code is divided into 10 levels, at each level you will receive {ffff00}increased bonus {ffffff}for player registration,\nand also {ffff00}increased donate percentage{ffffff}, for player donate. You can upgrade your level by activating promo code or by donating in promo management.\nTo receive rewards use {FF6347}/checkpromo{FFFFFF} and {FF6347}/mypromo {FFFFFF} to manage promo code",
                            "Back", ""
                        );
                    }
                    case 3:
                    {
                        callcmd::mypromo(playerid, "");
                    }
                }
            }
        }
        case DIALOG_PROMO_UPGRADE_LEVELS:
        {
            if(response)
            {
                new target_level = listitem + 1;
                new current_level = GetPromoLevelForOwner(playerid);
                new promo_activations, promo_donat_balance, promo_sql_id;
                new query[256];

                mysql_format(mysql, query, sizeof(query), "SELECT `id`, `activations`, `promo_balance` FROM `promocodes` WHERE `creator_account_id` = %d LIMIT 1", GetPlayerAccountID(playerid));
                new Cache:result = mysql_query(mysql, query);
                if(cache_num_rows(result) == 0)
                {
                    SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Promo code not found.");
                    cache_delete(result);
                    return 1;
                }
                promo_sql_id = cache_get_field_content_int(0, "id");
                promo_activations = cache_get_field_content_int(0, "activations");
                promo_donat_balance = cache_get_field_content_int(0, "promo_balance");
                cache_delete(result);

                if(target_level > current_level + 1)
                {
                    SendClientMessage(playerid, -1, "{ff2400}| {ffffff}You cannot skip levels. Upgrade in order.");
                    callcmd::mypromo(playerid, "");
                    return 1;
                }

                if(target_level > 10)
                {
                    SendClientMessage(playerid, -1, "{ff2400}| {ffffff}You have already reached the maximum level.");
                    callcmd::mypromo(playerid, "");
                    return 1;
                }

                new needed_activations = PROMO_LEVEL_DATA[target_level][1];
                new needed_donat = PROMO_LEVEL_DATA[target_level][3];
                new promo_money_bonus = PROMO_LEVEL_DATA[target_level][4];
                new dialog_text[512];

                if(promo_activations >= needed_activations)
                {
                    format(dialog_text, sizeof(dialog_text), "Do you really want to upgrade the promo code level for {ffff00}%d {ffffff}activations?\nUpon upgrade you will get new conditions: {ffff00}%d{ffffff}%% from player donate, {ffff00}%d{ffffff} rubles\nAs bonus per invited player", needed_activations, (target_level == 1 ? 0 : PROMO_LEVEL_DATA[target_level][2]), promo_money_bonus);
                }
                else if(promo_donat_balance >= needed_donat)
                {
                    format(dialog_text, sizeof(dialog_text), "Do you really want to upgrade the promo code level for {ffff00}%d {ffffff}donate?\nUpon upgrade you will get new conditions: {ffff00}%d{ffffff}%% from player donate, {ffff00}%d{ffffff} rubles\nAs bonus per invited player", needed_donat, (target_level == 1 ? 0 : PROMO_LEVEL_DATA[target_level][2]), promo_money_bonus);
                }
                else
                {
                    SendClientMessage(playerid, -1, "{ff2400}| {ffffff}You don't have enough activations or donate to upgrade level.");
                    callcmd::mypromo(playerid, "");
                    return 1;
                }

                ShowPlayerDialog(playerid, DIALOG_PROMO_UPGRADE_CONFIRM, DIALOG_STYLE_MSGBOX, "{FF0000} Promo code level upgrade", dialog_text, "Next", "Back");
                PlayerDialogPromoData[playerid] = target_level;
            }
            else
            {
                callcmd::mypromo(playerid, "");
            }
        }
        case DIALOG_PROMO_UPGRADE_CONFIRM:
        {
            if(response)
            {
                new target_level = PlayerDialogPromoData[playerid];
                new promo_activations, promo_donat_balance, promo_sql_id;
                new query[256];

                mysql_format(mysql, query, sizeof(query), "SELECT `id`, `activations`, `promo_balance` FROM `promocodes` WHERE `creator_account_id` = %d LIMIT 1", GetPlayerAccountID(playerid));
                new Cache:result = mysql_query(mysql, query);
                if(cache_num_rows(result) == 0)
                {
                     SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Promo code not found.");
                     cache_delete(result);
                     return 1;
                }
                promo_sql_id = cache_get_field_content_int(0, "id");
                promo_activations = cache_get_field_content_int(0, "activations");
                promo_donat_balance = cache_get_field_content_int(0, "promo_balance");
                cache_delete(result);

                new needed_activations = PROMO_LEVEL_DATA[target_level][1];
                new needed_donat = PROMO_LEVEL_DATA[target_level][3];

                if(promo_activations >= needed_activations)
                {
                    mysql_format(mysql, query, sizeof(query), "UPDATE `promocodes` SET `promo_level` = %d WHERE `id` = %d", target_level, promo_sql_id);
                    mysql_query(mysql, query, false);
                    SavePromoLevelPrizes(playerid, promo_sql_id, target_level);
                    SendClientMessage(playerid, -1, "{66CC33}| {FFFFFF}You successfully upgraded the promo code level using activations!");
                }
                else if(promo_donat_balance >= needed_donat)
                {
                    mysql_format(mysql, query, sizeof(query), "UPDATE `promocodes` SET `promo_level` = %d, `promo_balance` = `promo_balance` - %d WHERE `id` = %d", target_level, needed_donat, promo_sql_id);
                    mysql_query(mysql, query, false);
                    SavePromoLevelPrizes(playerid, promo_sql_id, target_level);
                    SendClientMessage(playerid, -1, "{66CC33}| {FFFFFF}You successfully upgraded the promo code level using donate!");
                }
                else
                {
                    SendClientMessage(playerid, -1, "{ff2400}| {ffffff}You don't have enough activations or donate to upgrade level.");
                }
                callcmd::mypromo(playerid, "");
            }
            else
            {
                callcmd::mypromo(playerid, "");
            }
        }
        case DIALOG_PROMO_INFO:
        {
            if(response)
            {
                callcmd::mypromo(playerid, "");
            }
        }
        case DIALOG_ACT_PROMO:
        {
            if(!response)
            {
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}You exited the promo code menu.");
                return 1;
            }

            switch (listitem)
            {
                case 0:
                {
                    callcmd::bcode(playerid, "");
                }
                case 1:
                {
                    SendClientMessage(playerid, -1, "{ff2400}| {ffffff}You didn't enter a YouTube promo.");
                    callcmd::promo(playerid, "");
                }
                case 2:
                    {
                        if(HasPlayerCreatedPromo(playerid))
                        {
                            callcmd::mypromo(playerid, "");
                        }
                        else
                        {
                            ShowPlayerDialog
                            (
                                playerid, DIALOG_ADDPROMO_CODE_BY_PLAYER, DIALOG_STYLE_INPUT,
                                "{ff0000}Create promo code",
                                "{ffff00}Promo code {FFFFFF}- a unique set of characters that allows you and the person using your promo code to receive rewards\n"\
                                "You can create your own {ffff00}promo code{FFFFFF}, provided it is free.\n\n"\
                                "\n"\
                                "However, remember that the number of characters in the promo code determines its {ffff00}cost\n"\
                                "{ffff00}From 3 characters - {FFFFFF}10,000,000 rubles or 2,000 BC\n"\
                                "{ffff00}From 5 to 7 characters - {FFFFFF}5,000,000 rubles.\n"\
                                "{ffff00}From 7 characters - {FFFFFF}3,000,000 rubles.\n"\
                                "You can use {ffff00}Latin and Cyrillic, # and numbers.\n\n"\
                                "{FF6347}Note! {FFFFFF}The first character of the promo code must be - {FF6347}@\n\n"\
                                "\n"\
                                "{FFFFFF}To create a promo code, enter the desired set of characters in the field below.\n",
                                "Next", "Cancel"
                            );
                        }
                    }
                case 3:
                {
                    new query[256];
                    new Cache:result;
                    new dialog_string[1024];
                    new accountId = GetPlayerAccountID(playerid);
                    new total_promos = 0;

                    mysql_format(mysql, query, sizeof(query),
                        "SELECT pr.code FROM player_promos pp JOIN promo_prizes ppz ON pp.promo_prize_sql_id = ppz.id JOIN promocodes pr ON ppz.promo_id = pr.id WHERE pp.account_id = %d",
                        accountId
                    );
                    result = mysql_query(mysql, query, true);

                    if(cache_num_rows(result) > 0)
                    {
                        total_promos = cache_num_rows(result);
                        format(dialog_string, sizeof(dialog_string), "{ffffff} #%s\t\t\t\tPrize taken", cache_get_field_content(0, "code"));
                        for(new i = 1; i < total_promos; i++)
                        {
                            new temp_code[MAX_PROMO_CODE_LENGTH];
                            cache_get_field_content(i, "code", temp_code, sizeof(temp_code));
                            format(dialog_string, sizeof(dialog_string), "%s\n{ffffff} #%s\t\t\t\tPrize taken", dialog_string, temp_code);
                        }
                    }
                    else
                    {
                        format(dialog_string, sizeof(dialog_string), "{ffffff}You have no used promo codes yet.");
                    }
                    cache_delete(result);

                    new title[128];
                    format(title, sizeof(title), "{FF0000} Number of promo codes: %d", total_promos);
                    ShowPlayerDialog(playerid, DIALOG_ACT_PROMO_PRIZES, DIALOG_STYLE_LIST, title, dialog_string, "OK", "");
                }
            }
        }
        case DIALOG_ADDPROMO_CODE_BY_PLAYER:
        {
            if(!response)
            {
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Promo code creation canceled.");
                return 1;
            }

            if(strlen(inputtext) == 0)
            {
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}You didn't enter a promo code. Please try again.");

                ShowPlayerDialog
                (
                    playerid, DIALOG_ADDPROMO_CODE_BY_PLAYER, DIALOG_STYLE_INPUT,
                    "{ff0000}Create promo code",
                    "{ffff00}Promo code {FFFFFF}- a unique set of characters that allows you and the person using your promo code to receive rewards\n"\
                    "You can create your own {ffff00}promo code{FFFFFF}, provided it is free.\n\n"\
                    "\n"\
                    "However, remember that the number of characters in the promo code determines its {ffff00}cost\n"\
                    "{ffff00}From 3 characters - {FFFFFF}10,000,000 rubles or 2,000 BC\n"\
                    "{ffff00}From 5 to 7 characters - {FFFFFF}5,000,000 rubles.\n"\
                    "{ffff00}From 7 characters - {FFFFFF}3,000,000 rubles.\n"\
                    "You can use {ffff00}Latin and Cyrillic, # and numbers.\n\n"\
                    "{FF6347}Note! {FFFFFF}The first character of the promo code must be - {FF6347}@\n\n"\
                    "\n"\
                    "{FFFFFF}To create a promo code, enter the desired set of characters in the field below.\n",
                    "Next", "Cancel"
                );
                return 1;
            }

            new len = strlen(inputtext);
            if(inputtext[0] != '@')
            {
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Error: Promo code must start with '@'.");
                callcmd::promo(playerid, "");
                return 1;
            }

            if(len < 3)
            {
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Error: Promo code must contain at least 3 characters.");
                callcmd::promo(playerid, "");
                return 1;
            }

            // Check for allowed characters (Latin, Cyrillic, # and digits)
            for(new i = 1; i < len; i++) // Start at 1, since first character already checked ('@')
            {
                new current_char = inputtext[i]; // Fixed: changed 'char' to 'current_char'
                // Check for Latin (lowercase and uppercase)
                if(!((current_char >= 'a' && current_char <= 'z') || (current_char >= 'A' && current_char <= 'Z') ||
                // Check for Cyrillic (simplified, full Unicode support requires extended checks)
                      (current_char >= 0x410 && current_char <= 0x44F) || (current_char >= 0x400 && current_char <= 0x40F) ||
                // Check for digits
                      (current_char >= '0' && current_char <= '9') ||
                // Check for #
                      (current_char == '#')))
                {
                    SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Error: Promo code contains invalid characters. Allowed: Latin, Cyrillic, digits and '#'.");
                    callcmd::promo(playerid, "");
                    return 1;
                }
            }
            OnPromoCodeCheckComplete(playerid, inputtext);
            return 1;
        }
        case DIALOG_ADDPROMO_CODE:
        {
            if(!response)
            {
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Promo code creation canceled.");
                return 1;
            }
            if(strlen(inputtext) == 0)
            {
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Promo code name cannot be empty.");
                callcmd::addcpromo(playerid, "");
                return 1;
            }
            if(strfind(inputtext, " ", true) != -1)
            {
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Promo code name cannot contain spaces.");
                callcmd::addcpromo(playerid, "");
                return 1;
            }
            if(strlen(inputtext) > MAX_PROMO_CODE_LENGTH)
            {
                new szMsg[128];
                format(szMsg, sizeof(szMsg), "{ff2400}| {ffffff}Promo code name is too long (max. %d characters).", MAX_PROMO_CODE_LENGTH);
                SendClientMessage(playerid, -1, szMsg);
                callcmd::addcpromo(playerid, "");
                return 1;
            }

            if(GetPromoCodeIndexByString(inputtext) != -1)
            {
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}A promo code with that name already exists.");
                callcmd::addcpromo(playerid, "");
                return 1;
            }

            strmid(PlayerPromoCreationData[playerid][NewPromoCodeString], inputtext, 0, MAX_PROMO_CODE_LENGTH);
            PlayerPromoCreationData[playerid][NewPromoCurrentPrizeIndex] = 0;

            ShowPlayerDialog(playerid, DIALOG_ADDPROMO_PRIZE_COUNT, DIALOG_STYLE_INPUT, "{FF6347}"SERVER_NAME" {FFFFFF}| Creating promo code", "Enter number of prizes (1-5):", "Next", "Cancel");
            return 1;
        }
        case DIALOG_ADDPROMO_PRIZE_COUNT:
        {
            if(!response)
            {
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Promo code creation canceled.");
                return 1;
            }
            new prizeCount = strval(inputtext);
            if(prizeCount < 1 || prizeCount > 5)
            {
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Number of prizes must be between 1 and 5.");
                ShowPlayerDialog(playerid, DIALOG_ADDPROMO_PRIZE_COUNT, DIALOG_STYLE_INPUT, "{FF6347}"SERVER_NAME" {FFFFFF}| Creating promo code", "Enter number of prizes (1-5):", "Next", "Cancel");
                return 1;
            }
            PlayerPromoCreationData[playerid][NewPromoPrizeCount] = prizeCount;

            ShowPlayerDialog(playerid, DIALOG_ADDPROMO_USES_LIMIT, DIALOG_STYLE_INPUT, "{FF6347}"SERVER_NAME" {FFFFFF}| Creating promo code", "Enter usage limit for the promo code (0 - unlimited):", "Next", "Cancel");
            return 1;
        }

        case DIALOG_ADDPROMO_USES_LIMIT:
        {
            if(!response)
            {
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Promo code creation canceled.");
                return 1;
            }
            new usesLimit = strval(inputtext);
            if(usesLimit < 0)
            {
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Usage limit cannot be negative.");
                ShowPlayerDialog(playerid, DIALOG_ADDPROMO_USES_LIMIT, DIALOG_STYLE_INPUT, "{FF6347}"SERVER_NAME" {FFFFFF}| Creating promo code", "Enter usage limit for the promo code (0 - unlimited):", "Next", "Cancel");
                return 1;
            }
            PlayerPromoCreationData[playerid][NewPromoUsesLimit] = usesLimit;

            new szDialogTitle[128];
            format(szDialogTitle, sizeof(szDialogTitle), "{FF6347}"SERVER_NAME" {FFFFFF}| Configuring prize %d/%d (Type)",
                PlayerPromoCreationData[playerid][NewPromoCurrentPrizeIndex] + 1,
                PlayerPromoCreationData[playerid][NewPromoPrizeCount]);

            ShowPlayerDialog(playerid, DIALOG_ADDPROMO_SINGLE_PRIZE_TYPE, DIALOG_STYLE_LIST,
                szDialogTitle,
                "1. {669900}Money\n2. {669900}Donate\n3. {669900}Vehicle\n4. {669900}EXP",
                "Select", "Cancel"
            );
            return 1;
        }

        case DIALOG_ADDPROMO_SINGLE_PRIZE_TYPE:
        {
            if(!response)
            {
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Promo code creation canceled.");
                return 1;
            }
            new currentPrizeIndex = PlayerPromoCreationData[playerid][NewPromoCurrentPrizeIndex];
            PlayerTempPrizes[playerid][currentPrizeIndex][TempPrizeType] = listitem;

            new szDialogText[256];
            switch (listitem)
            {
                case PRIZE_TYPE_MONEY: format(szDialogText, sizeof(szDialogText), "Enter amount of money:");
                case PRIZE_TYPE_DONATE: format(szDialogText, sizeof(szDialogText), "Enter amount of donate:");
                case PRIZE_TYPE_CAR: format(szDialogText, sizeof(szDialogText), "Enter vehicle model ID (e.g., 411 for Cheetah):");
                case PRIZE_TYPE_EXP: format(szDialogText, sizeof(szDialogText), "Enter amount of EXP:");
            }

            new szDialogTitle[128];
            format(szDialogTitle, sizeof(szDialogTitle), "{FF6347}"SERVER_NAME" {FFFFFF}| Configuring prize %d/%d",
                currentPrizeIndex + 1,
                PlayerPromoCreationData[playerid][NewPromoPrizeCount]);

            ShowPlayerDialog(playerid, DIALOG_ADDPROMO_SINGLE_PRIZE_VALUE, DIALOG_STYLE_INPUT,
                szDialogTitle,
                szDialogText, "Next", "Cancel"
            );
            return 1;
        }

        case DIALOG_ADDPROMO_SINGLE_PRIZE_VALUE:
        {
            if(!response)
            {
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Promo code creation canceled.");
                return 1;
            }
            new currentPrizeIndex = PlayerPromoCreationData[playerid][NewPromoCurrentPrizeIndex];
            new prizeValue = strval(inputtext);
            new prizeType = PlayerTempPrizes[playerid][currentPrizeIndex][TempPrizeType];

            new szDialogTitle[128];
            format(szDialogTitle, sizeof(szDialogTitle), "{FF6347}"SERVER_NAME" {FFFFFF}| Configuring prize %d/%d (Duration type)",
                currentPrizeIndex + 1,
                PlayerPromoCreationData[playerid][NewPromoPrizeCount]);

            if(prizeValue <= 0)
            {
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Prize value must be a positive number.");
                new szDialogText[256];
                switch (prizeType)
                {
                    case PRIZE_TYPE_MONEY: format(szDialogText, sizeof(szDialogText), "Enter amount of money:");
                    case PRIZE_TYPE_DONATE: format(szDialogText, sizeof(szDialogText), "Enter amount of donate:");
                    case PRIZE_TYPE_CAR: format(szDialogText, sizeof(szDialogText), "Enter vehicle model ID (e.g., 411 for Cheetah):");
                    case PRIZE_TYPE_EXP: format(szDialogText, sizeof(szDialogText), "Enter amount of EXP:");
                }
                ShowPlayerDialog(playerid, DIALOG_ADDPROMO_SINGLE_PRIZE_VALUE, DIALOG_STYLE_INPUT,
                    szDialogTitle,
                    szDialogText, "Next", "Cancel"
                );
                return 1;
            }

            PlayerTempPrizes[playerid][currentPrizeIndex][TempPrizeValue] = prizeValue;

            if(prizeType == PRIZE_TYPE_EXP)
            {
                PlayerTempPrizes[playerid][currentPrizeIndex][TempPrizeDuration] = 0;
                PlayerPromoCreationData[playerid][NewPromoCurrentPrizeIndex]++;

                if(PlayerPromoCreationData[playerid][NewPromoCurrentPrizeIndex] < PlayerPromoCreationData[playerid][NewPromoPrizeCount])
                {
                    format(szDialogTitle, sizeof(szDialogTitle), "{FF6347}"SERVER_NAME" {FFFFFF}| Configuring prize %d/%d (Type)",
                        PlayerPromoCreationData[playerid][NewPromoCurrentPrizeIndex] + 1,
                        PlayerPromoCreationData[playerid][NewPromoPrizeCount]);
                    ShowPlayerDialog(playerid, DIALOG_ADDPROMO_SINGLE_PRIZE_TYPE, DIALOG_STYLE_LIST,
                        szDialogTitle,
                        "1. {669900}Money\n2. {669900}Donate\n3. {669900}Vehicle\n4. {669900}EXP",
                        "Select", "Cancel"
                    );
                }
                else
                {
                    ShowPromoCreationConfirmation(playerid);
                }
                return 1;
            }

            ShowPlayerDialog(playerid, DIALOG_ADDPROMO_SINGLE_PRIZE_DURATION, DIALOG_STYLE_LIST,
                szDialogTitle,
                "1. {669900}Temporary (enter hours)\n2. {669900}Permanent (forever)",
                "Select", "Cancel"
            );
            return 1;
        }

        case DIALOG_ADDPROMO_SINGLE_PRIZE_DURATION:
        {
            if(!response)
            {
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Promo code creation canceled.");
                return 1;
            }
            new currentPrizeIndex = PlayerPromoCreationData[playerid][NewPromoCurrentPrizeIndex];
            new durationType = listitem;

            new szDialogTitle[128];

            if(durationType == 0)
            {
                format(szDialogTitle, sizeof(szDialogTitle), "{FF6347}"SERVER_NAME" {FFFFFF}| Configuring prize %d/%d (Duration)",
                    currentPrizeIndex + 1,
                    PlayerPromoCreationData[playerid][NewPromoPrizeCount]);

                ShowPlayerDialog(playerid, DIALOG_ADDPROMO_SINGLE_PRIZE_DURATION_HOURS, DIALOG_STYLE_INPUT,
                    szDialogTitle,
                    "Enter duration of the prize in hours:", "Next", "Cancel"
                );
                return 1;
            }
            else
            {
                PlayerTempPrizes[playerid][currentPrizeIndex][TempPrizeDuration] = 0;

                PlayerPromoCreationData[playerid][NewPromoCurrentPrizeIndex]++;
                if(PlayerPromoCreationData[playerid][NewPromoCurrentPrizeIndex] < PlayerPromoCreationData[playerid][NewPromoPrizeCount])
                {
                    format(szDialogTitle, sizeof(szDialogTitle), "{FF6347}"SERVER_NAME" {FFFFFF}| Configuring prize %d/%d (Type)",
                        PlayerPromoCreationData[playerid][NewPromoCurrentPrizeIndex] + 1,
                        PlayerPromoCreationData[playerid][NewPromoPrizeCount]);

                    ShowPlayerDialog(playerid, DIALOG_ADDPROMO_SINGLE_PRIZE_TYPE, DIALOG_STYLE_LIST,
                        szDialogTitle,
                        "1. {669900}Money\n2. {669900}Donate\n3. {669900}Vehicle\n4. {669900}EXP",
                        "Select", "Cancel"
                    );
                }
                else
                {
                    ShowPromoCreationConfirmation(playerid);
                }
                return 1;
            }
        }

        case DIALOG_ADDPROMO_SINGLE_PRIZE_DURATION_HOURS:
        {
            if(!response)
            {
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Promo code creation canceled.");
                return 1;
            }
            new currentPrizeIndex = PlayerPromoCreationData[playerid][NewPromoCurrentPrizeIndex];
            new durationHours = strval(inputtext);

            new szDialogTitle[128];

            if(durationHours <= 0)
            {
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Duration in hours must be a positive number.");

                format(szDialogTitle, sizeof(szDialogTitle), "{FF6347}"SERVER_NAME" {FFFFFF}| Configuring prize %d/%d (Duration)",
                    currentPrizeIndex + 1,
                    PlayerPromoCreationData[playerid][NewPromoPrizeCount]);

                ShowPlayerDialog(playerid, DIALOG_ADDPROMO_SINGLE_PRIZE_DURATION_HOURS, DIALOG_STYLE_INPUT,
                    szDialogTitle,
                    "Enter duration of the prize in hours:", "Next", "Cancel"
                );
                return 1;
            }
            PlayerTempPrizes[playerid][currentPrizeIndex][TempPrizeDuration] = durationHours;

            PlayerPromoCreationData[playerid][NewPromoCurrentPrizeIndex]++;
            if(PlayerPromoCreationData[playerid][NewPromoCurrentPrizeIndex] < PlayerPromoCreationData[playerid][NewPromoPrizeCount])
            {
                format(szDialogTitle, sizeof(szDialogTitle), "{FF6347}"SERVER_NAME" {FFFFFF}| Configuring prize %d/%d",
                    PlayerPromoCreationData[playerid][NewPromoCurrentPrizeIndex] + 1,
                    PlayerPromoCreationData[playerid][NewPromoPrizeCount]);

                ShowPlayerDialog(playerid, DIALOG_ADDPROMO_SINGLE_PRIZE_TYPE, DIALOG_STYLE_LIST,
                    szDialogTitle,
                    "1. {669900}Money\n2. {669900}Donate\n3. {669900}Vehicle\n4. {669900}EXP",
                    "Select", "Cancel"
                );
            }
            else
            {
                ShowPromoCreationConfirmation(playerid);
            }
            return 1;
        }

        case DIALOG_CONFIRM_PROMO_CREATION:
        {
            if(response)
            {
                CreatePromoCodeInDatabase(playerid);
            }
            else
            {
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Promo code creation canceled.");
            }
            return 1;
        }

case DIALOG_APPLY_PROMO_CODE:
{
    if(!response)
    {
        SendClientMessage(playerid, -1, "{ff2400}| {ffffff}You canceled entering the promo code.");
        return 1;
    }
    if(strlen(inputtext) == 0)
    {
        SendClientMessage(playerid, -1, "{ff2400}| {ffffff}You didn't enter a promo code. Please try again.");
        callcmd::bcode(playerid, "");
        return 1;
    }
    new promoData[E_PROMO_DATA];

    new accountId = GetPlayerAccountID(playerid);
    //new promoSqlId = promoData[PromoID]; stopped working + complex Werton
    new query[286];
    new Cache:result;

    mysql_format(mysql, query, sizeof(query), "SELECT * FROM `promocodes` WHERE `code` = '%s' LIMIT 1", inputtext);
    result = mysql_query(mysql, query, true);

    if(mysql_errno() != 0)
    {
        SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Error: MySQL errno");
        return 1;
    }

    if(cache_num_rows(result) == 0)
    {
        SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Error: Promo code not found.");
        cache_delete(result);
        callcmd::bcode(playerid, "");
    }

    new promoSqlId = cache_get_field_content_int(0, "id");
    new ownerAccountId = cache_get_field_content_int(0, "creator_account_id");
    new level = cache_get_field_content_int(0, "promo_level");
    new activations = cache_get_field_content_int(0, "activations");
    new promo_balance = cache_get_field_content_int(0, "promo_balance");

    cache_delete(result);

    if(level == 0)
    {
        SendClientMessage(playerid, -1, "{ff2400}| {ffffff}This promo code cannot be used because it is not configured and its level is 0.");
        return 1;
    }

    if(ownerAccountId == accountId)
    {
        SendClientMessage(playerid, -1, "{ff2400}| {ffffff}You cannot use your own promo code.");
        callcmd::bcode(playerid, "");
        return 1;
    }

    cache_delete(result);

    if(GetPromoCodeDataByString(inputtext, promoData))
    {
        if(promoData[UsesLeft] > 0 || promoData[PromoUses] == 0)
        {
            mysql_format(mysql, query, sizeof(query), "SELECT 1 FROM player_promos pp JOIN promo_prizes ppz ON pp.promo_prize_sql_id = ppz.id WHERE pp.account_id = %d AND ppz.promo_id = %d LIMIT 1", accountId, promoSqlId);
            result = mysql_query(mysql, query, true);

            if(cache_num_rows(result) > 0)
            {
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}You have already used this promo code.");
                cache_delete(result);
                return 1;
            }
            cache_delete(result);

            // additional check just in case, verton worries about the database
            mysql_format(mysql, query, sizeof(query), "SELECT 1 FROM `activated_promos` WHERE `account_id` = %d AND `promo_id` = %d LIMIT 1", accountId, promoSqlId);
            result = mysql_query(mysql, query);

            if(cache_num_rows(result) > 0)
            {
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}You have already used this promo code.");
                cache_delete(result);
                return 1;
            }
            cache_delete(result);

            new szActivationMessage[1024];
            format(szActivationMessage, sizeof(szActivationMessage), "{ffffff}Congratulations!\n\n{ffffff}You activated promo code: {ffff00}%s\n\n", inputtext);
            strcat(szActivationMessage, "{ffffff}You received:\n");

            mysql_format(mysql, query, sizeof(query), "SELECT id, prize_type, prize_value, prize_duration FROM promo_prizes WHERE promo_id = %d ORDER BY prize_index ASC", promoSqlId);
            result = mysql_query(mysql, query, true);

            if(mysql_errno() != 0 || cache_num_rows(result) == 0)
            {
                SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Error: Could not load prizes for this promo code. Report to administration.");
                printf("[WERTON_PROMO] Error loading prizes for promo code ID %d: %d", promoSqlId, mysql_errno());
                cache_delete(result);
                return 1;
            }

            new rows = cache_num_rows(result);
            new szDurationText[64];

            new prizeSqlId = 0;
            new prizeType = 0;
            new prizeValue = 0;
            new prizeDuration = 0;

            new prizeSqlId2 = 0;
            new prizeType2 = 0;
            new prizeValue2 = 0;
            new prizeDuration2 = 0;

            new prizeSqlId3 = 0;
            new prizeType3 = 0;
            new prizeValue3 = 0;
            new prizeDuration3 = 0;

            new prizeSqlId4 = 0;
            new prizeType4 = 0;
            new prizeValue4 = 0;
            new prizeDuration4 = 0;

            new prizeSqlId5 = 0;
            new prizeType5 = 0;
            new prizeValue5 = 0;
            new prizeDuration5 = 0;

            if(rows == 1)
            {
                prizeSqlId = cache_get_field_content_int(0, "id");
                prizeType = cache_get_field_content_int(0, "prize_type");
                prizeValue = cache_get_field_content_int(0, "prize_value");
                prizeDuration = cache_get_field_content_int(0, "prize_duration");

                new currentPrizeMsg[256];
                new carName[64];

                if(prizeDuration == 0) {
                    format(szDurationText, sizeof(szDurationText), " (permanent)");
                } else {
                    format(szDurationText, sizeof(szDurationText), " {ffffff}for {ffff00}%d {ffffff}h.", prizeDuration);
                }

                switch (prizeType)
                {
                    case PRIZE_TYPE_MONEY:
                    {
                        GivePlayerMoneyEx(playerid, prizeValue);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d rub.%s\n", prizeValue, szDurationText);
                    }
                    case PRIZE_TYPE_DONATE:
                    {
                        GivePlayerDonateRub(playerid, prizeValue);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d donate%s\n", prizeValue, szDurationText);
                    }
                    case PRIZE_TYPE_CAR:
                    {
                        GivePromoCar(playerid, prizeValue, promoSqlId);
                        new model_name[128], msg[512];
                        GetVehicleModelName(prizeValue, model_name, sizeof(model_name));
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- Vehicle: {ffff00}%s (model ID: %d)%s\n", model_name, prizeValue, szDurationText);
                        format(msg, sizeof(msg), "and received %s", model_name);
                        //ShowPlayerPrizeGUI(playerid, prizeValue, msg, "You activated promo code", 7, 30.0, 180.0, 15.0, 0.750);
                    }
                    case PRIZE_TYPE_EXP:
                    {
                        AddPlayerData(playerid, P_EXP, +, prizeValue);
                        UpdatePlayerDatabaseInt(playerid, "exp", GetPlayerData(playerid, P_EXP));
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d EXP\n", prizeValue);
                    }
                }
                strcat(szActivationMessage, currentPrizeMsg);

                new Cache:insertResult;
                mysql_format(mysql, query, sizeof(query),
                    "INSERT INTO `player_promos` (`account_id`, `promo_prize_sql_id`, `start_time`, `remaining_time`) VALUES (%d, %d, %d, %d)",
                    accountId, prizeSqlId, gettime(), prizeDuration * 3600);
                insertResult = mysql_query(mysql, query, true);
                if(mysql_errno() != 0)
                {
                    printf("[WERTON_PROMO] Error recording activation of prize %d for player %d: %d", prizeSqlId, accountId, mysql_errno());
                }
                else
                {
                    new playerPromoEntryID = cache_insert_id(insertResult);

                    if(prizeDuration > 0)
                    {
                        SetPlayerPromoTimer(playerid, playerPromoEntryID, prizeDuration);
                    }
                }
                cache_delete(insertResult);
            }
            else if(rows == 2)
            {
                prizeSqlId = cache_get_field_content_int(0, "id");
                prizeType = cache_get_field_content_int(0, "prize_type");
                prizeValue = cache_get_field_content_int(0, "prize_value");
                prizeDuration = cache_get_field_content_int(0, "prize_duration");

                prizeSqlId2 = cache_get_field_content_int(1, "id");
                prizeType2 = cache_get_field_content_int(1, "prize_type");
                prizeValue2 = cache_get_field_content_int(1, "prize_value");
                prizeDuration2 = cache_get_field_content_int(1, "prize_duration");

                new currentPrizeMsg[256];

                if(prizeDuration == 0) {
                    format(szDurationText, sizeof(szDurationText), " (permanent)");
                } else {
                    format(szDurationText, sizeof(szDurationText), " {ffffff}for {ffff00}%d {ffffff}h.", prizeDuration);
                }

                switch (prizeType)
                {
                    case PRIZE_TYPE_MONEY:
                    {
                        GivePlayerMoneyEx(playerid, prizeValue);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d rub.%s\n", prizeValue, szDurationText);
                    }
                    case PRIZE_TYPE_DONATE:
                    {
                        GivePlayerDonateRub(playerid, prizeValue);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d donate%s\n", prizeValue, szDurationText);
                    }
                    case PRIZE_TYPE_CAR:
                    {
                        GivePromoCar(playerid, prizeValue, promoSqlId);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- Vehicle: {ffff00}%s (model ID: %d)%s\n", GetVehicleInfo(prizeValue - 400, VI_NAME), prizeValue, szDurationText);
                    }
                    case PRIZE_TYPE_EXP:
                    {
                        AddPlayerData(playerid, P_EXP, +, prizeValue);
                        UpdatePlayerDatabaseInt(playerid, "exp", GetPlayerData(playerid, P_EXP));
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d EXP\n", prizeValue);
                    }
                }
                strcat(szActivationMessage, currentPrizeMsg);

                new Cache:insertResult;
                mysql_format(mysql, query, sizeof(query),
                    "INSERT INTO `player_promos` (`account_id`, `promo_prize_sql_id`, `start_time`, `remaining_time`) VALUES (%d, %d, %d, %d)",
                    accountId, prizeSqlId, gettime(), prizeDuration * 3600);
                insertResult = mysql_query(mysql, query, true);
                if(mysql_errno() != 0)
                {
                    printf("[WERTON_PROMO] Error recording activation of prize %d for player %d: %d", prizeSqlId, accountId, mysql_errno());
                }
                else
                {
                    new playerPromoEntryID = cache_insert_id(insertResult);
                    if(prizeDuration > 0)
                    {
                        SetPlayerPromoTimer(playerid, playerPromoEntryID, prizeDuration);
                    }
                }
                cache_delete(insertResult);
                //prize 2

                if(prizeDuration2 == 0) {
                    format(szDurationText, sizeof(szDurationText), " (permanent)");
                } else {
                    format(szDurationText, sizeof(szDurationText), " {ffffff}for {ffff00}%d {ffffff}h.", prizeDuration2);
                }

                switch (prizeType2)
                {
                    case PRIZE_TYPE_MONEY:
                    {
                        GivePlayerMoneyEx(playerid, prizeValue2);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d rub.%s\n", prizeValue2, szDurationText);
                    }
                    case PRIZE_TYPE_DONATE:
                    {
                        GivePlayerDonateRub(playerid, prizeValue2);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d donate%s\n", prizeValue2, szDurationText);
                    }
                    case PRIZE_TYPE_CAR:
                    {
                        GivePromoCar(playerid, prizeValue2, promoSqlId);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- Vehicle: {ffff00}%s (model ID: %d)%s\n", GetVehicleInfo(prizeValue2 - 400, VI_NAME), prizeValue2, szDurationText);
                    }
                    case PRIZE_TYPE_EXP:
                    {
                        AddPlayerData(playerid, P_EXP, +, prizeValue);
                        UpdatePlayerDatabaseInt(playerid, "exp", GetPlayerData(playerid, P_EXP));
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d EXP\n", prizeValue);
                    }
                }
                strcat(szActivationMessage, currentPrizeMsg);

                mysql_format(mysql, query, sizeof(query),
                    "INSERT INTO `player_promos` (`account_id`, `promo_prize_sql_id`, `start_time`, `remaining_time`) VALUES (%d, %d, %d, %d)",
                    accountId, prizeSqlId2, gettime(), prizeDuration2 * 3600);
                insertResult = mysql_query(mysql, query, true);
                if(mysql_errno() != 0)
                {
                    printf("[WERTON_PROMO] Error recording activation of prize %d for player %d: %d", prizeSqlId2, accountId, mysql_errno());
                }
                else
                {
                    new playerPromoEntryID = cache_insert_id(insertResult);
                    if(prizeDuration2 > 0)
                    {
                        SetPlayerPromoTimer(playerid, playerPromoEntryID, prizeDuration2);
                    }
                }
                cache_delete(insertResult);
            }
            else if(rows == 3)
            {
                prizeSqlId = cache_get_field_content_int(0, "id");
                prizeType = cache_get_field_content_int(0, "prize_type");
                prizeValue = cache_get_field_content_int(0, "prize_value");
                prizeDuration = cache_get_field_content_int(0, "prize_duration");

                prizeSqlId2 = cache_get_field_content_int(1, "id");
                prizeType2 = cache_get_field_content_int(1, "prize_type");
                prizeValue2 = cache_get_field_content_int(1, "prize_value");
                prizeDuration2 = cache_get_field_content_int(1, "prize_duration");

                prizeSqlId3 = cache_get_field_content_int(2, "id");
                prizeType3 = cache_get_field_content_int(2, "prize_type");
                prizeValue3 = cache_get_field_content_int(2, "prize_value");
                prizeDuration3 = cache_get_field_content_int(2, "prize_duration");

                new currentPrizeMsg[256];

                if(prizeDuration == 0) {
                    format(szDurationText, sizeof(szDurationText), " (permanent)");
                } else {
                    format(szDurationText, sizeof(szDurationText), " {ffffff}for {ffff00}%d {ffffff}h.", prizeDuration);
                }

                switch (prizeType)
                {
                    case PRIZE_TYPE_MONEY:
                    {
                        GivePlayerMoneyEx(playerid, prizeValue);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d rub.%s\n", prizeValue, szDurationText);
                    }
                    case PRIZE_TYPE_DONATE:
                    {
                        GivePlayerDonateRub(playerid, prizeValue);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d donate%s\n", prizeValue, szDurationText);
                    }
                    case PRIZE_TYPE_CAR:
                    {
                        GivePromoCar(playerid, prizeValue, promoSqlId);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- Vehicle: {ffff00}%s (model ID: %d)%s\n", GetVehicleInfo(prizeValue - 400, VI_NAME), prizeValue, szDurationText);
                    }
                    case PRIZE_TYPE_EXP:
                    {
                        AddPlayerData(playerid, P_EXP, +, prizeValue);
                        UpdatePlayerDatabaseInt(playerid, "exp", GetPlayerData(playerid, P_EXP));
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d EXP\n", prizeValue);
                    }
                }
                strcat(szActivationMessage, currentPrizeMsg);

                new Cache:insertResult;
                mysql_format(mysql, query, sizeof(query),
                    "INSERT INTO `player_promos` (`account_id`, `promo_prize_sql_id`, `start_time`, `remaining_time`) VALUES (%d, %d, %d, %d)",
                    accountId, prizeSqlId, gettime(), prizeDuration * 3600);
                insertResult = mysql_query(mysql, query, true);
                if(mysql_errno() != 0)
                {
                    printf("[WERTON_PROMO] Error recording activation of prize %d for player %d: %d", prizeSqlId, accountId, mysql_errno());
                }
                else
                {
                    new playerPromoEntryID = cache_insert_id(insertResult);
                    if(prizeDuration > 0)
                    {
                        SetPlayerPromoTimer(playerid, playerPromoEntryID, prizeDuration);
                    }
                }
                cache_delete(insertResult);
                //prize 2

                if(prizeDuration2 == 0) {
                    format(szDurationText, sizeof(szDurationText), " (permanent)");
                } else {
                    format(szDurationText, sizeof(szDurationText), " {ffffff}for {ffff00}%d {ffffff}h.", prizeDuration2);
                }

                switch (prizeType2)
                {
                    case PRIZE_TYPE_MONEY:
                    {
                        GivePlayerMoneyEx(playerid, prizeValue2);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d rub.%s\n", prizeValue2, szDurationText);
                    }
                    case PRIZE_TYPE_DONATE:
                    {
                        GivePlayerDonateRub(playerid, prizeValue2);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d donate%s\n", prizeValue2, szDurationText);
                    }
                    case PRIZE_TYPE_CAR:
                    {
                        GivePromoCar(playerid, prizeValue2, promoSqlId);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- Vehicle: {ffff00}%s (model ID: %d)%s\n", GetVehicleInfo(prizeValue2 - 400, VI_NAME), prizeValue2, szDurationText);
                    }
                    case PRIZE_TYPE_EXP:
                    {
                        AddPlayerData(playerid, P_EXP, +, prizeValue);
                        UpdatePlayerDatabaseInt(playerid, "exp", GetPlayerData(playerid, P_EXP));
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d EXP\n", prizeValue);
                    }
                }
                strcat(szActivationMessage, currentPrizeMsg);

                mysql_format(mysql, query, sizeof(query),
                    "INSERT INTO `player_promos` (`account_id`, `promo_prize_sql_id`, `start_time`, `remaining_time`) VALUES (%d, %d, %d, %d)",
                    accountId, prizeSqlId2, gettime(), prizeDuration2 * 3600);
                insertResult = mysql_query(mysql, query, true);
                if(mysql_errno() != 0)
                {
                    printf("[WERTON_PROMO] Error recording activation of prize %d for player %d: %d", prizeSqlId2, accountId, mysql_errno());
                }
                else
                {
                    new playerPromoEntryID = cache_insert_id(insertResult);
                    if(prizeDuration2 > 0)
                    {
                        SetPlayerPromoTimer(playerid, playerPromoEntryID, prizeDuration2);
                    }
                }
                cache_delete(insertResult);

                //prize 3

                if(prizeDuration3 == 0) {
                    format(szDurationText, sizeof(szDurationText), " (permanent)");
                } else {
                    format(szDurationText, sizeof(szDurationText), " {ffffff}for {ffff00}%d {ffffff}h.", prizeDuration3);
                }

                switch (prizeType3)
                {
                    case PRIZE_TYPE_MONEY:
                    {
                        GivePlayerMoneyEx(playerid, prizeValue3);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d rub.%s\n", prizeValue3, szDurationText);
                    }
                    case PRIZE_TYPE_DONATE:
                    {
                        GivePlayerDonateRub(playerid, prizeValue3);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d donate%s\n", prizeValue3, szDurationText);
                    }
                    case PRIZE_TYPE_CAR:
                    {
                        GivePromoCar(playerid, prizeValue3, promoSqlId);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- Vehicle: {ffff00}%s (model ID: %d)%s\n", GetVehicleInfo(prizeValue3 - 400, VI_NAME), prizeValue3, szDurationText);
                    }
                    case PRIZE_TYPE_EXP:
                    {
                        AddPlayerData(playerid, P_EXP, +, prizeValue);
                        UpdatePlayerDatabaseInt(playerid, "exp", GetPlayerData(playerid, P_EXP));
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d EXP\n", prizeValue);
                    }
                }
                strcat(szActivationMessage, currentPrizeMsg);

                mysql_format(mysql, query, sizeof(query),
                    "INSERT INTO `player_promos` (`account_id`, `promo_prize_sql_id`, `start_time`, `remaining_time`) VALUES (%d, %d, %d, %d)",
                    accountId, prizeSqlId3, gettime(), prizeDuration3 * 3600);
                insertResult = mysql_query(mysql, query, true);
                if(mysql_errno() != 0)
                {
                    printf("[WERTON_PROMO] Error recording activation of prize %d for player %d: %d", prizeSqlId3, accountId, mysql_errno());
                }
                else
                {
                    new playerPromoEntryID = cache_insert_id(insertResult);
                    if(prizeDuration3 > 0)
                    {
                        SetPlayerPromoTimer(playerid, playerPromoEntryID, prizeDuration3);
                    }
                }
                cache_delete(insertResult);
            }
            else if(rows == 4)
            {
                prizeSqlId = cache_get_field_content_int(0, "id");
                prizeType = cache_get_field_content_int(0, "prize_type");
                prizeValue = cache_get_field_content_int(0, "prize_value");
                prizeDuration = cache_get_field_content_int(0, "prize_duration");

                prizeSqlId2 = cache_get_field_content_int(1, "id");
                prizeType2 = cache_get_field_content_int(1, "prize_type");
                prizeValue2 = cache_get_field_content_int(1, "prize_value");
                prizeDuration2 = cache_get_field_content_int(1, "prize_duration");

                prizeSqlId3 = cache_get_field_content_int(2, "id");
                prizeType3 = cache_get_field_content_int(2, "prize_type");
                prizeValue3 = cache_get_field_content_int(2, "prize_value");
                prizeDuration3 = cache_get_field_content_int(2, "prize_duration");

                prizeSqlId4 = cache_get_field_content_int(3, "id");
                prizeType4 = cache_get_field_content_int(3, "prize_type");
                prizeValue4 = cache_get_field_content_int(3, "prize_value");
                prizeDuration4 = cache_get_field_content_int(3, "prize_duration");

                prizeSqlId = cache_get_field_content_int(0, "id");
                prizeType = cache_get_field_content_int(0, "prize_type");
                prizeValue = cache_get_field_content_int(0, "prize_value");
                prizeDuration = cache_get_field_content_int(0, "prize_duration");

                prizeSqlId2 = cache_get_field_content_int(1, "id");
                prizeType2 = cache_get_field_content_int(1, "prize_type");
                prizeValue2 = cache_get_field_content_int(1, "prize_value");
                prizeDuration2 = cache_get_field_content_int(1, "prize_duration");

                prizeSqlId3 = cache_get_field_content_int(2, "id");
                prizeType3 = cache_get_field_content_int(2, "prize_type");
                prizeValue3 = cache_get_field_content_int(2, "prize_value");
                prizeDuration3 = cache_get_field_content_int(2, "prize_duration");

                new currentPrizeMsg[256];

                if(prizeDuration == 0) {
                    format(szDurationText, sizeof(szDurationText), " (permanent)");
                } else {
                    format(szDurationText, sizeof(szDurationText), " {ffffff}for {ffff00}%d {ffffff}h.", prizeDuration);
                }

                switch (prizeType)
                {
                    case PRIZE_TYPE_MONEY:
                    {
                        GivePlayerMoneyEx(playerid, prizeValue);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d rub.%s\n", prizeValue, szDurationText);
                    }
                    case PRIZE_TYPE_DONATE:
                    {
                        GivePlayerDonateRub(playerid, prizeValue);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d donate%s\n", prizeValue, szDurationText);
                    }
                    case PRIZE_TYPE_CAR:
                    {
                        GivePromoCar(playerid, prizeValue, promoSqlId);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- Vehicle: {ffff00}%s (model ID: %d)%s\n", GetVehicleInfo(prizeValue - 400, VI_NAME), prizeValue, szDurationText);
                    }
                    case PRIZE_TYPE_EXP:
                    {
                        AddPlayerData(playerid, P_EXP, +, prizeValue);
                        UpdatePlayerDatabaseInt(playerid, "exp", GetPlayerData(playerid, P_EXP));
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d EXP\n", prizeValue);
                    }
                }
                strcat(szActivationMessage, currentPrizeMsg);

                new Cache:insertResult;
                mysql_format(mysql, query, sizeof(query),
                    "INSERT INTO `player_promos` (`account_id`, `promo_prize_sql_id`, `start_time`, `remaining_time`) VALUES (%d, %d, %d, %d)",
                    accountId, prizeSqlId, gettime(), prizeDuration * 3600);
                insertResult = mysql_query(mysql, query, true);
                if(mysql_errno() != 0)
                {
                    printf("[WERTON_PROMO] Error recording activation of prize %d for player %d: %d", prizeSqlId, accountId, mysql_errno());
                }
                else
                {
                    new playerPromoEntryID = cache_insert_id(insertResult);
                    if(prizeDuration > 0)
                    {
                        SetPlayerPromoTimer(playerid, playerPromoEntryID, prizeDuration);
                    }
                }
                cache_delete(insertResult);
                //prize 2

                if(prizeDuration2 == 0) {
                    format(szDurationText, sizeof(szDurationText), " (permanent)");
                } else {
                    format(szDurationText, sizeof(szDurationText), " {ffffff}for {ffff00}%d {ffffff}h.", prizeDuration2);
                }

                switch (prizeType2)
                {
                    case PRIZE_TYPE_MONEY:
                    {
                        GivePlayerMoneyEx(playerid, prizeValue2);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d rub.%s\n", prizeValue2, szDurationText);
                    }
                    case PRIZE_TYPE_DONATE:
                    {
                        GivePlayerDonateRub(playerid, prizeValue2);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d donate%s\n", prizeValue2, szDurationText);
                    }
                    case PRIZE_TYPE_CAR:
                    {
                        GivePromoCar(playerid, prizeValue2, promoSqlId);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- Vehicle: {ffff00}%s (model ID: %d)%s\n", GetVehicleInfo(prizeValue2 - 400, VI_NAME), prizeValue2, szDurationText);
                    }
                    case PRIZE_TYPE_EXP:
                    {
                        AddPlayerData(playerid, P_EXP, +, prizeValue);
                        UpdatePlayerDatabaseInt(playerid, "exp", GetPlayerData(playerid, P_EXP));
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d EXP\n", prizeValue);
                    }
                }
                strcat(szActivationMessage, currentPrizeMsg);

                mysql_format(mysql, query, sizeof(query),
                    "INSERT INTO `player_promos` (`account_id`, `promo_prize_sql_id`, `start_time`, `remaining_time`) VALUES (%d, %d, %d, %d)",
                    accountId, prizeSqlId2, gettime(), prizeDuration2 * 3600);
                insertResult = mysql_query(mysql, query, true);
                if(mysql_errno() != 0)
                {
                    printf("[WERTON_PROMO] Error recording activation of prize %d for player %d: %d", prizeSqlId2, accountId, mysql_errno());
                }
                else
                {
                    new playerPromoEntryID = cache_insert_id(insertResult);
                    if(prizeDuration2 > 0)
                    {
                        SetPlayerPromoTimer(playerid, playerPromoEntryID, prizeDuration2);
                    }
                }
                cache_delete(insertResult);

                //prize 3

                if(prizeDuration3 == 0) {
                    format(szDurationText, sizeof(szDurationText), " (permanent)");
                } else {
                    format(szDurationText, sizeof(szDurationText), " {ffffff}for {ffff00}%d {ffffff}h.", prizeDuration3);
                }

                switch (prizeType3)
                {
                    case PRIZE_TYPE_MONEY:
                    {
                        GivePlayerMoneyEx(playerid, prizeValue3);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d rub.%s\n", prizeValue3, szDurationText);
                    }
                    case PRIZE_TYPE_DONATE:
                    {
                        GivePlayerDonateRub(playerid, prizeValue3);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d donate%s\n", prizeValue3, szDurationText);
                    }
                    case PRIZE_TYPE_CAR:
                    {
                        GivePromoCar(playerid, prizeValue3, promoSqlId);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- Vehicle: {ffff00}%s (model ID: %d)%s\n", GetVehicleInfo(prizeValue3 - 400, VI_NAME), prizeValue3, szDurationText);
                    }
                    case PRIZE_TYPE_EXP:
                    {
                        AddPlayerData(playerid, P_EXP, +, prizeValue);
                        UpdatePlayerDatabaseInt(playerid, "exp", GetPlayerData(playerid, P_EXP));
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d EXP\n", prizeValue);
                    }
                }
                strcat(szActivationMessage, currentPrizeMsg);

                mysql_format(mysql, query, sizeof(query),
                    "INSERT INTO `player_promos` (`account_id`, `promo_prize_sql_id`, `start_time`, `remaining_time`) VALUES (%d, %d, %d, %d)",
                    accountId, prizeSqlId3, gettime(), prizeDuration3 * 3600);
                insertResult = mysql_query(mysql, query, true);
                if(mysql_errno() != 0)
                {
                    printf("[WERTON_PROMO] Error recording activation of prize %d for player %d: %d", prizeSqlId3, accountId, mysql_errno());
                }
                else
                {
                    new playerPromoEntryID = cache_insert_id(insertResult);
                    if(prizeDuration3 > 0)
                    {
                        SetPlayerPromoTimer(playerid, playerPromoEntryID, prizeDuration3);
                    }
                }
                cache_delete(insertResult);

                //prize 4

                if(prizeDuration4 == 0) {
                    format(szDurationText, sizeof(szDurationText), " (permanent)");
                } else {
                    format(szDurationText, sizeof(szDurationText), " {ffffff}for {ffff00}%d {ffffff}h.", prizeDuration4);
                }

                switch (prizeType4)
                {
                    case PRIZE_TYPE_MONEY:
                    {
                        GivePlayerMoneyEx(playerid, prizeValue4);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d rub.%s\n", prizeValue4, szDurationText);
                    }
                    case PRIZE_TYPE_DONATE:
                    {
                        GivePlayerDonateRub(playerid, prizeValue4);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d donate%s\n", prizeValue4, szDurationText);
                    }
                    case PRIZE_TYPE_CAR:
                    {
                        GivePromoCar(playerid, prizeValue4, promoSqlId);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- Vehicle: {ffff00}%s (model ID: %d)%s\n", GetVehicleInfo(prizeValue4 - 400, VI_NAME), prizeValue4, szDurationText);
                    }
                    case PRIZE_TYPE_EXP:
                    {
                        AddPlayerData(playerid, P_EXP, +, prizeValue);
                        UpdatePlayerDatabaseInt(playerid, "exp", GetPlayerData(playerid, P_EXP));
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d EXP\n", prizeValue);
                    }
                }
                strcat(szActivationMessage, currentPrizeMsg);

                mysql_format(mysql, query, sizeof(query),
                    "INSERT INTO `player_promos` (`account_id`, `promo_prize_sql_id`, `start_time`, `remaining_time`) VALUES (%d, %d, %d, %d)",
                    accountId, prizeSqlId4, gettime(), prizeDuration4 * 3600);
                insertResult = mysql_query(mysql, query, true);
                if(mysql_errno() != 0)
                {
                    printf("[WERTON_PROMO] Error recording activation of prize %d for player %d: %d", prizeSqlId4, accountId, mysql_errno());
                }
                else
                {
                    new playerPromoEntryID = cache_insert_id(insertResult);
                    if(prizeDuration4 > 0)
                    {
                        SetPlayerPromoTimer(playerid, playerPromoEntryID, prizeDuration4);
                    }
                }
                cache_delete(insertResult);
            }
            else if(rows == 5)
            {
                prizeSqlId = cache_get_field_content_int(0, "id");
                prizeType = cache_get_field_content_int(0, "prize_type");
                prizeValue = cache_get_field_content_int(0, "prize_value");
                prizeDuration = cache_get_field_content_int(0, "prize_duration");

                prizeSqlId2 = cache_get_field_content_int(1, "id");
                prizeType2 = cache_get_field_content_int(1, "prize_type");
                prizeValue2 = cache_get_field_content_int(1, "prize_value");
                prizeDuration2 = cache_get_field_content_int(1, "prize_duration");

                prizeSqlId3 = cache_get_field_content_int(2, "id");
                prizeType3 = cache_get_field_content_int(2, "prize_type");
                prizeValue3 = cache_get_field_content_int(2, "prize_value");
                prizeDuration3 = cache_get_field_content_int(2, "prize_duration");

                prizeSqlId4 = cache_get_field_content_int(3, "id");
                prizeType4 = cache_get_field_content_int(3, "prize_type");
                prizeValue4 = cache_get_field_content_int(3, "prize_value");
                prizeDuration4 = cache_get_field_content_int(3, "prize_duration");

                prizeSqlId5 = cache_get_field_content_int(4, "id");
                prizeType5 = cache_get_field_content_int(4, "prize_type");
                prizeValue5 = cache_get_field_content_int(4, "prize_value");
                prizeDuration5 = cache_get_field_content_int(4, "prize_duration");

                new currentPrizeMsg[256];

                if(prizeDuration == 0) {
                    format(szDurationText, sizeof(szDurationText), " (permanent)");
                } else {
                    format(szDurationText, sizeof(szDurationText), " {ffffff}for {ffff00}%d {ffffff}h.", prizeDuration);
                }

                switch (prizeType)
                {
                    case PRIZE_TYPE_MONEY:
                    {
                        GivePlayerMoneyEx(playerid, prizeValue);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d rub.%s\n", prizeValue, szDurationText);
                    }
                    case PRIZE_TYPE_DONATE:
                    {
                        GivePlayerDonateRub(playerid, prizeValue);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d donate%s\n", prizeValue, szDurationText);
                    }
                    case PRIZE_TYPE_CAR:
                    {
                        GivePromoCar(playerid, prizeValue, promoSqlId);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- Vehicle: {ffff00}%s (model ID: %d)%s\n", GetVehicleInfo(prizeValue - 400, VI_NAME), prizeValue, szDurationText);
                    }
                    case PRIZE_TYPE_EXP:
                    {
                        AddPlayerData(playerid, P_EXP, +, prizeValue);
                        UpdatePlayerDatabaseInt(playerid, "exp", GetPlayerData(playerid, P_EXP));
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d EXP\n", prizeValue);
                    }
                }
                strcat(szActivationMessage, currentPrizeMsg);

                new Cache:insertResult;
                mysql_format(mysql, query, sizeof(query),
                    "INSERT INTO `player_promos` (`account_id`, `promo_prize_sql_id`, `start_time`, `remaining_time`) VALUES (%d, %d, %d, %d)",
                    accountId, prizeSqlId, gettime(), prizeDuration * 3600);
                insertResult = mysql_query(mysql, query, true);
                if(mysql_errno() != 0)
                {
                    printf("[WERTON_PROMO] Error recording activation of prize %d for player %d: %d", prizeSqlId, accountId, mysql_errno());
                }
                else
                {
                    new playerPromoEntryID = cache_insert_id(insertResult);
                    if(prizeDuration > 0)
                    {
                        SetPlayerPromoTimer(playerid, playerPromoEntryID, prizeDuration);
                    }
                }
                cache_delete(insertResult);
                //prize 2

                if(prizeDuration2 == 0) {
                    format(szDurationText, sizeof(szDurationText), " (permanent)");
                } else {
                    format(szDurationText, sizeof(szDurationText), " {ffffff}for {ffff00}%d {ffffff}h.", prizeDuration2);
                }

                switch (prizeType2)
                {
                    case PRIZE_TYPE_MONEY:
                    {
                        GivePlayerMoneyEx(playerid, prizeValue2);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d rub.%s\n", prizeValue2, szDurationText);
                    }
                    case PRIZE_TYPE_DONATE:
                    {
                        GivePlayerDonateRub(playerid, prizeValue2);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d donate%s\n", prizeValue2, szDurationText);
                    }
                    case PRIZE_TYPE_CAR:
                    {
                        GivePromoCar(playerid, prizeValue2, promoSqlId);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- Vehicle: {ffff00}%s (model ID: %d)%s\n", GetVehicleInfo(prizeValue2 - 400, VI_NAME), prizeValue2, szDurationText);
                    }
                    case PRIZE_TYPE_EXP:
                    {
                        AddPlayerData(playerid, P_EXP, +, prizeValue);
                        UpdatePlayerDatabaseInt(playerid, "exp", GetPlayerData(playerid, P_EXP));
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d EXP\n", prizeValue);
                    }
                }
                strcat(szActivationMessage, currentPrizeMsg);

                mysql_format(mysql, query, sizeof(query),
                    "INSERT INTO `player_promos` (`account_id`, `promo_prize_sql_id`, `start_time`, `remaining_time`) VALUES (%d, %d, %d, %d)",
                    accountId, prizeSqlId2, gettime(), prizeDuration2 * 3600);
                insertResult = mysql_query(mysql, query, true);
                if(mysql_errno() != 0)
                {
                    printf("[WERTON_PROMO] Error recording activation of prize %d for player %d: %d", prizeSqlId2, accountId, mysql_errno());
                }
                else
                {
                    new playerPromoEntryID = cache_insert_id(insertResult);
                    if(prizeDuration2 > 0)
                    {
                        SetPlayerPromoTimer(playerid, playerPromoEntryID, prizeDuration2);
                    }
                }
                cache_delete(insertResult);

                //prize 3

                if(prizeDuration3 == 0) {
                    format(szDurationText, sizeof(szDurationText), " (permanent)");
                } else {
                    format(szDurationText, sizeof(szDurationText), " {ffffff}for {ffff00}%d {ffffff}h.", prizeDuration3);
                }

                switch (prizeType3)
                {
                    case PRIZE_TYPE_MONEY:
                    {
                        GivePlayerMoneyEx(playerid, prizeValue3);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d rub.%s\n", prizeValue3, szDurationText);
                    }
                    case PRIZE_TYPE_DONATE:
                    {
                        GivePlayerDonateRub(playerid, prizeValue3);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d donate%s\n", prizeValue3, szDurationText);
                    }
                    case PRIZE_TYPE_CAR:
                    {
                        GivePromoCar(playerid, prizeValue3, promoSqlId);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- Vehicle: {ffff00}%s (model ID: %d)%s\n", GetVehicleInfo(prizeValue3 - 400, VI_NAME), prizeValue3, szDurationText);
                    }
                    case PRIZE_TYPE_EXP:
                    {
                        AddPlayerData(playerid, P_EXP, +, prizeValue);
                        UpdatePlayerDatabaseInt(playerid, "exp", GetPlayerData(playerid, P_EXP));
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d EXP\n", prizeValue);
                    }
                }
                strcat(szActivationMessage, currentPrizeMsg);

                mysql_format(mysql, query, sizeof(query),
                    "INSERT INTO `player_promos` (`account_id`, `promo_prize_sql_id`, `start_time`, `remaining_time`) VALUES (%d, %d, %d, %d)",
                    accountId, prizeSqlId3, gettime(), prizeDuration3 * 3600);
                insertResult = mysql_query(mysql, query, true);
                if(mysql_errno() != 0)
                {
                    printf("[WERTON_PROMO] Error recording activation of prize %d for player %d: %d", prizeSqlId3, accountId, mysql_errno());
                }
                else
                {
                    new playerPromoEntryID = cache_insert_id(insertResult);
                    if(prizeDuration3 > 0)
                    {
                        SetPlayerPromoTimer(playerid, playerPromoEntryID, prizeDuration3);
                    }
                }
                cache_delete(insertResult);

                //prize 4

                if(prizeDuration4 == 0) {
                    format(szDurationText, sizeof(szDurationText), " (permanent)");
                } else {
                    format(szDurationText, sizeof(szDurationText), " {ffffff}for {ffff00}%d {ffffff}h.", prizeDuration4);
                }

                switch (prizeType4)
                {
                    case PRIZE_TYPE_MONEY:
                    {
                        GivePlayerMoneyEx(playerid, prizeValue4);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d rub.%s\n", prizeValue4, szDurationText);
                    }
                    case PRIZE_TYPE_DONATE:
                    {
                        GivePlayerDonateRub(playerid, prizeValue4);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d donate%s\n", prizeValue4, szDurationText);
                    }
                    case PRIZE_TYPE_CAR:
                    {
                        GivePromoCar(playerid, prizeValue4, promoSqlId);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- Vehicle: {ffff00}%s (model ID: %d)%s\n", GetVehicleInfo(prizeValue4 - 400, VI_NAME), prizeValue4, szDurationText);
                    }
                    case PRIZE_TYPE_EXP:
                    {
                        AddPlayerData(playerid, P_EXP, +, prizeValue);
                        UpdatePlayerDatabaseInt(playerid, "exp", GetPlayerData(playerid, P_EXP));
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d EXP\n", prizeValue);
                    }
                }
                strcat(szActivationMessage, currentPrizeMsg);

                mysql_format(mysql, query, sizeof(query),
                    "INSERT INTO `player_promos` (`account_id`, `promo_prize_sql_id`, `start_time`, `remaining_time`) VALUES (%d, %d, %d, %d)",
                    accountId, prizeSqlId4, gettime(), prizeDuration4 * 3600);
                insertResult = mysql_query(mysql, query, true);
                if(mysql_errno() != 0)
                {
                    printf("[WERTON_PROMO] Error recording activation of prize %d for player %d: %d", prizeSqlId4, accountId, mysql_errno());
                }
                else
                {
                    new playerPromoEntryID = cache_insert_id(insertResult);
                    if(prizeDuration4 > 0)
                    {
                        SetPlayerPromoTimer(playerid, playerPromoEntryID, prizeDuration4);
                    }
                }
                cache_delete(insertResult);

                //prize 5

                if(prizeDuration4 == 0) {
                    format(szDurationText, sizeof(szDurationText), " (permanent)");
                } else {
                    format(szDurationText, sizeof(szDurationText), " {ffffff}for {ffff00}%d {ffffff}h.", prizeDuration5);
                }

                switch (prizeType5)
                {
                    case PRIZE_TYPE_MONEY:
                    {
                        GivePlayerMoneyEx(playerid, prizeValue5);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d rub.%s\n", prizeValue5, szDurationText);
                    }
                    case PRIZE_TYPE_DONATE:
                    {
                        GivePlayerDonateRub(playerid, prizeValue5);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d donate%s\n", prizeValue5, szDurationText);
                    }
                    case PRIZE_TYPE_CAR:
                    {
                        GivePromoCar(playerid, prizeValue5, promoSqlId);
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- Vehicle: {ffff00}%s (model ID: %d)%s\n", GetVehicleInfo(prizeValue5 - 400, VI_NAME), prizeValue5, szDurationText);
                    }
                    case PRIZE_TYPE_EXP:
                    {
                        AddPlayerData(playerid, P_EXP, +, prizeValue);
                        UpdatePlayerDatabaseInt(playerid, "exp", GetPlayerData(playerid, P_EXP));
                        format(currentPrizeMsg, sizeof(currentPrizeMsg), "{ffffff}- {ffff00}%d EXP\n", prizeValue);
                    }
                }
                strcat(szActivationMessage, currentPrizeMsg);

                mysql_format(mysql, query, sizeof(query),
                    "INSERT INTO `player_promos` (`account_id`, `promo_prize_sql_id`, `start_time`, `remaining_time`) VALUES (%d, %d, %d, %d)",
                    accountId, prizeSqlId5, gettime(), prizeDuration5 * 3600);
                insertResult = mysql_query(mysql, query, true);
                if(mysql_errno() != 0)
                {
                    printf("[WERTON_PROMO] Error recording activation of prize %d for player %d: %d", prizeSqlId5, accountId, mysql_errno());
                }
                else
                {
                    new playerPromoEntryID = cache_insert_id(insertResult);
                    if(prizeDuration5 > 0)
                    {
                        SetPlayerPromoTimer(playerid, playerPromoEntryID, prizeDuration5);
                    }
                }
                cache_delete(insertResult);
            }
            cache_delete(result);

            if(promoData[PromoUses] != 0)
            {
                mysql_format(mysql, query, sizeof(query), "UPDATE promocodes SET uses_left = uses_left - 1 WHERE id = %d", promoSqlId);
                mysql_query(mysql, query, false);

                new index = GetPromoCodeIndexByString(inputtext);
                if(index != -1)
                {
                    PromoCodes[index][UsesLeft]--;
                }
            }

        new money_bonus = 0;

        if(level >= 0 && level <= 10)
        {
            money_bonus = PROMO_LEVEL_DATA[level][4];
        }

        mysql_format(mysql, query, sizeof(query), "UPDATE `promocodes` SET `activations` = `activations` + 1, `promo_balance` = `promo_balance` + %d WHERE `id` = %d", money_bonus, promoSqlId);
        mysql_query(mysql, query);

        new creator_playerid = GetPlayerIDFromAccountID(ownerAccountId);

        if(creator_playerid != -1)
        {
            new message[256];
            format(message, sizeof(message), "{66CC33}| {FFFFFF}Your promo code was just activated! You received {66CC33}%d{FFFFFF} rub. to balance.", money_bonus);
            SendClientMessage(creator_playerid, -1, message);
        }

            ShowPlayerDialog(playerid, DIALOG_PROMO_PRIZE_INFO, DIALOG_STYLE_MSGBOX, "{FF6347}"SERVER_NAME"{ffffff} | Promo code activation", szActivationMessage, "OK", "");
            ShowPlayerPrizeGUI(playerid, 19058, "You received a prize", "CONGRATULATIONS!", 0, 0.0, 180.0, 39.0, 0.9);
            AddPlayerActivatedPromo(GetPlayerAccountID(playerid), promoSqlId);
            return 1;
        }
        else
        {
            SendClientMessage(playerid, -1, "{ff2400}| {ffffff}This promo code is no longer available (uses: 0).");
            return 1;
        }
    }
    else
    {
        SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Invalid promo code.");
        return 1;
    }
}
    }
    #if defined prom_OnDialogResponse
    return prom_OnDialogResponse(playerid, dialogid, response, listitem, inputtext);
#else
    return 1;
#endif
}
#if defined _ALS_OnDialogResponse
#undef OnDialogResponse
#else
#define _ALS_OnDialogResponse
#endif
#define OnDialogResponse prom_OnDialogResponse
#if defined prom_OnDialogResponse
forward prom_OnDialogResponse(playerid, dialogid, response, listitem, inputtext[]);
#endif

// maybe someone needs it, not sure
public CheckUsePromoCode(playerid, accountId, promoSqlId)
{
    new query_test[156];

    mysql_format(mysql, query_test, sizeof(query_test), "SELECT 1 FROM player_promos pp JOIN promo_prizes ppz ON pp.promo_prize_sql_id = ppz.id WHERE pp.account_id = %d AND ppz.promo_id = %d LIMIT 1", accountId, promoSqlId);
    new Cache:result_test = mysql_query(mysql, query_test, false);

    if(cache_num_rows(result_test) > 0)
    {
        SendClientMessage(playerid, -1, "{ff2400}| {ffffff}You have already used this promo code.");
        cache_delete(result_test);
        return 0;
    }
    cache_delete(result_test);
    return 1;
}

public OnPromoCodeCheckComplete(playerid, const promoCode[])
{
    if(!IsPlayerConnected(playerid))
    {
        return 0;
    }

    new query[258];
    new accountId = GetPlayerAccountID(playerid);
    new player_money = GetPlayerMoneyEx(playerid);
    new temp_promoCode[MAX_PROMO_CODE_LENGTH];
    new message[256];
    new Cache:result;

    mysql_format(mysql, query, sizeof(query), "SELECT 1 FROM promocodes WHERE code = '%s' LIMIT 1", promoCode);
    result = mysql_query(mysql, query, false);

    if(mysql_errno() != 0)
    {
        SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Database error while checking promo code. Try again later.");
        callcmd::promo(playerid, "");
        cache_delete(result);
        return 1;
    }

    if(cache_num_rows(result) > 0)
    {
        SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Error: A promo code with that name already exists. Choose another.");
        callcmd::promo(playerid, "");
        cache_delete(result);
        return 1;
    }
    cache_delete(result);

    new len = strlen(promoCode);
    new cost = 0; // Cost of creating promo code in rubles
    new vc_cost = 0; // Cost of creating promo code in donate

    if(len >= 3 && len <= 4) // 3 to 4 characters
    {
        cost = 10000000;
        vc_cost = 2000;
    }
    else if(len >= 5 && len <= 7)
    {
        cost = 5000000;
    }
    else if(len >= 8) // 8 or more
    {
        cost = 3000000;
    }

    new i = 0;
    while (i < MAX_PROMO_CODE_LENGTH - 1 && promoCode[i] != EOS)
    {
        temp_promoCode[i] = promoCode[i];
        i++;
    }
    temp_promoCode[i] = EOS;

    new cost_text[64];
    if(vc_cost > 0) {
        format(cost_text, sizeof(cost_text), "%d rubles or %d BC", cost, vc_cost);
    } else {
        format(cost_text, sizeof(cost_text), "%d rubles", cost);
    }

    // DIALOG_ADDPROMO_PRIZE_MONEY_BY_PLAYER was removed

    mysql_format(mysql, query, sizeof(query), "INSERT INTO promocodes (code, uses_limit, promo_level, creator_account_id, created_at, creation_cost) VALUES ('%s', '0', '0', %d, NOW(), %d)", promoCode, accountId, cost);
    result = mysql_query(mysql, query, false);

    if(mysql_errno() != 0)
    {
        SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Error: A promo code with that name already exists. Choose another.");
        callcmd::promo(playerid, "");
        cache_delete(result);
        return 1;
    }
    cache_delete(result);

    if(player_money < (cost))
    {
        if(player_money < (vc_cost))
        {
            format(message, sizeof(message), "{ff2400}| {ffffff}Error: Insufficient funds. You need %d rubles or %d donate.", cost, vc_cost);
            SendClientMessage(playerid, -1, message);
            callcmd::promo(playerid, "");
            return 1;
        }
        else
        {
            GivePlayerDonateRub(playerid, -vc_cost);
            format(message, sizeof(message), "{FFFF00}| {FFFFFF}Promo code '{FFFF00}%s{FFFFFF}' successfully created! {FFFF00}%d donate{FFFFFF} was deducted from your balance.", promoCode, vc_cost);
            SendClientMessage(playerid, -1, message);
            callcmd::mypromo(playerid, "");
            LoadPromoCodesFromDatabase();
        }
    }
    else
    {
        GivePlayerMoneyEx(playerid, -cost);
        format(message, sizeof(message), "{FFFF00}| {FFFFFF}Promo code '{FFFF00}%s{FFFFFF}' successfully created! {FFFF00}%d rub{FFFFFF} was deducted from your balance.", promoCode, cost);
        SendClientMessage(playerid, -1, message);
        callcmd::mypromo(playerid, "");
        LoadPromoCodesFromDatabase();
    }

    return 1;
}

public HasPlayerCreatedPromo(playerid)
{
    new query[128];
    mysql_format(mysql, query, sizeof(query), "SELECT `id` FROM `promocodes` WHERE `creator_account_id` = %d LIMIT 1", GetPlayerAccountID(playerid));
    new Cache:result = mysql_query(mysql, query);
    new hasPromo = cache_num_rows(result) > 0;
    cache_delete(result);
    return hasPromo;
}

public AddPlayerActivatedPromo(account_id, promo_id)
{
    new query[256];
    mysql_format(mysql, query, sizeof(query), "INSERT INTO `activated_promos` (`account_id`, `promo_id`, `activated_at`) VALUES (%d, %d, NOW())", account_id, promo_id);
    mysql_query(mysql, query);
}

stock SavePromoLevelPrizes(playerid, promoId, level)
{
    new prizeCount;
    new query[256];

    new prizes[5][3];

    mysql_format(mysql, query, sizeof(query), "DELETE FROM `promo_prizes` WHERE `promo_id` = %d", promoId);
    mysql_query(mysql, query, false);

    prizeCount = PROMO_LEVEL_DATA[level][2];

    switch(level)
    {
        case 1:
        {
            for(new i = 0; i < prizeCount; i++) {
                prizes[i][0] = PromoLevelPrizes_1[i][0];
                prizes[i][1] = PromoLevelPrizes_1[i][1];
                prizes[i][2] = PromoLevelPrizes_1[i][2];
            }
        }
        case 2:
        {
            for(new i = 0; i < prizeCount; i++) {
                prizes[i][0] = PromoLevelPrizes_2[i][0];
                prizes[i][1] = PromoLevelPrizes_2[i][1];
                prizes[i][2] = PromoLevelPrizes_2[i][2];
            }
        }
        case 3:
        {
            for(new i = 0; i < prizeCount; i++) {
                prizes[i][0] = PromoLevelPrizes_3[i][0];
                prizes[i][1] = PromoLevelPrizes_3[i][1];
                prizes[i][2] = PromoLevelPrizes_3[i][2];
            }
        }
        case 4:
        {
            for(new i = 0; i < prizeCount; i++) {
                prizes[i][0] = PromoLevelPrizes_4[i][0];
                prizes[i][1] = PromoLevelPrizes_4[i][1];
                prizes[i][2] = PromoLevelPrizes_4[i][2];
            }
        }
        case 5:
        {
            for(new i = 0; i < prizeCount; i++) {
                prizes[i][0] = PromoLevelPrizes_5[i][0];
                prizes[i][1] = PromoLevelPrizes_5[i][1];
                prizes[i][2] = PromoLevelPrizes_5[i][2];
            }
        }
        case 6:
        {
            for(new i = 0; i < prizeCount; i++) {
                prizes[i][0] = PromoLevelPrizes_6[i][0];
                prizes[i][1] = PromoLevelPrizes_6[i][1];
                prizes[i][2] = PromoLevelPrizes_6[i][2];
            }
        }
        case 7:
        {
            for(new i = 0; i < prizeCount; i++) {
                prizes[i][0] = PromoLevelPrizes_7[i][0];
                prizes[i][1] = PromoLevelPrizes_7[i][1];
                prizes[i][2] = PromoLevelPrizes_7[i][2];
            }
        }
        case 8:
        {
            for(new i = 0; i < prizeCount; i++) {
                prizes[i][0] = PromoLevelPrizes_8[i][0];
                prizes[i][1] = PromoLevelPrizes_8[i][1];
                prizes[i][2] = PromoLevelPrizes_8[i][2];
            }
        }
        case 9:
        {
            for(new i = 0; i < prizeCount; i++) {
                prizes[i][0] = PromoLevelPrizes_9[i][0];
                prizes[i][1] = PromoLevelPrizes_9[i][1];
                prizes[i][2] = PromoLevelPrizes_9[i][2];
            }
        }
        case 10:
        {
            for(new i = 0; i < prizeCount; i++) {
                prizes[i][0] = PromoLevelPrizes_10[i][0];
                prizes[i][1] = PromoLevelPrizes_10[i][1];
                prizes[i][2] = PromoLevelPrizes_10[i][2];
            }
        }
    }

    for(new i = 0; i < prizeCount; i++)
    {
        new prizeType = prizes[i][0];
        new prizeValue = prizes[i][1];
        new prizeDuration = prizes[i][2];

        mysql_format(mysql, query, sizeof(query),
            "INSERT INTO `promo_prizes` (`promo_id`, `prize_index`, `prize_type`, `prize_value`, `prize_duration`) VALUES (%d, %d, %d, %d, %d)",
            promoId, i, prizeType, prizeValue, prizeDuration);

        mysql_query(mysql, query, false);

        if(mysql_errno() != 0)
        {
            printf("[WERTON_PROMO] Error adding prize (promo_prizes table) for promo code ID %d, prize %d: %d", promoId, i, mysql_errno());
        }
    }
}

stock GetPromoLevel(playerid, promoSQL_id)
{
    new query[128];
    new level = -1;

    mysql_format(mysql, query, sizeof(query), "SELECT `promo_level` FROM `promocodes` WHERE `id` = %d LIMIT 1", promoSQL_id);
    new Cache:result = mysql_query(mysql, query);

    if(cache_num_rows(result) > 0)
    {
        level = cache_get_field_content_int(0, "promo_level");
    }

    cache_delete(result);
    return level;
}

stock GetPromoLevelForOwner(playerid)
{
    new query[128];
    new level = -1;

    mysql_format(mysql, query, sizeof(query), "SELECT `promo_level` FROM `promocodes` WHERE `creator_account_id` = %d LIMIT 1", GetPlayerAccountID(playerid));
    new Cache:result = mysql_query(mysql, query);

    if(cache_num_rows(result) > 0)
    {
        level = cache_get_field_content_int(0, "promo_level");
    }

    cache_delete(result);
    return level;
}

CMD:createpromo(playerid)
{
    callcmd::addcpromo(playerid, "");
}

CMD:createytpromo(playerid)
{
    callcmd::addcpromo(playerid, "");
}

// was asked to add commands from radical, well I listen to my papas
CMD:addcpromo(playerid)
{
    if(GetPlayerAdminEx(playerid) < 13) return SendClientMessage(playerid, -1, "{ff2400}| {ffffff}You don't have permission to use this command.");

    ShowPlayerDialog(playerid, DIALOG_ADDPROMO_CODE, DIALOG_STYLE_INPUT, "{FF6347}"SERVER_NAME" {FFFFFF}| Creating promo code", "Enter promo code name (no spaces):", "Next", "Cancel");
    return 1;
}

CMD:promo(playerid)
{
    new dialog_text[512];
    new list_item_3_text[96];

    if(HasPlayerCreatedPromo(playerid))
    {
        format(list_item_3_text, sizeof(list_item_3_text), "{EB4C42} #3. {FFFFFF}Manage promo code\t\t\t\t {888888}click");
    }
    else
    {
        format(list_item_3_text, sizeof(list_item_3_text), "{EB4C42} #3. {FFFFFF}Create promo code\t\t\t\t\t {888888}click");
    }

    format(dialog_text, sizeof(dialog_text), "{EB4C42} #1. {FFFFFF}Activate promo code\t\t\t\t\t {888888}click\n{EB4C42} #2. {FFFFFF}YouTube gift\t\t\t\t\t\t {888888}click\n%s\n{EB4C42} #4. {FFFFFF}Take prizes\t\t\t\t\t\t\t {888888}click", list_item_3_text);

    ShowPlayerDialog(playerid, DIALOG_ACT_PROMO, DIALOG_STYLE_LIST,
        "{FF0000} Promo code",
        dialog_text,
        "Next", "Exit"
    );
    return 1;
}
alias:promo("promocode")

CMD:mypromo(playerid)
{
    new query[256];
    new dialog_text[512];
    new promo_code[MAX_PROMO_CODE_LENGTH];
    new promo_level, activations, nextLevelActivations;

    mysql_format(mysql, query, sizeof(query), "SELECT `code`, `promo_level`, `activations` FROM `promocodes` WHERE `creator_account_id` = %d LIMIT 1", GetPlayerAccountID(playerid));
    new Cache:result = mysql_query(mysql, query);

    if(cache_num_rows(result) == 0)
    {
        SendClientMessage(playerid, -1, "{ff2400}| {ffffff}You don't have a personal promo code.");
        cache_delete(result);
        return 1;
    }

    cache_get_field_content(0, "code", promo_code, sizeof(promo_code));
    promo_level = cache_get_field_content_int(0, "promo_level");
    activations = cache_get_field_content_int(0, "activations");

    if(promo_level >= 0 && promo_level < sizeof(PROMO_LEVEL_DATA))
    {
        nextLevelActivations = PROMO_LEVEL_DATA[promo_level + 1][1];
    }
    else
    {
        nextLevelActivations = 0;
    }

    format(dialog_text, sizeof(dialog_text), "{EB4C42} #1. {FFFFFF}Your promo code: {ff0000}%s\n{EB4C42} #2. {FFFFFF}Promo code level: {ff0000}%d\n{EB4C42} #3. {FFFFFF}Information about promo codes\n{EB4C42} #4. {FFFFFF}Promo code activated {ff0000}%d{ffffff} out of {ff0000}%d{ffffff} times.", promo_code, promo_level, activations, nextLevelActivations);

    ShowPlayerDialog(playerid, DIALOG_PROMO_MANAGEMENT, DIALOG_STYLE_LIST,
        "{FF0000} Promo code",
        dialog_text,
        "Next", "Exit"
    );

    cache_delete(result);
    return 1;
}
alias:mypromo("mypromocode")

CMD:checkpromo(playerid)
{
    new query[256];
    new dialog_text[512];
    new dialog_title[152];
    new Cache:result;

    mysql_format(mysql, query, sizeof(query), "SELECT `id`, `code`, `promo_level`, `activations`, `promo_balance` FROM `promocodes` WHERE `creator_account_id` = %d LIMIT 1", GetPlayerAccountID(playerid));
    result = mysql_query(mysql, query);

    if(cache_num_rows(result) == 0)
    {
        SendClientMessage(playerid, -1, "{ff2400}| {ffffff}You don't have a personal promo code.");
        cache_delete(result);
        return 1;
    }

    new promo_code[MAX_PROMO_CODE_LENGTH];
    new promo_level, promo_activations, promo_balance, promo_id;

    promo_id = cache_get_field_content_int(0, "id");
    cache_get_field_content(0, "code", promo_code, sizeof(promo_code));
    promo_level = cache_get_field_content_int(0, "promo_level");
    promo_activations = cache_get_field_content_int(0, "activations");
    promo_balance = cache_get_field_content_int(0, "promo_balance");
    cache_delete(result);

    if(promo_level == 0)
    {
        SendClientMessage(playerid, -1, "{ff2400}| {ffffff}Your promo code is not configured. Use /promo to set the level.");
        return 1;
    }

    format(dialog_title, sizeof(dialog_title), "{FF0000} %s", promo_code);

    format(dialog_text, sizeof(dialog_text), "Promo code statistics: {ff0000}%s\n\n{ffffff}Your promo code has been entered {FF0000}%d{ffffff} times and you received {ff0000}%d{ffffff} rubles!", promo_code, promo_activations, promo_balance);

    ShowPlayerDialog(playerid, DIALOG_PROMO_STATS, DIALOG_STYLE_MSGBOX, dialog_title, dialog_text, "Exit", "");

    if(promo_balance == 0) return 1;

    GivePlayerMoneyEx(playerid, promo_balance);

    mysql_format(mysql, query, sizeof(query), "UPDATE `promocodes` SET `promo_balance` = 0 WHERE `id` = %d", promo_id);
    mysql_query(mysql, query);

    return 1;
}

CMD:bcode(playerid)
{
    ShowPlayerDialog(playerid, DIALOG_APPLY_PROMO_CODE, DIALOG_STYLE_INPUT, "{FF0000}Promo code", "Enter promo code to receive a prize:", "Enter", "Exit");
    return 1;
}