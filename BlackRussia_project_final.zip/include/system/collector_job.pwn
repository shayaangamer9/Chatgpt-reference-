// File: collector_job.pwn
/*

Need to add these lines to g_teleport and increase it to 36 (or +4)

new g_teleport[36][E_TELEPORT_STRUCT] = //for new interior
{
	{"Bank\nArzamas", 395.029266,762.869506,12.630935, 0, 2890.355712,2488.004638,1051.004760,353.741363, 1, 1}, // entrance to Central Bank Arzamas
	{"Exit", 2890.299560,2484.910644,1051.004760, 1, 394.006500,761.715270,12.630935,157.697418, 0, 0}, // exit from Central Bank Arzamas
	//
	{"Bank\nLytkarino", -2326.625976,-29.081722,27.384737, 0, 2890.355712,2488.004638,1051.004760,353.741363, 1, 2}, // entrance to Central Bank Lytkarino
	{"Exit", 2890.299560,2484.910644,1051.004760, 2,-2326.839843,-27.583950,27.384737,357.855255, 0, 0}, // exit from Central Bank Lytkarino
	//
	{"Bank\nYuzhny", 2376.805664,-2139.199951,22.088638, 0, 2890.355712,2488.004638,1051.004760,353.741363, 1, 3}, // entrance to Central Bank Yuzhny
	{"Exit", 2890.299560,2484.910644,1051.004760, 3, 2376.305419,-2140.406738,21.973030,176.052505, 0, 0}, // exit from Central Bank Yuzhny
	//
	{"Bank\nBatyrevo", 1851.860351,2037.297119,16.518316, 0, 2890.355712,2488.004638,1051.004760,353.741363, 1, 4}, // entrance to Central Bank Batyrevo
	{"Exit", 2890.299560,2484.910644,1051.004760, 4, 1851.870361,2039.171875,16.511747,351.717041, 0, 0}, // exit from Central Bank Batyrevo
};

*/


#define COUNT_EXP_FOR_2_RANG    150
#define COUNT_EXP_FOR_3_RANG    300

#define order_c_cash_200     1
#define order_c_cash_500     2
#define order_c_cash_1000    3
#define order_c_packet_200   4
#define order_c_packet_500   5
#define order_c_packet_1000  6

new name_order_type[6][40] =
{
    {"Cash up to 700,000 rubles"},
    {"Cash up to 1,000,000 rubles"},
    {"Cash up to 1,500,000 rubles"},
    {"Share package up to 1,800,000 rubles"},
    {"Share package up to 2,000,000 rubles"},
    {"Share package up to 2,400,000 rubles"}
};

new Float:place_safe_bank[3] = {2930.936523,2525.372802,1051.004638};
new Float:place_bank[4] = {2927.294677,2484.445068,1051.004760};
new sphere_safe_bank;

/*2927.294677,2484.445068,1051.004760,0.942115,100,1 // npc new inter

2930.936523,2525.372802,1051.004638,283.521148,100,1 // seif new inter

1851.512573,2039.888427,16.511747,211.691741,0,0 // metka batika bank

1861.964843,2018.943481,16.511747,185.995559,0,0 // npc batka veh

1860.964599,2008.321655,15.115466,1.317162,0,0 // spawn batka veh

391.651977,783.632019,12.624366,337.065582,0,0 // npc arzamaz veh

396.351043,793.468139,11.240552,159.654357,0,0 // spawn arzamaz veh

393.945953,760.605590,12.624366,145.596084,0,0 // metka arzamaz

2376.792236,-2140.952880,21.972230,13.648014,0,0 // metka uzhni bank

2376.608886,-2127.770263,21.976562,2.937249,0,0 // npc uzhni veh

2388.106201,-2118.204101,21.232568,92.724845,0,0 // spawn uzhni veh

-2336.213378,-57.883251,26.126291,357.671356,0,0 // spawn litka veh

-2316.500000,-47.433452,27.378168,187.828155,0,0 // npc litka veh

-2326.648925,-27.537290,27.384737,0.862980,0,0 // npc litka veh

-2326.782714,-29.080144,27.384737,185.599380,0,0 // pickup litka bank

-2326.574707,-26.699550,27.378168,355.440490,0,0 // metka litka bank

394.877868,762.929565,12.630935,347.608825,0,0 // pickup arzamaz

2376.566894,-2139.199951,22.088638,327.764282,0,0 // pickup uzhni*/



enum struct_player_collector
{
    bool:job_active,
    rang_collector,
    exp_rang_collector,
    order_collector,
    player_partner,
    timer_c,
    second_c,
    fine_driver,
    c_quest_progress_1,
    c_quest_count_1,
    c_quest_progress_2,
    c_quest_count_2,
    c_quest_progress_3,
    c_quest_count_3,
    player_gang_zone_collector
}

new Float:coord_arenda_c[4][4]=
{
    {1861.964843,2018.943481,16.511747,185.995559},//batka
    {391.651977,783.632019,12.624366,337.065582},//arz
    {2376.608886,-2127.770263,21.976562,2.937249},//uzh
    {-2316.500000,-47.433452,27.378168,187.828155}//litka
};

new Float:coord_arenda_spawn[4][4] =
{
    {1860.964599,2008.321655,15.115466,1.317162},
    {396.351043,793.468139,11.240552,159.654357},
    {2388.106201,-2118.204101,21.232568,92.724845},
    {-2336.213378,-57.883251,26.126291,357.671356}
};


new sphere_arenda_collector[4];

new sphere_collector;

#define BR   "{FAD201}"

new player_collector[MAX_PLAYERS][struct_player_collector];

enum struct_orders_collectors
{
    order_type_active,
    orders_type,
    collector_id_driver,
    collector_id_collector,
    progress_order,
    Text3D:order_s_3dtext,
    Text3D:order_e_3dtext,
    order_sphere_start,
    order_sphere_end,
    Float: orders_start_point[3],
    Float: orders_end_point[3],
    place_start,
    place_end,
    collector_vehicle
}

#define TYPE_O_C_NOACTIVE  0
#define TYPE_O_C_ACTIVE    1
#define TYPE_O_C_TAKEN     2

#define MAX_ORDER_COL   30

new name_place_order[5][32] =
{
    {"ATM"},
    {"Bank Arzamas"},
    {"Bank Lytkarino"},
    {"Bank Yuzhny"},
    {"Bank Batyrevo"}
};


#define World_Bank_Arzamaz  1
#define World_Bank_Litka  2
#define World_Bank_Uzhni  3
#define World_Bank_Batirevo  4

#define Place_Col_1   1      //ATM
#define Place_Col_2   2      //Bank Arzamas
#define Place_Col_3   3      //Bank Lytkarino
#define Place_Col_4   4      //Bank Yuzhny
#define Place_Col_5   5      //Bank Batyrevo

/*
1405.907714,462.846069,13.163024,13.730526,0,0 // atm 1
2408.673339,-1841.696289,22.949813,356.944488,0,0 // atm 2
29.823257,511.317108,13.174163,57.959037,0,0 // atm 3?
-501.804748,1270.387451,20.890625,79.035469,0,0 // atm 5/
2481.007080,-718.345336,12.370574,0.355532,0,0 // atm 6/
-19.817697,2621.752197,10.989245,177.547027,0,0 // atm 7/
-2557.399414,39.671264,27.879764,220.350555,0,0 // atm 8
2419.060546,1397.435913,12.218092,120.040786,0,0 // atm 9
*/

/*-2326.574707,-26.699550,27.378168,355.440490,0,0 // metka litka bank
393.945953,760.605590,12.624366,145.596084,0,0 // metka arzamaz
2376.792236,-2140.952880,21.972230,13.648014,0,0 // metka uzhni bank
1851.512573,2039.888427,16.511747,211.691741,0,0 // metka batika bank*/

new orders_collectors[MAX_ORDER_COL][struct_orders_collectors] =
{
    {TYPE_O_C_NOACTIVE, 1, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {393.945953,760.605590,12.624366}, {1405.907714,462.846069,13.163024}, Place_Col_2, Place_Col_1, -1},
    {TYPE_O_C_NOACTIVE, 1, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {2408.673339,-1841.696289,22.949813}, {2376.792236,-2140.952880,21.972230}, Place_Col_1, Place_Col_4, -1},
    {TYPE_O_C_NOACTIVE, 1, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {-2326.574707,-26.699550,27.378168}, {29.823257,511.317108,13.174163}, Place_Col_3, Place_Col_1, -1},
    {TYPE_O_C_NOACTIVE, 1, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {393.945953,760.605590,12.624366}, {-501.804748,1270.387451,20.890625}, Place_Col_2, Place_Col_1, -1},
    {TYPE_O_C_NOACTIVE, 1, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {2376.792236,-2140.952880,21.972230}, {-501.804748,1270.387451,20.890625}, Place_Col_4, Place_Col_1, -1},
    {TYPE_O_C_NOACTIVE, 2, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {1851.512573,2039.888427,16.511747}, {2481.007080,-718.345336,12.370574}, Place_Col_5, Place_Col_1, -1},
    {TYPE_O_C_NOACTIVE, 2, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {-19.817697,2621.752197,10.989245}, {1851.512573,2039.888427,16.511747}, Place_Col_1, Place_Col_5, -1},
    {TYPE_O_C_NOACTIVE, 2, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {2376.792236,-2140.952880,21.972230}, {-2557.399414,39.671264,27.879764}, Place_Col_4, Place_Col_1,  -1},
    {TYPE_O_C_NOACTIVE, 2, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {1851.512573,2039.888427,16.511747}, {2419.060546,1397.435913,12.218092}, Place_Col_5, Place_Col_1,  -1},
    {TYPE_O_C_NOACTIVE, 2, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {29.823257,511.317108,13.174163}, {393.945953,760.605590,12.624366}, Place_Col_1, Place_Col_2,    -1},
    {TYPE_O_C_NOACTIVE, 3, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {393.945953,760.605590,12.624366}, {1405.907714,462.846069,13.163024}, Place_Col_2, Place_Col_1, -1},
    {TYPE_O_C_NOACTIVE, 3, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {2408.673339,-1841.696289,22.949813}, {2376.792236,-2140.952880,21.972230}, Place_Col_1, Place_Col_4, -1},
    {TYPE_O_C_NOACTIVE, 3, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {-2326.574707,-26.699550,27.378168}, {29.823257,511.317108,13.174163}, Place_Col_3, Place_Col_1, -1},
    {TYPE_O_C_NOACTIVE, 3, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {393.945953,760.605590,12.624366}, {-501.804748,1270.387451,20.890625}, Place_Col_2, Place_Col_1, -1},
    {TYPE_O_C_NOACTIVE, 3, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {2376.792236,-2140.952880,21.972230}, {-501.804748,1270.387451,20.890625}, Place_Col_4, Place_Col_1, -1},
    {TYPE_O_C_NOACTIVE, 4, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {1851.512573,2039.888427,16.511747}, {2481.007080,-718.345336,12.370574}, Place_Col_5, Place_Col_1, -1},
    {TYPE_O_C_NOACTIVE, 4, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {-19.817697,2621.752197,10.989245}, {1851.512573,2039.888427,16.511747}, Place_Col_1, Place_Col_5, -1},
    {TYPE_O_C_NOACTIVE, 4, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {2376.792236,-2140.952880,21.972230}, {-2557.399414,39.671264,27.879764}, Place_Col_4, Place_Col_1,  -1},
    {TYPE_O_C_NOACTIVE, 4, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {1851.512573,2039.888427,16.511747}, {2419.060546,1397.435913,12.218092}, Place_Col_5, Place_Col_1,  -1},
    {TYPE_O_C_NOACTIVE, 4, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {29.823257,511.317108,13.174163}, {393.945953,760.605590,12.624366}, Place_Col_1, Place_Col_2,    -1},
    {TYPE_O_C_NOACTIVE, 5, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {393.945953,760.605590,12.624366}, {1405.907714,462.846069,13.163024}, Place_Col_2, Place_Col_1, -1},
    {TYPE_O_C_NOACTIVE, 5, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {2408.673339,-1841.696289,22.949813}, {2376.792236,-2140.952880,21.972230}, Place_Col_1, Place_Col_4, -1},
    {TYPE_O_C_NOACTIVE, 5, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {-2326.574707,-26.699550,27.378168}, {29.823257,511.317108,13.174163}, Place_Col_3, Place_Col_1, -1},
    {TYPE_O_C_NOACTIVE, 5, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {393.945953,760.605590,12.624366}, {-501.804748,1270.387451,20.890625}, Place_Col_2, Place_Col_1, -1},
    {TYPE_O_C_NOACTIVE, 5, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {2376.792236,-2140.952880,21.972230}, {-501.804748,1270.387451,20.890625}, Place_Col_4, Place_Col_1, -1},
    {TYPE_O_C_NOACTIVE, 6, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {1851.512573,2039.888427,16.511747}, {2481.007080,-718.345336,12.370574}, Place_Col_5, Place_Col_1, -1},
    {TYPE_O_C_NOACTIVE, 6, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {-19.817697,2621.752197,10.989245}, {1851.512573,2039.888427,16.511747}, Place_Col_1, Place_Col_5, -1},
    {TYPE_O_C_NOACTIVE, 6, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {2376.792236,-2140.952880,21.972230}, {-2557.399414,39.671264,27.879764}, Place_Col_4, Place_Col_1,  -1},
    {TYPE_O_C_NOACTIVE, 6, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {1851.512573,2039.888427,16.511747}, {2419.060546,1397.435913,12.218092}, Place_Col_5, Place_Col_1,  -1},
    {TYPE_O_C_NOACTIVE, 6, -1, -1, 0, Text3D:-1, Text3D:-1, -1, -1, {29.823257,511.317108,13.174163}, {393.945953,760.605590,12.624366}, Place_Col_1, Place_Col_2,    -1}
};



public OnPlayerConnect(playerid)
{
    player_collector[playerid][job_active] = false;
    player_collector[playerid][rang_collector] = 0;
    player_collector[playerid][exp_rang_collector] = 1;
    player_collector[playerid][order_collector] = -1;
    player_collector[playerid][player_partner] = -1;
    player_collector[playerid][timer_c] = -1;
    player_collector[playerid][second_c] = 0;
    player_collector[playerid][fine_driver] = 0;
    player_collector[playerid][c_quest_progress_1] = 0;
    player_collector[playerid][c_quest_count_1] = 0;
    player_collector[playerid][c_quest_progress_2] = 0;
    player_collector[playerid][c_quest_count_2] = 0;
    player_collector[playerid][c_quest_progress_3] = 0;
    player_collector[playerid][c_quest_count_3] = 0;
    player_collector[playerid][player_gang_zone_collector] = -1;

    SetTimerEx("LoadRangCollector", 2500, false, "i", playerid);
    #if defined col_OnPlayerConnect
        return col_OnPlayerConnect(playerid);
    #else
        return 1;
    #endif
}
#if defined _ALS_OnPlayerConnect
    #undef OnPlayerConnect
#else
    #define _ALS_OnPlayerConnect
#endif
#define OnPlayerConnect col_OnPlayerConnect
#if defined col_OnPlayerConnect
    forward col_OnPlayerConnect(playerid);
#endif

public OnPlayerDisconnect(playerid, reason)
{
    if(player_collector[playerid][order_collector] != -1)
    {
        EndOrderCollector(playerid, player_collector[playerid][player_partner], false);
    }

    #if defined col_OnPlayerDisconnect
        return col_OnPlayerDisconnect(playerid, reason);
    #else
        return 1;
    #endif
}
#if defined _ALS_OnPlayerDisconnect
    #undef OnPlayerDisconnect
#else
    #define _ALS_OnPlayerDisconnect
#endif
#define OnPlayerDisconnect col_OnPlayerDisconnect
#if defined col_OnPlayerDisconnect
    forward col_OnPlayerDisconnect(playerid, reason);
#endif


public:LoadRangCollector(playerid)
{
    new database_txt[64], Cache:result;

    mysql_format(mysql, database_txt, sizeof database_txt, "SELECT * FROM accounts WHERE id = %d", GetPlayerAccountID(playerid));
    result = mysql_query(mysql, database_txt);


    if(mysql_errno()) return printf("error collector query: %d - database id", GetPlayerAccountID(playerid));
    else
    {
        if(cache_num_rows())
        {
            player_collector[playerid][exp_rang_collector] = cache_get_field_content_int(0, "exp_collector");



            switch(player_collector[playerid][exp_rang_collector])
            {
                case 0..149:    player_collector[playerid][rang_collector] = 1;
                case 150..299:  player_collector[playerid][rang_collector] = 2;
                default:       player_collector[playerid][rang_collector] = 3;
            }
        }
        else printf("id = %d | none cache collector", GetPlayerAccountID(playerid));

        if(!player_collector[playerid][exp_rang_collector]) player_collector[playerid][exp_rang_collector] = 1;
    }

    cache_delete(result);

    return 1;
}

public OnPlayerEnterCheckpoint(playerid)
{
    if(player_collector[playerid][order_collector] != -1)
    {
        new order = player_collector[playerid][order_collector];
        new partner = player_collector[playerid][player_partner];

        switch(orders_collectors[order][progress_order])
        {

            case 1:// player took money/shares
            {
                if(!GetPlayerVehicleSeat(playerid))
                {
                    orders_collectors[order][collector_id_driver] = playerid;
                    orders_collectors[order][collector_id_collector] = partner;
                }
                else if(!GetPlayerVehicleSeat(partner))
                {
                    orders_collectors[order][collector_id_driver] = partner;
                    orders_collectors[order][collector_id_collector] = playerid;
                }

                if(orders_collectors[order][place_start] != Place_Col_1)
                {
                    SendClientMessage(orders_collectors[order][collector_id_collector], -1,
                    ""SC" Go to the {FAD201}bank branch{FFFFFF} and take the funds from the {FAD201}vault.");
                }
                else
                {
                    SendClientMessage(orders_collectors[order][collector_id_collector], -1, ""SC" Go to the {FAD201}ATM{FFFFFF} and deliver the valuable cargo.");
                }
            }
            case 2:// player arrives at order completion point
            {
                if(!GetPlayerVehicleSeat(playerid))
                {
                    orders_collectors[order][collector_id_driver] = playerid;
                    orders_collectors[order][collector_id_collector] = partner;
                }
                else if(!GetPlayerVehicleSeat(partner))
                {
                    orders_collectors[order][collector_id_driver] = partner;
                    orders_collectors[order][collector_id_collector] = playerid;
                }
                if(orders_collectors[order][place_end] != Place_Col_1)
                {
                    SendClientMessage(orders_collectors[order][collector_id_collector], -1,
                    ""SC" Go to the {FAD201}bank branch{FFFFFF} and deliver the funds to the {FAD201}vault.");
                }
                else
                {
                    SendClientMessage(orders_collectors[order][collector_id_collector], -1, ""SC" Go to the {FAD201}ATM{FFFFFF} and deliver the valuable cargo.");
                }
            }
            default:printf("ERROR COLLECTOR: None Progress Order | id order: %d | id player: %d", order, playerid);
        }

        DisablePlayerCheckpoint(partner);
        DisablePlayerCheckpoint(playerid);
    }
    #if defined col_OnPlayerEnterCheckpoint
        return col_OnPlayerEnterCheckpoint(playerid);
    #else
        return 1;
    #endif
}
   #if defined _ALS_OnPlayerEnterCheckpoint
    #undef OnPlayerEnterCheckpoint
#else
    #define _ALS_OnPlayerEnterCheckpoint
#endif
#define OnPlayerEnterCheckpoint col_OnPlayerEnterCheckpoint
#if defined col_OnPlayerEnterCheckpoint
    forward col_OnPlayerEnterCheckpoint(playerid);
#endif



public OnDialogResponse(playerid, dialogid, response, listitem, inputtext[])
{
    if(dialogid == 1811)
    {
        if(response)
        {
            switch(listitem)
            {
                case 0:
                {
                    Dialog
                    (
                        playerid, -1, DIALOG_STYLE_MSGBOX,
                        ""BR""SERVER_NAME" {FFFFFF}-> Information",
                        "{FAD201}Collector{FFFFFF} - a bank employee engaged in transporting cash and other valuables\n"\
                        "for the needs of the bank or its clients.\n\n"\
                        "This job is {FAD201}team-based{FFFFFF}, you can only work in pairs with a partner.\n"\
                        "To find a partner, you can use the command "BR"/collist\n\n"\
                        "{FFFFFF}A team consists of two people:\n"\
                        ""BR"1. {FAD201}Driver - a team member who rented a vehicle. He never leaves the vehicle,\n"\
                        "monitors the situation.\n"\
                        ""BR"2. {FAD201}Collector - a team member who acts as a passenger in the vehicle\n"\
                        "and as a collector outside it. He directly interacts with the valuable cargo and is responsible for its safety.\n\n"\
                        "This job has 3 ranks:\n"\
                        ""BR"1. {FAD201}Collector 1st class{FFFFFF} - the lowest class of collector, who can interact with orders\n"\
                        "with a smaller amount of funds and can rent {FAD201}Gazelle Collector.\n"\
                        ""BR"2. {FAD201}Collector 2nd class{FFFFFF} - middle class collector, who can interact\n"\
                        "with orders with medium and low amount of funds, and can rent {FAD201}Gazelle Collector{FFFFFF} or {FAD201}Volkswagen Transporter.\n"\
                        ""BR"3. {FAD201}Collector 3rd class{FFFFFF} - the highest class collector, who can interact with all orders,\n"\
                        "and can also rent {FAD201}Gazelle Collector, {FAD201}Volkswagen Transporter{FFFFFF} or {FAD201}Mercedes-Benz V-klasse.\n\n"\
                        "To unlock a new level, you need to earn {FAD201}experience{FFFFFF}, which\n"\
                        "is awarded for each {FAD201}successfully completed order.{FFFFFF}.\n\n"\
                        "You can view your personal collector card using "BR"/cmenu",
                        "Back", ""
                    );
                }
                case 1:
                {
                    if(!player_collector[playerid][job_active])
                    {
                        Dialog
                        (
                            playerid, 1812, DIALOG_STYLE_MSGBOX,
                            ""BR"Vitaly - Director | Collection job",
                            "Hello, to get a job as a collector, you need:\n\n"\
                            ""BR"1. {FFFFFF}Have {FAD201}15 {FFFFFF}game level.\n"\
                            ""BR"2. {FFFFFF}Have {FAD201}a weapon license.\n"\
                            ""BR"3. {FFFFFF}Have {FAD201}a driver's license.\n"\
                            "{FFFFFF}If you are ready to get a job, click {FAD201}Next{FFFFFF}.",
                            "Next", "Close"

                        );
                    }
                    else
                    {
                        EndOrderCollector(playerid, player_collector[playerid][player_partner], false);
                        SendClientMessage(player_collector[playerid][player_partner], -1, ""USC"Your partner quit the job.");
                        SetPlayerSkinInit(playerid);
                        ResetPlayerWeapons(playerid);
                    }
                }
                case 2:
                {
                    new text_sql[124], Cache:result;

                    mysql_format(mysql, text_sql, sizeof text_sql, "SELECT * FROM accounts WHERE exp_collector >= '0' ORDER BY exp_collector DESC LIMIT 10");
                    result = mysql_query(mysql, text_sql);

                    if(mysql_errno()) return print("[COLLECTOR_SYSTEM] Error Sql Query: №1");

                    new rows = cache_num_rows();

                    new list[68], dialog[584] = ""BR"##\t"BR"Nick\t{979595}Points\n";

                    new name[24], exp;

                    for(new i;i < rows;i++)
                    {
                        cache_get_field_content(i, "name", name, mysql, 24);
                        exp = cache_get_field_content_int(i, "exp_collector");

                        format(list, sizeof list, ""BR"#%d\t{FFFFFF}%s\t{979595}%d\n", i+1, name, exp);
                        strcat(dialog, list);
                    }

                    DialogCollector(playerid, -1, DIALOG_STYLE_TABLIST_HEADERS, ""BR""SERVER_NAME" {FFFFFF}| Ranking of best collectors", dialog, "Back", "Close");

                }
                case 3:
                {
                    if(!player_collector[playerid][job_active])
                     return SendClientMessage(playerid, -1, ""USC"First start your {FAD201}work day.");

                    new dialog[534], quest_1[32], quest_2[32], quest_3[32];

                    switch(player_collector[playerid][c_quest_progress_1])
                    {
                        case 0:format(quest_1, sizeof quest_1, ""BR"Not active");
                        case 1:format(quest_1, sizeof quest_1, "{FAD201}Active");
                        case 2:format(quest_1, sizeof quest_1, "{1EFF00}Completed");
                    }

                    switch(player_collector[playerid][c_quest_progress_2])
                    {
                        case 0:format(quest_2, sizeof quest_2, ""BR"Not active");
                        case 1:format(quest_2, sizeof quest_2, "{FAD201}Active");
                        case 2:format(quest_2, sizeof quest_2, "{1EFF00}Completed");
                    }

                    switch(player_collector[playerid][c_quest_progress_3])
                    {
                        case 0:format(quest_3, sizeof quest_3, ""BR"Not active");
                        case 1:format(quest_3, sizeof quest_3, "{FAD201}Active");
                        case 2:format(quest_3, sizeof quest_3, "{1EFF00}Completed");
                    }

                    format
                    (
                        dialog, sizeof dialog,
                        ""BR"##\t"BR"Name\t"BR"Progress\t"BR"Status\n"\
                        ""BR"#1.\t"BR"Together is more fun\t"BR"%d/2\t%s\n"\
                        ""BR"#2.\t"BR"Worthy collector\t"BR"%d/5\t%s\n"\
                        ""BR"#3.\t"BR"This is a high position\t"BR"%d/10\t%s",
                        player_collector[playerid][c_quest_count_1], quest_1,
                        player_collector[playerid][c_quest_count_2], quest_2,
                        player_collector[playerid][c_quest_count_3], quest_3
                    );

                    DialogCollector
                    (
                        playerid, 1815, DIALOG_STYLE_TABLIST_HEADERS,
                        ""BR""SERVER_NAME"{FFFFFF}-> Daily tasks",
                        dialog,
                        "Next", "Cancel"
                    );
                }
                case 4:
                {
                    new text[384], exp[124], order[194];

                    switch(player_collector[playerid][rang_collector])
                    {
                        case 1:
                        {
                            format(exp, sizeof exp, "{FAD201}3. {FFFFFF}Required experience to unlock next class: {FAD201}%d/%d{FFFFFF}\n",
                            player_collector[playerid][exp_rang_collector], COUNT_EXP_FOR_2_RANG);

                            format(order, sizeof order, "- %s\n- %s", name_order_type[0], name_order_type[1]);
                        }
                        case 2:
                        {
                            format(exp, sizeof exp, "{FAD201}3. {FFFFFF}Required experience to unlock next class: {FAD201}%d/%d{FFFFFF}\n",
                            player_collector[playerid][exp_rang_collector], COUNT_EXP_FOR_3_RANG);
                            format(order, sizeof order, "- %s\n- %s\n- %s\n- %s", name_order_type[0], name_order_type[1], name_order_type[2], name_order_type[3]);
                        }
                        case 3:
                        {
                            format(exp, sizeof exp, "{FAD201}3. {FFFFFF}Maximum collector level reached\n");
                            format(order, sizeof order, "- %s\n- %s\n- %s\n- %s\n- %s\n- %s", name_order_type[0], name_order_type[1], name_order_type[2], name_order_type[3], name_order_type[4], name_order_type[5]);
                        }
                    }

                    format
                    (
                        text, sizeof text,
                        "{FAD201}1. {FFFFFF}Current position: {FAD201}Collector %d class{FFFFFF}\n"\
                        "{FAD201}2. {FFFFFF}Current collector experience: {FAD201}%d{FFFFFF}\n"\
                        "%s\n"\
                        "{FAD201}4. {FFFFFF}Available orders:\n"\
                        "%s",
                        player_collector[playerid][rang_collector], player_collector[playerid][exp_rang_collector], exp, order
                    );

                    Dialog(playerid, -1, DIALOG_STYLE_MSGBOX, ""BR""SERVER_NAME"{FFFFFF}-> Personal card", text, "Back", "Close");
                }
            }
        }
    }
    if(dialogid == 1810)
    {
        if(response)
        {
            new id = GetPlayerListitemValue(playerid, listitem + 1), text[154];

            if(orders_collectors[id][collector_id_driver] != -1 && orders_collectors[id][collector_id_collector] != -1)
                return SendClientMessage(playerid, -1, ""USC" This order is already taken.");

            if(!GetPlayerVehicleID(playerid))
                return SendClientMessage(playerid, -1, ""USC" You must be in a vehicle");

            new id_car = GetPlayerVehicleID(playerid);
            new model = GetVehicleModel(id_car);

            switch(model)
            {
                case 482, 428, 427: model = 0; //meaningless
                default:return SendClientMessage(playerid, -1, ""SC" Rent a work vehicle. The rental manager is located at the back of the bank");
            }

            switch(orders_collectors[id][orders_type])
            {
                case 3,4:if(player_collector[playerid][rang_collector] == 1) return SendClientMessage(playerid, -1, ""USC"This order is for a higher collector class");
                case 5,6:if(player_collector[playerid][rang_collector] <= 2) return SendClientMessage(playerid, -1, ""USC"This order is for a higher collector class");
            }

            new partner = player_collector[playerid][player_partner];

            if(!GetPlayerVehicleSeat(playerid))
            {
                orders_collectors[id][collector_id_driver] = playerid;
                orders_collectors[id][collector_id_collector] = partner;
            }
            else if(!GetPlayerVehicleSeat(partner))
            {
                orders_collectors[id][collector_id_driver] = partner;
                orders_collectors[id][collector_id_collector] = playerid;
            }

            player_collector[playerid][order_collector] = id;
            player_collector[partner][order_collector] = id;


            orders_collectors[id][collector_vehicle] = GetPlayerVehicleID(playerid);

            orders_collectors[id][progress_order]++;

            load_order_colllector(id);

            SetPlayerCheckpoint(playerid, orders_collectors[id][orders_start_point][0], orders_collectors[id][orders_start_point][1], orders_collectors[id][orders_start_point][2], 5.0);
            SetPlayerCheckpoint(partner, orders_collectors[id][orders_start_point][0], orders_collectors[id][orders_start_point][1], orders_collectors[id][orders_start_point][2], 5.0);
            SetPlayerGPSPoint(playerid, orders_collectors[id][orders_start_point][0], orders_collectors[id][orders_start_point][1]);
            SetPlayerGPSPoint(partner, orders_collectors[id][orders_start_point][0], orders_collectors[id][orders_start_point][1]);

            // ADD GANGZONE (small map marker):
            CreateSmallGangZoneForCollector(playerid, orders_collectors[id][orders_start_point][0], orders_collectors[id][orders_start_point][1]);
            CreateSmallGangZoneForCollector(partner, orders_collectors[id][orders_start_point][0], orders_collectors[id][orders_start_point][1]);

            format(text, sizeof text, ""SC"You have successfully taken order {FAD201}#%d{FFFFFF}, go to the marked GPS point.", id + 1);
            SendClientMessage(playerid, -1, text);
            SendClientMessage(partner, -1, text);
        }
    }
    if(dialogid == 1812)
    {
        if(response)
        {
            if(GetPVarInt(playerid, "d_c_1"))
            {
                SendClientMessage(playerid, -1, ""SC"You started your {FAD201}collector{FFFFFF} job. Find a partner using {FAD201}/colinv [ID]");

                player_collector[playerid][job_active] = true;

                switch(player_collector[playerid][rang_collector])
                {
                    case 1:SetPlayerSkin(playerid, 168);
                    case 2:SetPlayerSkin(playerid, 132);
                    case 3:SetPlayerSkin(playerid, 28);
                }

                GivePlayerWeapon(playerid, 29, 500);
                GivePlayerWeapon(playerid, 24, 500);
                SetPlayerArmour(playerid, 100.0);

                player_collector[playerid][player_partner]  = -1;


                player_collector[playerid][order_collector] = -1;
                player_collector[playerid][timer_c]         = -1;
                player_collector[playerid][second_c]        = 0;

                return 1;
            }

            if(GetPlayerLevel(playerid) < 15)
                return SendClientMessage(playerid, -1, ""USC" Required level for collector job is 15.");

            if(GetPlayerData(playerid, P_WEAPON_LIC) != 1)
                return SendClientMessage(playerid, -1, ""USC" A weapon license is required for collector job.");

            if(!GetPlayerData(playerid, P_DRIVING_LIC))
                return SendClientMessage(playerid, -1, ""USC" A driver's license is required for collector job.");

            Dialog
            (
                playerid, 1812, DIALOG_STYLE_MSGBOX,
                ""BR""SERVER_NAME" {FFFFFF}-> Collector",
                "{FAD201}Collector{FFFFFF} - a bank employee engaged in transporting cash\n"\
                "and other valuables for the needs of the bank or its clients\n\n"\
                "To get a job as a collector, you need to have {FAD201}15 game level{FFFFFF}\n"\
                "and {FAD201}a weapon license{FFFFFF}. Remember that collection is a team job:\n"\
                "before starting work, you need to find partners and accept an order together with them.\n"\
                "You can learn more about the job in any of the {FAD201}Banks{FFFFFF} or\n"\
                "in the {FAD201}command list {FFFFFF}(/mn >> Command list).\n\n"\
                "If you are ready to get a job, click - {FAD201}next.",
                "Next",
                "Cancel"
            );

            SetPVarInt(playerid, "d_c_1", 1);
        }
        else DeletePVar(playerid, "d_c_1");
    }
    if(dialogid == 1813)
    {
        if(response)
        {
            new text[584];
            switch(listitem)
            {

                case 0:
                {
                          new playertextt[54], exp[124], order[194];

                        switch(player_collector[playerid][rang_collector])
                        {
                            case 1:
                            {
                                format(exp, sizeof exp, "{FAD201}3. {FFFFFF}Required experience to unlock next class: {FAD201}%d/%d{FFFFFF}\n",
                                player_collector[playerid][exp_rang_collector], COUNT_EXP_FOR_2_RANG);

                                format(order, sizeof order, "- %s\n- %s", name_order_type[0], name_order_type[1]);
                            }
                            case 2:
                            {
                                format(exp, sizeof exp, "{FAD201}3. {FFFFFF}Required experience to unlock next class: {FAD201}%d/%d{FFFFFF}\n",
                                player_collector[playerid][exp_rang_collector], COUNT_EXP_FOR_3_RANG);
                                format(order, sizeof order, "- %s\n- %s\n- %s\n- %s", name_order_type[0], name_order_type[1], name_order_type[2], name_order_type[3]);
                            }
                            case 3:
                            {
                                format(exp, sizeof exp, "{FAD201}3. {FFFFFF}Maximum collector level reached\n");
                                format(order, sizeof order, "- %s\n- %s\n- %s\n- %s\n- %s\n- %s", name_order_type[0], name_order_type[1], name_order_type[2], name_order_type[3], name_order_type[4], name_order_type[5]);
                            }
                        }

                        format(playertextt, sizeof playertextt, ""BR""SERVER_NAME"{FFFFFF}-> Player %s personal card", GetPlayerNameEx(playerid));

                        format
                        (
                            text, sizeof text,
                            "{FAD201}1. {FFFFFF}Current position: {FAD201}Collector %d class{FFFFFF}\n"\
                            "{FAD201}2. {FFFFFF}Current collector experience: {FAD201}%d{FFFFFF}\n"\
                            "%s\n"\
                            "{FAD201}4. {FFFFFF}Available orders:\n"\
                            "%s",
                            player_collector[playerid][rang_collector], player_collector[playerid][exp_rang_collector], exp, order
                        );

                        Dialog(playerid, -1, DIALOG_STYLE_MSGBOX, playertextt, text, "Back", "Close");
                }
                case 1:
                {
                    if(player_collector[playerid][order_collector] == -1)
                        return SendClientMessage(playerid, -1, ""USC" You don't have an order.");

                    new id = player_collector[playerid][order_collector], distance;

                    distance = DistancePointToPoint(orders_collectors[id][orders_start_point][0], orders_collectors[id][orders_start_point][1], orders_collectors[id][orders_start_point][2],
                    orders_collectors[id][orders_end_point][0], orders_collectors[id][orders_end_point][1], orders_collectors[id][orders_end_point][2]);

                    format
                    (
                        text, sizeof text,
                        "{FAD201}1. {FFFFFF}Order name: {FAD201}%s{FFFFFF}\n"\
                        "{FAD201}2. {FFFFFF}Order starting point: {FAD201}%s{FFFFFF}\n"\
                        "{FAD201}3. {FFFFFF}Order end point: {FAD201}%s{FFFFFF}\n"\
                        "{FAD201}4. {FFFFFF}Distance between points: {FAD201}%d\n"\
                        "{FAD201}5. {FFFFFF}Partner: {FAD201}%s",
                        name_order_type[orders_collectors[id][orders_type]-1],
                        name_place_order[orders_collectors[id][place_start]-1],
                        name_place_order[orders_collectors[id][place_end]-1],
                        distance, GetPlayerNameEx(player_collector[playerid][player_partner])
                    );
                    Dialog(playerid, -1, DIALOG_STYLE_MSGBOX, ""BR""SERVER_NAME"{FFFFFF}-> Current order info", text, "Back", "Close");
                }
            }
        }
    }
    if(dialogid == 1814)
    {
        if(response)
        {
            new vehicle, money, spawn = -1;

            if(player_collector[playerid][player_partner] == -1)
                return SendClientMessage(playerid, -1, ""USC" First find a partner.");

            if(player_collector[playerid][rang_collector] < listitem+1) return SendClientMessage(playerid, -1, ""USC" Your rank does not allow you to take this vehicle.");

            for(new i;i < sizeof coord_arenda_c;i++)
            {
                if(!IsPlayerInDynamicArea(playerid, sphere_arenda_collector[i])) continue;
               // spawn = playerid;
            }

            if(spawn == -1) return SendClientMessage(playerid, -1, ""USC" Error! Select again");

            switch(listitem)
            {
                case 0:
                {
                    vehicle = CreateVehicle(427, coord_arenda_spawn[spawn][0], coord_arenda_spawn[spawn][1], coord_arenda_spawn[spawn][2], coord_arenda_spawn[spawn][3], 1, 1, -1);
                    money = 25000;
                }
                case 1:
                {
                    vehicle = CreateVehicle(428, coord_arenda_spawn[spawn][0], coord_arenda_spawn[spawn][1], coord_arenda_spawn[spawn][2], coord_arenda_spawn[spawn][3], 1, 1, -1);
                    money = 25000;
                }
                case 2:
                {
                    vehicle = CreateVehicle(482, coord_arenda_spawn[spawn][0], coord_arenda_spawn[spawn][1], coord_arenda_spawn[spawn][2], coord_arenda_spawn[spawn][3], 1, 1, -1);
                    money = 25000;
                }
            }

            new p = player_collector[playerid][player_partner];

            SetPlayerVirtualWorld(playerid, 0);
            SetPlayerInterior(playerid, 0);

            SetPlayerVirtualWorld(p, 0);
            SetPlayerInterior(p, 0);

            GivePlayerMoneyEx(playerid, -money);

            PutPlayerInVehicle(playerid, vehicle, 0);
            PutPlayerInVehicle(p, vehicle, 1);

        }
    }
    if(dialogid == 1815)
    {
        if(response)
        {
            if(GetPVarInt(playerid, "c_q_d_1"))
            {
                if(player_collector[playerid][c_quest_progress_1])
                    return SendClientMessage(playerid, -1, ""USC" You already started this task.");

                SendClientMessage(playerid, -1, ""SC"You started the task {FAD201}\"Together is more fun\"");
                player_collector[playerid][c_quest_progress_1] = 1;
                DeletePVar(playerid, "c_q_d_1");
                CallLocalFunction("OnPlayerEnterDynamicArea", "ii", playerid, sphere_collector);
                return 1;
            }
            else if(GetPVarInt(playerid, "c_q_d_2"))
            {
                if(player_collector[playerid][c_quest_progress_2])
                    return SendClientMessage(playerid, -1, ""USC" You already started this task.");

                SendClientMessage(playerid, -1, ""SC"You started the task {FAD201}\"Worthy collector\"");
                player_collector[playerid][c_quest_progress_2] = 1;
                DeletePVar(playerid, "c_q_d_2");
                CallLocalFunction("OnPlayerEnterDynamicArea", "ii", playerid, sphere_collector);
                return 1;
            }
            else if(GetPVarInt(playerid, "c_q_d_3"))
            {
                if(player_collector[playerid][c_quest_progress_3])
                    return SendClientMessage(playerid, -1, ""USC" You already started this task.");

                SendClientMessage(playerid, -1, ""SC"You started the task {FAD201}\"This is a high position\"");
                player_collector[playerid][c_quest_progress_3] = 1;
                DeletePVar(playerid, "c_q_d_3");
                CallLocalFunction("OnPlayerEnterDynamicArea", "ii", playerid, sphere_collector);
                return 1;
            }

            switch(listitem)
            {
                case 0:
                {
                    Dialog
                    (
                        playerid, 1815, DIALOG_STYLE_MSGBOX,
                        ""BR" "SERVER_NAME" {FFFFFF}| Together is more fun",
                        "Every time they start a shift, collectors strive to find a worthy partner.\n"\
                        "We sincerely hope that in our department this partner is you. You need to prove it!\n\n"\
                        "Your task: {FAD201}complete different orders with at least two different partners.\n"\
                        "{FFFFFF}Reward: {FAD201}5,000 rubles.",
                        "Next", "Back"
                    );

                    SetPVarInt(playerid, "c_q_d_1", 1);
                }
                case 1:
                {
                    Dialog
                    (
                        playerid, 1815, DIALOG_STYLE_MSGBOX,
                        ""BR" "SERVER_NAME" {FFFFFF}| Worthy collector",
                        "Collector is not a position. It's a calling. Every collector tries to work\n"\
                        "worthily, giving themselves fully to the cause. You need to prove that you are one of the\n"\
                        "most worthy collectors!\n\n"\
                        "Your task: {FAD201}complete at least 5 orders per day.\n"\
                        "{FFFFFF}Reward: {FAD201}5,000 rubles.",
                        "Next", "Back"
                    );

                    SetPVarInt(playerid, "c_q_d_2", 1);
                }
                case 2:
                {
                    Dialog
                    (
                        playerid, 1815, DIALOG_STYLE_MSGBOX,
                        ""BR" "SERVER_NAME" {FFFFFF}| This is a high position",
                        "It's nice to be at the top of the list every time, to be better and cooler than others.\n"\
                        "Every collector can become an ideal in their field, can take the highest position.\n"\
                        "To do this, you need to work hard every day.\n\n"\
                        "Your task: {FAD201}earn 10 rating points within 24 hours\n"\
                        "Partners may be different.{FFFFFF}Reward: {FAD201}10,000 rubles.",
                        "Next", "Back"
                    );

                    SetPVarInt(playerid, "c_q_d_3", 1);
                }
            }
        }
        else
        {
            if(GetPVarInt(playerid, "c_q_d_1")) DeletePVar(playerid, "c_q_d_1");
            if(GetPVarInt(playerid, "c_q_d_2")) DeletePVar(playerid, "c_q_d_2");
            if(GetPVarInt(playerid, "c_q_d_3")) DeletePVar(playerid, "c_q_d_3");
            CallLocalFunction("OnPlayerEnterDynamicArea", "ii", playerid, sphere_collector);
        }
    }
    #if defined col_OnDialogResponse
return col_OnDialogResponse(playerid, dialogid, response, listitem, inputtext);
#endif
}
#if defined _ALS_OnDialogResponse
#undef OnDialogResponse
#else
#define _ALS_OnDialogResponse
#endif
#define OnDialogResponse col_OnDialogResponse
#if defined col_OnDialogResponse
forward col_OnDialogResponse(playerid, dialogid, response, listitem, inputtext[]);
#endif

public OnGameModeInit()
{
    LoadCollectorJob();

    SetTimer("UpdateOrderListCollector", 1000*60, true);
    #if defined col_OnGameModeInit
        return col_OnGameModeInit();
    #else
        return 1;
    #endif
}
   #if defined _ALS_OnGameModeInit
    #undef OnGameModeInit
#else
    #define _ALS_OnGameModeInit
#endif
#define OnGameModeInit col_OnGameModeInit
#if defined col_OnGameModeInit
    forward col_OnGameModeInit();
#endif

public OnPlayerEnterDynamicArea(playerid, areaid)
{
    if(areaid == sphere_collector)
    {
        DialogCollector
        (
            playerid, 1811, DIALOG_STYLE_TABLIST_HEADERS,
            ""BR""SERVER_NAME"{FFFFFF}-> Collection",
            ""BR"##\t"BR"Name\t{979595}Action\n"\
            ""BR"#1\t{FFFFFF}Information\t{979595}click to interact\n"\
            ""BR"#2\t{FFFFFF}Start/End work day\t{979595}click to interact\n"\
            ""BR"#3\t{FFFFFF}Rating of best collectors\t{979595}click to interact\n"\
            ""BR"#4\t{FFFFFF}Daily collector tasks\t{979595}click to interact\n"\
            ""BR"#5\t{FFFFFF}Personal card\t{979595}click to interact",
            "Select", "Cancel"
        );

        return 1;
    }
    if(sphere_arenda_collector[0] <= areaid <= sphere_arenda_collector[3])
    {
        if(player_collector[playerid][player_partner] == -1)
            return SendClientMessage(playerid, -1, ""USC"First find a partner. /colinv [ID]");

        if(player_collector[playerid][order_collector] != -1)
            return SendClientMessage(playerid, -1, ""USC"You have an active order. Vehicle rental is not possible.");

        DialogCollector
        (
            playerid, 1814, DIALOG_STYLE_TABLIST_HEADERS,
            ""BR""SERVER_NAME"{FFFFFF}-> Collection",
            ""BR"##\t"BR"Name\t"BR"Rental cost\t{979595}Availability\n"\
            ""BR"#1.\t{FFFFFF}Gazelle \"Collection\"\t{FFFFFF}25,000 rubles\t{979595}1\n"\
            ""BR"#3.\t{FFFFFF}Volkwagen Multivan T6\t{FFFFFF}25,000 rubles\t{979595}2\n"\
            ""BR"#2.\t{FFFFFF}Mersedes-Benz V-Class\t{FFFFFF}25,000 rubles\t{979595}3",
            "Select", "Cancel"
        );

        return 1;
    }
    if(player_collector[playerid][order_collector] != -1)
    {
        new order = player_collector[playerid][order_collector];

        new partner = player_collector[playerid][player_partner];

        if(areaid == orders_collectors[order][order_sphere_start])
        {
            if(orders_collectors[order][progress_order] != 1) return 1;
            if(orders_collectors[order][collector_id_collector] != playerid)
                return SendClientMessage(playerid, -1, ""USC"The {FFFFFF}driver {FAD201}cannot take the funds.");

            if(IsPlayerInAnyVehicle(playerid))
                return SendClientMessage(playerid, -1, ""USC"Get out of the vehicle to take {FAD201}the funds.");

            SendClientMessage(playerid, -1, ""SC" You have successfully taken the funds. Go to the {FAD201}collection vehicle.");

            orders_collectors[order][progress_order]++;

            ApplyAnimation(playerid, "BOMBER", "BOM_Plant", 1.0, 1, 0, 0, 0, 2000);

            SetPlayerAttachedObject(playerid, 9, 1210, 5, 0.299999,0.099999,0.000000,0.000000,-83.000000,0.000000,1.000000,1.000000,1.000000);

            if(IsValidDynamicArea(orders_collectors[order][order_sphere_start])) DestroyDynamicArea(orders_collectors[order][order_sphere_start]);
            if(IsValidDynamic3DTextLabel(orders_collectors[order][order_s_3dtext])) DestroyDynamic3DTextLabel(orders_collectors[order][order_s_3dtext]);


            SetPlayerCheckpoint(playerid, orders_collectors[order][orders_end_point][0], orders_collectors[order][orders_end_point][1], orders_collectors[order][orders_end_point][2], 5.0);
            SetPlayerCheckpoint(partner, orders_collectors[order][orders_end_point][0], orders_collectors[order][orders_end_point][1], orders_collectors[order][orders_end_point][2], 5.0);
            SetPlayerGPSPoint(playerid, orders_collectors[order][orders_end_point][0], orders_collectors[order][orders_end_point][1]);
            SetPlayerGPSPoint(partner, orders_collectors[order][orders_end_point][0], orders_collectors[order][orders_end_point][1]);
            CreateSmallGangZoneForCollector(playerid, orders_collectors[order][orders_end_point][0], orders_collectors[order][orders_end_point][1]);
            CreateSmallGangZoneForCollector(partner, orders_collectors[order][orders_end_point][0], orders_collectors[order][orders_end_point][1]);

        }
        if(areaid == orders_collectors[order][order_sphere_end])
        {
            if(orders_collectors[order][progress_order] != 2) return 1;

            if(!IsPlayerInDynamicArea(playerid, orders_collectors[order][order_sphere_end])) return 0;

            if(IsPlayerInAnyVehicle(playerid))
                return SendClientMessage(playerid, -1, ""USC"Get out of the vehicle to take {FAD201}the funds.");


            ApplyAnimation(playerid, "BOMBER", "BOM_Plant", 1.0, 1, 0, 0, 0, 2000);
            RemovePlayerAttachedObject(playerid, 9);
            SendClientMessage(playerid, -1, ""SC" Order successfully completed, go to the {FAD201}Bank {FFFFFF}to view new orders.");
            SendClientMessage(partner, -1, ""SC" Order successfully completed, go to the {FAD201}Bank {FFFFFF}to view new orders.");

            new salary;

            switch(orders_collectors[order][orders_type])
            {
                case 1,2:salary = 1500000 + random(250000);
                case 3,4:salary = 1800000 + random(270000);
                case 5,6:salary = 2000000 + random(310000);
            }

  //          if(g_doubling[DOUBLING_WAGE]) salary = salary * 2;

            new salary_driver = salary - player_collector[orders_collectors[order][collector_id_driver]][fine_driver];

            GivePlayerMoneyEx(orders_collectors[order][collector_id_collector], salary);
            GivePlayerMoneyEx(orders_collectors[order][collector_id_driver], salary);

            new text[248], text_1[18];

            format(text, sizeof text, "You received %d rubles", salary);
            format(text_1, sizeof text_1, "You received %d rubles", salary_driver);

            ShowNotification(orders_collectors[order][collector_id_collector], 2, text, 3, "", "");
            ShowNotification(orders_collectors[order][collector_id_driver], 2, text_1, 3, "", "");

            ShowNotificationSile(playerid, 1, 6, 0, 0, "You successfully delivered the cargo", "");
            ShowNotificationSile(partner, 1, 6, 0, 0, "You successfully delivered the cargo", "");
            EndOrderCollector(playerid, partner, true);

            if(player_collector[playerid][c_quest_progress_1] ||player_collector[partner][c_quest_progress_1])
            {
                if(player_collector[playerid][c_quest_progress_1])
                {
                    player_collector[playerid][c_quest_count_1]++;

                    format(text, sizeof text, "You completed {FAD201}%d{FFFFFF} out of {FAD201}2{FFFFFF} for the task {FAD201}Together is more fun",
                    player_collector[playerid][c_quest_count_1]);
                    SendClientMessage(playerid, -1, text);
                }
                if(player_collector[partner][c_quest_progress_1])
                {
                    player_collector[partner][c_quest_count_1]++;

                    format(text, sizeof text, "You completed {FAD201}%d{FFFFFF} out of {FAD201}2{FFFFFF} for the task {FAD201}Together is more fun",
                    player_collector[partner][c_quest_count_1]);
                    SendClientMessage(partner, -1, text);
                }

                if(player_collector[playerid][c_quest_count_1] >= 2 ||player_collector[partner][c_quest_count_1] >= 2)
                {
                    if(player_collector[playerid][c_quest_count_1] >= 2)
                    {
                        player_collector[playerid][c_quest_progress_1] = 2;
                        GivePlayerMoney(playerid, 5000);

                        format(text, sizeof text, "You successfully completed the daily task {FAD201}Together is more fun",
                        player_collector[playerid][c_quest_count_1]);
                        SendClientMessage(playerid, -1, text);
                        SendClientMessage(playerid, -1, ""SC" You received {FAD201}5000{FFFFFF} rubles for completing the task.");
                    }
                    if(player_collector[partner][c_quest_count_1] >= 2)
                    {
                        player_collector[partner][c_quest_progress_1] = 2;
                        GivePlayerMoney(partner, 5000);

                        format(text, sizeof text, "You successfully completed the daily task {FAD201}Together is more fun",
                        player_collector[partner][c_quest_count_1]);
                        SendClientMessage(partner, -1, text);
                        SendClientMessage(partner, -1, ""SC" You received {FAD201}5000{FFFFFF} rubles for completing the task.");
                    }
                }
            }

            if(player_collector[playerid][c_quest_progress_2] ||player_collector[partner][c_quest_progress_2])
            {
                if(player_collector[playerid][c_quest_progress_2])
                {
                    player_collector[playerid][c_quest_count_2]++;

                    format(text, sizeof text, "You completed {FAD201}%d{FFFFFF} out of {FAD201}5{FFFFFF} for the task {FAD201}Worthy collector",
                    player_collector[playerid][c_quest_count_2]);
                    SendClientMessage(playerid, -1, text);
                }
                if(player_collector[partner][c_quest_progress_2])
                {
                    player_collector[partner][c_quest_count_2]++;

                    format(text, sizeof text, "You completed {FAD201}%d{FFFFFF} out of {FAD201}5{FFFFFF} for the task {FAD201}Worthy collector",
                    player_collector[partner][c_quest_count_2]);
                    SendClientMessage(partner, -1, text);
                }

                if(player_collector[playerid][c_quest_count_2] >= 5 ||player_collector[partner][c_quest_count_2] >= 5)
                {
                    if(player_collector[playerid][c_quest_count_2] >= 5)
                    {
                        player_collector[playerid][c_quest_progress_2] = 2;

                        GivePlayerMoney(playerid, 5000);

                        format(text, sizeof text, "You successfully completed the daily task {FAD201}Worthy collector",
                        player_collector[playerid][c_quest_count_1]);
                        SendClientMessage(playerid, -1, text);
                        SendClientMessage(playerid, -1, ""SC" You received {FAD201}5000{FFFFFF} rubles for completing the task.");
                    }
                    if(player_collector[partner][c_quest_count_2] >= 5)
                    {
                        player_collector[partner][c_quest_progress_2] = 2;

                        GivePlayerMoney(partner, 5000);

                        format(text, sizeof text, "You successfully completed the daily task {FAD201}Worthy collector",
                        player_collector[partner][c_quest_count_1]);
                        SendClientMessage(partner, -1, text);
                        SendClientMessage(partner, -1, ""SC" You received {FAD201}5000{FFFFFF} rubles for completing the task.");
                    }
                }
            }

            SendClientMessage(playerid, -1, ""SC"You received {FAD201}1 {FFFFFF}collector experience.");
            SendClientMessage(partner, -1, ""SC"You received {FAD201}1 {FFFFFF}collector experience.");
            player_collector[playerid][exp_rang_collector]++;
            player_collector[partner][exp_rang_collector]++;

            new database_txt[84];

            mysql_format(mysql, database_txt, sizeof database_txt, "UPDATE accounts SET exp_collector=%d WHERE id=%d", player_collector[playerid][exp_rang_collector], GetPlayerAccountID(playerid));
            mysql_query(mysql, database_txt, false);

            mysql_format(mysql, database_txt, sizeof database_txt, "UPDATE accounts SET exp_collector=%d WHERE id=%d", player_collector[partner][exp_rang_collector], GetPlayerAccountID(partner));
            mysql_query(mysql, database_txt, false);

            if(mysql_errno()) return print("[COLLECTOR_SYSTEM] Error Sql Query: №2");


            if(player_collector[playerid][exp_rang_collector] >= 150 && player_collector[playerid][rang_collector] == 1) player_collector[playerid][rang_collector] = 2;
            else if(player_collector[playerid][exp_rang_collector] >= 300 && player_collector[playerid][rang_collector] == 2) player_collector[playerid][rang_collector] = 3;


            if(player_collector[partner][exp_rang_collector] >= 150 && player_collector[partner][rang_collector] == 1) player_collector[partner][rang_collector] = 2;
            else if(player_collector[partner][exp_rang_collector] >= 300 && player_collector[partner][rang_collector] == 2) player_collector[partner][rang_collector] = 3;

            if(player_collector[playerid][c_quest_progress_3] || player_collector[partner][c_quest_progress_3])
            {
                if(player_collector[playerid][c_quest_progress_3])
                {
                    player_collector[playerid][c_quest_count_3]++;

                    format(text, sizeof text, "You completed {FAD201}%d{FFFFFF} out of {FAD201}10{FFFFFF} for the task {FAD201}This is a high position",
                    player_collector[playerid][c_quest_count_3]);
                    SendClientMessage(playerid, -1, text);
                }
                if(player_collector[partner][c_quest_progress_3])
                {
                    player_collector[partner][c_quest_count_3]++;

                    format(text, sizeof text, "You completed {FAD201}%d{FFFFFF} out of {FAD201}10{FFFFFF} for the task {FAD201}This is a high position",
                    player_collector[partner][c_quest_count_3]);
                    SendClientMessage(partner, -1, text);
                }

                if(player_collector[playerid][c_quest_count_3] >= 5 ||player_collector[partner][c_quest_count_3] >= 5)
                {
                    if(player_collector[playerid][c_quest_count_3] >= 5)
                    {
                        player_collector[playerid][c_quest_progress_3] = 2;

                        GivePlayerMoney(playerid, 10000);

                        format(text, sizeof text, "You successfully completed the daily task {FAD201}This is a high position",
                        player_collector[playerid][c_quest_count_1]);
                        SendClientMessage(playerid, -1, text);
                        SendClientMessage(playerid, -1, ""SC" You received {FAD201}10000{FFFFFF} rubles for completing the task.");
                    }
                    if(player_collector[partner][c_quest_count_3] >= 5)
                    {
                        player_collector[partner][c_quest_progress_3] = 2;

                        GivePlayerMoney(partner, 10000);

                        format(text, sizeof text, "You successfully completed the daily task {FAD201}This is a high position",
                        player_collector[partner][c_quest_count_1]);
                        SendClientMessage(partner, -1, text);
                        SendClientMessage(partner, -1, ""SC" You received {FAD201}10000{FFFFFF} rubles for completing the task.");
                    }
                }
            }
        }
    }
    #if defined col_OnPlayerEnterDynamicArea
        return col_OnPlayerEnterDynamicArea(playerid, STREAMER_TAG_AREA:areaid);
    #else
        return 0;
    #endif
}
   #if defined _ALS_OnPlayerEnterDynamicArea
    #undef OnPlayerEnterDynamicArea
#else
    #define _ALS_OnPlayerEnterDynamicArea
#endif
#define OnPlayerEnterDynamicArea col_OnPlayerEnterDynamicArea
#if defined col_OnPlayerEnterDynamicArea
    forward col_OnPlayerEnterDynamicArea(playerid, STREAMER_TAG_AREA:areaid);
#endif

public OnPlayerExitVehicle(playerid, vehicleid)
{
    if(player_collector[playerid][order_collector] != -1)
    {
        new id = player_collector[playerid][order_collector];

        if(vehicleid == orders_collectors[id][collector_vehicle])
        {
            if(orders_collectors[id][progress_order] == 2)
            {
                SendClientMessage(playerid, -1, ""SC" You have {FAD201}180 {FFFFFF}seconds to get back into the vehicle.");
                player_collector[playerid][second_c] = 180;
                player_collector[playerid][timer_c] = SetTimerEx("GameTextCollector", 1000, true, "i", playerid);
            }
            else
            {
                SendClientMessage(playerid, -1, ""SC" You have {FAD201}60 {FFFFFF}seconds to get back into the vehicle.");
                player_collector[playerid][second_c] = 60;
                player_collector[playerid][timer_c] = SetTimerEx("GameTextCollector", 1000, true, "i", playerid);
            }
        }
    }
    #if defined col_OnPlayerExitVehicle
        return col_OnPlayerExitVehicle(playerid, vehicleid);
    #else
        return 1;
    #endif
}
   #if defined _ALS_OnPlayerExitVehicle
    #undef OnPlayerExitVehicle
#else
    #define _ALS_OnPlayerExitVehicle
#endif
#define OnPlayerExitVehicle col_OnPlayerExitVehicle
#if defined col_OnPlayerExitVehicle
    forward col_OnPlayerExitVehicle(playerid, vehicleid);
#endif

public OnPlayerEnterVehicle(playerid, vehicleid, ispassenger)
{
    if(IsPlayerLogged(playerid) || IsPlayerConnected(playerid))
    {
        if(player_collector[playerid][order_collector] != -1)
        {
            new id = player_collector[playerid][order_collector];

            if(vehicleid == orders_collectors[id][collector_vehicle])
            {
                KillTimer(player_collector[playerid][timer_c]);
            }
        }
    }
    #if defined col_OnPlayerEnterVehicle
        return col_OnPlayerEnterVehicle(playerid, vehicleid, ispassenger);
    #else
        return 1;
    #endif
}
   #if defined _ALS_OnPlayerEnterVehicle
    #undef OnPlayerEnterVehicle
#else
    #define _ALS_OnPlayerEnterVehicle
#endif
#define OnPlayerEnterVehicle col_OnPlayerEnterVehicle
#if defined col_OnPlayerEnterVehicle
    forward col_OnPlayerEnterVehicle(playerid, vehicleid, ispassenger);
#endif

public OnVehicleDamageStatusUpdate(vehicleid, playerid)
{
    if(GetVehicleParam(vehicleid, V_ENGINE) == VEHICLE_PARAM_ON && GetPlayerData(playerid, P_IMPROVEMENTS) < 4)
    {
        if(player_collector[playerid][job_active])
        {
            if(player_collector[playerid][order_collector] != -1)
            {
                new id = player_collector[playerid][order_collector];

                if(orders_collectors[id][collector_vehicle] == vehicleid)
                {
                    SendClientMessage(playerid, -1, ""SC" You damaged the work vehicle, a fine will be applied to you upon order completion.");
                    player_collector[playerid][fine_driver] += 300;
                    return 1;
                }
            }
        }
    }
	#if defined col_OnVehicleDamageStatusUp
		return col_OnVehicleDamageStatusUp(vehicleid, playerid);
	#else
	    return 0;
	#endif
}
#if defined _ALS_OnVehicleDamageStatusUp
    #undef OnVehicleDamageStatusUpdate
#else
    #define _ALS_OnVehicleDamageStatusUp
#endif
#if defined col_OnVehicleDamageStatusUp
	forward col_OnVehicleDamageStatusUp(vehicleid, playerid);
#endif
#define	OnVehicleDamageStatusUpdate col_OnVehicleDamageStatusUp

stock LoadCollectorJob()
{
    for(new i;i < 4;i++) CreateDynamicActor(28, place_bank[0], place_bank[1], place_bank[2], place_bank[3], _, _, i+1, 1);

    CreateDynamic3DTextLabel("{FAD201}Head of collection service\n{FFFFFF}Approach for {FAD201}interaction", -1, place_bank[0], place_bank[1], place_bank[2], 10.0);
    sphere_collector = CreateDynamicSphere(place_bank[0], place_bank[1], place_bank[2], 2.0);

    for(new i;i < 4;i++)
    {
        CreateActor(28, coord_arenda_c[i][0], coord_arenda_c[i][1], coord_arenda_c[i][2], coord_arenda_c[i][3]);
        CreateDynamic3DTextLabel("{FAD201}Head of the vehicle fleet\n{FFFFFF}Approach for {FAD201}interaction", -1, coord_arenda_c[i][0], coord_arenda_c[i][1], coord_arenda_c[i][2], 10.0);
        sphere_arenda_collector[i] = CreateDynamicSphere(coord_arenda_c[i][0], coord_arenda_c[i][1], coord_arenda_c[i][2], 2.0);
    }

    for(new i, count[6], type;i < sizeof orders_collectors;i++)
    {
        if(orders_collectors[i][order_type_active] != TYPE_O_C_NOACTIVE) continue;

        type = orders_collectors[i][orders_type] - 1;

        if(count[type] >= 2) continue;

        count[type]++;

        orders_collectors[i][order_type_active] = TYPE_O_C_ACTIVE;
    }
}

CMD:blist(playerid)
{
    if(player_collector[playerid][player_partner] == -1)
        return SendClientMessage(playerid, -1, ""USC"First find a partner. (/colinv [id])");

    if(player_collector[playerid][order_collector] != -1)
        return SendClientMessage(playerid, -1, ""USC"First complete the previous order.");

    new count, dialog[1184] = ""BR"##\t"BR"Order type\t"BR"Distance between points\t"BR"Availability\n", text[144];

    for(new i, type, distance, class; i < sizeof orders_collectors;i++)
    {
        if(!orders_collectors[i][order_type_active]) continue;

        count++;

        distance = DistancePointToPoint(orders_collectors[i][orders_start_point][0], orders_collectors[i][orders_start_point][1], orders_collectors[i][orders_start_point][2],
        orders_collectors[i][orders_end_point][0], orders_collectors[i][orders_end_point][1], orders_collectors[i][orders_end_point][2]);


        switch(orders_collectors[i][orders_type])
        {
            case 1,2:class = 1;
            case 3,4:class = 2;
            case 5,6:class = 3;
        }

        /*format(text, sizeof text, "");
        valstr(text, distance);
        SendClientMessage(playerid, -1, text);*/

        type = orders_collectors[i][orders_type] - 1;

        format
        (
            text, sizeof text,
            ""BR"#%d.\t{FFFFFF}%s\t{FFFFFF}%d\t{979595}Collector %d class\n",
            count, name_order_type[type], distance, class
        );
        strcat(dialog, text);
        SetPlayerListitemValue(playerid, count, i);
    }

    if(!count) return SendClientMessage(playerid, -1, ""USC" No orders available at the moment.");

    DialogCollector(playerid, 1810, DIALOG_STYLE_TABLIST_HEADERS, ""BR"Order list", dialog, "Next", "Back");

    return 1;
}

CMD:colinv(playerid, params[])
{
    extract params -> new partner;



    if(player_collector[playerid][order_collector] != -1)
        return ShowNotificationSile(playerid, 2, 6, 0, 0, "First complete the current order.", "");

    if(player_collector[playerid][player_partner] != -1)
    {
        player_collector[player_collector[playerid][player_partner]][player_partner] = -1;
        SendClientMessage(player_collector[playerid][player_partner], -1, ""USC" Your partner declined you. You are no longer partners.");

        player_collector[playerid][player_partner] = -1;
        ShowNotificationSile(playerid, 1, 6, 0, 0, "You declined your partner.", "");

    }

    if(sscanf(params, "u", params[0]))
    return ShowNotificationSile(playerid, 2, 6, 0, 0, "Usage: '/colinv' [player id].", "");

    if(!IsPlayerLogged(partner) || !IsPlayerConnected(partner))
        return ShowNotificationSile(playerid, 2, 6, 0, 0, "Player with this ID not found.", "");

    if(!player_collector[partner][job_active])
        return ShowNotificationSile(playerid, 2, 6, 0, 0, "Player is not working in collection.", "");

    if(!player_collector[playerid][job_active])
        return ShowNotificationSile(playerid, 1, 6, 0, 0, "You are not a collector.", "");

    new Float:x, Float:y, Float:z;
    GetPlayerPos(partner, x, y, z);
    new Float:distance = GetPlayerDistanceFromPoint(playerid, x, y, z);

    if(distance >= 7.0) return ShowNotificationSile(playerid, 2, 6, 0, 0, "Player is too far away.", "");

    if(player_collector[partner][player_partner] != -1)
        return ShowNotificationSile(playerid, 2, 6, 0, 0, "Player already has a partner.", "");

    new text[52];
    format(text, sizeof text, "%s invites you to be partners, /joincoll", GetPlayerNameEx(playerid));

    ShowNotificationSile(partner, 2, 6, 0, 0, text, "");

    SetPVarInt(partner, "player_partner", playerid);
    return 1;
}

cmd:collist(playerid)
{
    if(!player_collector[playerid][job_active]) return SendClientMessage(playerid, -1, ""USC" First get a job as a collector.");

    new list[58], dialog[348], count;

    foreach(new i : Player)
    {
        if(!player_collector[i][job_active]) continue;
        else if(player_collector[i][player_partner] != -1) continue;
        count = true;

        format(list, sizeof list, "Collector %d class - %s - %d\n", player_collector[i][rang_collector], GetPlayerNameEx(i),
        GetPlayerPhone(i));
        strcat(dialog, list);
    }

    if(!count) return SendClientMessage(playerid, -1, ""SC" No free collectors at the moment.");

    Dialog(playerid, -1, DIALOG_STYLE_LIST, ""BR""SERVER_NAME" -> Collectors online", dialog, "Next", "Back");

    return 1;
}

cmd:joincoll(playerid)
{
    new partner = GetPVarInt(playerid, "player_partner");
    DeletePVar(playerid, "player_partner");

    player_collector[playerid][player_partner] = partner;
    player_collector[partner][player_partner] = playerid;

    SendClientMessage(partner, -1, ""SC" Player agreed. Now you are partners! Get into the work vehicle and start completing orders.");
    SendClientMessage(playerid, -1, ""SC" You agreed. Now you are partners! Get into the work vehicle and start completing orders.");
    SendClientMessage(partner, -1, ""SC" You can rent a vehicle at the back of the bank. To decline your partner, type /colinv");
    SendClientMessage(playerid, -1, ""SC" You can rent a vehicle at the back of the bank. To decline your partner, type /colinv");
    return 1;
}

stock DialogCollector(playerid, dialogid, style, const title[], const text[], const button[], const button2[])
{
  if(style == 5)
  {
     ShowPlayerDialog(playerid, 0, DIALOG_STYLE_LIST, "...", "...", "...", "");
  }
  ShowPlayerDialog(playerid, dialogid, style, title, text, button, button2);
  return 1;
}

cmd:cmenu(playerid)
{

    DialogCollector
    (
        playerid, 1813, DIALOG_STYLE_TABLIST_HEADERS,
        ""BR""SERVER_NAME" {FFFFFF}-> Collector job info",
        ""BR"##\t"BR"Description\t"BR"Action\n"\
        ""BR"#1\t"BR"Personal collector card\t"BR"Click to continue\n"\
        ""BR"#2\t"BR"Current order info\t"BR"Click to continue",
        "Continue", "Close"
    );
}

stock DistancePointToPoint(Float: x, Float: y, Float: z, Float: fx, Float:fy, Float: fz) return floatround(floatsqroot(floatpower(fx - x, 2) + floatpower(fy - y, 2) + floatpower(fz - z, 2)));


stock EndOrderCollector(playerid, partner = -1, bool:complete = true)
{
    if(player_collector[playerid][order_collector] != -1)
    {
        new order = player_collector[playerid][order_collector];

        if(!complete)
        {
            if(orders_collectors[order][collector_vehicle] != -1)
            {
                if(IsValidVehicle(orders_collectors[order][collector_vehicle]))
                DestroyVehicle(orders_collectors[order][collector_vehicle]);
            }
        }

        delete_order_collector(order);
    }
    if(player_collector[playerid][player_gang_zone_collector] != -1)
    {
        GangZoneHideForPlayer(playerid, player_collector[playerid][player_gang_zone_collector]);
        GangZoneDestroy(player_collector[playerid][player_gang_zone_collector]);
        player_collector[playerid][player_gang_zone_collector] = -1;
    }

    if(partner != -1)
    {
        if(player_collector[partner][player_gang_zone_collector] != -1)
        {
            GangZoneHideForPlayer(partner, player_collector[partner][player_gang_zone_collector]);
            GangZoneDestroy(player_collector[partner][player_gang_zone_collector]);
            player_collector[partner][player_gang_zone_collector] = -1;
        }
    }

    if(!complete)
    {
        player_collector[playerid][job_active]      = false;
        player_collector[playerid][player_partner]  = -1;
        SetPlayerSkinInit(playerid);

        if(partner != -1)
        {
            player_collector[partner][job_active]      = false;
            player_collector[partner][player_partner]  = -1;
            SetPlayerSkinInit(partner);
        }
    }

    player_collector[playerid][order_collector] = -1;
    if(player_collector[playerid][timer_c] != -1) KillTimer(player_collector[playerid][timer_c]);
    player_collector[playerid][timer_c]         = -1;
    player_collector[playerid][second_c]        = 0;

    if(partner != -1)
    {
        if(player_collector[playerid][timer_c] != -1) KillTimer(player_collector[playerid][timer_c]);
        player_collector[partner][order_collector] = -1;
        player_collector[partner][timer_c]         = -1;
        player_collector[partner][second_c]        = 0;
    }

    return 1;
}

public: GameTextCollector(playerid)
{
    if(player_collector[playerid][second_c] != 0)
    {
        player_collector[playerid][second_c]--;

        new text[56];

        format(text, sizeof text, "~y~%d", player_collector[playerid][second_c]);
        GameTextForPlayer(playerid, text, 900, 3);
    }
    else
    {
        SendClientMessage(playerid, -1, ""USC"You didn't get back into the vehicle in time. Order failed.");
        SendClientMessage(player_collector[playerid][player_partner], -1, ""USC"Partner didn't get back into the vehicle in time. Order failed.");
        KillTimer(player_collector[playerid][timer_c]);


        EndOrderCollector(playerid, player_collector[playerid][player_partner], false);
    }
}

public:UpdateOrderListCollector()
{
    new count;

    for(new i;i < MAX_ORDER_COL;i++)
    {
        if(!orders_collectors[i][order_type_active]) continue;

        count++;
    }

    if(count >= 10) return 1;
    else
    {
        for(new i;i < MAX_ORDER_COL;i++)
        {
            if(orders_collectors[i][order_type_active] != TYPE_O_C_NOACTIVE) continue;

            orders_collectors[i][order_type_active] = TYPE_O_C_ACTIVE;
            break;
        }

        foreach(new i : Player)
        {
            if(!IsPlayerConnected(i) || !IsPlayerLogged(i)) continue;
            if(!player_collector[i][job_active]) continue;

            SendClientMessage(i, -1, "{FAD201}| [Dispatcher]: A new order has been added to the order list: {FAD201}/blist");
        }
    }

    return 1;
}


stock load_order_colllector(id)
{
    new world_s = orders_collectors[id][place_start] - 1;
    new world_e = orders_collectors[id][place_end] - 1;

    if(orders_collectors[id][place_start] == Place_Col_1)
    {
        orders_collectors[id][order_sphere_start] = CreateDynamicSphere(orders_collectors[id][orders_start_point][0], orders_collectors[id][orders_start_point][1], orders_collectors[id][orders_start_point][2],
        2.0, 0, 0);

        orders_collectors[id][order_s_3dtext] = CreateDynamic3DTextLabel("{FAD201}ATM\n{FFFFFF}Approach to interact", -1, orders_collectors[id][orders_start_point][0], orders_collectors[id][orders_start_point][1], orders_collectors[id][orders_start_point][2],
        6.0);

    }
    else
    {
        orders_collectors[id][order_sphere_start] = CreateDynamicSphere(place_safe_bank[0], place_safe_bank[1], place_safe_bank[2], 2.0, world_s, 1);

        orders_collectors[id][order_s_3dtext] = CreateDynamic3DTextLabel("{FAD201}Valuable cargo\n{FFFFFF}Approach to interact", -1, place_safe_bank[0], place_safe_bank[1], place_safe_bank[2],
        6.0, _, _, _, world_s, 1);
    }

    if(orders_collectors[id][place_end] == Place_Col_1)
    {
        orders_collectors[id][order_sphere_end] = CreateDynamicSphere(orders_collectors[id][orders_end_point][0], orders_collectors[id][orders_end_point][1], orders_collectors[id][orders_end_point][2],
        2.0, 0, 0);

        orders_collectors[id][order_e_3dtext] = CreateDynamic3DTextLabel("{FAD201}ATM\n{FFFFFF}Approach to interact", -1, orders_collectors[id][orders_end_point][0], orders_collectors[id][orders_end_point][1], orders_collectors[id][orders_end_point][2],
        6.0);
    }
    else
    {
        orders_collectors[id][order_sphere_end] = CreateDynamicSphere(place_safe_bank[0], place_safe_bank[1], place_safe_bank[2], 2.0, world_e);

        orders_collectors[id][order_e_3dtext] = CreateDynamic3DTextLabel("{FAD201}Valuable cargo\n{FFFFFF}Approach to interact", -1, place_safe_bank[0], place_safe_bank[1], place_safe_bank[2],
        6.0, _, _, _, world_e, 1);
    }

    return 1;
}

stock delete_order_collector(id)
{
    orders_collectors[id][order_type_active]      = TYPE_O_C_NOACTIVE;
    orders_collectors[id][collector_id_driver]    = -1;
    orders_collectors[id][collector_id_collector] = -1;
    orders_collectors[id][progress_order]         = 0;
    orders_collectors[id][collector_vehicle]      = -1;

    if(IsValidDynamicArea(orders_collectors[id][order_sphere_start]) && IsValidDynamicArea(orders_collectors[id][order_sphere_end]))
    {
        DestroyDynamicArea(orders_collectors[id][order_sphere_start]);
        DestroyDynamicArea(orders_collectors[id][order_sphere_end]);

        orders_collectors[id][order_sphere_end]     = -1;
        orders_collectors[id][order_sphere_start]   = -1;
    }

    if(IsValidDynamic3DTextLabel(orders_collectors[id][order_s_3dtext])) DestroyDynamic3DTextLabel(orders_collectors[id][order_s_3dtext]);
    if(IsValidDynamic3DTextLabel(orders_collectors[id][order_e_3dtext])) DestroyDynamic3DTextLabel(orders_collectors[id][order_e_3dtext]);

    orders_collectors[id][order_s_3dtext] = Text3D:-1;
    orders_collectors[id][order_e_3dtext] = Text3D:-1;
}
stock CreateSmallGangZoneForCollector(playerid, Float:x, Float:y)
{
    // Delete old gangzone if exists
    if(player_collector[playerid][player_gang_zone_collector] != -1)
    {
        GangZoneHideForPlayer(playerid, player_collector[playerid][player_gang_zone_collector]);
        GangZoneDestroy(player_collector[playerid][player_gang_zone_collector]);
    }

    // Create small gangzone (size 50x50 meters - like a marker)
    new Float:size = 25.0; // marker radius (can be changed to 15.0 or 35.0)

    player_collector[playerid][player_gang_zone_collector] = GangZoneCreate(
        x - size, // minimum X
        y - size, // minimum Y
        x + size, // maximum X
        y + size  // maximum Y
    );

    // Show gangzone to player (yellow with transparency)
    GangZoneShowForPlayer(playerid, player_collector[playerid][player_gang_zone_collector], 0x00FFFFFF );
    GangZoneFlashForPlayer(playerid, player_collector[playerid][player_gang_zone_collector], 0xFF00EAFF); // Purple color for flashing
    //                                                                                       ^^^^^^^^^
    //                                                                                       Color: yellow semi-transparent

    return 1;
}
